#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
新闻价值衰减模型 (News Value Decay Model)

核心理念:
  新闻缓存不应按简单时间过期，而应基于:
  1. 交易时段 (盘前/盘中/盘后) - 决定新闻的"消化窗口"
  2. 信息质量评分 - 决定新闻的"保留优先级"
  3. 市场影响度 - 决定新闻的"衰减速度"

保留策略:
  - 盘前重要新闻 → 保留至开盘后 2 小时 (消化窗口)
  - 盘中突发新闻 → 保留至收盘后 1 小时
  - 盘后分析新闻 → 保留至次日开盘前
  - 低质量新闻 → 30 分钟后自动清理

作者: FTSeek Team
日期: 2026-04-17
"""

import json
import logging
import os
import time
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass, asdict

logger = logging.getLogger("news_value_decay")

# [NEW 2026-04-17] 导入 LLM 评分器和反馈学习器
try:
    from scripts.llm_news_scorer import LLMNewsScorer
    from scripts.news_feedback_learner import FeedbackLearner
    _HAS_LLM_SCORER = True
except ImportError:
    _HAS_LLM_SCORER = False
    logger.warning("LLM 评分器不可用，使用规则评分")


# ============================================================
# 港股交易时段配置 (HKT, UTC+8)
# ============================================================

HKG_TRADING_HOURS = {
    "pre_market": {"start": "09:00", "end": "09:30"},    # 盘前竞价
    "morning":    {"start": "09:30", "end": "12:00"},    # 上午交易
    "lunch":      {"start": "12:00", "end": "13:00"},    # 午间休市
    "afternoon":  {"start": "13:00", "end": "16:00"},    # 下午交易
    "post_market":{"start": "16:00", "end": "16:10"},    # 盘后竞价
}


# ============================================================
# 新闻质量评分模型
# ============================================================

@dataclass
class NewsQualityScore:
    """新闻质量评分"""
    total_score: float = 0.0      # 总分 0-100
    timeliness: float = 0.0       # 时效性 (0-25)
    impact: float = 0.0          # 市场影响度 (0-25)
    relevance: float = 0.0       # 与监控股票相关度 (0-25)
    source_credibility: float = 0.0  # 来源可信度 (0-15)
    uniqueness: float = 0.0      # 信息独特性 (0-10)
    
    @property
    def grade(self) -> str:
        """质量等级"""
        if self.total_score >= 80:
            return "S"    # 重大新闻
        elif self.total_score >= 65:
            return "A"    # 重要新闻
        elif self.total_score >= 50:
            return "B"    # 一般新闻
        elif self.total_score >= 35:
            return "C"    # 低价值
        else:
            return "D"    # 垃圾信息


class NewsQualityScorer:
    """新闻质量评分器"""
    
    # 关键词权重映射
    IMPACT_KEYWORDS = {
        # 高影响 (25 分)
        "高影响": {
            "keywords": ["财报", "业绩", "盈利", "亏损", "并购", "重组", "停牌", "复牌", 
                        "IPO", "上市", "退市", "监管", "处罚", "调查", "诉讼"],
            "score": 25,
        },
        # 中影响 (18 分)
        "中影响": {
            "keywords": ["利率", "加息", "降息", "CPI", "PPI", "非农", "GDP", "PMI",
                        "美联储", "央行", "政策", "关税", "制裁"],
            "score": 18,
        },
        # 低影响 (10 分)
        "低影响": {
            "keywords": ["分析", "评级", "目标价", "研报", "预测", "展望", "策略"],
            "score": 10,
        },
    }
    
    # 来源可信度映射
    SOURCE_CREDIBILITY = {
        "rsshub/富途快讯": 15,
        "rsshub/彭博市场": 15,
        "rsshub/金十数据": 13,
        "rsshub/华尔街见闻全球": 12,
        "rsshub/华尔街见闻中国": 11,
        "rsshub/财联社电报": 10,
        "futu_flash/富途快讯": 12,  # 降级数据源
    }
    
    def score(self, news_item: dict, watchlist: set = None) -> NewsQualityScore:
        """对新闻条目进行质量评分"""
        title = news_item.get("title", "")
        content = news_item.get("content", "")
        source = news_item.get("source", "")
        tags = news_item.get("tags", [])
        text = f"{title} {content}"
        
        score = NewsQualityScore()
        
        # 1. 时效性评分 (0-25)
        score.timeliness = self._score_timeliness(news_item)
        
        # 2. 市场影响度评分 (0-25)
        score.impact = self._score_impact(text)
        
        # 3. 相关度评分 (0-25)
        score.relevance = self._score_relevance(text, watchlist)
        
        # 4. 来源可信度 (0-15)
        score.source_credibility = self.SOURCE_CREDIBILITY.get(source, 8)
        
        # 5. 信息独特性 (0-10)
        score.uniqueness = self._score_uniqueness(news_item)
        
        # 总分
        score.total_score = (
            score.timeliness + 
            score.impact + 
            score.relevance + 
            score.source_credibility + 
            score.uniqueness
        )
        
        return score
    
    def _score_timeliness(self, news_item: dict) -> float:
        """时效性评分：越新的新闻分数越高"""
        published_at = news_item.get("published_at", "")
        if not published_at:
            return 10.0
        
        try:
            pub_time = datetime.fromisoformat(published_at.replace("Z", "+00:00"))
            now = datetime.now(pub_time.tzinfo) if pub_time.tzinfo else datetime.now()
            age_hours = (now - pub_time).total_seconds() / 3600
            
            if age_hours < 1:
                return 25.0
            elif age_hours < 3:
                return 20.0
            elif age_hours < 6:
                return 15.0
            elif age_hours < 12:
                return 10.0
            else:
                return 5.0
        except:
            return 10.0
    
    def _score_impact(self, text: str) -> float:
        """市场影响度评分"""
        for level, config in self.IMPACT_KEYWORDS.items():
            if any(kw in text for kw in config["keywords"]):
                return config["score"]
        return 8.0  # 默认低影响
    
    def _score_relevance(self, text: str, watchlist: set = None) -> float:
        """与监控股票相关度评分"""
        if not watchlist:
            return 12.0  # 无 watchlist 时给中等分数
        
        # 检查是否包含 watchlist 股票代码或名称
        for code in watchlist:
            if code.split(".")[-1] in text or code in text:
                return 25.0
        
        # 检查是否包含宏观指标
        macro_keywords = ["恒生指数", "恒生科技", "港股", "美联储", "纳指", "标普"]
        if any(kw in text for kw in macro_keywords):
            return 18.0
        
        return 10.0
    
    def _score_uniqueness(self, news_item: dict) -> float:
        """信息独特性评分"""
        content = news_item.get("content", "")
        title = news_item.get("title", "")
        
        # 内容越长、信息量越大，独特性越高
        content_len = len(content)
        if content_len > 300:
            return 10.0
        elif content_len > 150:
            return 8.0
        elif content_len > 50:
            return 6.0
        else:
            return 4.0


# ============================================================
# 交易时段感知器
# ============================================================

class TradingSessionAware:
    """交易时段感知器"""
    
    def get_current_session(self) -> str:
        """获取当前交易时段"""
        now = datetime.now()
        current_time = now.strftime("%H:%M")
        
        for session, hours in HKG_TRADING_HOURS.items():
            if hours["start"] <= current_time < hours["end"]:
                return session
        
        return "closed"  # 非交易时段
    
    def get_session_news_ttl(self, session: str, quality_grade: str) -> timedelta:
        """根据交易时段和新闻质量获取保留时长"""
        
        # TTL 矩阵 (小时)
        ttl_matrix = {
            "pre_market": {
                "S": timedelta(hours=4),   # 盘前重大新闻 → 保留至开盘后 2h
                "A": timedelta(hours=3),   # 盘前重要新闻 → 保留至开盘后 1h
                "B": timedelta(hours=2),   # 盘前一般新闻 → 保留至开盘
                "C": timedelta(minutes=30), # 低价值 → 30min
                "D": timedelta(minutes=15), # 垃圾 → 15min
            },
            "morning": {
                "S": timedelta(hours=3),   # 盘中重大新闻 → 保留至收盘后 1h
                "A": timedelta(hours=2),
                "B": timedelta(hours=1),
                "C": timedelta(minutes=30),
                "D": timedelta(minutes=15),
            },
            "lunch": {
                "S": timedelta(hours=4),   # 午间重大新闻 → 保留至下午收盘后
                "A": timedelta(hours=3),
                "B": timedelta(hours=2),
                "C": timedelta(minutes=30),
                "D": timedelta(minutes=15),
            },
            "afternoon": {
                "S": timedelta(hours=3),   # 盘中重大新闻 → 保留至收盘后 1h
                "A": timedelta(hours=2),
                "B": timedelta(hours=1),
                "C": timedelta(minutes=30),
                "D": timedelta(minutes=15),
            },
            "post_market": {
                "S": timedelta(hours=16),  # 盘后重大新闻 → 保留至次日开盘前
                "A": timedelta(hours=14),
                "B": timedelta(hours=12),
                "C": timedelta(hours=2),
                "D": timedelta(minutes=30),
            },
            "closed": {
                "S": timedelta(hours=16),  # 非交易时段重大新闻 → 保留至次日开盘前
                "A": timedelta(hours=14),
                "B": timedelta(hours=12),
                "C": timedelta(hours=2),
                "D": timedelta(minutes=30),
            },
        }
        
        return ttl_matrix.get(session, ttl_matrix["closed"]).get(quality_grade, timedelta(hours=1))
    
    def is_digest_window(self, news_item: dict) -> bool:
        """判断新闻是否处于消化窗口期"""
        published_at = news_item.get("published_at", "")
        if not published_at:
            return False
        
        try:
            pub_time = datetime.fromisoformat(published_at.replace("Z", "+00:00"))
            now = datetime.now(pub_time.tzinfo) if pub_time.tzinfo else datetime.now()
            age_hours = (now - pub_time).total_seconds() / 3600
            
            # 开盘后 2 小时内为消化窗口
            current_session = self.get_current_session()
            if current_session in ["morning", "afternoon"]:
                return age_hours < 2
            
            return False
        except:
            return False


# ============================================================
# 智能缓存管理器
# ============================================================

class SmartNewsCacheManager:
    """智能新闻缓存管理器"""
    
    def __init__(self, cache_dir: str = "/opt/ftseek/FTSeek/data/rsshub_multi_source"):
        self.cache_dir = Path(cache_dir)
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        
        self.scorer = NewsQualityScorer()
        self.session_aware = TradingSessionAware()
        
        # [NEW 2026-04-17] LLM 评分器
        self.llm_scorer = None
        self.feedback_learner = None
        if _HAS_LLM_SCORER:
            try:
                self.llm_scorer = LLMNewsScorer(str(Path(cache_dir).parent))
                self.feedback_learner = FeedbackLearner()
                logger.info("LLM 评分器已启用")
            except Exception as e:
                logger.warning(f"LLM 评分器初始化失败: {e}")
        
        self.metadata_file = self.cache_dir / "cache_metadata.json"
        self.metadata = self._load_metadata()
    
    def _load_metadata(self) -> dict:
        """加载缓存元数据"""
        if self.metadata_file.exists():
            try:
                with open(self.metadata_file, 'r') as f:
                    return json.load(f)
            except:
                pass
        return {
            "news_items": {},  # news_id -> metadata
            "last_cleanup": None,
        }
    
    def _save_metadata(self):
        """保存缓存元数据"""
        try:
            with open(self.metadata_file, 'w') as f:
                json.dump(self.metadata, f, indent=2, ensure_ascii=False)
        except Exception as e:
            logger.warning(f"保存缓存元数据失败: {e}")
    
    def score_and_tag_news(self, news_list: list, watchlist: set = None) -> list:
        """对新闻列表进行评分并添加质量标签 - 2026-04-17 升级为 LLM 辅助评分"""
        scored_news = []
        
        # [NEW 2026-04-17] 如果有 LLM 评分器，先进行 LLM 批量评分
        if self.llm_scorer:
            try:
                # 批量评分 (默认前 10 条，控制 API 调用量)
                news_list = self.llm_scorer.batch_score(news_list, watchlist, max_batch=10)
                logger.info(f"LLM 批量评分完成: {min(len(news_list), 10)} 条")
            except Exception as e:
                logger.warning(f"LLM 批量评分失败: {e}")
        
        for news in news_list:
            quality = self.scorer.score(news, watchlist)
            
            # 添加质量信息到新闻条目
            news["_quality"] = {
                "score": quality.total_score,
                "grade": quality.grade,
                "timeliness": quality.timeliness,
                "impact": quality.impact,
                "relevance": quality.relevance,
                "source_credibility": quality.source_credibility,
                "uniqueness": quality.uniqueness,
            }
            
            # [NEW 2026-04-17] 如果有 LLM 评分结果，合并到 _quality
            if "_llm_score" in news:
                llm_result = news.pop("_llm_score")
                news["_quality"]["llm_score"] = llm_result.get("total_score", 0)
                
                # 混合评分：规则 40% + LLM 60%
                rule_score = quality.total_score
                llm_score = llm_result.get("total_score", 0)
                combined_score = rule_score * 0.4 + llm_score * 0.6
                
                news["_quality"]["score"] = combined_score
                news["_quality"]["rule_score"] = rule_score
                
                # 根据混合分数更新等级
                if combined_score >= 80:
                    news["_quality"]["grade"] = "S"
                elif combined_score >= 65:
                    news["_quality"]["grade"] = "A"
                elif combined_score >= 50:
                    news["_quality"]["grade"] = "B"
                elif combined_score >= 35:
                    news["_quality"]["grade"] = "C"
                else:
                    news["_quality"]["grade"] = "D"
            
            # 计算过期时间
            session = self.session_aware.get_current_session()
            ttl = self.session_aware.get_session_news_ttl(session, news["_quality"]["grade"])
            expires_at = (datetime.now() + ttl).isoformat()
            
            news["_expires_at"] = expires_at
            news["_session"] = session
            
            scored_news.append(news)
            
            # 更新元数据
            news_id = news.get("id", "")
            if news_id:
                self.metadata["news_items"][news_id] = {
                    "grade": news["_quality"]["grade"],
                    "score": news["_quality"]["score"],
                    "session": session,
                    "expires_at": expires_at,
                    "created_at": datetime.now().isoformat(),
                    "has_llm_score": "_llm_score" in news if "_llm_score" in news else False,
                }
        
        # 保存元数据
        self._save_metadata()
        
        return scored_news
    
    def cleanup_expired(self, news_list: list) -> tuple:
        """清理过期新闻，返回 (保留列表，清理数量)"""
        now = datetime.now()
        kept = []
        removed = 0
        
        for news in news_list:
            expires_at = news.get("_expires_at", "")
            if not expires_at:
                # 无过期时间的新闻保留
                kept.append(news)
                continue
            
            try:
                expire_time = datetime.fromisoformat(expires_at)
                if now < expire_time:
                    kept.append(news)
                else:
                    removed += 1
                    # 从元数据中移除
                    news_id = news.get("id", "")
                    if news_id in self.metadata["news_items"]:
                        del self.metadata["news_items"][news_id]
            except:
                kept.append(news)
        
        # 保存更新后的元数据
        self._save_metadata()
        
        return kept, removed
    
    def get_priority_sorted(self, news_list: list) -> list:
        """按优先级排序新闻列表"""
        def sort_key(news):
            quality = news.get("_quality", {})
            score = quality.get("score", 0)
            grade = quality.get("grade", "D")
            
            # 等级权重
            grade_weights = {"S": 1000, "A": 800, "B": 600, "C": 400, "D": 200}
            grade_weight = grade_weights.get(grade, 0)
            
            # 时间衰减
            published_at = news.get("published_at", "")
            time_decay = 1.0
            if published_at:
                try:
                    pub_time = datetime.fromisoformat(published_at.replace("Z", "+00:00"))
                    now = datetime.now(pub_time.tzinfo) if pub_time.tzinfo else datetime.now()
                    age_hours = (now - pub_time).total_seconds() / 3600
                    time_decay = max(0.1, 1.0 - (age_hours / 24))
                except:
                    pass
            
            return (grade_weight + score) * time_decay
        
        return sorted(news_list, key=sort_key, reverse=True)
    
    def get_cache_stats(self, news_list: list) -> dict:
        """获取缓存统计信息"""
        stats = {
            "total": len(news_list),
            "by_grade": {"S": 0, "A": 0, "B": 0, "C": 0, "D": 0},
            "by_session": {},
            "avg_score": 0,
            "digest_window_count": 0,
            "llm_scored_count": 0,  # [NEW 2026-04-17]
            "avg_llm_score": 0,     # [NEW 2026-04-17]
        }
        
        total_score = 0
        total_llm_score = 0
        for news in news_list:
            quality = news.get("_quality", {})
            grade = quality.get("grade", "D")
            score = quality.get("score", 0)
            session = news.get("_session", "unknown")
            
            stats["by_grade"][grade] = stats["by_grade"].get(grade, 0) + 1
            stats["by_session"][session] = stats["by_session"].get(session, 0) + 1
            total_score += score
            
            # [NEW 2026-04-17] 统计 LLM 评分
            if quality.get("llm_score"):
                stats["llm_scored_count"] += 1
                total_llm_score += quality["llm_score"]
            
            if self.session_aware.is_digest_window(news):
                stats["digest_window_count"] += 1
        
        stats["avg_score"] = total_score / len(news_list) if news_list else 0
        stats["avg_llm_score"] = total_llm_score / max(1, stats["llm_scored_count"])
        
        return stats


# ============================================================
# 使用示例
# ============================================================

if __name__ == "__main__":
    # 测试示例
    cache_manager = SmartNewsCacheManager()
    
    # 模拟新闻数据
    test_news = [
        {
            "id": "test1",
            "title": "腾讯控股发布 Q2 财报，净利润同比增长 50%",
            "content": "腾讯今日发布第二季度财报，显示净利润大幅增长...",
            "source": "rsshub/富途快讯",
            "published_at": datetime.now().isoformat(),
            "tags": ["rsshub", "HK"],
        },
        {
            "id": "test2",
            "title": "美联储宣布维持利率不变",
            "content": "美联储今日宣布维持联邦基金利率不变，符合市场预期...",
            "source": "rsshub/彭博市场",
            "published_at": datetime.now().isoformat(),
            "tags": ["rsshub", "US"],
        },
    ]
    
    watchlist = {"HK.00700", "HK.09988", "US.AAPL"}
    
    # 评分
    scored = cache_manager.score_and_tag_news(test_news, watchlist)
    
    # 排序
    sorted_news = cache_manager.get_priority_sorted(scored)
    
    # 统计
    stats = cache_manager.get_cache_stats(sorted_news)
    
    print("=== 新闻质量评分 ===")
    for news in sorted_news:
        q = news["_quality"]
        print(f"[{q['grade']}] {news['title'][:30]}... (score={q['score']:.1f})")
        print(f"  时效性: {q['timeliness']:.1f} | 影响度: {q['impact']:.1f} | 相关度: {q['relevance']:.1f}")
        print(f"  来源可信度: {q['source_credibility']:.1f} | 独特性: {q['uniqueness']:.1f}")
        print(f"  过期时间: {news['_expires_at']}")
        print()
    
    print("=== 缓存统计 ===")
    print(f"总数: {stats['total']}")
    print(f"平均分数: {stats['avg_score']:.1f}")
    print(f"消化窗口内: {stats['digest_window_count']}")
    print(f"按等级: {stats['by_grade']}")
    print(f"按时段: {stats['by_session']}")
