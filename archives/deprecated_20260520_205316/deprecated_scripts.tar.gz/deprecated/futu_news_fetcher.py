#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
富途快讯采集器 - 集成到 FTSeek 新闻监控系统

功能:
1. 多方式采集富途 7×24 快讯
2. 情感分析集成
3. 标准化数据结构
4. 缓存与限流控制

采集方式:
- 方式1: requests + HTML解析 (简单页面)
- 方式2: playwright (动态渲染页面)
- 方式3: 富途APP抓包API (需认证)

作者: FTSeek Team
日期: 2026-04-12
"""

import asyncio
import hashlib
import json
import logging
import os
import re
import time
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from typing import Dict, List, Optional, Tuple

import aiohttp
import requests

# 配置日志
logger = logging.getLogger('futu_news_fetcher')

# ============================================================
# 数据结构定义
# ============================================================

class FutuNewsType(Enum):
    """富途新闻类型"""
    FLASH = "flash"       # 快讯
    NEWS = "news"         # 新闻
    REPORT = "report"     # 研报
    NOTICE = "notice"     # 公告


@dataclass
class FutuNewsItem:
    """富途新闻数据结构"""
    id: str
    title: str
    content: str
    source: str = "futu"  # 富途来源
    news_type: FutuNewsType = FutuNewsType.FLASH
    publish_time: datetime = None
    stocks: List[str] = field(default_factory=list)  # 相关股票
    sentiment: str = "neutral"
    sentiment_score: float = 0.0
    importance: str = "normal"
    url: str = ""
    raw_data: dict = field(default_factory=dict)
    
    def to_dict(self) -> dict:
        """转换为字典"""
        return {
            'id': self.id,
            'title': self.title,
            'content': self.content,
            'source': self.source,
            'news_type': self.news_type.value,
            'publish_time': self.publish_time.isoformat() if self.publish_time else None,
            'stocks': self.stocks,
            'sentiment': self.sentiment,
            'sentiment_score': self.sentiment_score,
            'importance': self.importance,
            'url': self.url,
        }


# ============================================================
# 富途快讯采集器
# ============================================================

class FutuNewsFetcher:
    """
    富途快讯采集器
    
    采集方式:
    1. HTML解析方式 (推荐) - 解析富途新闻页面
    2. API方式 (需抓包获取真实端点)
    3. Playwright方式 (动态页面)
    """
    
    # 富途新闻页面 URL
    NEWS_URLS = {
        'flash': 'https://news.futunn.com/main/live?lang=zh-cn',  # 7×24快讯
        'news': 'https://news.futunn.com/main?lang=zh-cn',        # 焦点新闻
        'hot': 'https://news.futunn.com/main/topic?lang=zh-cn',   # 热门专题
    }
    
    # 重要新闻关键词
    MAJOR_KEYWORDS = [
        '财报', '业绩', '盈利', '亏损', '并购', '收购',
        '监管', '处罚', '诉讼', '调查',
        '合同', '订单', '突破', '创新',
        '上市', 'IPO', '退市', '停牌',
    ]
    
    # 负面关键词
    NEGATIVE_KEYWORDS = [
        '亏损', '下滑', '下跌', '暴跌', '处罚',
        '诉讼', '调查', '违规', '裁员', '破产',
    ]
    
    # 正面关键词
    POSITIVE_KEYWORDS = [
        '盈利', '增长', '上涨', '突破', '新高',
        '订单', '合同', '创新', '分红', '增持',
    ]
    
    def __init__(self, use_playwright: bool = False):
        """
        初始化
        
        Args:
            use_playwright: 是否使用 playwright 动态抓取
        """
        self.use_playwright = use_playwright
        self.session: Optional[aiohttp.ClientSession] = None
        
        # 缓存
        self.cache: Dict[str, List[FutuNewsItem]] = {}
        self.cache_time: Dict[str, datetime] = {}
        self.cache_ttl = timedelta(minutes=3)
        
        # 统计
        self.stats = {
            'total_fetches': 0,
            'successful_fetches': 0,
            'failed_fetches': 0,
            'last_fetch_time': None,
            'avg_latency_ms': 0,
        }
        
        logger.info("FutuNewsFetcher initialized")
    
    async def _ensure_session(self):
        """确保 HTTP 会话存在"""
        if self.session is None or self.session.closed:
            timeout = aiohttp.ClientTimeout(total=15)
            self.session = aiohttp.ClientSession(
                timeout=timeout,
                headers={
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                    'Accept-Language': 'zh-CN,zh;q=0.9',
                }
            )
    
    async def close(self):
        """关闭资源"""
        if self.session and not self.session.closed:
            await self.session.close()
    
    def _generate_id(self, title: str, time_str: str) -> str:
        """生成新闻 ID"""
        content = f"{title}:{time_str}"
        return hashlib.md5(content.encode('utf-8')).hexdigest()[:16]
    
    def _parse_time(self, time_str: str) -> datetime:
        """解析时间字符串"""
        try:
            # 尝试多种格式
            formats = [
                '%Y-%m-%d %H:%M:%S',
                '%Y/%m/%d %H:%M',
                '%m/%d %H:%M',  # 如 "04/11 14:57"
                '%H:%M',        # 如 "10:31"
            ]
            
            for fmt in formats:
                try:
                    dt = datetime.strptime(time_str.strip(), fmt)
                    # 如果只有时间，补上今天的日期
                    if dt.year == 1900:
                        dt = dt.replace(year=datetime.now().year, month=datetime.now().month, day=datetime.now().day)
                    return dt
                except Exception as e:
                    continue
            
            # 默认返回当前时间
            return datetime.now()
        except Exception as e:
            return datetime.now()
    
    def _classify_importance(self, title: str, content: str) -> str:
        """分类重要性"""
        text = f"{title} {content}".lower()
        
        major_count = sum(1 for kw in self.MAJOR_KEYWORDS if kw in text)
        
        if major_count >= 2:
            return "major"
        elif major_count == 1:
            return "normal"
        else:
            return "minor"
    
    def _analyze_sentiment(self, title: str, content: str) -> Tuple[str, float]:
        """分析情感"""
        text = f"{title} {content}"
        
        positive_count = sum(1 for kw in self.POSITIVE_KEYWORDS if kw in text)
        negative_count = sum(1 for kw in self.NEGATIVE_KEYWORDS if kw in text)
        
        total = positive_count + negative_count
        if total == 0:
            return "neutral", 0.0
        
        score = (positive_count - negative_count) / total
        
        if score > 0.2:
            return "positive", score
        elif score < -0.2:
            return "negative", score
        else:
            return "neutral", score
    
    def _extract_stocks(self, text: str) -> List[str]:
        """提取股票代码"""
        stocks = []
        
        # 港股代码模式
        hk_pattern = r'HK\.?\d{5}|0\d{4}\.HK'
        hk_matches = re.findall(hk_pattern, text)
        for m in hk_matches:
            code = m.replace('.HK', '').replace('HK.', '')
            stocks.append(f"HK.{code}")
        
        # 美股代码模式 (大写字母)
        us_pattern = r'\b[A-Z]{2,5}\b'
        us_matches = re.findall(us_pattern, text)
        known_us_stocks = ['AAPL', 'NVDA', 'TSLA', 'MSFT', 'GOOGL', 'AMZN', 'META', 'AMD', 'INTC']
        for m in us_matches:
            if m in known_us_stocks:
                stocks.append(f"US.{m}")
        
        # 常见股票名称映射
        stock_names = {
            '腾讯': 'HK.00700',
            '阿里巴巴': 'HK.09988',
            '美团': 'HK.03690',
            '小米': 'HK.01810',
            '拼多多': 'US.PDD',
            '特斯拉': 'US.TSLA',
            '苹果': 'US.AAPL',
            '英伟达': 'US.NVDA',
            '中芯国际': 'HK.00981',
            '泡泡玛特': 'HK.09992',
        }
        
        for name, code in stock_names.items():
            if name in text:
                stocks.append(code)
        
        return list(set(stocks))
    
    async def fetch_flash_html(self) -> List[FutuNewsItem]:
        """
        方式1: HTML解析方式获取快讯
        
        解析富途快讯页面的 HTML 结构
        """
        news_list = []
        url = self.NEWS_URLS['flash']
        
        try:
            await self._ensure_session()
            
            async with self.session.get(url) as response:
                if response.status == 200:
                    html = await response.text()
                    
                    # 解析 HTML 提取快讯
                    # 富途快讯页面结构分析后确定解析规则
                    
                    # 模式1: 查找新闻列表项
                    # 根据实际页面结构调整
                    
                    # 尝试提取 a 标签中的新闻
                    pattern = r'<a[^>]*href="/post/(\d+)[^"]*"[^>]*>(.*?)</a>'
                    matches = re.findall(pattern, html, re.DOTALL)
                    
                    for post_id, content in matches[:20]:
                        # 清理 HTML 标签
                        title = re.sub(r'<[^>]+>', '', content).strip()
                        if title and len(title) > 10:
                            news = FutuNewsItem(
                                id=f"futu-{post_id}",
                                title=title[:100],
                                content=title,
                                news_type=FutuNewsType.FLASH,
                                publish_time=datetime.now(),
                                url=f"https://news.futunn.com/post/{post_id}",
                            )
                            news_list.append(news)
                    
                    # 如果上面没找到，尝试其他模式
                    if not news_list:
                        # 模式2: 查找快讯 div
                        pattern = r'<div[^>]*class="[^"]*news-item[^"]*"[^>]*>(.*?)</div>'
                        matches = re.findall(pattern, html, re.DOTALL)
                        
                        for content in matches[:20]:
                            title = re.sub(r'<[^>]+>', '', content).strip()
                            if title and len(title) > 10:
                                news = FutuNewsItem(
                                    id=self._generate_id(title, datetime.now().isoformat()),
                                    title=title[:100],
                                    content=title,
                                    news_type=FutuNewsType.FLASH,
                                    publish_time=datetime.now(),
                                )
                                news_list.append(news)
                    
                    logger.info(f"Fetched {len(news_list)} flash news from HTML")
                    
                else:
                    raise Exception(f"HTTP {response.status}")
                    
        except Exception as e:
            logger.warning(f"HTML fetch failed: {e}")
        
        return news_list
    
    async def fetch_with_playwright(self) -> List[FutuNewsItem]:
        """
        方式2: Playwright 动态抓取
        
        需要 playwright 库
        """
        news_list = []
        
        try:
            # 尝试导入 playwright
            from playwright.async_api import async_playwright
            
            async with async_playwright() as p:
                browser = await p.chromium.launch(headless=True)
                page = await browser.new_page()
                
                # 设置语言
                await page.set_extra_http_headers({'Accept-Language': 'zh-CN,zh'})
                
                # 访问快讯页面
                url = self.NEWS_URLS['flash']
                await page.goto(url, wait_until='networkidle')
                
                # 等待内容加载
                await page.wait_for_timeout(3000)
                
                # 提取新闻元素
                # 根据富途页面结构调整选择器
                news_elements = await page.query_selector_all('a[href^="/post/"]')
                
                for element in news_elements[:20]:
                    try:
                        href = await element.get_attribute('href')
                        text = await element.inner_text()
                        
                        if text and len(text) > 10:
                            post_id = href.split('/post/')[-1].split('/')[0]
                            
                            news = FutuNewsItem(
                                id=f"futu-{post_id}",
                                title=text.strip()[:100],
                                content=text.strip(),
                                news_type=FutuNewsType.FLASH,
                                publish_time=datetime.now(),
                                url=f"https://news.futunn.com{href}",
                            )
                            news_list.append(news)
                            
                    except Exception as e:
                        logger.debug(f"Element extraction failed: {e}")
                
                await browser.close()
                
                logger.info(f"Fetched {len(news_list)} flash news with Playwright")
                
        except ImportError:
            logger.warning("Playwright not installed, skipping dynamic fetch")
            # 回退到 HTML 解析
            news_list = await self.fetch_flash_html()
            
        except Exception as e:
            logger.warning(f"Playwright fetch failed: {e}")
            # 回退到 HTML 解析
            news_list = await self.fetch_flash_html()
        
        return news_list
    
    async def fetch_news(self, stock: Optional[str] = None) -> List[FutuNewsItem]:
        """
        获取富途快讯
        
        Args:
            stock: 可选的股票代码过滤
            
        Returns:
            List[FutuNewsItem]: 新闻列表
        """
        start_time = time.time()
        self.stats['total_fetches'] += 1
        
        # 检查缓存
        cache_key = stock or 'all'
        if cache_key in self.cache:
            cache_time = self.cache_time.get(cache_key)
            if cache_time and datetime.now() - cache_time < self.cache_ttl:
                logger.debug(f"Using cached news for {cache_key}")
                return self.cache[cache_key]
        
        # 选择抓取方式
        if self.use_playwright:
            news_list = await self.fetch_with_playwright()
        else:
            news_list = await self.fetch_flash_html()
        
        # 处理新闻
        for news in news_list:
            # 分类重要性
            news.importance = self._classify_importance(news.title, news.content)
            
            # 情感分析
            sentiment, score = self._analyze_sentiment(news.title, news.content)
            news.sentiment = sentiment
            news.sentiment_score = score
            
            # 提取股票
            news.stocks = self._extract_stocks(f"{news.title} {news.content}")
        
        # 按股票过滤
        if stock:
            news_list = [n for n in news_list if stock in n.stocks or not n.stocks]
        
        # 按时间排序
        news_list.sort(key=lambda x: x.publish_time or datetime.now(), reverse=True)
        
        # 去重
        seen_ids = set()
        unique_news = []
        for news in news_list:
            if news.id not in seen_ids:
                seen_ids.add(news.id)
                unique_news.append(news)
        news_list = unique_news[:30]
        
        # 更新缓存
        self.cache[cache_key] = news_list
        self.cache_time[cache_key] = datetime.now()
        
        # 更新统计
        latency_ms = int((time.time() - start_time) * 1000)
        self.stats['successful_fetches'] += 1
        self.stats['last_fetch_time'] = datetime.now()
        
        n = self.stats['successful_fetches']
        self.stats['avg_latency_ms'] = (self.stats['avg_latency_ms'] * (n-1) + latency_ms) / n
        
        logger.info(f"Fetched {len(news_list)} news in {latency_ms}ms")
        
        return news_list
    
    def get_stats(self) -> dict:
        """获取统计信息"""
        return {
            **self.stats,
            'cache_size': len(self.cache),
            'use_playwright': self.use_playwright,
        }


# ============================================================
# 集成到 FTSeek 新闻监控系统
# ============================================================

async def fetch_futu_news_as_source(stock: Optional[str] = None, use_playwright: bool = False) -> List[dict]:
    """
    作为新闻源集成
    
    Args:
        stock: 股票代码过滤
        use_playwright: 是否使用 playwright
        
    Returns:
        List[dict]: 标准化的新闻列表
    """
    fetcher = FutuNewsFetcher(use_playwright=use_playwright)
    
    try:
        news_list = await fetcher.fetch_news(stock)
        return [n.to_dict() for n in news_list]
    finally:
        await fetcher.close()


def integrate_to_news_monitor():
    """
    集成说明
    
    在 modules/news_monitor.py 中添加富途新闻源:
    
    1. 在 NewsSource 枚举中添加:
        FUTU = "futu"  # 富途快讯
        
    2. 在 NewsMonitor 类中添加方法:
        async def _fetch_futu_news(self, stock: str) -> List[NewsItem]:
            from scripts.futu_news_fetcher import fetch_futu_news_as_source
            futu_news = await fetch_futu_news_as_source(stock)
            return [NewsItem(**n) for n in futu_news]
            
    3. 在 fetch_news() 方法中添加富途源调用:
        tasks_map[NewsSource.FUTU] = asyncio.create_task(self._fetch_futu_news(stock))
    """
    return integrate_to_news_monitor.__doc__


# ============================================================
# 测试与演示
# ============================================================

async def test_futu_fetcher():
    """测试富途快讯采集器"""
    print("=" * 70)
    print("🔍 富途快讯采集器测试")
    print("=" * 70)
    
    fetcher = FutuNewsFetcher(use_playwright=False)
    
    print("\n【Step 1】获取快讯列表:")
    news_list = await fetcher.fetch_news()
    
    print(f"  采集数量: {len(news_list)} 条")
    
    if news_list:
        print("\n【Step 2】快讯内容示例:")
        for i, news in enumerate(news_list[:5], 1):
            print(f"\n  [{i}] {news.title[:60]}...")
            print(f"      类型: {news.news_type.value}")
            print(f"      重要性: {news.importance}")
            print(f"      情感: {news.sentiment} ({news.sentiment_score:.2f})")
            print(f"      相关股票: {news.stocks}")
            print(f"      URL: {news.url}")
    
    print("\n【Step 3】统计信息:")
    stats = fetcher.get_stats()
    for k, v in stats.items():
        print(f"  {k}: {v}")
    
    await fetcher.close()
    
    print("\n" + "-" * 70)
    print("✅ 测试完成")
    print("-" * 70)


if __name__ == "__main__":
    asyncio.run(test_futu_fetcher())