#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
LLM 新闻评分器 (LLM News Scorer)

使用 LLM 对新闻进行二阶推理评估:
1. 市场影响度评分 (0-25) - 直接影响
2. 二阶影响评估 (0-25) - 间接影响、产业链传导
3. 交易可操作性 (0-25) - 是否具备明确交易信号
4. 时间敏感性 (0-25) - 信息窗口期判断

作者: FTSeek Team
日期: 2026-04-17
"""

import json
import logging
import os
import time
from datetime import datetime
from typing import Dict, List, Optional, Tuple
from pathlib import Path

logger = logging.getLogger("llm_news_scorer")

# [NEW 2026-04-17] 加载 .env 文件
try:
    from dotenv import load_dotenv
    load_dotenv("/opt/ftseek/FTSeek/.env")
except ImportError:
    pass


# ============================================================
# LLM 配置
# ============================================================

LLM_CONFIG = {
    "model": "qwen-plus",  # 使用阿里云 Qwen
    "temperature": 0.1,    # 低温度保证评分稳定性
    "max_tokens": 500,
    "timeout": 30,
}


# ============================================================
# LLM 评分 Prompt 模板
# ============================================================

NEWS_SCORING_PROMPT = """你是一个专业的量化交易新闻分析师。请对以下新闻进行多维度评分。

【新闻信息】
标题: {title}
内容: {content}
来源: {source}
发布时间: {published_at}
相关股票: {watchlist_codes}

【评分维度】
请从以下 4 个维度进行评分 (每个维度 0-25 分):

1. 市场影响度 (0-25):
   - 25 分: 直接影响多个 watchlist 股票，可能引发显著价格波动
   - 20 分: 直接影响 1-2 个 watchlist 股票
   - 15 分: 间接影响 watchlist 股票，或通过产业链传导
   - 10 分: 影响整个行业/板块
   - 5 分: 影响较小，市场关注度低
   - 0 分: 与 watchlist 股票完全无关

2. 二阶影响评估 (0-25):
   - 25 分: 有明显的二阶效应 (如：地缘事件→油价→能源股→化工股)
   - 20 分: 有清晰的产业链传导路径
   - 15 分: 可能引发市场情绪变化
   - 10 分: 影响范围有限，传导路径不清晰
   - 5 分: 几乎无二阶影响
   - 0 分: 孤立事件，无连锁反应

3. 交易可操作性 (0-25):
   - 25 分: 提供明确的交易信号 (方向、时机、标的清晰)
   - 20 分: 有明确的交易方向，但时机不确定
   - 15 分: 有交易机会，但需要进一步分析
   - 10 分: 信息模糊，交易信号不明确
   - 5 分: 难以转化为交易策略
   - 0 分: 无交易价值

4. 时间敏感性 (0-25):
   - 25 分: 信息窗口极短 (<1 小时)，需要立即反应
   - 20 分: 信息窗口短 (1-3 小时)
   - 15 分: 信息窗口中等 (3-6 小时)
   - 10 分: 信息窗口较长 (6-12 小时)
   - 5 分: 信息窗口很长 (>12 小时)
   - 0 分: 信息已过时，无时效性

【输出格式】
请严格按照以下 JSON 格式输出，不要添加任何额外内容:

```json
{{
  "market_impact": {{
    "score": 0-25,
    "reason": "简短说明评分理由"
  }},
  "second_order_impact": {{
    "score": 0-25,
    "reason": "说明二阶影响路径",
    "chain": ["事件 A → 事件 B → 事件 C"]
  }},
  "trade_actionability": {{
    "score": 0-25,
    "reason": "说明交易可操作性",
    "signals": ["可能的交易信号"]
  }},
  "time_sensitivity": {{
    "score": 0-25,
    "reason": "说明时间敏感性",
    "window_hours": 预估信息窗口小时数
  }},
  "total_score": 0-100,
  "grade": "S/A/B/C/D",
  "summary": "一句话总结新闻价值"
}}
```

【评分标准】
- S 级 (≥80): 重大新闻，直接影响 watchlist，有明确交易信号
- A 级 (65-79): 重要新闻，有显著影响，交易机会明确
- B 级 (50-64): 一般新闻，有潜在影响，需要进一步分析
- C 级 (35-49): 低价值新闻，影响有限
- D 级 (<35): 垃圾信息，无交易价值
"""


# ============================================================
# LLM 评分器
# ============================================================

class LLMNewsScorer:
    """LLM 新闻评分器"""
    
    def __init__(self, cache_dir: str = "/opt/ftseek/FTSeek/data"):
        self.cache_dir = Path(cache_dir) / "llm_scores"
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        
        self.score_cache_file = self.cache_dir / "score_cache.json"
        self.score_cache = self._load_cache()
        
        # 检查 API Key 是否配置
        api_key = os.getenv("DASHSCOPE_API_KEY") or os.getenv("OPENAI_API_KEY")
        self.is_enabled = bool(api_key)
        
        if not self.is_enabled:
            logger.info("LLM 评分器已禁用 (未配置 DASHSCOPE_API_KEY 或 OPENAI_API_KEY)")
        
        # 统计
        self.stats = {
            "total_scored": 0,
            "cache_hits": 0,
            "cache_misses": 0,
            "llm_errors": 0,
            "avg_score": 0,
            "last_scored_at": None,
        }
        self._load_stats()
    
    def _load_cache(self) -> dict:
        """加载评分缓存"""
        if self.score_cache_file.exists():
            try:
                with open(self.score_cache_file, 'r') as f:
                    return json.load(f)
            except:
                pass
        return {}
    
    def _save_cache(self):
        """保存评分缓存"""
        try:
            with open(self.score_cache_file, 'w') as f:
                json.dump(self.score_cache, f, indent=2, ensure_ascii=False)
        except Exception as e:
            logger.warning(f"保存 LLM 评分缓存失败: {e}")
    
    def _load_stats(self):
        """加载统计信息"""
        stats_file = self.cache_dir / "scorer_stats.json"
        if stats_file.exists():
            try:
                with open(stats_file, 'r') as f:
                    self.stats.update(json.load(f))
            except:
                pass
    
    def _save_stats(self):
        """保存统计信息"""
        stats_file = self.cache_dir / "scorer_stats.json"
        try:
            with open(stats_file, 'w') as f:
                json.dump(self.stats, f, indent=2, ensure_ascii=False)
        except Exception as e:
            logger.warning(f"保存 LLM 评分统计失败: {e}")
    
    def score_news(self, news_item: dict, watchlist: set = None, use_cache: bool = True) -> dict:
        """对新闻进行 LLM 评分"""
        # 如果 LLM 评分器未启用，直接返回降级评分
        if not self.is_enabled:
            return self._fallback_score(news_item)
        
        news_id = news_item.get("id", "")
        title = news_item.get("title", "")
        content = news_item.get("content", "")
        
        # 检查缓存
        if use_cache and news_id and news_id in self.score_cache:
            cached = self.score_cache[news_id]
            # 检查缓存是否过期 (2 小时)
            if time.time() - cached.get("timestamp", 0) < 7200:
                self.stats["cache_hits"] += 1
                self._save_stats()
                return cached["result"]
        
        self.stats["cache_misses"] += 1
        
        # 调用 LLM 评分
        try:
            result = self._call_llm_scoring(news_item, watchlist)
            
            # 缓存结果
            if news_id:
                self.score_cache[news_id] = {
                    "result": result,
                    "timestamp": time.time(),
                }
                self._save_cache()
            
            self.stats["total_scored"] += 1
            self.stats["avg_score"] = (
                (self.stats["avg_score"] * (self.stats["total_scored"] - 1) + result["total_score"])
                / self.stats["total_scored"]
            )
            self.stats["last_scored_at"] = datetime.now().isoformat()
            self._save_stats()
            
            return result
            
        except Exception as e:
            logger.error(f"LLM 评分失败: {e}")
            self.stats["llm_errors"] += 1
            self._save_stats()
            
            # 降级: 返回默认评分
            return self._fallback_score(news_item)
    
    def _call_llm_scoring(self, news_item: dict, watchlist: set = None) -> dict:
        """调用 LLM 进行评分"""
        # 构建 prompt
        prompt = NEWS_SCORING_PROMPT.format(
            title=news_item.get("title", ""),
            content=news_item.get("content", "")[:500],
            source=news_item.get("source", ""),
            published_at=news_item.get("published_at", ""),
            watchlist_codes=", ".join(list(watchlist)[:10]) if watchlist else "无",
        )
        
        # 调用 LLM API
        try:
            from openai import OpenAI
            
            client = OpenAI(
                api_key=os.getenv("DASHSCOPE_API_KEY"),
                base_url="https://dashscope.aliyuncs.com/compatible-mode/v1",
            )
            
            response = client.chat.completions.create(
                model=LLM_CONFIG["model"],
                messages=[
                    {"role": "system", "content": "你是一个专业的量化交易新闻分析师。请严格按照 JSON 格式输出评分结果，不要添加任何额外内容。"},
                    {"role": "user", "content": prompt},
                ],
                temperature=LLM_CONFIG["temperature"],
                max_tokens=LLM_CONFIG["max_tokens"],
                timeout=LLM_CONFIG["timeout"],
            )
            
            # 解析响应 - 尝试提取 JSON 部分
            content = response.choices[0].message.content
            
            # 如果响应包含 markdown 代码块，提取 JSON
            if "```json" in content:
                json_str = content.split("```json")[1].split("```")[0].strip()
            elif "```" in content:
                json_str = content.split("```")[1].split("```")[0].strip()
            else:
                json_str = content.strip()
            
            try:
                result = json.loads(json_str)
            except json.JSONDecodeError as e:
                # 尝试修复常见 JSON 问题
                logger.warning(f"JSON 解析失败，尝试修复: {e}")
                # 移除控制字符
                json_str = ''.join(c for c in json_str if ord(c) >= 32 or c in '\n\r\t')
                # 转义未转义的引号
                json_str = json_str.replace('\\"', '"')
                try:
                    result = json.loads(json_str)
                except:
                    logger.error(f"JSON 修复失败，使用降级评分")
                    return self._fallback_score(news_item)
            
            # 验证结果格式
            required_keys = ["market_impact", "second_order_impact", "trade_actionability", "time_sensitivity", "total_score", "grade", "summary"]
            for key in required_keys:
                if key not in result:
                    raise ValueError(f"LLM 响应缺少必要字段: {key}")
            
            return result
            
        except ImportError:
            logger.warning("openai 库未安装，使用降级评分")
            return self._fallback_score(news_item)
        except Exception as e:
            logger.error(f"LLM API 调用失败: {e}")
            raise
    
    def _fallback_score(self, news_item: dict) -> dict:
        """降级评分 (当 LLM 不可用时)"""
        title = news_item.get("title", "")
        content = news_item.get("content", "")
        text = f"{title} {content}"
        
        # 简单关键词匹配
        impact_keywords = ["财报", "业绩", "盈利", "亏损", "并购", "监管", "处罚", "利率", "加息", "降息"]
        impact_score = 15 if any(kw in text for kw in impact_keywords) else 8
        
        return {
            "market_impact": {"score": impact_score, "reason": "降级评分"},
            "second_order_impact": {"score": 10, "reason": "降级评分", "chain": []},
            "trade_actionability": {"score": 12, "reason": "降级评分", "signals": []},
            "time_sensitivity": {"score": 15, "reason": "降级评分", "window_hours": 6},
            "total_score": impact_score + 10 + 12 + 15,
            "grade": "B" if impact_score + 10 + 12 + 15 >= 50 else "C",
            "summary": "LLM 不可用，使用降级评分",
        }
    
    def batch_score(self, news_list: list, watchlist: set = None, max_batch: int = 10) -> list:
        """批量评分新闻"""
        # 如果未启用，直接返回原列表
        if not self.is_enabled:
            return news_list
        
        scored_news = []
        
        # 只评分前 max_batch 条 (控制 API 调用量)
        for news in news_list[:max_batch]:
            llm_result = self.score_news(news, watchlist)
            
            # 将 LLM 评分结果添加到新闻条目
            news["_llm_score"] = llm_result
            
            # 合并 LLM 评分到原有的 _quality
            if "_quality" in news:
                # 更新总分 (LLM 评分权重 60%, 规则评分权重 40%)
                rule_score = news["_quality"].get("score", 0)
                llm_score = llm_result.get("total_score", 0)
                combined_score = rule_score * 0.4 + llm_score * 0.6
                
                news["_quality"]["score"] = combined_score
                news["_quality"]["llm_score"] = llm_score
                news["_quality"]["rule_score"] = rule_score
                
                # 更新等级
                if combined_score >= 80:
                    news["_quality"]["grade"] = "S"
                elif combined_score >= 65:
                    news["_quality"]["grade"] = "A"
                elif combined_score >= 50:
                    news["_quality"]["grade"] = "B"
                elif combined_score >= 35:
                    news["_quality"]["grade"] = "C"
                else:
                    news["_quality"]["grade"] = "D"
            
            scored_news.append(news)
        
        return scored_news
    
    def get_scorer_stats(self) -> dict:
        """获取评分器统计"""
        return {
            "total_scored": self.stats["total_scored"],
            "cache_hits": self.stats["cache_hits"],
            "cache_misses": self.stats["cache_misses"],
            "cache_hit_rate": self.stats["cache_hits"] / max(1, self.stats["cache_hits"] + self.stats["cache_misses"]) * 100,
            "llm_errors": self.stats["llm_errors"],
            "avg_score": self.stats["avg_score"],
            "last_scored_at": self.stats["last_scored_at"],
        }


# ============================================================
# 使用示例
# ============================================================

if __name__ == "__main__":
    # 测试示例
    scorer = LLMNewsScorer()
    
    test_news = {
        "id": "test_llm_1",
        "title": "腾讯控股发布 Q2 财报，净利润同比增长 50%",
        "content": "腾讯今日发布第二季度财报，显示净利润大幅增长 50%，超出市场预期。主要受游戏业务和广告收入增长驱动...",
        "source": "rsshub/富途快讯",
        "published_at": datetime.now().isoformat(),
        "tags": ["rsshub", "HK"],
    }
    
    watchlist = {"HK.00700", "HK.09988", "HK.03690"}
    
    result = scorer.score_news(test_news, watchlist)
    
    print("=== LLM 评分结果 ===")
    print(f"总分: {result['total_score']}")
    print(f"等级: {result['grade']}")
    print(f"市场影响度: {result['market_impact']['score']} - {result['market_impact']['reason']}")
    print(f"二阶影响: {result['second_order_impact']['score']} - {result['second_order_impact']['reason']}")
    print(f"交易可操作性: {result['trade_actionability']['score']} - {result['trade_actionability']['reason']}")
    print(f"时间敏感性: {result['time_sensitivity']['score']} - {result['time_sensitivity']['reason']}")
    print(f"总结: {result['summary']}")
    
    print("\n=== 评分器统计 ===")
    stats = scorer.get_scorer_stats()
    for k, v in stats.items():
        print(f"{k}: {v}")
