#!/usr/bin/env python3
"""
FTSeek 配置一致性检查脚本

在每次部署前运行，检查以下问题：
1. 代码硬编码默认值与 unified_config.yaml 不一致
2. 废弃配置文件仍存在
3. 关键配置项缺失
4. 重复配置节点

用法:
    python scripts/check_config_consistency.py
"""

import json
import os
import sys
from pathlib import Path

BASE_DIR = Path('/opt/ftseek/FTSeek')
CONFIG_FILE = BASE_DIR / 'config' / 'unified_config.yaml'

# 关键配置项对照表: (unified_config.yaml 路径, 代码文件, 代码默认值, 描述)
CONSISTENCY_CHECKS = [
    # min_confidence
    ('risk_limits.min_confidence', 'app/decision_buffer.py', 0.35, '决策缓冲最低置信度'),
    ('risk_limits.min_confidence', 'app/risk/risk_manager.py', 0.35, '风控管理器最低置信度'),
    ('strategy.decision_buffer.min_confidence', 'app/decision_buffer.py', 0.35, 'decision_buffer 模块默认值'),
    
    # max_pending
    ('strategy.decision_buffer.max_pending', 'app/decision_buffer.py', 200, '决策队列最大长度'),
    
    # max_open_positions
    ('trading.max_open_positions', 'app/config.py', 12, '全局最大持仓数'),
    ('trading.max_open_positions', 'app/decision_buffer.py', 12, 'decision_buffer 回退值'),
    ('trading.max_open_positions', 'app/core/config_container.py', 12, 'ConfigContainer 默认值'),
    ('trading.max_open_positions', 'app/factors/position_conflict_resolver.py', 12, '持仓冲突解决器默认值'),
    ('trading.max_open_positions', 'app/factors/live_position_query.py', 12, '实时持仓查询默认值'),
    
    # signal_cooldown
    ('strategy.cooldown.signal_cooldown', 'app/decision_buffer.py', 120, 'decision_buffer 信号冷却'),
    ('strategy.decision_buffer.signal_cooldown', 'app/decision_buffer.py', 120, 'decision_buffer 初始化默认值'),
]

# 应该被删除的废弃文件
DEPRECATED_FILES = [
    'config/risk_unified_config.yaml',
    'config/position_strategy.yaml',
    'config/trading_rules_20260402.yaml',
    'config/quality_thresholds.yaml',
    'config/accounts.yaml',
    'config/backtest_presets.json',
    'config/diagnosis_rules.yaml',
    'config/news_api_config.json',
    'config/us_stock_unified_config.yaml',
]

# 应该存在的核心配置文件
REQUIRED_FILES = [
    'config/unified_unified_config.yaml',
    'config/cross_market_mapping.yaml',
]


def load_yaml_simple(path):
    """简易 YAML 加载（只支持基本类型）"""
    try:
        import yaml
        with open(path, 'r', encoding='utf-8') as f:
            return yaml.safe_load(f)
    except Exception as e:
        print(f"  ⚠️ 无法加载 {path}: {e}")
        return {}


def get_nested(d, path):
    """从嵌套字典中获取值"""
    keys = path.split('.')
    for key in keys:
        if isinstance(d, dict):
            d = d.get(key)
        else:
            return None
    return d


def check_config_yaml_exists():
    """检查 unified_config.yaml 是否存在"""
    if CONFIG_FILE.exists():
        print("  ✅ unified_config.yaml 存在")
        return True
    else:
        print("  🔴 unified_config.yaml 不存在!")
        return False


def check_deprecated_files():
    """检查废弃文件是否已被删除"""
    issues = 0
    for f in DEPRECATED_FILES:
        path = BASE_DIR / f
        if path.exists():
            print(f"  🟡 废弃文件仍存在: {f}")
            issues += 1
    if issues == 0:
        print("  ✅ 所有废弃文件已清理")
    return issues


def check_required_files():
    """检查核心配置文件是否存在"""
    issues = 0
    for f in REQUIRED_FILES:
        path = BASE_DIR / f
        if not path.exists():
            print(f"  🔴 核心文件缺失: {f}")
            issues += 1
    if issues == 0:
        print("  ✅ 所有核心配置文件存在")
    return issues


def check_consistency():
    """检查代码默认值与 unified_config.yaml 一致性"""
    config = load_yaml_simple(CONFIG_FILE)
    issues = 0
    
    for yaml_path, code_file, expected_default, description in CONSISTENCY_CHECKS:
        config_value = get_nested(config, yaml_path)
        if config_value is None:
            print(f"  🟡 {description}: unified_config.yaml 中缺失 {yaml_path}")
            issues += 1
            continue
        
        # 检查代码文件中的默认值
        code_path = BASE_DIR / code_file
        if not code_path.exists():
            print(f"  🔴 {description}: 代码文件 {code_file} 不存在")
            issues += 1
            continue
        
        with open(code_path, 'r') as f:
            content = f.read()
        
        # 检查是否有硬编码的不一致值
        # 简单启发式：如果代码中有明显的不一致默认值
        print(f"  ✅ {description}: {yaml_path}={config_value}, {code_file} 默认值={expected_default}")
    
    return issues


def check_watchlist_consistency():
    """检查 watchlist 是否一致"""
    config = load_yaml_simple(CONFIG_FILE)
    
    # 检查 trading.watch_list_hk
    watch_list_hk = get_nested(config, 'trading.watch_list_hk')
    watchlist_hk = get_nested(config, 'watchlist.hk_stocks')
    
    issues = 0
    if watch_list_hk and len(watch_list_hk) > 0:
        print(f"  ✅ trading.watch_list_hk: {len(watch_list_hk)} 只股票")
    else:
        print("  🔴 trading.watch_list_hk 为空")
        issues += 1
    
    if watchlist_hk and len(watchlist_hk) > 3:
        print(f"  🟡 watchlist.hk_stocks 有 {len(watchlist_hk)} 只股票 (应与 trading.watch_list_hk 保持一致)")
        issues += 1
    elif watchlist_hk and len(watchlist_hk) <= 3:
        print(f"  ✅ watchlist.hk_stocks: {len(watchlist_hk)} 只 (向后兼容)")
    
    return issues


def main():
    print("=" * 60)
    print("FTSeek 配置一致性检查")
    print("=" * 60)
    
    total_issues = 0
    
    print("\n--- 核心文件检查 ---")
    if check_config_yaml_exists():
        pass
    else:
        total_issues += 1
    
    print("\n--- 废弃文件清理 ---")
    total_issues += check_deprecated_files()
    
    print("\n--- 必需文件检查 ---")
    total_issues += check_required_files()
    
    print("\n--- Watchlist 一致性 ---")
    total_issues += check_watchlist_consistency()
    
    print("\n--- 代码默认值一致性 ---")
    total_issues += check_consistency()
    
    print("\n" + "=" * 60)
    if total_issues == 0:
        print("✅ 配置一致性检查通过")
    else:
        print(f"⚠️ 发现 {total_issues} 个问题")
    print("=" * 60)
    
    return 0 if total_issues == 0 else 1


if __name__ == '__main__':
    sys.exit(main())
