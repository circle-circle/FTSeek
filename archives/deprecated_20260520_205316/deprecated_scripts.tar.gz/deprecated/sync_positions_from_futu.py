#!/usr/bin/env python3
"""
从富途同步持仓信息到数据库
P0 紧急修复脚本 — 2026-04-15 升级：写入止损止盈
"""

import sys
import os
sys.path.insert(0, '/opt/ftseek/FTSeek')

import sqlite3
import logging
from datetime import datetime
from futu import OpenSecTradeContext, TrdMarket

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s | %(levelname)s | %(message)s',
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler('/opt/ftseek/FTSeek/logs/sync_positions.log')
    ]
)
logger = logging.getLogger('sync_positions')

# 配置
DB_PATH = "/opt/ftseek/FTSeek/data/ftseek.db"
OPEND_HOST = os.getenv("OPEND_HOST", "127.0.0.1")
OPEND_PORT = int(os.getenv("OPEND_PORT", "11111"))

# 止损止盈默认值 (对齐 dynamic_exit_params.yaml default)
DEFAULT_STOP_PCT = 0.03   # -3%
DEFAULT_TAKE_PCT = 0.10   # +10%


def get_db_connection():
    """获取数据库连接"""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def sync_positions():
    """同步持仓信息并写入止损止盈"""
    logger.info("="*60)
    logger.info("开始同步富途持仓信息...")
    logger.info("="*60)
    
    conn = None
    ctx = None
    
    try:
        # 连接数据库
        conn = get_db_connection()
        logger.info("✅ 数据库连接成功")
        
        # 连接富途
        ctx = OpenSecTradeContext(
            host=OPEND_HOST,
            port=OPEND_PORT,
            filter_trdmarket=TrdMarket.HK
        )
        logger.info(f"✅ 富途连接成功 ({OPEND_HOST}:{OPEND_PORT})")
        
        # 获取持仓
        logger.info("获取持仓信息...")
        ret, data = ctx.position_list_query(trd_env=1)  # 1=SIMULATE
        
        if ret != 0:
            logger.error(f"❌ 获取持仓失败：{data}")
            return 0
        
        if data is None or len(data) == 0:
            logger.info("⚠️  无持仓")
            return 0
        
        active = data[data['qty'] > 0][['code', 'qty', 'cost_price']].drop_duplicates(subset='code')
        logger.info(f"📊 找到 {len(active)} 个有效持仓")
        
        now_str = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        cursor = conn.cursor()
        
        # 查本地所有 OPEN 仓
        cursor.execute("SELECT id, code FROM positions WHERE status='OPEN'")
        local_open = {row[1]: row[0] for row in cursor.fetchall()}
        
        synced, inserted, fixed = [], [], []
        
        for _, row in active.iterrows():
            code = row['code']
            qty = int(row['qty'])
            cost = float(row['cost_price'])
            
            # 计算止损止盈
            sl = round(cost * (1 - DEFAULT_STOP_PCT), 4)
            tp = round(cost * (1 + DEFAULT_TAKE_PCT), 4)
            
            if code in local_open:
                pos_id = local_open[code]
                # 同步并修复止损止盈
                cursor.execute(
                    "UPDATE positions SET quantity=?, entry_price=?, stop_loss=?, take_profit=? WHERE id=?",
                    (qty, cost, sl, tp, pos_id)
                )
                synced.append(f"{code}({qty}股@{cost})")
                logger.info(f"  同步 {code}: qty={qty}, cost={cost}, SL={sl}(-3%), TP={tp}(+10%)")
            else:
                cursor.execute(
                    "INSERT INTO positions (code, action, quantity, entry_price, entry_time, status, stop_loss, take_profit) VALUES (?,?,?,?,?,'OPEN',?,?)",
                    (code, 'BUY', qty, cost, now_str, sl, tp)
                )
                inserted.append(f"{code}({qty}股@{cost})")
                logger.info(f"  新增 {code}: qty={qty}, cost={cost}, SL={sl}, TP={tp}")
        
        # 检查是否有异常止损价 (stop_loss = entry_price)
        cursor.execute("SELECT id, code, entry_price, stop_loss FROM positions WHERE status='OPEN' AND ABS(stop_loss - entry_price) < 0.01")
        bad_rows = cursor.fetchall()
        for bad in bad_rows:
            bid, bcode, bentry, bsl = bad
            new_sl = round(bentry * (1 - DEFAULT_STOP_PCT), 4)
            new_tp = round(bentry * (1 + DEFAULT_TAKE_PCT), 4)
            cursor.execute("UPDATE positions SET stop_loss=?, take_profit=? WHERE id=?", (new_sl, new_tp, bid))
            fixed.append(f"{bcode}: SL {bsl} -> {new_sl}")
            logger.warning(f"  修复异常止损 {bcode}: {bsl} -> {new_sl}")
        
        conn.commit()
        
        if synced or inserted or fixed:
            logger.info(f"同步完成 | 更新: {len(synced)} | 新增: {len(inserted)} | 修复止损: {len(fixed)}")
        else:
            logger.info("本地与富途持仓一致，无需更新")
        
        return len(active)
        
    except Exception as e:
        logger.error(f"❌ 同步失败：{e}", exc_info=True)
        return 0
        
    finally:
        if conn:
            conn.close()
        if ctx:
            ctx.close()


if __name__ == '__main__':
    imported = sync_positions()
    sys.exit(0 if imported > 0 else 1)
