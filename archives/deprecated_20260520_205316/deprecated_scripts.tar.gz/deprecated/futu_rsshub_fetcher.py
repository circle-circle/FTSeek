#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
富途快讯 RSSHub 采集器 - 最优雅方案

使用 RSSHub 获取富途快讯:
- URL: https://rsshub.rssforever.com/futunn/live
- 格式: 标准 RSS XML
- 解析: feedparser
- 条数: 约 30 条

优点:
- ✅ 无需认证
- ✅ 标准 RSS 格式
- ✅ Python feedparser 一行解析
- ✅ 公共服务可用
- ✅ 可自建实例

作者: FTSeek Team
日期: 2026-04-12
"""

import asyncio
import hashlib
import json
import logging
import time
from datetime import datetime, timedelta
from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional, Tuple

# 配置日志
logger = logging.getLogger('futu_rsshub')

# ============================================================
# RSSHub 配置
# ============================================================

RSSHUB_INSTANCES = [
    "https://rsshub.rssforever.com",  # 公共实例
    "https://rsshub.app",              # 官方实例
]

FUTU_ROUTES = {
    'flash': '/futunn/live',           # 快讯 (7×24)
    'news': '/futunn/news',            # 新闻
    'topic': '/futunn/topic',          # 专题
}

# ============================================================
# 数据结构
# ============================================================

class NewsSentiment(Enum):
    POSITIVE = "positive"
    NEGATIVE = "negative"
    NEUTRAL = "neutral"

class NewsImportance(Enum):
    MAJOR = "major"
    NORMAL = "normal"
    MINOR = "minor"

@dataclass
class FutuFlashNews:
    """富途快讯数据结构"""
    id: str
    title: str
    content: str
    link: str
    publish_time: datetime
    source: str = "futu_rsshub"
    sentiment: NewsSentiment = NewsSentiment.NEUTRAL
    sentiment_score: float = 0.0
    importance: NewsImportance = NewsImportance.NORMAL
    stocks: List[str] = field(default_factory=list)
    
    def to_dict(self) -> dict:
        return {
            'id': self.id,
            'title': self.title,
            'content': self.content,
            'link': self.link,
            'publish_time': self.publish_time.isoformat(),
            'source': self.source,
            'sentiment': self.sentiment.value,
            'sentiment_score': self.sentiment_score,
            'importance': self.importance.value,
            'stocks': self.stocks,
        }

# ============================================================
# 富途快讯采集器
# ============================================================

class FutuRSSHubFetcher:
    """
    RSSHub 富途快讯采集器
    
    最优雅的富途快讯获取方式:
    - 使用 RSSHub 公共服务
    - 标准 RSS 格式解析
    - feedparser 一行代码
    """
    
    # 重要新闻关键词
    MAJOR_KEYWORDS = [
        '财报', '业绩', '盈利', '亏损', '并购', '收购',
        '监管', '处罚', '诉讼', '调查', 'IPO', '上市',
        '合同', '订单', '突破', '创新', '重大',
    ]
    
    # 负面关键词
    NEGATIVE_KEYWORDS = [
        '亏损', '下滑', '下跌', '暴跌', '处罚',
        '诉讼', '调查', '违规', '裁员', '破产',
    ]
    
    # 正面关键词
    POSITIVE_KEYWORDS = [
        '盈利', '增长', '上涨', '突破', '新高',
        '订单', '合同', '创新', '分红', '增持',
    ]
    
    # 股票名称映射
    STOCK_NAMES = {
        '腾讯': 'HK.00700',
        '阿里巴巴': 'HK.09988',
        '阿里': 'HK.09988',
        '美团': 'HK.03690',
        '小米': 'HK.01810',
        '中芯国际': 'HK.00981',
        '泡泡玛特': 'HK.09992',
        '特斯拉': 'US.TSLA',
        '苹果': 'US.AAPL',
        '英伟达': 'US.NVDA',
        '微软': 'US.MSFT',
        '谷歌': 'US.GOOG',
        '亚马逊': 'US.AMZN',
        'Meta': 'US.META',
    }
    
    def __init__(self, rsshub_instance: str = None):
        """
        初始化
        
        Args:
            rsshub_instance: RSSHub 实例 URL，默认使用第一个可用实例
        """
        self.rsshub_instance = rsshub_instance or RSSHUB_INSTANCES[0]
        self.route = FUTU_ROUTES['flash']
        
        # 缓存
        self.cache: List[FutuFlashNews] = []
        self.cache_time: datetime = None
        self.cache_ttl = timedelta(minutes=3)
        
        # 统计
        self.stats = {
            'total_fetches': 0,
            'successful_fetches': 0,
            'failed_fetches': 0,
            'last_fetch_time': None,
            'avg_latency_ms': 0,
        }
        
        logger.info(f"FutuRSSHubFetcher initialized: {self.rsshub_instance}")
    
    def _generate_id(self, link: str) -> str:
        """从链接生成唯一 ID"""
        return hashlib.md5(link.encode()).hexdigest()[:16]
    
    def _parse_time(self, time_str: str) -> datetime:
        """解析 RSS 时间格式"""
        try:
            # RSS 时间格式: "Sun, 12 Apr 2026 06:18:48 GMT"
            from email.utils import parsedate_to_datetime
            return parsedate_to_datetime(time_str)
        except Exception:
            logger.error("Failed to parse RSS time format", exc_info=True)
            return datetime.now()
    
    def _classify_importance(self, text: str) -> NewsImportance:
        """分类重要性"""
        major_count = sum(1 for kw in self.MAJOR_KEYWORDS if kw in text)
        
        if major_count >= 2:
            return NewsImportance.MAJOR
        elif major_count == 1:
            return NewsImportance.NORMAL
        else:
            return NewsImportance.MINOR
    
    def _analyze_sentiment(self, text: str) -> Tuple[NewsSentiment, float]:
        """分析情感"""
        positive_count = sum(1 for kw in self.POSITIVE_KEYWORDS if kw in text)
        negative_count = sum(1 for kw in self.NEGATIVE_KEYWORDS if kw in text)
        
        total = positive_count + negative_count
        if total == 0:
            return NewsSentiment.NEUTRAL, 0.0
        
        score = (positive_count - negative_count) / total
        
        if score > 0.2:
            return NewsSentiment.POSITIVE, score
        elif score < -0.2:
            return NewsSentiment.NEGATIVE, score
        else:
            return NewsSentiment.NEUTRAL, score
    
    def _extract_stocks(self, text: str) -> List[str]:
        """提取相关股票"""
        stocks = []
        
        for name, code in self.STOCK_NAMES.items():
            if name in text:
                stocks.append(code)
        
        return stocks
    
    async def fetch(self) -> List[FutuFlashNews]:
        """
        获取富途快讯
        
        Returns:
            List[FutuFlashNews]: 快讯列表
        """
        start_time = time.time()
        self.stats['total_fetches'] += 1
        
        # 检查缓存
        if self.cache and self.cache_time:
            if datetime.now() - self.cache_time < self.cache_ttl:
                logger.debug("Using cached news")
                return self.cache
        
        rss_url = f"{self.rsshub_instance}{self.route}"
        
        try:
            import feedparser
            
            logger.info(f"Fetching from {rss_url}")
            feed = feedparser.parse(rss_url)
            
            if not feed.entries:
                logger.warning(f"No entries found")
                self.stats['failed_fetches'] += 1
                return []
            
            news_list = []
            
            for entry in feed.entries:
                title = entry.title if hasattr(entry, 'title') else ''
                link = entry.link if hasattr(entry, 'link') else ''
                summary = entry.summary if hasattr(entry, 'summary') else ''
                published = entry.published if hasattr(entry, 'published') else ''
                
                if not title:
                    continue
                
                # 创建快讯对象
                news = FutuFlashNews(
                    id=self._generate_id(link),
                    title=title,
                    content=summary or title,
                    link=link,
                    publish_time=self._parse_time(published),
                )
                
                # 分析情感
                text = f"{title} {summary}"
                sentiment, score = self._analyze_sentiment(text)
                news.sentiment = sentiment
                news.sentiment_score = score
                
                # 分类重要性
                news.importance = self._classify_importance(text)
                
                # 提取股票
                news.stocks = self._extract_stocks(text)
                
                news_list.append(news)
            
            # 按时间排序
            news_list.sort(key=lambda x: x.publish_time, reverse=True)
            
            # 更新缓存
            self.cache = news_list
            self.cache_time = datetime.now()
            
            # 更新统计
            latency_ms = int((time.time() - start_time) * 1000)
            self.stats['successful_fetches'] += 1
            self.stats['last_fetch_time'] = datetime.now()
            
            n = self.stats['successful_fetches']
            self.stats['avg_latency_ms'] = (
                (self.stats['avg_latency_ms'] * (n-1) + latency_ms) / n
            )
            
            logger.info(f"Fetched {len(news_list)} news in {latency_ms}ms")
            
            return news_list
            
        except ImportError:
            logger.error("feedparser not installed: pip install feedparser")
            self.stats['failed_fetches'] += 1
            return []
            
        except Exception as e:
            logger.error(f"Fetch failed: {e}")
            self.stats['failed_fetches'] += 1
            return []
    
    def get_stats(self) -> dict:
        """获取统计信息"""
        return {
            **self.stats,
            'cache_size': len(self.cache),
            'rsshub_instance': self.rsshub_instance,
            'route': self.route,
        }


# ============================================================
# 集成到 FTSeek 新闻系统
# ============================================================

async def fetch_futu_flash() -> List[dict]:
    """
    获取富途快讯 (标准化输出)
    
    用法:
        news_list = await fetch_futu_flash()
        for news in news_list:
            print(news['title'])
    
    Returns:
        List[dict]: 标准化的快讯列表
    """
    fetcher = FutuRSSHubFetcher()
    news_list = await fetcher.fetch()
    return [n.to_dict() for n in news_list]


def integrate_to_news_monitor():
    """
    集成说明
    
    在 modules/news_monitor.py 中添加:
    
    1. NewsSource 枚举添加:
        FUTU_RSSHUB = "futu_rsshub"
    
    2. 添加抓取方法:
        async def _fetch_futu_rsshub(self, stock: str) -> List[NewsItem]:
            from scripts.futu_rsshub_fetcher import fetch_futu_flash
            
            futu_news = await fetch_futu_flash()
            
            news_list = []
            for n in futu_news:
                news = NewsItem(
                    id=n['id'],
                    title=n['title'],
                    content=n['content'],
                    source=NewsSource.FUTU_RSSHUB,
                    publish_time=datetime.fromisoformat(n['publish_time']),
                    stocks=n['stocks'],
                    sentiment=NewsSentiment(n['sentiment']),
                    sentiment_score=n['sentiment_score'],
                    importance=NewsImportance(n['importance']),
                    raw_url=n['link'],
                )
                news_list.append(news)
            
            # 按股票过滤
            if stock:
                news_list = [n for n in news_list 
                             if stock in n.stocks or not n.stocks]
            
            return news_list
    
    3. fetch_news() 中添加:
        tasks_map[NewsSource.FUTU_RSSHUB] = asyncio.create_task(
            self._fetch_futu_rsshub(stock)
        )
    """
    return integrate_to_news_monitor.__doc__


# ============================================================
# 测试
# ============================================================

async def test():
    """测试 RSSHub 采集器"""
    print("=" * 70)
    print("🔍 富途快讯 RSSHub 采集器测试")
    print("=" * 70)
    
    fetcher = FutuRSSHubFetcher()
    
    print("\n【Step 1】获取快讯:")
    news_list = await fetcher.fetch()
    
    print(f"  采集数量: {len(news_list)} 条")
    
    if news_list:
        print("\n【Step 2】快讯示例:")
        for i, news in enumerate(news_list[:5], 1):
            print(f"\n  [{i}] {news.title[:60]}...")
            print(f"      时间: {news.publish_time}")
            print(f"      情感: {news.sentiment.value} ({news.sentiment_score:.2f})")
            print(f"      重要性: {news.importance.value}")
            print(f"      股票: {news.stocks}")
            print(f"      链接: {news.link}")
    
    print("\n【Step 3】统计信息:")
    stats = fetcher.get_stats()
    for k, v in stats.items():
        print(f"  {k}: {v}")
    
    print("\n" + "-" * 70)
    print("✅ RSSHub 方案测试完成")
    print("-" * 70)


if __name__ == "__main__":
    asyncio.run(test())