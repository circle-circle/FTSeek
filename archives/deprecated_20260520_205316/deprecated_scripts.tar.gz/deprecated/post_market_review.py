#!/usr/bin/env python3
"""
盘后复盘自动化脚本 (Post-Market Review)

由 Crontab 每日收盘后 (16:15 HKT) 调用。
职责：
1. 加载当日的 daily_battle_plan.json
2. 获取市场实际收盘价 (从数据库或 API)
3. 执行对比分析，生成 daily_review_report.json
4. 发送复盘摘要到钉钉 (可选)
"""

import os
import sys
import json
import logging
from datetime import datetime

# Add project root to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.pipeline.post_review import PostMarketReviewer

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(message)s'
)
logger = logging.getLogger("scripts.post_review")

def get_market_data_from_db():
    """
    从本地数据库获取交易结果，用于复盘
    优先使用实际交易盈亏，如果没有交易则尝试 K 线数据
    """
    try:
        import sqlite3
        db_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'data', 'ftseek.db')
        if not os.path.exists(db_path):
            logger.warning("数据库不存在")
            return {}

        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # 尝试从 trades 表获取今日已平仓交易的实际盈亏
        # 注意：这里假设 entry_time 是今天
        # 为了简单，我们获取所有状态为 closed 的交易，计算盈亏百分比
        # 真正的复盘应该对比 "计划" vs "实际收盘"，但在没有 K 线数据的情况下，用 "已实现 PnL" 代替也是一种复盘
        
        # 获取所有已实现盈亏
        cursor.execute("""
            SELECT code, pnl_percent FROM trades 
            WHERE status = 'closed' AND pnl_percent IS NOT NULL
        """)
        rows = cursor.fetchall()
        
        data = {}
        for row in rows:
            code, pnl = row
            data[code] = {
                "realized_pnl": float(pnl),
                "open": 0,
                "close": 0
            }
        return data
            
    except Exception as e:
        logger.error(f"数据库查询失败: {e}")
        return {}

def main():
    logger.info("📊 开始盘后复盘任务...")
    
    # 1. Paths
    data_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'data')
    plan_path = os.path.join(data_dir, 'daily_battle_plan.json')
    
    # Check if plan exists
    if not os.path.exists(plan_path):
        logger.warning("⚠️ 未找到今日作战计划，跳过复盘")
        return

    # 2. Get Market Data
    logger.info("  [1/3] 获取市场收盘数据...")
    market_data = get_market_data_from_db()
    
    # Fallback: 如果数据库查不到，可能需要在 cron 里传入或者从 API 拉
    # 这里如果没有数据，reviewer 会处理 (skip)
    if not market_data:
        logger.warning("⚠️ 未能获取市场数据，复盘可能不完整")

    # 3. Run Review
    logger.info("  [2/3] 执行对比分析...")
    reviewer = PostMarketReviewer()
    report, feedback = reviewer.review(plan_path, market_data)
    
    if not report:
        logger.error("❌ 复盘生成失败")
        return

    # 4. Output Summary
    logger.info("  [3/3] 生成复盘报告...")
    logger.info(f"  ✅ 今日命中率: {report.get('hit_rate', 0):.0%} ({report.get('hits', 0)}/{report.get('total_targets', 0)})")
    
    # 打印反馈 Prompt 供调试
    logger.info(f"  💡 次日反馈 Prompt 片段:\n{feedback[:100]}...")

if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        logger.error(f"💥 盘后复盘任务崩溃: {e}", exc_info=True)
        sys.exit(1)
