#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
统一新闻推送引擎 (Unified News Push Engine)

合并自:
- futu_flash_cron.py 的钉钉推送、情感分析、股票关联提取
- rsshub_multi_source_cron.py 的多源采集、质量评分

功能:
1. 重要新闻钉钉推送 (带全局去重)
2. 情感分析
3. 股票关联提取
4. 事件驱动管线注入 (on_news_event)
5. 统一推送统计

作者: FTSeek Team
日期: 2026-04-17
"""

import asyncio
import json
import logging
import os
import sys
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Set

logger = logging.getLogger("unified_news_push")

# 配置路径
sys.path.insert(0, '/opt/ftseek/FTSeek')

from app.utils.dedup import get_dedup
from app.utils.dedup_global import get_global_dedup


# ============================================================
# 重要新闻关键词 (合并自 futu_flash)
# ============================================================

MAJOR_KEYWORDS = [
    # 个股事件
    '财报', '业绩', '盈利', '亏损', '并购', '收购',
    '监管', '处罚', 'IPO', '上市', '重大合同',
    '涨停', '跌停', '暴涨', '暴跌', '熔断',
    # 宏观/地缘事件
    '美联储', 'FED', '利率', '加息', '降息', 'CPI', 'PPI', '非农',
    '纳指', '道指', '标普', 'S&P', 'Nasdaq', 'Dow', '恒生',
    '制裁', '关税', '贸易战', '地缘', '战争', '停火', '中东',
    '原油', '油价', '黄金', 'bitcoin', 'crypto',
    '芯片', '半导体', 'AI', '电动车', 'EV',
]


# ============================================================
# 股票名称映射 (合并自 futu_flash)
# ============================================================

STOCK_NAME_MAP = {
    '腾讯': 'HK.00700', '阿里巴巴': 'HK.09988', '阿里': 'HK.09988',
    '美团': 'HK.03690', '小米': 'HK.01810', '中芯国际': 'HK.00981',
    '泡泡玛特': 'HK.09992', '快手': 'HK.01024', '京东': 'HK.09618',
    '百度': 'HK.09888', '平安': 'HK.02318', '友邦': 'HK.01299',
    '港交所': 'HK.00388', '建行': 'HK.00939', '信达': 'HK.01801',
    '药明': 'HK.02269', '京东健康': 'HK.06618', '华虹': 'HK.01347',
    '舜宇': 'HK.02382', '比亚迪': 'HK.01211', '理想': 'HK.02015',
    '小鹏': 'HK.09868',
    '英伟达': 'US.NVDA', 'NVDA': 'US.NVDA',
    '特斯拉': 'US.TSLA', 'TSLA': 'US.TSLA',
    '苹果': 'US.AAPL', 'AAPL': 'US.AAPL',
    '微软': 'US.MSFT', 'MSFT': 'US.MSFT',
    '谷歌': 'US.GOOG', 'GOOGL': 'US.GOOG',
    '亚马逊': 'US.AMZN', 'AMZN': 'US.AMZN',
    'META': 'US.META', '拼多多': 'US.PDD', 'PDD': 'US.PDD',
}


# ============================================================
# 情感分析器
# ============================================================

class SentimentAnalyzer:
    """简易情感分析器 (合并自 futu_flash)"""
    
    POSITIVE_KEYWORDS = [
        '增长', '上升', '利好', '超预期', '突破', '新高', '上涨',
        '盈利', '盈利增长', '收益增长', '收购', '合并', '合作',
        '利好消息', '买入', '增持', '上调', '目标价上调',
    ]
    
    NEGATIVE_KEYWORDS = [
        '下降', '下跌', '利空', '低于预期', '暴跌', '新低', '亏损',
        '处罚', '调查', '诉讼', '制裁', '贸易战', '风险',
        '卖出', '减持', '下调', '目标价下调', '警告',
    ]
    
    def analyze(self, text: str) -> str:
        """分析文本情感: positive/negative/neutral"""
        positive_count = sum(1 for kw in self.POSITIVE_KEYWORDS if kw in text)
        negative_count = sum(1 for kw in self.NEGATIVE_KEYWORDS if kw in text)
        
        if positive_count > negative_count:
            return "positive"
        elif negative_count > positive_count:
            return "negative"
        else:
            return "neutral"


# ============================================================
# 统一新闻推送引擎
# ============================================================

class UnifiedNewsPushEngine:
    """统一新闻推送引擎"""
    
    def __init__(self, watchlist: set = None):
        self.watchlist = watchlist or set()
        self.sentiment_analyzer = SentimentAnalyzer()
        
        # 全局去重器 (2 小时 TTL)
        self.dedup = get_global_dedup(ttl_hours=2)
        
        # 推送统计
        self.stats = {
            "total_pushed": 0,
            "major_pushed": 0,
            "duplicate_skipped": 0,
            "last_push_time": None,
        }
        self._load_stats()
    
    def _load_stats(self):
        """加载推送统计"""
        stats_file = Path("/opt/ftseek/FTSeek/data/unified_push_stats.json")
        if stats_file.exists():
            try:
                with open(stats_file, 'r') as f:
                    self.stats.update(json.load(f))
            except:
                pass
    
    def _save_stats(self):
        """保存推送统计"""
        stats_file = Path("/opt/ftseek/FTSeek/data/unified_push_stats.json")
        try:
            with open(stats_file, 'w') as f:
                json.dump(self.stats, f, indent=2, ensure_ascii=False)
        except Exception as e:
            logger.warning(f"保存推送统计失败: {e}")
    
    def is_major_news(self, title: str, content: str = "") -> bool:
        """判断是否为重要新闻"""
        text = f"{title} {content}"
        return any(kw in text for kw in MAJOR_KEYWORDS)
    
    def extract_stocks(self, text: str) -> List[str]:
        """提取相关股票"""
        stocks = []
        
        # 通过股票名称映射
        for name, code in STOCK_NAME_MAP.items():
            if name in text:
                stocks.append(code)
        
        # 通过 watchlist 代码
        for code in self.watchlist:
            code_short = code.replace('HK.', '').replace('US.', '')
            if code_short in text:
                stocks.append(code)
        
        return list(set(stocks))
    
    def analyze_sentiment(self, text: str) -> str:
        """分析情感"""
        return self.sentiment_analyzer.analyze(text)
    
    async def push_news(self, news_list: List[dict], max_push: int = 5) -> int:
        """
        推送重要新闻到钉钉
        
        Args:
            news_list: 新闻列表 (来自 rsshub_multi_source 或 futu_flash)
            max_push: 单次最多推送数量
            
        Returns:
            实际推送数量
        """
        if not news_list:
            return 0
        
        pushed_count = 0
        
        try:
            from app.notifier.dingtalk import DingTalkNotifier
            notifier = DingTalkNotifier()
            
            for news in news_list:
                if pushed_count >= max_push:
                    break
                
                title = news.get('title', '')
                content = news.get('content', '')
                source = news.get('source', '未知来源')
                publish_time = news.get('published_at', news.get('publish_time', ''))
                
                # 判断重要性 (优先使用已有的 is_major 标记)
                is_major = news.get('is_major', False) or self.is_major_news(title, content)
                if not is_major:
                    continue
                
                # 全局去重
                if not self.dedup.check_and_mark(title, source, channel='unified_push'):
                    logger.debug(f"[去重] 跳过已推送: {title[:50]}")
                    self.stats["duplicate_skipped"] += 1
                    continue
                
                # 提取股票和情感
                text = f"{title} {content}"
                stocks = self.extract_stocks(text)
                sentiment = self.analyze_sentiment(text)
                
                # 构建推送内容
                source_emoji = {
                    "rsshub/富途快讯": "🔴",
                    "rsshub/彭博市场": "🔵",
                    "rsshub/金十数据": "🟡",
                    "rsshub/华尔街见闻全球": "🟣",
                    "rsshub/华尔街见闻中国": "🟠",
                    "rsshub/财联社电报": "🟢",
                }.get(source, "⚪")
                
                text_msg = f"""
### {source_emoji} {source.split('/')[-1] if '/' in source else source} 重要快讯

**标题**: {title[:100]}

**时间**: {str(publish_time)[:19]}

**情感**: {'📈 正面' if sentiment == 'positive' else '📉 负面' if sentiment == 'negative' else '➡️ 中性'}

**相关股票**: {', '.join(stocks) if stocks else '未识别'}

**链接**: {news.get('url', '无链接')}

---
💡 此快讯包含重要关键词，请关注
"""
                
                # 发送钉钉消息
                try:
                    result = notifier.send_text(text_msg)
                    if result:
                        pushed_count += 1
                        self.stats["total_pushed"] += 1
                        self.stats["major_pushed"] += 1
                        self.stats["last_push_time"] = datetime.now().isoformat()
                        logger.info(f"推送重要快讯: {title[:50]}")
                    else:
                        logger.warning(f"推送失败: {title[:50]}")
                except Exception as e:
                    logger.error(f"钉钉发送异常: {e}")
            
            # 保存统计
            self._save_stats()
            
            return pushed_count
            
        except ImportError:
            logger.warning("DingTalkNotifier 不可用，跳过推送")
            return 0
        except Exception as e:
            logger.error(f"推送失败: {e}")
            return 0
    
    async def trigger_event_pipeline(self, news_list: List[dict], max_events: int = 20):
        """
        将新闻注入事件驱动管线 (原 futu_flash 的 _trigger_event_pipeline)
        
        链路: news → DataSubscriber.on_news_event() → 分层策略 → 共识引擎
        """
        if not news_list:
            return
        
        try:
            # 构造新闻事件格式
            news_events = []
            for n in news_list[:max_events]:
                text = f"{n.get('title', '')} {n.get('content', '')}"
                related = self.extract_stocks(text)
                
                news_events.append({
                    'id': n.get('id', n.get('content_hash', '')),
                    'title': n.get('title', ''),
                    'content': n.get('content', ''),
                    'source': n.get('source', 'unknown'),
                    'publish_time': n.get('published_at', n.get('publish_time', '')),
                    'related_stocks': related,
                    'url': n.get('url', ''),
                })
            
            if not news_events:
                return
            
            # 调用 FTSeek API 注入新闻事件
            try:
                import requests
                resp = requests.post(
                    'http://localhost:8899/api/news/event',
                    json={'news_list': news_events},
                    timeout=5
                )
                if resp.status_code == 200:
                    logger.info(f"[事件驱动] {len(news_events)} 条快讯已注入管线")
                else:
                    logger.debug(f"[事件驱动] API 返回 {resp.status_code}，主进程可能未运行")
            except requests.exceptions.ConnectionError:
                logger.debug("[事件驱动] FTSeek 主进程未运行 (localhost:8899 不可达)，跳过注入")
            except Exception as e:
                logger.debug(f"[事件驱动] 注入失败: {e}")
                
        except Exception as e:
            logger.warning(f"事件管线注入异常: {e}")
    
    def get_stats(self) -> dict:
        """获取推送统计"""
        return self.stats.copy()


# ============================================================
# 使用示例
# ============================================================

if __name__ == "__main__":
    # 测试示例
    engine = UnifiedNewsPushEngine(watchlist={"HK.00700", "HK.09988"})
    
    test_news = [
        {
            "title": "腾讯发布 Q2 财报，净利润同比增长 50%",
            "content": "腾讯今日发布第二季度财报...",
            "source": "rsshub/富途快讯",
            "published_at": datetime.now().isoformat(),
        },
        {
            "title": "普通新闻",
            "content": "这是一条普通新闻",
            "source": "rsshub/财联社电报",
            "published_at": datetime.now().isoformat(),
        },
    ]
    
    # 测试推送
    async def test_push():
        count = await engine.push_news(test_news)
        print(f"推送了 {count} 条新闻")
        print(f"统计: {engine.get_stats()}")
    
    asyncio.run(test_push())
