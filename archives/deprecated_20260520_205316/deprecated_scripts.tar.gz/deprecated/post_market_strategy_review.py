#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
FTSeek 新闻策略盘后复盘 (Post-Market News Strategy Review)

功能:
1. 评估所有到期的新闻策略信号 (30分钟后)
2. 汇总当日所有新闻策略表现
3. 生成迭代建议
4. 推送到钉钉/飞书

触发时机:
- crontab 16:30 交易日自动执行 (盘后)
- 也可手动触发

作者: FTSeek Team
日期: 2026-04-15
"""

import asyncio
import json
import logging
import os
import sys
import time
from datetime import datetime
from pathlib import Path

# ============================================================
# 路径
# ============================================================
BASE_DIR = Path("/opt/ftseek/FTSeek")
sys.path.insert(0, str(BASE_DIR))

# 加载 .env
try:
    from dotenv import load_dotenv
    load_dotenv(BASE_DIR / ".env")
except ImportError:
    pass

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(name)s: %(message)s",
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler(BASE_DIR / "logs" / "strategy_review.log"),
    ]
)
logger = logging.getLogger("strategy_review")


# ============================================================
# 行情获取
# ============================================================

def get_latest_prices(codes: list) -> dict:
    """获取股票最新价格"""
    prices = {}
    try:
        from futu import OpenQuoteContext
        ctx = OpenQuoteContext(host="127.0.0.1", port=11111)
        ret, data = ctx.get_market_snapshot(codes)
        ctx.close()
        
        if ret == 0:
            for _, row in data.iterrows():
                code = row.get("code", "")
                prices[code] = {
                    "current": float(row.get("last_price", 0)),
                    "high": float(row.get("high_price", 0)),
                    "low": float(row.get("low_price", 0)),
                }
    except Exception as e:
        logger.warning(f"行情获取失败: {e}")
    
    return prices


# ============================================================
# 钉钉推送
# ============================================================

def send_review_to_dingtalk(report: str) -> bool:
    """发送复盘报告到钉钉"""
    import requests
    import hmac
    import hashlib
    import base64
    import urllib.parse
    
    webhook = os.getenv("DINGTALK_WEBHOOK_URL", "")
    secret = os.getenv("DINGTALK_SECRET", "")
    
    if not webhook:
        logger.error("钉钉 Webhook 未配置")
        return False
    
    # 加签
    if secret:
        timestamp = str(round(time.time() * 1000))
        string_to_sign = f"{timestamp}\n{secret}"
        hmac_code = hmac.new(
            secret.encode("utf-8"),
            string_to_sign.encode("utf-8"),
            digestmod=hashlib.sha256,
        ).digest()
        sign = urllib.parse.quote_plus(base64.b64encode(hmac_code))
        url = f"{webhook}&timestamp={timestamp}&sign={sign}"
    else:
        url = webhook
    
    payload = {
        "msgtype": "markdown",
        "markdown": {
            "title": "FTSeek 新闻策略复盘",
            "text": report,
        },
    }
    
    try:
        resp = requests.post(url, json=payload, timeout=10)
        if resp.status_code == 200:
            result = resp.json()
            if result.get("errcode") == 0:
                logger.info("✅ 复盘报告钉钉推送成功")
                return True
            else:
                logger.error(f"❌ 钉钉返回错误: {result}")
                return False
        else:
            logger.error(f"❌ 钉钉 HTTP {resp.status_code}")
            return False
    except Exception as e:
        logger.error(f"钉钉推送异常: {e}")
        return False


# ============================================================
# 主流程
# ============================================================

def run_review():
    """执行盘后复盘"""
    from app.factors.strategy_review import get_review_engine
    
    engine = get_review_engine()
    
    logger.info("=" * 70)
    logger.info(f"FTSeek 新闻策略盘后复盘 | {datetime.now().strftime('%Y-%m-%d %H:%M')}")
    logger.info("=" * 70)
    
    # Step 1: 自动评估到期的策略
    logger.info("检查待评估策略...")
    
    # 获取价格函数
    def get_price_fn(code):
        prices = get_latest_prices([code])
        data = prices.get(code, {})
        return data.get("current", 0), data.get("high", 0), data.get("low", 0)
    
    outcomes = engine.check_pending_assessments(get_price_fn)
    
    if outcomes:
        logger.info(f"自动评估完成: {len(outcomes)}条")
        for o in outcomes:
            record = engine._records.get(o.record_id)
            if record:
                logger.info(
                    f"  {record.code} | {o.outcome_label} | "
                    f"PnL={o.actual_pnl_pct:+.1f}% | {o.assessment_details}"
                )
    
    # Step 2: 生成日报
    report = engine.generate_daily_report()
    
    # Step 3: 保存到文件
    output_file = BASE_DIR / "logs" / f"strategy_review_{datetime.now().strftime('%Y%m%d')}.md"
    with open(output_file, "w", encoding="utf-8") as f:
        f.write(report)
    logger.info(f"报告已保存: {output_file}")
    
    # Step 4: 推送到钉钉
    success = send_review_to_dingtalk(report)
    
    # Step 5: 输出统计
    stats = engine.get_stats_summary()
    logger.info(f"\n📊 累计统计:")
    logger.info(f"  总信号: {stats['total_signals']}")
    logger.info(f"  胜率: {stats['win_rate']:.0%}")
    logger.info(f"  方向准确率: {stats['direction_accuracy']:.0%}")
    logger.info(f"  平均盈亏: {stats['avg_pnl_pct']:+.1f}%")
    
    if stats['suggestions']:
        logger.info(f"\n💡 迭代建议:")
        for s in stats['suggestions']:
            logger.info(f"  {s}")
    
    return success


if __name__ == "__main__":
    success = run_review()
    sys.exit(0 if success else 1)
