#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""美股数据配置管理器 (SSOT - 已迁移至 unified_config.yaml)"""

import logging

from config.config_center import get_config_center

logger = logging.getLogger("ftseek.us_config")

_config_center = get_config_center()

class USDataConfig:
    def __init__(self):
        self._config = _config_center.get('data_sources.us', {})
        logger.info(f"[USDataConfig] 配置已加载: data_sources.us")

    @property
    def sources(self):
        return self._config.get('sources', [])

    def is_enabled(self, source_name):
        for source in self.sources:
            if source['name'] == source_name:
                return source.get('enabled', False)
        return False
