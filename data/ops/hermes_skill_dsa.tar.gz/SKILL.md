---
name: deep-stock-analysis
version: 0.97
description: >-
  美股个股深度分析管线：盘前多渠道扫描 → 20 维数据采集 → LLM 多空辩论（分析师 + 证伪官）→ 信号门禁 →
  写 FTSeek playbook_instructions → 盘后复盘与策略记忆累积。
  用于：对指定标的做 KO 级深度分析（该股独有论据 + 三层因果链 + 具体价位 + 机器可核销失效条件）、
  全市场广度扫描找机会、盘后复盘与论据级 IC 累积。
  不用于：事件驱动的宇宙外标的发现（那是 FTSeek 仓内 UE `scripts/llm_universe_scan.py` 的职责）、
  退出参数调参（FTSeek 侧冻结）、实盘下单（四锁闭合，仅 sim）。
  入口 `scripts/pipeline.py`（必须用 `/opt/ftseek/FTSeek-US/venv/bin/python3.11`）。
  版本史见 `references/CHANGELOG.md`；参考文档路由见 `references/INDEX.md`。
metadata:
  author: Hermes Agent
  python_env: /opt/ftseek/FTSeek-US/venv/bin/python3.11
---

# 深度股票分析管线

## 何时使用

- 用户要求对某只股票做深度分析
- 用户要求扫描全市场找机会
- 需要KO示例级别的分析报告（独有论据+因果链+具体价位）
- 需要全市场广度扫描（FTSeek screener只从watchlist筛选）

**DA吞吐量+盘中SILENT Bug**: 见 `references/da-throughput-and-silent-bug-20260714.md` (候选上限/触发率41%/IC归属错误/intraday-diagnose SILENT吞消息)
**幻觉检测基础设施**: 见 `references/hallucination-detection-infrastructure-20260711.md` (3层防护2层未接线, 5项迭代修复路径, 幻觉模式分类)
**📚 参考文档路由**: 68 份 reference 的分类索引见 `references/INDEX.md`; 已闭环 Pitfalls 全文见 `references/pitfalls-closed-archive.md`; 版本史见 `references/CHANGELOG.md`。

**换模型 A/B（问"换个模型能不能提升指令/标的质量"时先读这条）**: 输入可逐字节复刻 ——
`/opt/ftseek/FTSeek-US/data/da_checkpoint/<date>/<SYM>.raw.json` 里的 `user_prompt` 就是当年真实发送的正文，
SYSTEM_PROMPT 静态可取。回放器在 FTSeek 仓 `scripts/da_model_ab_replay.py`（抽样按日分层、逐行落盘、
输三率：有效卡/可达/命中）。生产参数是 temp 0.0 / max_tokens 3000 / json_object / thinking 开；
**GLM 系思考 token 计入 completion 预算，必须抬到 16000**，否则 3000 被烧光只返回 `{\n`（这不是能力结论）。
改模型前必查 `/models` 实测可用清单（配置里写的不是可用清单），预注册判据与完整陷阱见
`skill_view('llm-prompt-engineering')` 的 model-ab-replay-protocol 参考。

**能力边界**: DA是per-stock垂直管道，不具备跨资产/宏观事件驱动推理。5个结构性缺口+代码证据见 `references/capability-boundary-cross-asset-reasoning-20260714.md`。判断DA是否具备某能力时，看实际喂给LLM的数据(非prompt要求)。

**推荐证据卡 v1 (2026-11-09, record-only)**: `scripts/recommendation_evidence.py` 将 prompt 可见新闻的稳定
`evidence_id/story_id`、发布时点、VIX/指数/行业口径、价格方向对齐、挑战者反证和证据缺口统一写入
analysis、bridge candidate 与 `raw_instruction.recommendation_evidence`。论点只按完整ID/URL/完整标题精确链接，
无法链接明确 `UNLINKED`，不做模糊语义硬匹配，不据此改方向。消费者为 FTSeek
`scripts/da_recommendation_evidence_replay.py`；证据卡异常只写 `status=ERROR`，不得让候选分析失败。
本字段不参与 prompt、Signal Gate、admission、仓位或执行；离线报告不得被解释为方向/费后 edge 已改善。

**LLM推理≠预测**: 更全面的macro分析提升分析质量但不改变IC。从"看到油价数据"到"预测半导体会跌"缺的是历史验证层(事件回测引擎)，不是LLM推理能力。详见上述reference的"LLM关联推理≠预测"段。

**IC归属规则**: voting_llm IC=-0.067是已废弃旧系统的指标，讨论DA能力时不可混用。
**⚠️ 现状更正 (2026-09-06)**: DA IC **已不再"待验证"** —— `scripts/alpha_backfill.py` 已长期在跑，`scripts/claim_ic_cache.json` 最近更新 2026-09-05，`strategy_id=deep_analysis`、`total_samples=1805`、101 个 claim_type，**overall_ic_t1 = −0.0061 (≈0，无预测力)**。快照基数也从当时的 334/287 涨到 `signal_snapshots.db` 里 DA **1,844 条 / 1,808 条有 T1**（UE 251 条）。结论：DA 的方向 alpha 在论据级 IC 上测不出信号，与 pitfall `#75`(自评 conf 零预测力) 同向；不要再用"样本不够"解释 IC 缺失。

**用户交易哲学**: "不预测，识别。趋势明朗中抓住多赚并能抽身，在不确定性波动中落袋为安。" DA的alpha来源不在预测方向，在识别regime+退出纪律。macro reasoning的正确用途是判断不确定性高低→调整退出策略，不是预测涨跌。
**⚠️ "EOD 86% WR" 已过期 (2026-09-06 实测, `data/ftseek_us.db`)**: DA 已平仓 **n=308 / 净 −$302.57 / 胜率 54.5%**（口径 `source_type='PLAYBOOK_SIM' AND decision_id LIKE 'DA-%' AND exit_time IS NOT NULL`，金额 `COALESCE(pnl_net, realized_pnl)`）。退出结构：
- **利润引擎** `SL_TRAIL_LOCK` n=75 / 93.3% WR / **+$3,347**；`PRE_CLOSE_EXIT` n=28 / 71.4% / +$750；`TAKE_PROFIT` n=1 / +$444；`SL_BREAKEVEN` n=105 / 62.9% / +$266。EOD 类合计 n=32 / **+$552**（62.5% WR，不是 86%）。
- **死单池** n=62 / **0% WR** / **−$3,850**：`SL_INITIAL` −$2,380(n=13) · `MFE_STALL_EXIT` −$752(n=21) · `TIME_EXIT` −$718(n=28)。
- **窗口敏感**：DA ≥2026-08-06 为 n=181 / **+$557.01** / 64.6% WR；UE 全史 n=65 / −$400.11 / 53.8% WR。
- 权威产物（含分方向、77 天窗）见 FTSeek 仓 `data/exit_rule_expectancy_latest.json`（由 `scripts/exit_calibration_refresh.py` 生成，`source_filter=PLAYBOOK_SIM`）与 `data/exit_scorecard_latest.json`。**引用退出结构请读产物，不要重跑 ad-hoc SQL。**

**吞吐量瓶颈(2026-07-14) — ⚠️ 建议部分已失效**: DA运行5天(7/9-7/13)，17条instruction→7触发→8执行(win=2/loss=4)。三个限流点: ①pipeline scan_limit=10/top_n=5/top_bearish[:2]=最多7只进深度分析 ②触发率41%(入场区间太窄) ③低conf(25-35%)导致小仓位。详见上述reference的"当前DA吞吐量真实数据"段。
**现状更正 (2026-09-06)**: 限流点①的解法 **`top_bearish[:2]→[:3]` 已作废** —— 2026-07-18 用户裁**废除多/空配额**，改为合并两桶按 conviction 统一择优：`scripts/pipeline.py:446-461`（`conviction = score`(多) / `10-score`(空)，取前 `top_n+2`，多空占比由信号强度决定）。不要再按"提高 bearish 配额"提吞吐建议。
**供给现状 (≥2026-08-25, `playbook_instructions`)**: DA **BUY 91 / SELL_SHORT 11 / SKIP 23**（n=125，`decision_id LIKE 'DA-%'`）；UE **SELL_SHORT 29 / BUY 19 / SKIP 8**（n=56，`decision_id LIKE 'universe_expansion%'`）。SHORT 供给仍结构性偏少，但瓶颈已从"候选配额"移到"信号本身给不出看空信念"。
## 与FTSeek的分工

| 功能 | FTSeek已有 | 本skill做 |
|------|-----------|----------|
| 基本面 | FundamentalProvider(多源) | Finnhub直接调API(133指标) |
| 分析师评级 | ❌ | ✅ Finnhub recommendation |
| 内部人交易 | InsiderProvider(SEC Form4) | ✅ Finnhub insider-transactions |
| 异动信号 | ❌ | ✅ 3维异动(技术/资金/衍生品) |
| 社区情绪 | Reddit/HN | 富途stock_feed |
| 市场扫描 | watchlist内 | 全市场涨跌量榜 |
| 分析引擎 | LLM辩论(9次调用) | LLM合成(1次调用,秒级) |
| IC追踪 | signal_ic_tracker | ❌ 输出ic_snapshot格式供FTSeek |
| entry/SL/TP | instruction_generator | ❌ 不算(交给FTSeek) |
| 退出规则 | _check_playbook_exit_rules | ❌ 输出exit_meta格式 |
| 执行下单 | _submit_order | ❌ 输出voting_result格式 |

## 架构

```
Signal → Filter → Output → Execute → Result
市场扫描   筛选    LLM分析  4种适配   FTSeek接管
                   (qwen)   格式输出  (执行/退出/IC)
```

## 模块

| 文件 | 职责 | 依赖 |
|------|------|------|
| config.py | 路径/密钥/模型配置(唯一定义) | 无 |
| data_collector.py | 18数据源采集+3个多渠道collect(v0.23) + market_context+industry_peers(v0.39) (Finnhub+OpenD+富途HTTP) | config |
| market_scanner.py | 全市场多渠道扫描+四信号评分+板块轮动+操作分桶 (v0.23) | data_collector |
| llm_synth.py | 2模型辩论合成KO示例级分析(qwen分析→deepseek挑战, v0.39) | config |
| deep_analyzer.py | 8维分析+评分(LLM可注入,可降级) | llm_synth(可选) |
| adapter.py | 4种FTSeek接口格式+conditions合法枚举映射 | 无(纯函数) |
| ic_writer.py | IC写入FTSeek signal_snapshots.db+论据级claim_type分类 | config |
| alpha_backfill.py | Alpha IC(剥离SPY beta)+论据级IC统计+claim_ic缓存 | ic_writer,FTSeek(只读) |
| strategy_memory.py | 策略记忆库(pattern/symbol/lesson三表) | config |
| signal_gate.py | 信号质量门禁+策略推荐(7维评估，含论据有效性检查) | strategy_memory,alpha_backfill |
| feedback_loop.py | 盘后自动复盘→更新memory→提取教训 | strategy_memory |
| pullback_stats.py | 前序回吐率shadow: 大涨日(>+5%)后3/5/10日守成率+均涨, 纯K线零LLM; 产出pullback_shadow.json被llm_synth注入(≥3样本才展示); DA cron Step2每日刷新 | get_kline.py |
| pipeline.py | 5阶段编排(lazy import) + Obsidian per-symbol归档 | 各模块 |

## 关键陷阱 (Pitfalls)


**仍生效的原则（源自下方已闭环条目，全文见归档）** — 这几条不是历史，是现役设计的"为什么":

- `#75` **LLM 自评 confidence 零预测力**（三系统 r=−0.211/−0.073/−0.038）→ 门禁改用**辩论一致度** `decision_conf`，不用模型自评档位。
- `#70` **bridge 的 `entry_price` 是 LLM 建议价，不是实时价** → 执行端必须 re-price；锚定昨收价的入场带开盘即失效。
- `#49` **数据真实性验证方法**："这种扫描和分析是真实的吗？不要虚构" —— 输出数字必须能在输入材料中命中出处（现役实现 `_verify_sourced_numbers`）。
- `#68` **Ponytail + Karpathy 原则**：最简方案优先，复用既有设施，不新建平行层。
- `#76` **计划-执行四大断裂**（价格单点 vs 区间 / 趋势生成≠触发 / 范围永不过期 / SL-TP 联动断裂）—— 现役 `entry_archetype`+`confirmation`+`chase_cap_price` 结构化语义即为治此断裂。
- **`--format json` stdout 契约污染（2026-10-12 实锤, 已修）**：llm_synth 瞬态故障重试的 3 个 print 原缺 `file=sys.stderr`，重试分支平时无触发=无声潜伏；10/12 LLM API SSL 握手超时首触发 → `[llm_synth]` 行混入 stdout 头部 → carrier (`da_main_carrier.py`) `json.loads` 首字符即败 exit 1 告警。**parse 失败 ≠ 产物丢失**：pipeline.py 运行中已直写 playbook_instructions（`DA-<ts>` decision_id 时间戳落在运行窗内可证），carrier 另存原始 stdout 到 scratch `da_pipeline_out_YYYYMMDD.json` — 恢复只需剥首个 `{` 前缀重 parse 出汇总，不必重跑 39min 管线。修法=源头 print 转 stderr（AST 全文件扫描验证：仅剩 L2813 standalone `__main__` 出口的 stdout print，管线不可达），不在 carrier 加"找第一个 {"解析补丁（源头过滤>层层校验）。类级教训：重试/降级/容错分支的诊断 print 必须 stderr — 潜伏 bug 只在分支首次触发时暴露（同 ftseek-intraday-cron-diagnosis "硬编码只在新分支首次触发时暴露"模式）。

> **已闭环历史条目（58 条 ✅，v0.4–v0.52 时代，约 60,526 字符）已迁至** 
> `references/pitfalls-closed-archive.md`（逐字保留、原编号不重排、带目录与行号回溯）。
> 下方只保留**未闭环/仍需注意**的条目（🔴 未修 / ⚠️ 注意 / 无标记的现役机制记录）。

### -6. ✅ 主链零交易日守卫 + `ic_writer` 假日表漏劳动节 — 2026-09-06 立案, 2026-09-07 修复 (v0.76, 用户裁「按建议执行」= A+B)
**一句话**: DA 会在美股假日照跑、照写陈旧指令，并且把 IC 快照的 `trade_date` 写成非交易日 ⇒ 该批样本**静默永久退出 IC 统计**。仓内本有权威交易日历，DA 没接，反而自己维护了一份更弱的平行假日表。

**✅ 已修 (2026-09-07, v0.76)**: A+B 均落地并通过 52 条契约测试 —— 详见下方「已执行修法」与「四条现役不变量」；实现细节与验证全文见 `references/CHANGELOG.md` v0.76。**下方事实链原样保留作根因取证。**
**归档待办**: 本条已 ✅，按 Pitfalls 惯例（正文只保留未闭环条目）应在 9/7 夜实弹验证通过后迁 `references/pitfalls-closed-archive.md`（可再减 ~5.8K 字符）；验证未完成前暂留原位。

**事实链（2026-09-06 逐层实测到代码/DB）**:
1. **主链零守卫**: `scripts/pipeline.py:1567 main()` 从 argparse 直接构造 `Pipeline(...)`，无任何日期/假日判断。全 skill `grep -rn "holiday_calendar\|is_trading_day\|get_holiday_calendar\|is_us_holiday" scripts/*.py` → **零命中**。cron `e0d574cc1a3c`（`0 20 * * 1-5`）**只排周末**，prompt Step1-4 全文也没有"假日跳过"指令。
2. **对照组都接了仓内 SSOT**: FTSeek `app/utils/holiday_calendar.py`（Futu `request_trading_days` 权威 + 硬编码 2026-2028 降级；2026 年 11 个假日，**含 `2026-09-07 Mon` 劳动节**）。
   - UE `scripts/llm_universe_scan.py:152 _is_us_trading_day_today()`（fail-open，3 处消费 1765/1989/2964）。其 docstring 把理由写得一字不差：「cron `30 20 * * 1-5` 仅排周末, 不排美股节假日 → 靠本守卫避免假日白跑 LLM/写陈旧指令」。
   - FTSeek `app/playbook/pipeline.py:523 _is_trading_day_today()`（4 处消费：967 盘前生成 / 2106 / 2964 / 3524 auto_execute）。
3. **🔴 DA 自己维护了一份更弱的平行假日表**: `scripts/ic_writer.py::_get_et_trade_date()` 内 `known_holidays = {(7,3), (7,4), (12,25), (1,1), (11,26), (11,27)}` —— **劳动节不在内**；MLK / 总统日 / 耶稣受难日 / 阵亡将士日 / 六月节 / 哥伦布日 / 退伍军人日**也都不在**。
   9/7 是周一 ⇒ 周末前推分支不触发 + 假日表不命中 ⇒ **返回 `trade_date = 2026-09-07`（非交易日）**。这正是该函数 docstring「根因修复2」自述要治的病（原文：「周末/假日运行时 trade_date=非交易日 → FTSeek backfill 找不到该日的日K线 → IC 永远不回填」），**只是它自己的表没覆盖到**。

**后果分级**:
- (a) **白跑**: 30-40 只 × 30-60s LLM ≈ 20-40 分钟，分析的是上一交易日陈旧行情 → 浪费 token 与时延。
- (b) **写陈旧指令**: 直写 `playbook_instructions`，`date=9/7`，entry/SL/TP 全部锚上一交易日收盘。
- (c) **🔴 IC 快照静默丢样**: `trade_date=9/7` 无日K ⇒ FTSeek `backfill_forward_returns.py` 填不上 `close_t0/t1` ⇒ 恒 NULL ⇒ 该批 snapshot **永久退出 IC 样本且不报错**。注意 `scripts/alpha_backfill.py:281` 找 SPY 只往前搜 `[0,-1,-2,-3]`（刻意避免前视偏差）⇒ SPY 侧会"自愈"到 9/4，但标的侧 `close_t0` 仍 NULL，alpha 照样算不出 —— **是丢样，不是算错**，别误报成数据污染。

**误交易风险已排除（两道闸实测在场，不要夸大）**: `run_playbook_auto_execute` 非交易日直接 return（`app/playbook/pipeline.py:3524`）；取指令走 `get_instructions_by_date` 严格 `WHERE date = ?`（`app/playbook/db.py:602`）⇒ 9/7 的陈旧行对 9/8 **不可见**，不会漏到次日执行。

**为什么 DB 里查不到历史证据 —— 因为还没轮到**: DA 7/9 上线，`holiday_calendar` 的 2026 假日表在 7/9→9/6 区间**零个假日**（7/3 在上线前，下一个就是 9/7）⇒ **2026-09-07 是本缺陷的首次实弹**，且恰逢本 skill `version 0.75` 首生效夜。实测印证：`signal_snapshots` 里落在美股假日的行只有 5 条 `voting_llm`@`2026-07-03`，**DA 零条**（不是没问题，是还没发生）。
**顺带体检（避免误判）**: DA 现有 36 条无 T1 快照 = 33 条 `2026-09-04`(Fri) + 2 条 `08-13` + 1 条 `07-30`。**9/4 那 33 条是正常的**（周五的 T1 = 9/8，因 9/7 休市），不是本缺陷产物；只有 3 条是真滞后。

**已执行修法（2026-09-07 用户裁「按建议执行」= A+B；C「只在 cron prompt 加 Step 0」被否 —— 提示词守卫不如代码守卫可靠，UE 的先例正是代码守卫）**: 新增薄适配层 **`scripts/trading_calendar.py`**（纯函数、零 IO 副作用），三层降级、上层优先、每层独立 try、任一层给出答案即返回：**L1 `ftseek_ssot`**（仓内 `app.utils.holiday_calendar`，权威源）→ **L2 `rule`**（按 NYSE 规则**现算**，不复制任何日期表：Good Friday 走复活节算法、固定日假日 observed 平移、元旦落周六 NYSE 不补休特例）→ **L3 `legacy`**（`ic_writer` 原 6 条表逐字保留为兜底）。API：`resolve(d)->(bool, layer)`（`lru_cache(512)`）/ `is_us_trading_day` / `latest_trading_day(d, max_back=12)` / `rule_holidays(year)` / `today_et()`。**A** = `ic_writer._get_et_trade_date()` 委托 `latest_trading_day()`（原「周末前推」+「假日表前推」两套分叉合并成单一循环；适配层不可用则退回纯周末前推 + stderr 留痕）。**B** = `pipeline.main()` 在 `Pipeline(...)` 构造**之前**插守卫（晚一步就已开始扫描），非交易日 → stderr 消息 +（`--format json` 时吐 `{"skipped":true,"skip_reason":"NON_TRADING_DAY",...}` 保 JSON 契约，cron Step4 按 JSON 解析不能吐裸文本）+ exit 0；新增 `--force` 逃逸口（人工假日复盘/调试用，**cron 不传**）。

**⚠️ 改这块前必读的四条现役不变量**（全部由契约测试钉住，违反即红）:
1. **失败语义 = fail-open**：三层全灭 / 日历异常 → **视为交易日 → 照跑**，与 UE `llm_universe_scan._is_us_trading_day_today()` / FTSeek `app/playbook/pipeline._is_trading_day_today()` 同口径。**不要改成 fail-close** —— 那会在日历故障日静默停掉整条 DA 主链，代价远大于白跑一轮。
2. **层序不可调换 + 禁止往 L3 `legacy` 加日期**：只有 L1 知道临时全国哀悼日那类无规则可算的休市；往 legacy 补日期 = 重新制造平行真源（它**已知漏劳动节**，正是本次修复的对象），要补请改 L2 规则。
3. **判日必须用 `today_et()`，不能用 `date.today()`**：容器时区 CST(UTC+8)，CST 周一凌晨 = ET 周日晚（实测 2026-09-07 06:47 CST：`date.today()`=09-07 而 `today_et()`=09-06）。同 pitfall `#28`「时区 bug 后必须 grep 全模块扫漏网」。
4. **哥伦布日 / 退伍军人日 / 12-24 圣诞夜是交易日**（NYSE 照常开盘，12-24 为提前收盘 13:00 ET）—— 它们是联邦假日、**债市**休市；拿债市日历套股市是本类修复最典型的复发方向。

**契约测试**: FTSeek 仓 `tests/test_da_trading_day_guard.py`（52 条）—— L2 规则层 2026-2028 **逐日精确** / L2 与仓内 SSOT 离线表**跨仓一致**（唯一允许差异 = 2026-12-24）/ 上述四条不变量 / `latest_trading_day` 跨周末+假日前推 + 2026 全年穷举 / ic_writer **不得再持有假日表**（AST 级反平行真源闸）/ 守卫顺序·`--force`·JSON+text 双契约。跑法 `cd /opt/ftseek/FTSeek-US && ./venv/bin/python -m pytest tests/test_da_trading_day_guard.py -q`。
**纪律核查（数据口径七律#2）**: A 改变 `trade_date` 口径 ⇒ 核查影响面 = **历史 0 条**（`signal_snapshots` 落在美股假日的行仅 5 条 `voting_llm`@2026-07-03，DA 零条）⇒ **无需基线切分、不追溯改写**，结论记入 `ic_writer._get_et_trade_date()` docstring。
**回滚**: 删 `scripts/trading_calendar.py` + `git -C /root checkout -- .hermes/skills/deep-stock-analysis/scripts/{ic_writer,pipeline}.py`。
**🔶 残留缺口 → 已于同日 07b 补齐**: DA cron `e0d574cc1a3c` **不是裸调 `pipeline.py`，而是四步 LLM agent prompt**（Step1 取 watchlist → Step2 `pullback_stats.py` 刷新回吐率 shadow(~2min) → Step3 `pipeline.py --mode full --top 5 --symbols "$SYMBOLS" --format json` → Step4 出摘要）。**代码守卫只覆盖 Step 3** ⇒ 假日仍会白跑 agent 会话 + Step1 + Step2。**已补 Step 0**（经 `hermes cron edit --prompt` 落地，prompt 1838→3335 字符，除 prompt 外零字段变化）：判定仍由 `/root/.hermes/skills/deep-stock-analysis/scripts/trading_calendar.py` 给出 —— exit 0 继续 / exit 3 **立即终止不跑 Step1-3** / 命令报错或超时则 **fail-open 继续**并在摘要首行留痕；Step 4 另加「若 JSON 含 `"skipped": true` 则**不得编造** candidates/analyses 数字」；prompt 内明写「本 cron 任何情况下不得给 `pipeline.py` 加 `--force`」。这与被否的 C 案（**纯提示词**判断假日）不同：真源仍是代码，prompt 只决定是否继续 Step1-2。
**⚠️ 写 cron prompt 的坑（本批实测踩到，被既有护栏判红）**: prompt 里**不要用裸 `scripts/xxx.py`** 指代 skill 侧脚本 —— FTSeek 仓 `tests/test_hermes_job_prompts.py::test_referenced_repo_scripts_exist` 会把裸 `scripts/x.py` 当成**仓库相对引用**去 `/opt/ftseek/FTSeek-US/scripts/` 找，找不到即红（其正则 `(?<![/\w])scripts/…` 特意排除绝对路径）。必须写全路径 `/root/.hermes/skills/deep-stock-analysis/scripts/xxx.py`。**纪律：改任何 hermes cron prompt 后必须跑 `tests/test_hermes_job_prompts.py`**（cron prompt 不受版本控制、不被 pytest 覆盖，是活体调度里最没有护栏的一环）。
**⚠️ 本条先前结论已被推翻（2026-09-07 同日扩批核实）**: 原写「两条 intraday-diagnose cron（`36cc015242ee` / `5513c8e94b06`）无假日守卫」——**错**。二者其实都有守卫（`ops/hermes/intraday_diagnose.py:45` / `intraday_diagnose_late.py:53` subprocess 调 FTSeek 仓 `scripts/trading_day_check.py`），但**判据是死的**：该工具 docstring 自称「exit code 始终 0，按 stdout 判断」，而全仓 **9 个消费方无一读 stdout、全部读 exit code** ⇒ 假日分支恒不触发。这是比本 pitfall 更大的一族病灶，已在 FTSeek 仓侧根治（工具改为 exit 1 = 非交易日，一处修好 9 个消费方）；详见 FTSeek 仓 `handoff.md` `### 2026-09-07b` 与 `tests/test_trading_day_check_contract.py`。**教训升级**：不只是「仓内已有权威表就别硬编码副本」，还要加一条 —— **工具的 docstring 契约与全部调用方的实际读法必须对账**（本例 9/9 调用方与文档相反，且无人发现，因为失效方向是「照跑」而非「报错」）。**仓内侧顺带发现（已登记 handoff，本 skill 不改）**: FTSeek SSOT 在 **2026-12-24** 自相矛盾（离线 `US_HOLIDAYS` 列整休 vs Futu 权威路径返回 True）—— L1/L2 的**唯一**分歧日，测试已把范围钉死。
**完整实现细节、验证记录与顺带发现全文见 `references/CHANGELOG.md` v0.76**（本条只留现役不变量，不在正文重复版本史）。
**教训（可迁移）**: 仓外 skill 复制了一份仓内已有的日历/枚举/口径真源 ⇒ 仓内 SSOT 更新时 skill 侧不会跟着更新，漂移是必然的。**同类风险点已核实还有一处**：`#3`（conditions 27 个合法枚举）—— 仓内真源是 `app/playbook/condition_taxonomy.py`（枚举表 + 中文映射 + 「动量类/趋势类」分组，被 `exit_engine.py` 的 `factor_exit_rules` conditions 匹配消费），而 DA 侧 `scripts/adapter.py:59+ _map_bullish_conditions()` 把 `above_ma20` / `macd_golden_cross` / `volume_expansion` / `rsi_oversold` / `bollinger_upper` / `revenue_growth_high` / `roe_high` 等**逐个硬编码成字符串字面量**。仓内新增或改名一个 condition，DA 侧不会报错、只会静默匹配不上退出规则。**凡是"仓内已有权威表"的东西（交易日历 / condition 枚举 / 时区口径），skill 侧一律 import，不要硬编码副本。**

### -5. dc校准链: 历史首读数作废, 从8/14重新攒 (2026-08-14 用户裁)
**组件**: `dc_calibration_collector.py` → `dc_calibration_samples.jsonl`, 盘后cron Step1.6。三源JOIN: da_gate_decisions.jsonl × playbook_instructions × signal_snapshots.db。
**用户裁定**: DA/UE prompt 8/14 升级 (P1/P2/P3) = 新测量系统, 历史样本不可比 → `MIN_TRADE_DATE="2026-08-14"` 起点闸, 首跑 n=379 混合窗口读数全部作废, 样本文件已清空重攒。**若未来再改 prompt, 此日期同步前移, 旧样本作废重攒。**
**最大坑(已修)**: PASS/WARN 的 instructions.fwd_return 是 **entry→close_t1(含日内段)**, BLOCK 无成交价只有 **close_t0→close_t1**。两基线混算会把 regime 当日日内涨幅(+2.06pp, 与两源差异 corr=0.999)记在 PASS 头上 → 假信号。主口径统一 close0→close1(snapshot源), entry基线仅副列归因。
**结构事实**: BLOCK 行大多 direction=SKIP(分析师自己判SKIP, gate映射BLOCK) — 无方向不可方向化, 天然排除; 真正"gate否决方向候选"的对照样本很稀(8/14仅RDTL 1条) → PASS-vs-gateBLOCK 校准攒样慢, 属结构必然。
**纪律**: 攒到 n>=100 且双窗同向|差|>=15pp 才列候选; 禁止用不足样本改门禁。**2026-09-23 起加一条: n 与双窗只在同 `prompt_hash` 桶内计数** (样本行已落指纹, 报告 ⓪ 段分桶) —— 指纹切换=换测量系统, 跨桶混算会把不同届 AI 的表现平均掉 (实测桶间差 mean 1.7pp+)。"无指纹(旧样本)"桶只作历史参考, 不进裁决。
**2026-09-23 两处修复 (均可回滚)**:
- **配对补齐**: 同一 decision_id 在 playbook_instructions 可落两行 (分析日 executed=0 无 fwd / 执行日 executed=1 有 fwd), 按 `(date|symbol)` 取指令会取到分析日行 ⇒ 已成交却「待T+1回填」永久挂账 (实测 08-31 4 笔)。修法: 指令索引补 decision_id 维度 + 「有 fwd > 已执行 > 日期更晚」确定性优选。效果: pending 6→2, 配对 212→216。
- **截留率口径**: 原 `mean(strat/close)` 被小分母笔拉飞 (均值 0.47 / 中位 0.11 / Σ/Σ 0.19), collector ⑥ 与 `ops/hermes/dual_caliber_report.py` 同批改为 Σ/Σ 为主 + 中位。历史 state 里 2026-09-23 及以前的 capture 是旧口径, 不与新值比较。
**回滚**: 删 collector + samples.jsonl + cron Step1.6。

### -4. 死胎攒样器上线 (2026-08-14, 入场质量优化的唯一前置)
**组件**: `deadfetus_collector.py` → `deadfetus_samples.jsonl` (skill scripts目录)。按 trade_records.id 去重幂等, 漏跑自愈; 只记 8/4(F2快照部署日)后有 ts_ctx 的成交。
**挂载**: 盘后复盘 cron `3a6c83bbd84c` Step 1.5 (feedback_loop 之后, 纯记账失败不阻塞)。
**标签口径**: DEAD=MFE<0.3% / WIN=MFE>=1.0% / MID其余 (mfe_pct正数口径)。
**裁决协议**: 攒样只记账, 裁决在 `deadfetus_adjudicator.py` (cron Step 1.7)。预注册判据写死: n>=100+双窗gap≥15pp同向+桶量≥10+单调形状(Spearman|rho|>=0.5)+误杀检查(盈利占比>40%且盈利额>净亏→降级)+冻结源检查(桶最新样本落后全池>14天→降级FROZEN_SOURCE, 2026-10-06加: REENTRY 9/17已裁关但历史26笔随窗切分漂移在n=390凑齐双窗门槛回声触发, 停更通道无未来样本可保护, 通道重启须重新预注册)。GATE_CANDIDATES_FOUND 破例推送, 走DEB不直接进门禁。collector 含 chase_pct 字段(实际价 vs opportunity_scan 计划价; UE/REENTRY→null, 可从历史scan重建)。首批 n=68 死胎率42.6%, chase 非单调(回踩62.5%最高/重追22.2%最低) — 单调检查专拦此类伪候选。n<100 禁决策。
**回滚**: 删 collector+adjudicator+jsonl/json+cron Step1.5/1.7。
**背景衔接**: 见 Pitfall -3 共同推论 (盈亏杠杆在入场质量, 非TP/SL/regime)。

### -3. 两大实锤定论: TP/SL死参数 + regime弱相关 (2026-08-14, 勿再浪费精力)
**定论A — TP/SL是死参数 (重放实锤)**: 54笔(8/4起)×真实1min路径重放, ATR自适应TP/SL(V1)与纯be/dd重放 **54/54逐笔相同**。三重验证: ①实际MFE最高2.99%/MAE最深4.0%, 无一笔触碰-5%SL或+7.5%TP区间 ②日内完整路径(不受提前退出截断)顺向波动达+5%的 **0笔**, 达+7.5%的 **0笔**, 中位仅 **0.64%** ③V1 SL(1×ATR%)绑定笔数0/54。结论: be/dd(0.5%保本+0.8%回撤锁利)机制比任何TP/SL都先触发, TP/SL从不绑定, 调它们零效果。**勿再设计任何TP/SL自适应/模板优化。** 真实出场由保本/锁利/超时驱动。脚本: `scripts/exit_replay_shadow.py`, 数据: `data/analysis/exit_replay_20260814.json`。
**定论B — regime弱相关 (方差分解)**: 清洁窗口n=248, regime仅解释 **1.5%** 单笔收益波动(eta²), 个股特质+执行主导98.5%。direction单独0.09%, regime×direction联合2.78%(交互增量仅+1.15%)。各regime内部标准差1.07-1.84%/极差6-11%, 同股跨regime结局天差地别(TSM risk_on -0.1% vs cautious -0.08%)。cautious-SHORT WR 60.9%(n=23) vs 其他14.3%(n=21)看似大, 但 **Welch t=1.58不显著** → 只是候选非已验证edge。**勿按regime放大/收缩仓位**(1.5%解释力撑不起); cautious-SHORT继续shadow攒样, n≥40且跨两周t≥2再谈加权。
**共同推论**: 盈亏杠杆不在TP/SL参数、不在regime分类, 而在 **入场质量(死胎过滤)**——那是98.5%波动里唯一未被be/dd覆盖且可优化的部分。

### -2. 新闻层升级 P1-P3 上线 (2026-08-14)
**P1 数据层**: `collect_finnhub_news()` (data_collector.py) — Finnhub company-news 7天窗+去重+模板垃圾过滤+ticker相关性过滤(top6, 摘要截断200字), 注册为 `news_v2` 独立维度(不动原富途标题源)。`llm_synth` 注入"Finnhub 新闻事实流"段。实测 CRM: 3条光标题→6条带摘要事实(含反面新闻"3 Reasons to Avoid CRM")。
**P2 schema层**: 分析师输出新增 `execution_plan.tripwires[{metric,threshold,deadline,source}]` 硬要求≥2条全量化, 保留原 invalidation; adapter 两处透传(to_signal_score 经 llm_raw 全量流入 FTSeek metadata)。
**P3 验证层**: 挑战者v2 2a条加反虚构硬规(来源不明数字→missed_risks标注+my_score每处-1); 挑战者数据视图 FULL 白名单加"Finnhub 新闻事实流"。注意: 反虚构后验证(`_verify_sourced_numbers`→signal_gate扣分)早已存在(DEB-20260811/14), full模式对prompt全文regex提白名单→新闻摘要数字自动覆盖, 勿重造。
**回滚**: `DA_NEWS_V2=0` (采集返回空, 显示/白名单自然静默; P2 schema向后兼容无需回滚)。
**坑**: data_collector.py 模块级缺 `import re`/`datetime` → 模块级 re.compile 在 import 时 NameError, 已补。实弹 import 测试必做(py_compile 抓不到运行时缺失)。

### -1. 前序回吐率 shadow 链路上线 (2026-08-14)
**组件**: `pullback_stats.py`(计算) → `pullback_shadow.json`(合并写入,非覆盖) → `llm_synth.py _format_data_for_prompt` 末尾注入段(样本≥3才展示)。
**cron**: DA job `e0d574cc1a3c` Step2 每日盘前刷新, 失败不阻塞; Step4 摘要附一行注入统计。
**回滚**: `DA_PULLBACK_SHADOW=0` 或删 pullback_shadow.json + 删 cron Step2。
**纪律**: shadow 只注入证据不参与裁决; IC 验证(claim_ic 攒够≥30 spike事件对照)前不得进门禁。
**实测特征**: SNDK hold5d=69.4%/avg_fwd5d=+6.9%(强续涨, 独立复现回购"估值换锚"论点); UBER hold5d=0%(完全回吐); CRM hold5d=60%但avg_fwd5d=-0.68% → 守成率与均值会背离(单次大跌拉负), 双指标都保留。
**坑**: ①脚本输出全量覆盖会冲掉未刷新标的 → 已改合并写入; ②cron 的 $SYMBOLS 是单个逗号串 → 脚本已兼容拆分; ③无参时 fallback watchlist_manager(生产同款来源)。

### 0. 盘前快照三大实锤 (2026-08-11, v0.64 修复)
1. **get_market_snapshot 批量含任一无效代码(OTC/退市)→整批 RET=-1 全灭** — 必须分批(chunk=30)+失败二分重试隔离毒码。LIF 案例: 138只池子含 HNHPF → 全批空。
2. **单次批量 >~130 只返回空** (API 隐性上限)。
3. **get_stock_filter 的 change_rate 盘前时段恒为 0** (不反映盘前涨跌) — 涨跌榜在盘前无选股价值; 盘前异动只能靠 pre_change_rate 字段批量快照过滤。
4. 多渠道合并时 premarket 字段必须合并进已有候选 (LIF 先经 earnings_surprise 进池, premarket_movers 后命中只加渠道名不合并字段 → premarket_chg_pct 恒 0)。

### 1. futu-api F10 API不可用
> **Pitfall 0**: DA 18:00 cron扫描验证方法 + Feishu thread_id[99992402]投递失败 → 见 `references/da-cron-verification-20260713.md`
futu-api 10.05.6508的`OpenQuoteContext`**没有**`get_financials_statements`/`get_research_analyst_consensus`/`get_insider_trade_list`等方法。这些需要更新的SDK或`OpenUSContext`。**替代方案**: 用Finnhub HTTP API获取基本面/分析师/内部人数据。

### 2. signal_snapshots.db的created_at_snap约束
FTSeek的`signal_snapshots`表有`created_at_snap TEXT NOT NULL`约束。写入时必须提供此字段，否则INSERT静默失败(OR IGNORE吞掉错误)。完整必填字段: `decision_id/symbol/direction/created_at/trade_date/created_at_snap`。

### 3. conditions必须用FTSeek 27个合法枚举
FTSeek的`condition_taxonomy.py`定义了27个固定condition标签(如`above_ma20`/`revenue_growth_high`/`news_positive`)。输出不存在的标签(如`fundamental_strong`)会落default退出规则(trailing=False, max_hold=1d)，导致"分析对了但退出策略错了"。详见 `references/ftseek-interface-contract.md`。

### 4. FTSeek运行时DB的WAL模式
FTSeek进程以WAL模式持有signal_snapshots.db。外部进程写入时不要设`PRAGMA journal_mode=WAL`(会创建独立WAL不可见)，用默认模式即可。写入后FTSeek的cron `backfill_forward_returns.py`会自动回填T1/T5/T20收益。

### 5. Python环境
必须用`/opt/ftseek/FTSeek-US/venv/bin/python3.11`(futu-api 10.05.6508)。hermes venv有protobuf冲突，FTSeek venv默认python→3.8(旧版10.3.6308)。

### 23. ⚠️ IC归属错误 — 用旧系统IC否定新系统 (2026-07-14)
**场景**: 讨论DA是否具备macro关联推理能力时, 用IC=-0.067论证"DA没有预测力"。
**根因**: IC=-0.067是**voting_llm**(已废弃的3模型投票)的IC, 不是DA的。DA 7/9上线后是新链路(18维采集+2模型辩论+bridge直写DB), 当时还没有足够样本算IC。
**教训**: 用旧系统IC否定新系统潜力 = "用旧数据驱动新管线调优"同类错误。
**规则**: 讨论DA预测力前必须先查 `SELECT strategy_id, COUNT(*) FROM signal_snapshots GROUP BY strategy_id` 确认IC归属。
**⚠️ 现状更正 (2026-09-06)**: "DA 的 IC 是开放问题"这句**已过期**。DA 快照现有 **1,844 条 / 1,808 条有 T1**，`alpha_backfill` 早已在跑，`claim_ic_cache.json`(2026-09-05 更新) 给出 **overall_ic_t1 = −0.0061 ≈ 0**。归属纪律仍然有效（不要拿 voting_llm 的 −0.067 说 DA），但**结论已从"待验证"变成"论据级 IC 测不出方向 alpha"**。

### 24. ⚠️ 盘中诊断SILENT规则吞消息 (2026-07-14)
**现象**: intraday-diagnose cron (36cc015242ee) 正常运行, 每次输出完整状态报告(scan_loop/market_data/playbook/broker), 但最后一行加 `[SILENT]` → 系统检测到标记 → **抑制投递** → 用户从未收到盘中诊断。
**根因**: cron prompt的SILENT规则设计有矛盾。规则说"无新问题→[SILENT]", LLM把"系统正常运行"理解为"nothing new" → 加[SILENT], 但同时输出了完整status report → 违反"不可同时输出内容+[SILENT]" → delivery系统抑制整条消息。
**修复方向**: 盘中诊断cron应去掉SILENT规则——状态报告本身就是用户要看的内容, 不该被静默。或者改为"只在所有指标正常时静默, 有任何状态变化就报告(不加[SILENT])"。
**验证方法**: `ls /root/.hermes/cron/output/36cc015242ee/ | tail -5` → 检查最近输出是否以 [SILENT] 结尾。
**✅ 状态 (2026-09-06 复核)**: 已不再吞消息 —— 最近一次输出 `2026-09-04_23-30-23.md` 是完整状态报告(scan_loop/market_data/playbook/broker + 持仓行 + `日志 ERROR/Traceback: 0` + `服务: active`)，**结尾无 `[SILENT]`**。cron `ftseek-intraday-diagnose` 仍 enabled，schedule `*/30 21-23 * * 1-5`(CST)，另有 `ftseek-intraday-diagnose-late`(5513c8e94b06) `*/30 0-4 * * 2-6` 接力；周末无输出属正常。**注意两条 cron 都没有交易日守卫**，美国假日(如 2026-09-07 劳动节)仍会跑。

### 25. ⚠️ DA吞吐量瓶颈 — 候选数量上限和触发率 (2026-07-14)
> **⚠️ 本条的"提升方案"与"IC验证时间表"均已过期 (2026-09-06)**：多空配额已于 2026-07-18 废除，`top_bearish[:2]→[:3]` 无处可施；IC 验证也早已完成(结论见 #23 现状更正)。保留本条只为记录 7 月初的吞吐诊断方法与当时的限流点拆解。
**实测数据** (7/9-7/13):
- signal_snapshots: 334个DA记录, 287个有T1收益(足够算IC, 但还没跑alpha_backfill)
- Bridge文件: 每日3-4只候选
- Instructions: 17条 → triggered 7 → executed 8 (触发率41%)
- 主流瓶颈: ①pipeline scan_limit=10/top_n=5 限制候选数 ②入场区间太窄41%未触发 ③低confidence(25-35%)导致小仓位
**提升方案(不降原则)**: ~~scan_limit 10→15, top_n 5→8, top_bearish[:2]→[:3]~~ → **已作废**：`scripts/pipeline.py:446-461` 现按 conviction 统一择优取前 `top_n+2`，多空比例由信号强度决定，不存在 bearish 配额旋钮。
**IC验证时间表**: ~~需20-30笔干净样本~~ → 已远超门槛(1,808 条有 T1)，结论 IC≈0。
**现役供给口径 (≥2026-08-25)**: DA n=125 (BUY 91/SHORT 11/SKIP 23)、UE n=56 (SHORT 29/BUY 19/SKIP 8)；SHORT 供给偏少已不是配额问题，是信号侧给不出看空信念。

### 25. 🔴 quality_score非正交加减分——重复惩罚/奖励 — v0.16审计发现, 暂不修
**位置**: `signal_gate.py` 全局
**问题**: 维度不正交——"个股历史差"(-15)和"匹配亏钱pattern"(-10)高度相关(重复惩罚)；"LLM score≥8"(+15)和"confidence≥0.8"(+5)高度相关(重复奖励)。同一个风险被计算多次。
**不修理由**: IC验证体系还没跑稳(6条deep_analysis样本0回填)，等30+样本后claim_ic反馈稳定了再重构评分体系。重构需要正交化处理(Gram-Schmidt或PCA)，复杂度高。

### 28. 时区bug后必须grep全模块扫漏网 — v0.18教训
用户纠正: 时区问题又没有主动检测出来。修复feedback_loop+deep_analyzer后没主动扫其他模块,用户指出后grep发现4处漏网(data_collector财报日历+llm_synth prompt+strategy_memory rolling window+lesson cutoff)。全部改为ET时区。教训: 修复一处系统性bug后必须grep datetime.now()扫全模块。审计命令: cd scripts && grep -n "datetime.now()" *.py | grep -v "timezone|_ET_TZ|et_now|# |import|def |__pycache__"

### 29. scanner score被K线block覆盖 — v0.19修复
位置: market_scanner.py:179。问题: _quick_score先做市值过滤(result["score"]-=0.5)和主流标的加分(result["score"]+=0.2),然后K线block里score=5.0新建局部变量,最后result["score"]=score覆盖了前面所有调整。修复: 改为score=result.get("score",5.0)在已有分基础上累加。验证: AAPL score=6.4含大盘+主流标的signals。教训: 局部变量和dict key同名时注意覆盖。

### 30. snapshot内嵌Python代码注入 — v0.19修复
位置: data_collector.py:164-196。问题: collect_snapshot用f-string把symbol注入Python代码字符串,有代码注入风险。修复: 改为subprocess参数传递(sys.argv),同时OpenD地址从硬编码改为config读取。教训: subprocess执行Python代码字符串时永远用参数传递不用f-string注入。

### 31. adapter重复计算to_voting_result — v0.19修复
位置: adapter.py:222,248。问题: to_signal_score和to_exit_meta都调to_voting_result(analysis).get("conditions")——3次重复计算conditions映射。修复: 各自缓存vr=to_voting_result(analysis)再取conditions。教训: 纯函数无状态不等于免费,重复调用相同输入做相同计算是浪费。

### 63. 🔴 旧参数数据不能驱动新参数决策 — v0.38教训 (2026-07-09)
**用户纠正原话**: "原来历史的数据是历史参数参数的 不能用于新修改后的链路和策略 要通过新的管线表现再来做调整和决策"
**背景**: v0.37落地了6项P0修复+M1数据基础设施(回撤止损替代步进trailing、仓位4%降至0.5%risk、SL分桶2-5%、gap过滤、daily_notional_cap DB持久化、feedback_loop全样本override)。然后我用旧数据(旧步进trailing/旧仓位/旧SL下产生的12笔交易)推导出3条建议:
- HIGH_VOL regime过滤(HIGH_VOL两方向都亏)
- TRAILING_STOP参数调优(84笔51%WR但-$224)
- DAY_TRADE_TP优先(13笔100%WR)

**用户指出全部作废**: 这些数据的分布反映的是旧参数的行为, 不是新管线的. 用旧数据指导新参数=循环错误.
**验证时序**:
```
pipeline.py patch:  2026-07-09 13:49 CST
服务重启:           2026-07-09 13:56 CST
7/9已有4笔交易:     CST 09:10-11:55 (全部在patch之前)
patch后新管线交易:  0笔
```
**12笔交易全部是旧管线下产生的. MFE/MAE全部为0(采集代码虽然在pipeline.py里, 但那4笔7/9交易在重启前完成, 没跑到新代码).**
**方法论原则**: 参数变更后, 必须验证数据来源时间线:
1. 检查代码mtime: `stat -c '%y' app/playbook/pipeline.py`
2. 检查服务重启时间: `systemctl show ftseek-us --property=ActiveEnterTimestamp`
3. 检查交易创建时间: `SELECT created_at FROM trade_records ORDER BY created_at DESC LIMIT 5`
4. 如果交易时间 < patch时间 → 数据无效, 不能用于新管线决策
5. 等积累20-30笔新管线下干净交易后, 再用新数据做参数决策
**教训**: ①改参数后旧数据立即失效. ②用旧数据推荐新参数改动是方法论错误, 即使数据"看起来有道理"(HIGH_VOL确实两方向都亏). ③"停止加管道, 先测水"——62个pitfall说明管道已经足够精致, 问题是信号质量(47%≈随机), 不是基础设施. 先用MFE/MAE测出信号问题在哪, 再决定改什么.

### 61. 🔴 backfill_forward_returns.py进程完成不退出 — v0.34诊断 (2026-07-09)
**位置**: `scripts/backfill_forward_returns.py` (FTSeek侧, 非skill脚本)
**问题**: cron `30 5 * * 2-6` 启动backfill, 日志显示05:31就完成了("最终统计: 总2290, 已回填T1=2191"), 但进程(PID 36153)仍在运行5+小时(到10:06还在). 可能是daemon线程或socket未关闭.
**检测**: `ps -o pid,etime,rss -p <PID>` 看ELAPSED时间. 如果日志显示完成但进程还在=卡住.
**修复**: `kill <PID>` 手动kill. 长期: backfill脚本应在完成后显式`sys.exit(0)`或确保所有daemon线程退出.
**教训**: cron脚本的"完成"不等于"退出". 日志输出"最终统计"只是Python逻辑完成, 进程可能因daemon线程/未关闭连接而挂着. 检查cron脚本健康时不能只看日志, 必须检查进程是否退出.

### 57. 🔴 空跑管线和死策略诊断 — v0.33诊断 (2026-07-09)
**诊断方法**: systemctl+crontab+DB+日志4源交叉验证
**当前FTSeek服务(ftseek-us.service)跑4条管线, 只有1条实际产出交易**:

| 管线 | 状态 | 最近交易 | 问题 |
|------|------|---------|------|
| PLAYBOOK_SIM | 唯一活跃下单 | 7/8(今天) | 正常 |
| signal_pipeline (main/legacy) | **空跑** | 6/30(后无交易) | _skip_execution_in_trading=True, 每5分钟跑Scan→Signal→Risk全链路但不下单, 与playbook的_get_watchlist+screener+voting冗余 |
| ORB engine daemon | **空跑** | 6/22(16天前) | enabled=true, daemon线程mode=active在跑, 0笔交易16天, PnL=-$1002 |
| PLAYBOOK_SHADOW | **死了** | 6/23(15天前) | shadow_eod_replay cron每日16:30空跑, 23笔历史仓位已全close |
| SCALPING | **死了** | 5/18(50天前) | 129笔PnL=-$1638 |

**冲突**: signal_pipeline的`_skip_execution=True` + playbook的`auto_execute=true` = 两条并行跑, 如果有人改回skip=False会同时下单→重复仓位
**DB污染**: SCALPING/ORB/MAIN_PIPELINE/PLAYBOOK_SHADOW的亏损pattern被feedback_loop学到strategy_memory, 可能误导deep_analysis的signal_gate
**建议** (止血): ORB config `enabled: false` / signal_pipeline停掉或改playbook预热 / shadow_eod_replay cron停 / feedback_loop加`WHERE source_type='PLAYBOOK_SIM'`过滤死策略

### 32. collect_incremental冗余 — v0.19删除
collect_incremental采集6个数据源,collect_all采集16个完全包含这6个。pipeline只调collect_all。删函数+CLI默认改为all。YAGNI。

### 39. 🔴 deep_analysis退出规则被FTSeek覆盖 — v0.20发现,不修(FTSeek冻结期)
**关键发现**: deep_analysis精心计算的entry/SL/TP和conditions,在实际交易中会被FTSeek的4条退出规则覆盖。deep_analysis建议的$198止损,如果ATR计算的止损更紧,会用ATR的;deep_analysis建议的$282止盈,如果收盘前8分钟盈利≥2ATR,会提前平掉。
**FTSeek当前启用的4条退出规则**(exit_policy.yaml v3.0):
1. atr_stop: entry±ATR×桶mult(low/medium/high/extreme),max_loss% 1.5-4%
2. pre_close_exit: 收盘前8min,盈利≥2ATR全平/亏损平/微利减半
3. pre_close adaptive: 盈利100%平/保本50%平/亏损不强制
4. earnings_guard: 财报前2天+后1天减仓50%
**禁用的规则**: breakeven/chanelder_trail/scale_out/time_exit/technical_breach(全部因回测EV为负或形同虚设而禁用)
**真实交易退出分布**(374笔): sl_hit 115笔16.5%WR -$2023 | TRAILING_STOP 85笔50.6%WR -$3802(已禁用) | PRE_CLOSE_EXIT 33笔42.4%WR +$7511(唯一正PnL主力) | DAY_TRADE_TP 13笔100%WR +$13101(最赚但已禁用)
> 详见 `references/ftseek-exit-rules-20260705.md`（exit_policy.yaml v3.0完整配置+4条规则详解+禁用规则列表+374笔真实退出分布+方向×退出交叉矩阵+deep_analysis与FTSeek退出系统的关系图）

### 39. 🔴 deep_analysis无执行路径 — 架构gap + 替代voting_llm三阶段方案 (v0.21发现)
**关键发现**: deep_analysis写了19条signal_snapshots，但在trade_records里0条执行记录。adapter.py有`to_voting_result()`格式转换函数，但**没有任何FTSeek代码调用它**。

**FTSeek playbook pipeline的实际数据流**:
```
_build_instructions_from_votes()
  → voting_coordinator.vote()          ← 3模型投票(deepseek/qwen/glm)
  → record_signal_snapshot()           ← 写signal_snapshots (strategy_id=voting_llm)
  → compute_instruction_values()       ← 算SL/TP/仓位 (从playbook_horizon.yaml读配置)
  → Instruction(BUY/SELL_SHORT/SKIP)   ← 写playbook_instructions
  → _submit_order()                    ← 执行
```

deep_analysis skill (Hermes侧):
```
pipeline.py → llm_synth.py             ← 1模型(qwen)深度分析
  → ic_writer.write_signal_snapshot()  ← 只写signal_snapshots (strategy_id=deep_analysis)
  → signal_gate.evaluate_signal()      ← 只评估不执行
  → adapter.to_voting_result()         ← 有格式但无人调用
```

**结论**: deep_analysis只写IC不执行交易。要让它影响交易，有三种路径:
1. **门禁模式(Phase 1, 立即可做)**: 在`_build_instructions_from_votes()`的BUY分支前查signal_snapshots里deep_analysis对该股的同日分析，无背书则SKIP。5行代码消灭LONG系统性亏损(-$5,865)。**不需要改FTSeek运行时代码**，只需在pipeline的过滤逻辑中加一个DB查询。
2. **执行模式(Phase 2, 积累30+样本后)**: 让adapter.to_voting_result()输出直接注入playbook_instructions表，用source_type=DEEP_ANALYSIS标记。voting_llm退化为"扫描层"（广度筛选），deep_analysis成为"执行层"（深度决策）。
3. **完全替代(Phase 3, IC验证后)**: voting_llm只保留signal_snapshots写入（维持IC对比基线），所有playbook_instructions由deep_analysis生成。3模型投票降级为"影子系统"（shadow tracking对比但不执行）。

### 40. 🔴 playbook_horizon.yaml SL/TP配置链 — SL_FIXED_PCT根因 (v0.21发现)
**SL来源**: `instruction_generator.py compute_instruction_values()`按以下优先级:
1. `_compute_volatility_based_sl_tp()` 按ATR%选桶(low/medium/high/extreme)
2. ATR缺失(atr_14=0) → fallback到固定百分比
3. 固定百分比: `buy_fixed_stop_loss_pct: 2.5` / `sell_fixed_stop_loss_pct: 2.0`
4. `rr_ratio=999` → 无TP(让EOD捕获利润)

**退出规则**: `factor_exit_rules` in playbook_horizon.yaml, 按conditions匹配退出配置:
- default: time_exit_hours=2.0, breakeven_at_pct=0.5, trailing=false
- 趋势类(above_ma20等): time_exit=6h, trailing=true
- 波动类(volume_expansion等): time_exit=0.5h, trailing=false

**2-4h死亡区间(391笔)**: 2-4h 49笔 -$10,229 vs 4-8h 38笔 +$14,573。time_exit_hours=2.0在错误时间杀了正确的仓。
**被动退出vs主动退出(391笔)**: 被动(PRE_CLOSE+EOD+DAY_TP) 61笔 62%WR +$22,473 vs 主动(sl_hit+TRAILING+STRUCTURE+TIME) 249笔 28%WR -$10,146。**系统越"管理"越亏。**

**最小改动方案(只改config)**: playbook_horizon.yaml改3处:
1. `default.time_exit_hours: 2.0 → 4.0` — 跨过死亡区间
2. `short_horizon.buy_fixed_stop_loss_pct: 2.5 → 3.0` — BA级别的1.8%不该出现
3. `default.breakeven_at_pct: 0.5 → 1.5` — 0.5%保本太早，正常波动就触发

### 44. FTSeek重启: ftseek_us.sh stop匹配不到进程名 — v0.21教训
**问题**: `ftseek_us.sh stop`用`pkill -f "ftseek_us"`但实际进程是`python main.py --start`,不匹配"ftseek_us"字符串。stop命令看似执行了但没杀任何进程。
**修复**: 直接kill PID: `kill -TERM <PID>; sleep 3; kill -9 <PID> if still running; bash ftseek_us.sh start`。
**验证**: `pgrep -af "main.py.*--start"` 确认新PID + uptime<30s。

### 45. 用户偏好: 每只股深度分析优先于批量输出 — v0.20教训
**用户原话**: "模型批量输出那说明结果是不可靠的, 真正根据每只股不同的情况进行深度分析非常重要, 可以开启thinking 时间可以不限制 充分思考给出有价值的推理 要质量先不关注成本"

**核心偏好**:
- **质量>成本**: 不限制thinking时间, 充分推理, 给出有价值的分析
- **个股差异**: 每只股必须根据自身情况深度分析, 不能用批量模板
- **KO示例标准**: 用户提供了KO/MOS/MSTR/NVO/RIVN/ACLS等个股分析+市场观察示例作为质量标杆, 包含: 结论+核心理由(带强度标注)+交易计划(分批入场+止损+目标+追势例外)+关键位+风险+数据质量
- **市场观察**: 机会扫描Top5需要包含市况叙事(板块轮动/资金切换/量能特征), 不是简单列表

**实践要求**:
- LLM prompt已有KO级深度要求(pitfall #8), 但用户强调的是**输出阶段**也要按个股差异呈现, 不是JSON结构化就完事
- 分析报告格式应包含: 评级+信心+结论→核心理由(带强度)→交易计划(分批+止损+目标+例外)→关键位→风险→数据质量
- 市场扫描输出应有市况叙事(板块轮动/资金切换), 不是简单Top列表

| # | 验证层 | 检查项 | 命令/方法 |
|---|--------|--------|-----------|
| 1 | Python环境 | venv存在+版本 | `ls /opt/ftseek/FTSeek-US/venv/bin/python3.11 && --version` |
| 2 | SDK | futu-api版本 | `python3.11 -c "import futu; print(futu.__version__)"` |
| 3 | 进程 | OpenD运行中 | `pgrep -af OpenD` |
| 4 | 文件 | 11个模块文件存在 | `stat` 每个文件 |
| 5 | 导入 | 全部模块可import | `python3.11 -c "import config; import data_collector; ..."` |
| 6 | 密钥 | DASHSCOPE+FINNHUB可读 | `from config import DASHSCOPE_KEY, FINNHUB_KEY; bool(key)` |
| 7 | API可达 | Finnhub HTTP 200 | `requests.get(finnhub_url)` |
| 8 | API可达 | DashScope HTTP 200 | `requests.post(dashscope_url, test_payload)` |
| 9 | 链路 | 单股analyze完整跑通 | `pipeline.py --mode analyze --symbol US.NVDA` |
| 10 | 链路 | scan模式可运行 | `pipeline.py --mode scan --limit 5 --top 2` |
| 11 | 数据库 | strategy_memory+signal_snapshots | `sqlite3 .db "SELECT COUNT(*)"` |
| 12 | 自动化 | cron schedule时区正确 | CST→ET换算验证 |
| 13 | **跨模块数据流** | **FTSeek backfill真的回填了deep_analysis的IC** | `SELECT strategy_id, COUNT(*), SUM(CASE WHEN fwd_ret_t1 IS NOT NULL THEN 1 ELSE 0 END) FROM signal_snapshots GROUP BY strategy_id` — deep_analysis的t1_filled应该>0。v0.12发现15条0回填→根因是非交易日trade_date |
| 14 | **跨模块数据流** | **pipeline每个mode都调了ic_writer+gate** | 读源码确认run_full()和run_analyze_only()都有ic_writer/gate调用。v0.12发现run_full()缺失→已修复 |
| 15 | **跨模块数据流** | **下游模块读的字段在上游模块的输出中存在** | 读deep_analyzer读的`self.data.get("capital_flow")`→查data_collector.collect_all()返回里有没有。v0.12发现缺失→已加capital_flow+distribution |
| 16 | **兜底值合法性** | **adapter的`.get("key", default)`的default在FTSeek合法枚举里** | `to_exit_meta`的`["default"]`→不在27枚举里。v0.12已修复→`[]` |
| 17 | **非交易日场景** | **周末/假日运行时trade_date/today是否正确** | `ic_writer._get_et_trade_date()`在7/5周日应返回7/2周四。v0.12已修复→前推到最近交易日+假日检查。**⚠️ 2026-09-07 更正**: v0.12 的「假日检查」用的是函数内自带 6 条表，**漏劳动节等 6 个 NYSE 全日休市日**（9/7 周一实测仍返回 `2026-09-07`）；现已改为委托 `scripts/trading_calendar.py` 三层日历，见 pitfall `-6`。查法：`./venv/bin/python -c "import sys;sys.path.insert(0,'/root/.hermes/skills/deep-stock-analysis/scripts');import trading_calendar as t;from datetime import date;print(t.latest_trading_day(date.today()))"` |
| 17b | **主链假日守卫** | **`pipeline.py` 在美股假日是否跳过** | `pipeline.py --format json`（假日）应吐 `{"skipped":true,"skip_reason":"NON_TRADING_DAY",...}` 且 exit 0、零 LLM 调用；人工强制运行加 `--force`。2026-09-07 v0.76 新增，见 pitfall `-6` |

**这次验证发现了时区bug(#15)——cron设的是CST 9:00=ET 21:00前一天，如果没验证直接周一跑，分析的是前日数据且FTSeek预检后才有结果。**

### 40. 🔴 IC分方向拆解: LONG IC=-0.067(负值!) + Strength倒挂 + 4h生死线 — v0.21发现
**数据源**: signal_snapshots.db(763条) + ftseek_us.db(391笔) + decisions.db(model_votes) 多DB实算。
**核心发现**:
1. **LONG IC=-0.0674**(293条) — voting_llm对LONG方向是反指标: strength越高LONG回报越差。全局IC=0.1075掩盖了这一点。
2. **Strength倒挂**: low(<40) WR=44.8% +$6,437 vs vhigh(70+) WR=42.1% -$1,101。高strength=高consensus=04:xx模板投票→错误方向集中→亏损。
3. **4h生死线**: 2-4h 49笔 -$10,229(死亡区间) vs 4-8h 38笔 +$14,573(黄金时段)。SL在趋势发展前触发。
4. **04:xx模板投票实锤**: 38只股票全部投37/47或35/45(std<3),未被标记degraded→污染consensus。
5. **主动退出=亏损引擎**: 249笔主动退出总亏-$8,931 vs 61笔被动退出总赚+$22,473。
6. **NEUTRAL 0%WR**(54条T1 filled, 0正确) — 完全无用，浪费扫描预算。
**三个根因联动**: 模板投票→错误consensus→错误方向+错误strength→窄SL在错误方向上快速止损→亏损。修任何一个都不够，必须同时修。
**优化方案优先级**: P0=LONG需deep_analysis背书+SL→ATR分桶+模板投票std<3过滤; P1=NEUTRAL不生成instruction+time_exit 2h→4h+SHORT_PROXY_OPTION禁用; P2=T5/T20回填修复+deep_analysis top 2→5加速graduation。
> 详见 `references/ic-direction-strength-inversion-20260708.md`（7个Finding完整数据+优化方案优先级矩阵+多DB诊断路径+审计SQL模板）

## 验证方法论（重要教训）

**用户反复问"完美了吗？""完整了吗？"——每次都要诚实回答不完美，然后用真实数据列出具体gap，最后改掉能改的。**

这个模式在v0.6/v0.10/v0.11反复出现：
- v0.6: 用户问"完美了吗"→发现LONG胜率27.9%系统性亏损+IC样本不足
- v0.10: 用户问"周一能跑吗"→发现cron时区bug(盘前扫描CST 9:00=ET 21:00前一天)
- v0.11: 用户问"完整和完美了吗"→发现数据质量审计撒谎+LLM论据无溯源+pattern样本不足强推退出+社区情绪乱码

**正确流程**：
1. **不凭记忆回答"能跑"**——系统验证每个依赖层（12项检查）
2. **不凭嘴说"完美"**——实跑pipeline→查DB→对比KO示例→列具体gap
3. **gap分两类**：能改的立即改（代码修复），不能改的诚实说明（IC样本需时间积累/FTSeek冻结期/Finnhub免费层限制）
4. **改完再验证**——每个修复都要实跑确认效果（不只看代码不报错）

**光读代码看格式匹配不够——必须实跑+查数据库**:
- v0.4的IC写入: 上一个context声称"验证通过"，但实际查DB发现trade_date=2026-07-05(CST周日)，不是交易日，backfill永远找不到日K线→IC永远为0
- v0.5的conditions: 上一个context声称"全部合法"，但实际跑NVDA发现BUY信号带2个bearish conditions——虽然validate_conditions通过(都在27枚举内)，但方向冲突
- v0.6的OKR: 分析输出达到KO级（NVDA bull_case="GB300碾压20倍"+bear_case="MSPR -77.39"），但查真实交易数据发现LONG方向胜率只有27.9%——**分析对了不代表交易能赚钱**

**用户反复问"完美了吗？"——每次都要重新用真实数据验证，不能凭嘴说完美**:
1. 写入DB后`SELECT`读回来验证字段值(不只看INSERT不报错)
2. conditions不只验证在27枚举内——还要验证与direction方向一致(bearish_hits=[])
3. scanner不只看不报错——看top_bullish的实际股票(有没有仙股)
4. LLM不只看JSON结构——看论据是不是该股独有的(不是通用模板)
5. **分析质量≠交易质量**——必须查trade_records的胜率/PnL/退出原因，验证分析输出能否真正提升OKR
6. **IC样本量**——deep_analysis只有5条IC样本(0回填)，远未达到FTSeek graduation gate的30样本+IC(T+3)>0.05，信号无法进入实盘
7. **方向先验缺失**——LLM分析个股时不知道"LONG近期胜率只有27.9%"，盲目输出BUY。v0.7修复：查近7天trade_records注入方向先验，NVDA从BUY降为SKIP

## 个股复盘+赢亏pattern归因（v0.8 核心机制）

**用户纠正**：v0.7的方向门禁（"LONG弱就不让BUY"）太粗暴——市场是动态的，NVDA在$189.8支撑位+GB300催化可能就是那20%会赢的long。不能因为整体LONG弱就一刀切SKIP，需要的是**个股级复盘归因**——这只股上次怎么赢的、怎么亏的，当前setup更像赢的pattern还是亏的pattern。

**机制**：`deep_analyzer._get_trade_experience()` 在调 `llm_synth.synthesize()` 前查FTSeek trade_records，生成5层经验文本注入LLM prompt：

1. **个股历史复盘**（这只股最近5笔交易：赢/亏/退出模式/PnL）——个股级信号，不是整体方向
2. **近期赚钱setup**（7天内赚钱的direction+exit_reason组合，如`SHORT+EOD_FORCE_CLOSE 4笔4胜`）
3. **近期亏钱setup**（7天内亏钱的direction+exit_reason组合，如`SHORT+PRE_CLOSE_EXIT 1笔 PnL=-$124`）
4. **30天方向参考**（LONG/SHORT整体胜率，标注"不强制"——背景信息不是硬约束）
5. **退出效果**（哪种退出方式赚钱：DAY_TRADE_TP 100%胜率 vs TRAILING_STOP 51%但PnL负）

**LLM prompt中的使用原则**（权威真源 = `scripts/llm_synth.py:880-892`；本段仅为描述，冲突时以代码为准）：
- **这不是方向门禁！** 不要因为"LONG整体弱"就一律拒绝BUY
- **历史胜负无方向预测力**（2026-08-25 更正 — 原"个股复盘优先：本股历史全亏需更强理由"已被实证证伪并从生产 prompt 删除）：标的级历史胜负对本股下一笔无预测力，半程自相关 pearson=−0.40 且反持续（DEB-20260825 第2轮）；亏损后再入场恰是回放证明的少数盈利行为之一（同 DEB 第10轮）。不因既往亏损拒绝同方向信号，也不因既往盈利放松证据标准，**多空对称适用**
- **经验数据只有三类可用**：①具体失败模式的事实（如"上次财报日跳空打止损"）→ 检查本次是否存在同类未定价事件，存在则计入 risks，不存在不构成反对理由；②退出机制效果统计 → 只用于 execution_plan 松紧参考，**禁止用于方向判断**；③连续同方向推荐的"这次有何不同"要求 → 防惯性不防方向本身
- **pattern匹配**：当前个股setup接近"赚钱setup"→更积极；接近"亏钱setup"→需额外确认
- **退出效果参考**：DAY_TRADE_TP 100%但TRAILING_STOP 51%且PnL负→"快止盈"比"让利润奔跑"更有效→execution_plan倾向更紧止盈
- **方向参考是背景不是约束**：30天LONG胜率40%不代表这只股的LONG一定亏；不得据此对同方向信号加码证据要求（同上更正）
- **无历史记录时**：用整体方向+pattern匹配判断，不因缺数据就SKIP；此时注入的全市场经验会标注"(全市场参考,非本股,置信度very_low)"（DEB-20260830 E1）

**验证效果（NVDA vs AVGO对比）**：

| 维度 | NVDA（历史3笔全亏） | AVGO（历史2笔1胜1负） |
|------|---|---|
| direction | **BUY** (不SKIP!) | **SKIP** |
| score | 7 | 5 |
| 理由 | GB300/Nemotron催化>历史全亏 | MSPR=-88.69更极端+CEO亲自卖+跌幅-24.7% |
| constraints | "近期3笔NVDA交易全亏(PnL -$2905)，LONG+PRE_CLOSE_EXIT模式失效" | 无（直接SKIP） |
| risks | "近期LONG交易3连亏，市场微观结构不利于多头持仓过夜" | 等待$356企稳 |
| entry | 分2批+触发条件(15min K线站稳+量>1.2倍) | 严禁左侧接刀 |

**关键**：NVDA历史全亏但LLM仍输出BUY——因为GB300/Nemotron催化够强。但把历史全亏放进了constraints和risks，入场策略更谨慎。这就是"不被历史束缚但从历史中学习"。

**经验文本示例（NVDA）**：
```
本股US.NVDA近期3笔交易: 0胜3负 PnL=$-2905 方向=LONG,SHORT 退出=PRE_CLOSE_EXIT,STRUCTURE_EXIT
  2026-05-01 LONG 亏 PnL=$-815 reason=PRE_CLOSE_EXIT hold=0.0h
  2026-05-01 SHORT 亏 PnL=$-1302 reason=STRUCTURE_EXIT hold=2.5h
  2026-04-30 LONG 亏 PnL=$-787 reason=PRE_CLOSE_EXIT hold=5.6h
近期赚钱setup: SHORT+EOD_FORCE_CLOSE(4笔4胜 PnL=$419 hold=17.2h); LONG+EOD_FORCE_CLOSE(1笔1胜 PnL=$68 hold=18.0h)
近期亏钱setup: SHORT+EOD_FORCE_CLOSE(2笔 PnL=$-124 hold=17.3h); SHORT+PRE_CLOSE_EXIT(1笔 PnL=$-124)
30天方向参考(不强制): LONG:31笔 WR=42% PnL=$-3187 | SHORT:22笔 WR=55% PnL=$+1686
退出效果: EOD_FORCE_CLOSE(14笔 WR=86% PnL=$+1786); PRE_CLOSE_EXIT(4笔 WR=50% PnL=$+194)
```

> 详见 `references/trade-experience-injection.md`（5层经验文本+SQL模板+prompt设计+NVDA/AVGO对比验证）

## OKR对齐差距分析（v0.6关键发现）

**分析输出达到KO级≠能提升胜率和盈利OKR。** 用真实交易数据验证：

### 真实交易基线
| 维度 | 数据 | 问题 |
|------|------|------|
| 全量胜率 | 36.6%（140胜243负） | 远低于50% |
| Profit Factor | 1.12 | 极低 |
| **LONG方向** | 165笔 胜率**27.9%** PnL=**-$5992** | 做多系统性亏损 |
| SHORT方向 | 205笔 胜率44.9% PnL=+$25936 | 做空是唯一盈利来源 |
| voting_llm | 182笔 PnL=**-$13371** | 最大亏损源——deep_analysis要替代它 |
| deep_analysis IC | 5样本 0回填 | 远未达到graduation gate的30样本 |

### 三层差距
- **A层（选股）**: deep_analysis输出BUY信号时不知道LONG方向胜率只有27.9%。LLM看到NVDA基本面强就输出BUY——但市场环境不利多头。需要在LLM prompt中注入方向先验。
- **B层（退出）**: LONG亏损核心在退出策略（TRAILING_STOP 44笔 PnL=-$1150, 0-2h 49笔 PnL=-$6305）。但退出系统7/24冻结期不能碰。
- **C层（IC积累）**: 5样本远未达到graduation gate的30样本。即使cron每天产出4只，需7-8天积累。

### 退出原因×方向 诊断模式
```sql
-- LONG方向退出原因分析（找亏损根因）
SELECT exit_reason, COUNT(*) as cnt,
       SUM(CASE WHEN realized_pnl > 0 THEN 1 ELSE 0 END) as wins,
       ROUND(SUM(realized_pnl), 2) as pnl
FROM trade_records WHERE realized_pnl IS NOT NULL AND direction='LONG'
GROUP BY exit_reason ORDER BY pnl;

-- 持仓时间 vs 盈亏（找最优持仓窗口）
SELECT CASE WHEN holding_hours < 2 THEN '0-2h'
            WHEN holding_hours < 6 THEN '2-6h'
            WHEN holding_hours < 12 THEN '6-12h'
            WHEN holding_hours < 24 THEN '12-24h'
            ELSE '24h+' END as bucket,
       COUNT(*), SUM(CASE WHEN realized_pnl > 0 THEN 1 ELSE 0 END) as wins,
       ROUND(SUM(realized_pnl), 2) as pnl
FROM trade_records WHERE realized_pnl IS NOT NULL AND direction='LONG'
GROUP BY bucket ORDER BY pnl;
```

> 详见 `references/okr-gap-analysis.md`（真实交易诊断+方向先验注入方案+graduation gate要求）

## 自动化

### 盘前分析 cron
cron job已创建: 每周一至周五18:00 CST(=ET 6:00, 开盘前3.5h)自动扫描+分析+IC写入+signal_gate。
- job_id: `e0d574cc1a3c`
- schedule: `0 18 * * 1-5`
- v0.10修正: 原来设`0 9 * * 1-5`(CST 9:00=ET 21:00前一天)，离开盘12.5h，数据是前日收盘的。改为`0 18`(CST 18:00=ET 6:00)，跑完正好给FTSeek盘前预检(CST 20:00=ET 8:00)参考。
- v0.4修复: 显式用`/opt/ftseek/FTSeek-US/venv/bin/python3.11`(futu-api只在此venv) + 交易日检查(非交易日SILENT) + workdir=skill scripts目录
- v0.5修复: top_bearish可能为空(普涨日), cron prompt加"不编造做空候选"
- v0.12验证: cron调scan+analyze模式(先scan取top→再对每只调analyze)，analyze已集成ic_writer+gate。prompt完整内容已审计确认。

### 盘前bridge生成 cron (v0.31新增)
cron job已创建: 每周一至周五16:00 CST(=ET 03:00, 盘前1.5h)自动跑full pipeline生成bridge文件。
- job_id: `13dde1f65703`
- schedule: `0 16 * * 1-5`
- 执行: `pipeline.py --mode full --limit 15 --top 5 --synth llm` → 生成`opportunity_scan_YYYYMMDD.json`
- **目的**: 确保FTSeek 04:23ET盘前扫描时bridge文件已存在→scheduler走BridgeVotingAdapter→预算全给bridge信号(不被VotingCoordinator先吃光)
- v0.31修复: 之前bridge文件13:19ET(盘中)才生成,盘前已走VotingCoordinator路径消耗$44K预算,bridge候选15:24ET触发时预算耗尽

### 盘后复盘 cron
cron job已创建: 每周一至周五05:30 CST(=ET 16:30, 收盘后)自动复盘+更新memory+推送报告。
- job_id: `895169e95c50`

**复盘方法论参考文件**:
- 每日汇总复盘: `references/eod-performance-review-methodology-20260714.md` — 4步DB验证+5维评价
- 单笔全链路复盘: `references/single-trade-full-chain-review-20260714.md` — 7步链路追踪+6维评价+DB表地图. 用于用户要求详细复盘某笔交易从选股到退出全链路时
- schedule: `30 5 * * 1-5`
- 执行feedback_loop.py: 扫描当日已平仓交易→更新strategy_memory→提取教训→生成复盘报告→飞书推送
- v0.31新增: 同时跑alpha_backfill.py --backfill 1 (当日claim IC)

### Alpha backfill cron
cron job已创建: 每周二至周六06:30 CST(FTSeek backfill 06:00后接力)自动回填SPY alpha+论据级IC。
- job_id: `6af0648e3eb3`
- schedule: `30 6 * * 2-6`
- 执行alpha_backfill.py: 拉SPY日K→计算alpha_t1/t5/t20→跑claim IC统计→写claim_ic_cache.json
- claim_ic_cache.json供llm_synth(注入prompt)和signal_gate(检查论据有效性)读取

## 知行合一闭环（v0.15 核心设计原则）

**用户需求**："如何知行合一 现有分析推导如何真正制定出对应的方案并确保执行 并且不要过于复杂"

**脱节问题**：验证层发现"pe_below_industry IC=-0.43（无效）"，但LLM下次分析时仍用它当看多理由——验证结果没有反馈回分析和门禁。

**解决方案**：一个JSON缓存 + 三个读取点，不新增模块：

```
①盘后alpha_backfill跑claim IC
    ↓
②写claim_ic_cache.json (effective/ineffective分类)
    ↓
    ┌───────────────────────┐
    │                       │
    ▼                       ▼
③llm_synth读缓存        ④signal_gate读缓存
  prompt注入一段文本：      检查LLM用的论据：
  "pe_below IC=-0.43       用了无效论据→降10分
   volume_expansion +0.30  用了有效论据→加5分
   避免用无效做核心依据"    标注在risk_notes里
```

**关键设计决策**：
- LLM是**软约束**（告诉它哪些论据有效，但不禁止用）— 市场在变，今天无效的论据明天可能有效
- Gate是**硬约束**（用了无效论据降10分）— 但只降分不BLOCK，让信号仍能通过只是仓位更小
- **不要过于复杂**：只加一个JSON缓存文件，三个读取点各几行代码，不需要新DB表、不需要新服务

### 陷阱：claim_type命名不一致

`ic_writer._classify_claim()`输出的claim_type（如`valuation_cheap`）与voting_llm的factors_json里的condition名（如`pe_below_industry`）命名不同。signal_gate检查时需要`_CLAIM_NAME_MAP`映射表统一比较。只映射真正等价的（`valuation_cheap→pe_below_industry`），不要把`technical_breakout`映射到`macd_golden_cross/rsi_oversold`——后者在voting_llm里有独立IC统计，别名覆盖会导致误匹配。

> 详见 `references/three-layer-verification-implementation.md`（Alpha IC 11列+claim_type 11类分类+首跑916条数据+知行合一反馈闭环+命名映射陷阱）

## 自我进化交易闭环（v0.9 核心架构）

**用户需求**：利用最新资讯和信号筛选→选择合理交易策略→控制风险→结合表现不断积累迭代→形成独有交易技能沉淀→实现稳定收益→完成并超越OKR目标。

```
                    ┌──────────────────────────────────────────────┐
                    │            strategy_memory.db                │
                    │  pattern_memory | symbol_memory | lesson_log │
                    └──────┬───────────────────────────────┬───────┘
                           │                               │
                    读经验 │                               │ 写经验
                           ▼                               ▲
  ┌──────────────────────────────────────────┐    ┌────────┴────────┐
  │            盘前 (9:00 CST)               │    │  盘后 (5:00 CST) │
  │                                          │    │                 │
  │  scan → analyze → signal_gate → adapter  │    │  feedback_loop  │
  │          │              │           │    │    │       │         │
  │          │              │           ▼    │    │  ┌────▼────┐    │
  │          │              ▼     FTSeek执行 │    │  │更新memory│    │
  │          │     质量门禁+策略推荐         │    │  │提取教训  │    │
  │          │     PASS/WARN/BLOCK           │    │  │生成报告  │    │
  │          ▼                               │    │  └─────────┘    │
  │   LLM分析(注入个股复盘+pattern)          │    │                 │
  │                                          │    │  →飞书推送复盘   │
  └──────────────────────────────────────────┘    └─────────────────┘
```

### 3个新模块

#### 1. strategy_memory.py — 策略记忆库
- **pattern_memory表**: direction×exit_reason×strength_bucket聚合统计（胜率/PnL/持仓时间）
- **symbol_memory表**: 单股×方向历史表现（胜率/PnL/最佳/最差）
- **lesson_log表**: 每日复盘教训（win_pattern/loss_pattern/symbol_insight/market_regime）

API:
- `update_from_trade(trade)` — 从一笔已平仓交易更新memory
- `get_strategy_hint(symbol, direction)` — 获取策略提示（个股历史+赢亏pattern+退出效果+教训）
- `format_hint_for_prompt(hint, symbol)` — 格式化为LLM可读文本
- `add_lesson(date, type, content, evidence, impact)` — 添加复盘教训
- `get_memory_summary()` — 获取摘要（供报告用）

#### 2. signal_gate.py — 信号质量门禁 + 策略推荐
对每个deep_analysis输出做7维评估：
- 个股历史（本股同方向WR/PnL — BUY→LONG映射）
- pattern匹配（赚钱/亏钱pattern — 方向感知）
- 信号质量（LLM score+confidence）
- 盈亏比检查（reward/risk ratio）
- conditions完整性
- 退出效果推荐（基于历史最赚退出方式）
- **论据有效性检查**（v0.15新增：从claim_ic_cache.json读取，用了IC<0的论据降10分，用了IC>0.05的加5分）

决策: PASS(≥65) / WARN(≥40) / BLOCK(<40)

API:
- `evaluate_signal(analysis)` — 返回 {quality_score, decision, reasons, strategy_hint, pattern_match}
- `format_gate_report(gate_result, symbol)` — 人类可读报告

**关键修复**: BUY→LONG/SELL_SHORT→SHORT方向映射 — pattern_memory和symbol_memory存的是FTSeek格式(LONG/SHORT)，不是LLM格式(BUY/SELL_SHORT)。

#### 3. feedback_loop.py — 盘后自动复盘
- 扫描当日已平仓交易 → 逐笔更新strategy_memory
- 自动提取赢/亏pattern教训（4类: win_pattern/loss_pattern/symbol_insight/market_regime）
- 生成复盘报告（飞书Markdown）

API:
- `run_daily(target_date)` — 执行当日复盘，返回报告文本
- `run_backfill(days)` — 回填最近N天交易到memory
- `extract_lessons(trades, date)` — 从交易中提取教训
- `format_daily_report(trades, lessons, date)` — 生成复盘报告

### 闭环如何自我进化

1. **每天盘后**: feedback_loop自动从trade_records提取当日交易→更新pattern_memory和symbol_memory→提取教训写入lesson_log
2. **每天盘前**: deep_analyzer从strategy_memory读取个股历史+赢亏pattern→注入LLM prompt→signal_gate用memory做质量评估+策略推荐
3. **持续积累**: pattern_memory的统计样本越来越大→胜率/PnL越来越准→LLM的经验信息越来越丰富→信号质量越来越高
4. **教训反哺**: lesson_log的"近期教训"注入LLM prompt

## 幻觉检测与置信度门禁 (2026-07-11)

> **⚠️ 本节是 2026-07-11 的历史立项书，5 项修复的落地形态已全部演化，逐条现状见下方「现状更正」。不要再按本节原文去改代码。**

**数据**: 挑战者检查16条论据, 6条被标记为幻觉/选择性偏差 (38%). 但只降confidence不拦→仍执行→亏钱. conf<40的8笔交易0%胜率.

**根因**: 防护机制都已实现但未接线:
- `_verify_sourced_numbers()`: ✅实现, ❌无人读
- claim IC反馈: ✅实现, ⚠️只注入top3/bottom3
- 挑战者辩论: ✅实现, ❌抓到幻觉只降conf不SKIP
- confidence gate: ✅实现, ❌DA-候选直写DB绕过
- signal_gate: ✅实现, ✅接线

**5迭代修复** (共~33行): 详见 `references/hallucination-detection-and-conf-bypass-20260711.md`
1. conf<40 auto_execute硬拦截 (5行)
2. 挑战者抓到幻觉→SKIP (8行)
3. LLM prompt强制给定同行列表 (10行)
4. claim IC<-0.1→prompt标注"禁用" (5行)
5. _verify_sourced_numbers接线: unverified>3→降conf (5行)

**最大幻觉模式**: 同行选择性偏差 (6条中3条=50%). LLM自己选同行→cherry-pick. 解决: prompt强制使用数据采集层的sector分类同行列表.

### 现状更正 (2026-09-06 逐条核对源码)

| 原修复项 | 现役状态 | 证据 |
|---|---|---|
| ①`conf<40` 硬拦截 | **已不存在**，改配置驱动门 | FTSeek `config/unified_config.yaml:1425-1426` `playbook.supply_conf_gate_buy/short: 55`，消费在 `app/playbook/pipeline.py:1759-1760`（`_build_instructions_from_votes` 内）。另有 `strategy_registry.BATTLE_PLAN_FAST_PATH.direction_filter.BUY/SHORT_min_confidence: 70`（`config/unified_config.yaml:2307-2309`，该策略 `enabled: false`） |
| ②挑战者抓到幻觉→SKIP | **思路换了**：从"事后文本惩罚"改为"事前数据验证" | `scripts/llm_synth.py:2234`（DEB-20260814 §9.4）+ `_kline_derived_whitelist`（`DA_P5_KLINE_VERIFY=1`）+ 白名单扩为 prompt 全文数字（`DA_SOURCE_VERIFY_MODE=full`，DEB-20260811 O5 方案A：旧 4-dict 白名单实测**误报率 100%**，GS `$1222.5` 被误判） |
| ③prompt 强制同行列表 | **✅ 已落地并保留** | `scripts/llm_synth.py:569-597` 注入 `collected["industry_peers"]`（industry/peers top5/行业均涨跌/peer 明细） |
| ④claim IC prompt 注入 | **2026-07-18 用户裁关闭**；2026-09-01 换窄口径负向警示 | 关闭：`scripts/llm_synth.py:1556-1561`（函数体保留便于回滚）。替代：`_load_negative_claims_warning_for_prompt`（`scripts/llm_synth.py:1302+`）只注**负向**清单、只留语义论据、门槛 `n≥10 且 T+1 alpha<−0.2%`、开关 `playbook.claim_negative_prompt_enabled`。signal_gate 侧仍读 claim_ic 缓存做**事后** risk_notes（`scripts/signal_gate.py:279`） |
| ⑤`_verify_sourced_numbers` 接线 | **✅ 已接线（2026-08-04），但改为软扣分** | 计算 `scripts/llm_synth.py:1715`；消费 `scripts/signal_gate.py:339-357`：`uv≥3 → quality_score −15`、`uv≥1 → −10`，**不单独 BLOCK** |

**新增的统一收口（原文没有）**: `app/playbook/admission.py`（2026-08-06）挂在 `app/playbook/db.py:368` 的 `save_instruction`，一次覆盖 DA直写/UE/topup/generate 四条写入路径。立项根因正是原文那行"confidence gate ❌DA-候选直写DB绕过"（实测 35 日 DA 219 条 BUY 平均 conf=36 全入库、执行 123 笔）。代码 fallback 为 `enforce=false`，但生产 YAML 当前为 `playbook.admission.enabled=true/enforce=true`；confidence 类判据阈值仍为 **0（不拦）**——60 日 n=242 实测 confidence IC=−0.021 (t=−0.33)，无实证支持。运行状态必须以生产 YAML 为准。

**⚠️ 本节的数据论据已作废**: "conf<40 的 8 笔 0% 胜率"是 n=8 的巧合，不是因果。三系统实测 LLM 自评 confidence **零预测力**（r=−0.211/−0.073/−0.038，pitfall `#75`），门禁已改用**辩论一致度** `decision_conf`。顶层 `confidence` 列被 gate WARN 罚分后**退化为常量**（近 14 天 89/95 条 <40，分层能力归零，`scripts/pipeline.py:1300`），因此另外落了 `confidence_semantic` / `decision_conf` / `llm_self_confidence`(record-only，不入任何门) 三列做取证。
### 对OKR的影响路径

> **⚠️ 本表绑定 OKR-2026-08 的 KR 集，该 OKR 已于 2026-08-23 提前结算为 SUPERSEDED。现行判据见 FTSeek 仓 `docs/OKR-2026-09.md`；表内 pattern 名(`DAY_TRADE_TP`/`SL_ATR_STOP`)在现役退出集合里已不存在。**

| OKR维度 | 闭环作用 |
|---------|---------|
| KR1 胜率 | signal_gate的WARN/BLOCK过滤低质量信号→只交易高概率setup |
| KR2 P&L | ~~pattern推荐最赚退出方式(DAY_TRADE_TP 100%)→避免最亏pattern(SL_ATR_STOP)~~ → 现役利润引擎 `SL_TRAIL_LOCK`，死单池 `SL_INITIAL`/`TIME_EXIT`/`MFE_STALL_EXIT` |
| KR4 IC | deep_analysis IC样本每天+4→7天过30样本门槛→graduation gate |
| KR5 触发率 | gate的PASS/WARN/BLOCK分级→只让高质量信号触发 |

### 当前积累状态（90天回填）
> **⚠️ 整块是 v0.11 时代(90 天回填)快照，数字与 pattern 名均已过期，仅作历史留档。现役数字见下方「现役积累状态」。**
- 64个pattern / 92只股票 / 148条教训 / 362笔交易
- 最赚pattern: SHORT+DAY_TRADE_TP WR=100% PnL=$10786 (11笔, confidence=low)
- 最亏pattern: SHORT+BREAKEVEN_STOP PnL=$-6235 (3笔, confidence=very_low)
- SHORT+EOD_FORCE_CLOSE WR=78% PnL=$2926 (24笔, confidence=medium) ← 唯一中等置信的赚钱pattern
- NVDA: LONG 2笔0胜 PnL=-$1603 (confidence=very_low), SHORT 1笔0胜 PnL=-$1302

### 现役积累状态 (2026-09-06 实测)
- **策略记忆** `data/strategy_memory.db`：`pattern_memory` **73** 行（覆盖 447 笔）/ `symbol_memory` **144** 只 / `lesson_log` **415** 条。
- **playbook_patterns**（FTSeek `data/ftseek_us.db`）：**21** 个，`active` 2 / `observing` 10 / `retired` 9 —— 置信度分层生效，大样本 pattern 多已 retire。
- **最赚**：`LONG+SL_TRAIL_LOCK` n=40 / 95.0% / **+$2,749**；`SHORT+SL_TRAIL_LOCK` n=12 / 100% / +$959；`LONG+SL_BREAKEVEN` n=53 / 84.9% / +$469；`LONG+PRE_CLOSE_EXIT` n=21 / 76.2% / +$445。
- **最亏**：`LONG+SL_INITIAL` n=12 / **0%** / **−$2,238**；`LONG+TIME_EXIT` n=24 / 0% / −$560；`LONG+MFE_STALL_EXIT` n=19 / 5.3% / −$552。
- **现役退出原因只剩 7 种**（≥2026-08-25 成交口径）：`SL_BREAKEVEN` 46 · `SL_TRAIL_LOCK` 27 · `DEAD_SIGNAL_EXIT` 13 · `SL_INITIAL` 11 · `PRE_CLOSE_EXIT` 3 · `TAKE_PROFIT` 1 · `OVERNIGHT_GAP_STOP` 1。`DAY_TRADE_TP` / `BREAKEVEN_STOP` / `EOD_FORCE_CLOSE` / `SL_ATR_STOP` / `SL_FIXED_PCT` / `TRAILING_STOP*` 已退出生产（仅存在于 7–8 月历史样本）。
- 2026-09-06 0906B 重构后退出引擎宿主迁至 FTSeek `app/playbook/exit_engine.py`，隔夜豁免三轨合一至 `app/playbook/overnight_decision.py`；讨论退出行为先读这两个文件，别只看本 skill 的 `exit_meta` 输出格式。

**v0.11置信度标注后的Gate行为变化**：
- 修复前: NVDA Gate PASS(70), 推荐TRAILING_STOP, normal仓位——基于7笔噪声数据
- 修复后: NVDA Gate WARN(50), 不强推退出, small仓位——诚实承认样本不足
- 只有confidence≥medium的pattern(20+笔)才会被Gate用于退出方式推荐

## 解耦设计

- config.py: 所有路径/密钥集中, 改只改一处
- deep_analyzer: synth_module可注入(None=LLM, 'rule'=纯规则)
- pipeline: 各阶段lazy import + try/except, 单模块故障不阻塞
- adapter: 4种格式纯函数, 无状态

## FTSeek接口适配 (4种格式)

1. **voting_result** → `_submit_order`: source_type=PLAYBOOK_SIM, direction, confidence(0-1)
2. **signal_score** → `SignalScore`: direction=LONG/SHORT, strength(0-100), metadata
3. **exit_meta** → `_check_playbook_exit_rules`: cohort, stop_loss, peak_price, conditions
4. **ic_snapshot** → `record_signal_snapshot`: decision_id, direction, strength, factors

conditions映射到FTSeek 27个合法枚举(condition_taxonomy.py)，确保退出规则正确匹配。

## 使用方法

> 质量标准对标KO示例——详见 `references/ko-example-quality-bar.md`（个股7段结构+市场观察叙事+论据独有性要求）
> LLM prompt设计模式——详见 `references/llm-prompt-ko-pattern.md`（KO示例反推的6项深度要求+7条硬性约束）
> FTSeek接口契约——详见 `references/ftseek-interface-contract.md`（4种格式+27枚举+方向一致性规则+DB schema）
> OKR对齐差距——详见 `references/okr-gap-analysis.md`（真实交易诊断+方向先验注入方案+graduation gate要求）
> 交易经验注入——详见 `references/trade-experience-injection.md`（_get_trade_experience实现+SQL模板+prompt设计+NVDA验证对比）
> 自我进化闭环架构——详见 `references/self-evolving-loop-architecture.md`（strategy_memory+signal_gate+feedback_loop三模块设计+数据流+验证结果+cron配置）
> 上线前验证方法论——详见 `references/pre-launch-verification-20260705.md`（12项验证清单+cron时区bug发现+密钥读取路径）
> v0.11诚实质量审计——详见 `references/honest-quality-audit-v0.11.md`（7项修复：数据质量三级评估+LLM溯源约束+社区情绪解码+pattern置信度+Gate低置信不强推+scanner市值提升+主流标的偏好）
> 跨模块数据流审计方法论——详见 `references/cross-module-audit-methodology.md`（6步审计法+8个发现详情：ic_writer非交易日trade_date+run_full未集成ic_writer/gate+cron prompt验证+exit_meta非法枚举+LLM溯源后验证+feedback_loop ET时区+capital数据源接入+direction映射验证）
> Code review checklist——详见 `references/code-review-checklist.md`（8类bug检查方法：字段名跨模块追踪+API返回格式验证+dead variable/branch+index bug+RSI计算+过时匹配+兜底值合法性）
> 策略涌现分析——详见 `references/strategy-emergence-from-trade-data.md`（从362笔交易挖出3条可收益规则：时段PnL矩阵+方向×退出盈利表+确定性亏损组合+单股洞察+时间分布+signal_gate实现映射）
> 策略涌现+市场上下文桥接层——详见 `references/strategy-emergence-and-market-context-bridge.md`（技术债5项+3条可收益规则+方向×时段PnL矩阵+FTSeek已有市场上下文数据源清单+三层认知架构方案：市场全景图+交叉验证引擎+情境记忆）
> 三层验证体系+架构辩论结论——详见 `references/three-layer-verification-architecture.md`（Alpha IC剥离SPY beta+论据级IC用claim_type分类+情境IC验证market_context增益+三视角辩论结论+泛化能力来源）
> 量化架构师审计12隐患+修复决策——详见 `references/quant-architect-audit-v0.16.md`（P0: 前视偏差/关键词分类/非正交评分/全量累计。P1: Finnhub限流/prompt超长/WAL冲突/CST日期。P2: 非原子写入/硬编码映射/串行无限流/SQL时区。v0.17修了4个P0/P1，含修复决策框架：按OKR链路排优先级+不修8个低ROI的+审计方法论）
> 时区审计方法论——详见 `references/timezone-audit-methodology.md`（修复时区bug后的grep全模块扫描法+4处漏网案例+ET时区标准代码片段+系统性pattern修复原则）
> 数据流审计方法论——详见 `references/data-flow-audit-methodology.md`（8类数据流问题检查清单:重复写入/地址不一致/代码注入/变量覆盖/分类冗余/并行限流/冗余函数/重复计算+修复决策框架）
> 3股全链路模拟验证——详见 `references/full-pipeline-simulation-20260705.md`（MU/CVNA/MRVL实跑5阶段输出+12个跨阶段优化点：scanner-LLM方向冲突/pattern非个股特定/盈亏比无下限/溯源率<50%/过期财报日未清洗/claim_type去重缺失）
> FTSeek退出规则全景——详见 `references/ftseek-exit-rules-20260705.md`（exit_policy.yaml v3.0的4条启用规则+禁用规则列表+374笔真实退出分布+方向×退出交叉矩阵+deep_analysis与FTSeek退出系统的关系图+关键源码位置）
> 波动率桶×方向SL/TP数据推导——详见 `references/volatility-bucket-sl-tp-analysis-20260705.md`（374笔数据按桶×方向分桶盈亏中位数+SL/TP不匹配诊断+分桶×方向阈值建议+优雅实现方案3步+5条退出策略建议+亏损仓退出方式对比+持仓时间×方向盈亏矩阵）
> IC分方向拆解+Strength倒挂+4h生死线——详见 `references/ic-direction-strength-inversion-20260708.md`（7个Finding完整数据: LONG IC=-0.067/Strength低胜率高/2-4h死亡区间/04:xx模板投票实锤/主动退出=亏损引擎/NEUTRAL 0%WR+优化方案优先级矩阵+多DB诊断路径+审计SQL模板）
> deep_analysis架构gap+替代voting_llm三阶段方案——详见 `references/deep-analysis-replace-voting-20260708.md`
> 市场扫描差距分析(参考报告vs FTSeek)——详见 `references/market-scanner-gap-analysis-20260708.md`（5个差距:渠道源/板块轮动叙事/四信号评分/featured override/操作分桶+P0-P2优先级+实现约束）
> 规划-执行分离架构分析——详见 `references/plan-execute-separation-20260708.md`（3个断裂点:adapter无人消费/分桶退出脱节/反馈环路断裂+3个最小改动方案+FTSeek退出规则映射表+claim_ic_cache有效性数据+冻结期可做项清单）
> HorizonSelector趋势强度评分——详见 `references/horizon-selector-trend-scoring-20260708.md`（T1/T3/T5胜率对比+持仓时间vs PnL+趋势强度0-6分规则+高波动一票否决+7/7验证结果+验证SQL模板）
> v0.23多渠道扫描实施记录——详见 `references/market-scanner-v023-implementation-20260708.md`（3个collect函数+6个新方法+四信号评分公式+5桶分桶条件+change_rate bug修复+验证结果）
> 盘前全链路验证(代码改动后服务运行中)——详见 `references/pre-market-verification-20260708.md`（mtime vs process_start判断+7项验证清单+重启决策矩阵）（FTSeek playbook pipeline数据流+deep_analysis无执行路径证明+三阶段方案+SL/TP配置链+多DB地图+05:xx模板投票检测SQL）
> voting_llm移除/迁移分析——详见 `references/voting-removal-migration-20260709.md`
> 交易表现分析方法论——详见 `references/trade-performance-analysis-20260709.md`（5步查询法+跨库ATTACH执行率分析+SQL模板+2026-07-09实盘快照: 80笔40%胜率-$1435/执行率4.7%/空壳DB陷阱）
> Bridge链路审计方法论——详见 `references/bridge-link-audit-methodology.md`（5点审计法:bridge文件/runtime读取/voting路径/DB执行/脚本状态+DB位置陷阱+列名陷阱+时序gap发现+断点确认方法+审计SQL模板）
> 退出规则三层架构——详见 `references/exit-rule-three-layer-architecture-20260709.md`（Layer1:盘前conditions→factor_exit_rules匹配退出策略类型 | Layer2:vol_buckets分桶算SL/TP数值,rr_ratio=999覆盖TP | Layer3:exit_param_override动态反馈调整 | bridge vs voting conditions对比 | 动态SL计算公式 | 当前限制:无condition级TP差异化）
> 三方辩论+第一性原理复盘——详见 `references/three-agent-debate-and-first-principles-20260709.md`（多头/空头/架构师辩论+voting_llm方向47%≈随机+TRAILING_STOP实际-$224+DAY_TRADE_TP唯一盈利+持仓4-8h唯一盈利窗口+MFE/MAE采集+decision_id贯穿+f1-f5持久化+6项P0修复+期权清理+修复优先级路线图。**注意**: 文中"立即可做"的建议(HIGH_VOL regime过滤/TRAILING_STOP调参)已作废——这些基于旧参数数据, 见 Pitfall #63**）
> 参数变更后旧数据失效——详见 `references/stale-data-after-parameter-change-20260709.md`（用户纠正: 旧参数数据不能驱动新参数决策+时间线验证命令+方法论原则+新管线下需等待的数据清单）
> 取消3模型投票+2模型辩论+bridge直写DB——详见 `references/voting-replacement-and-2-model-debate-20260709.md`（NullVotingAdapter切断噪声源+SPY/QQQ/行业peer数据采集+qwen→deepseek 2模型辩论融合+AAPL/NVDA实测辩论结果+Ponytail/Karpathy原则应用+bridge直写instruction到DB绕过幂等+NullVotingAdapter防SKIP覆盖+退出参数收紧breakeven/drawdown）
> 规划-执行解耦架构审计——详见 `references/plan-execute-decoupling-audit-20260709.md`
> confidence第一性原理分析——详见 `references/confidence-first-principles-20260710.md`（三系统零预测力数据验证+LLM自评r=-0.211+数据质量r=-0.073+SignalQualityScorer r=-0.038+模型一致度r=+0.102+debate-only最终方案+验证SQL）（12点消费链路验证+3个P0断点修复+cron钉钉推送+退出参数收紧+日cap提升）
>  计划-执行四大断裂分析——详见 `references/plan-execute-gap-first-principles-20260711.md`（价格单点vs区间+趋势生成≠触发+范围永不过期+SL/TP联动断裂+DB证据60-80%不触发+entry_strategy被丢弃+zone+type+sl_basis+validity设计模式+向后兼容+审计SQL模板）
> SL/TP re-price kill chain分析——详见 `references/sl-tp-reprice-kill-chain-20260711.md`（NVDA 7/10完整kill chain+DA-交易SL对比+MFE分布+breakeven影响+核心洞察:入场质量>止损位置+sl_basis分流方案+审计SQL模板）

```bash
cd ~/.hermes/skills/deep-stock-analysis/scripts

# LLM深度分析(默认) — 必须用FTSeek venv的python3.11
/opt/ftseek/FTSeek-US/venv/bin/python3.11 pipeline.py --mode analyze --symbol US.NVDA --synth llm

# 纯规则分析(不调LLM,秒级)
/opt/ftseek/FTSeek-US/venv/bin/python3.11 pipeline.py --mode analyze --symbol US.NVDA --synth rule

# 市场扫描 — v0.11已提升市值过滤(min-market-cap 500=5亿美元)+主流标的偏好评分
/opt/ftseek/FTSeek-US/venv/bin/python3.11 pipeline.py --mode scan --limit 15 --top 5

# 完整管线
/opt/ftseek/FTSeek-US/venv/bin/python3.11 pipeline.py --mode full --limit 15 --top 5
```

## Obsidian per-symbol 归档 (v0.22新增)

每次deep_analysis产出后, 自动追加到 `obsidian_vault/symbols/US_XXX.md`:
- **位置**: `/opt/ftseek/FTSeek-US/obsidian_vault/symbols/`
- **触发**: pipeline.py的`run_full()`和`run_analyze_only()`中, `ic_writer.write_signal_snapshot()`后自动调用
- **内容**: 日期section含verdict/bull_case/bear_case/execution_plan/causal_chain + frontmatter战绩(strategy_memory.db同步)
- **论据IC标注 (v0.22.1)**: 每条论据后附`[IC=+0.56✅n=9]`(从claim_ic_cache.json读取), section底部有"论据IC验证"段(effective/ineffective列表)
- **wikilinks (v0.22.1)**: frontmatter含industry字段, `_find_industry_peers()`扫描同行业symbol pages生成`[[US_MSFT]]`链接
- **历史回填 (v0.22.1)**: `scripts/backfill_symbol_pages.py`从signal_snapshots.db灌历史分析(54条→43页), 兼容旧/新factors_json格式
- **幂等**: decision_id作为HTML注释锚点`<!-- id:xxx -->`,同id不重复追加
- **best-effort**: 失败只log warning不阻塞pipeline
- **实现**: `app/core/obsidian_writer.py` `write_symbol_analysis()` + 4个helper方法(`_load_claim_ic`/`_claim_ic_tag`/`_build_ic_summary`/`_find_industry_peers`)
- **用途**: 在Obsidian中打开obsidian_vault目录, 按标的浏览历次深度分析, 用wikilink交叉引用同行业标的, 每条论据可看到历史IC预测力

| 维度 | 来源 | 时效 |
|------|------|------|
| 快照(PE/PB/EPS/市值/52w) | OpenD | 实时 |
| K线(60日OHLCV) | OpenD | 实时 |
| **资金流向(主力净流入)** | **OpenD** | **实时** |
| **资金分布(大单/中单/小单)** | **OpenD** | **实时** |
| 技术异动 | OpenD | 7日 |
| 资金异动 | OpenD | 7日 |
| 衍生品异动 | OpenD | 7日 |
| 新闻(10条) | 富途HTTP | 实时 |
| 研报(5条) | 富途HTTP | 实时 |
| 社区情绪(30帖) | 富途HTTP | 实时 |
| 基本面(营收增长/ROE/利润率) | Finnhub | TTM |
| 分析师评级(buy/hold/sell) | Finnhub | 月度 |
| 内部人交易(买卖记录) | Finnhub | 实时 |
| 内部人情绪(MSPR) | Finnhub | 月度 |
| 公司概况(行业) | Finnhub | 实时 |
| 财报日历(下次财报) | Finnhub | 实时 |
| **数据质量审计** | 内部 | 实时 |

> v0.12新增: capital_flow + capital_distribution 两源(OpenD get_capital_flow.py/get_capital_distribution.py)，deep_analyzer资金面不再永远空。
