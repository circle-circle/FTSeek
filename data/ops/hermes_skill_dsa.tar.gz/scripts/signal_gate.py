#!/usr/bin/env python3
"""
Signal Gate — 信号质量门禁 + 策略推荐
=====================================
盘前对deep_analysis输出做最终质量检查，基于strategy_memory的经验。

职责:
  1. 信号质量评分：用个股历史+pattern匹配给信号打质量分
  2. 策略推荐：根据赢/亏pattern推荐持仓时长、退出方式
  3. 风险控制：检查方向冲突、极端条件、仓位集中度
  4. 门禁决策：PASS / WARN / BLOCK

不做:
  - 不替代LLM的个股分析（只做质量检查+策略适配）
  - 不碰FTSeek退出系统（只推荐，不修改退出规则）
  - 不做方向门禁（不因为"LONG弱"就一律BLOCK BUY）
"""

import json
import os
import sys
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import strategy_memory


def _load_claim_ic_for_gate() -> Optional[Dict]:
    """读取claim IC缓存供Gate检查论据有效性"""
    try:
        from alpha_backfill import load_claim_ic
        return load_claim_ic()
    except Exception:
        return None


def _load_regime_for_gate() -> Optional[str]:
    """读取当前市场 regime (复用 FTSeek MarketRegimeGate, 与 bridge 同源).

    2026-08-04 接线 (回测实证): 入场侧 score/conf/quality_score 对成交质量
    均无区分度 (WR 50-60% 无单调), 但 regime 有: cautious 61笔 WR=54% PnL=-$341
    是最大亏损源 (risk_off 67% +$15 / UNKNOWN 45% +$83). 故 gate 用 regime 做
    软降权, 替代无效的 score 门槛调整.
    """
    try:
        import sys as _sys
        _sys.path.insert(0, "/opt/ftseek/FTSeek-US")
        from app.playbook.market_regime import MarketRegimeGate as _MRG
        _rc = _MRG().assess()
        return _rc.regime.value
    except Exception:
        return None


def _infer_claim_type(thesis: str, source_type: str, evidence: str = "") -> str:
    """从论点文本推断claim_type（复用ic_writer._classify_claim逻辑）"""
    try:
        from ic_writer import _classify_claim
        return _classify_claim(thesis, source_type, evidence)
    except ImportError:
        return "unclassified"


def evaluate_signal(analysis: Dict[str, Any]) -> Dict[str, Any]:
    """对deep_analysis的输出做质量评估+策略推荐。

    analysis: pipeline analyze的输出dict

    Returns:
        {
            "quality_score": 0-100,
            "decision": "PASS" / "WARN" / "BLOCK",
            "reasons": [str, ...],
            "strategy_hint": {
                "recommended_hold": "short(<2h)" / "mid(2-12h)" / "long(12h+)",
                "recommended_exit": "EOD_FORCE_CLOSE" / "TRAILING_STOP" / ...,
                "position_size_hint": "normal" / "small" / "tiny",
                "risk_notes": [str, ...],
            },
            "pattern_match": {
                "similar_win": {direction, exit_reason, win_rate, ...} or None,
                "similar_loss": {direction, exit_reason, pnl, ...} or None,
            },
        }
    """
    symbol = analysis.get("symbol", "")
    direction = analysis.get("action", "SKIP")
    score = float(analysis.get("score", 5.0))
    confidence = 0.7  # default

    llm_out = analysis.get("_llm_output", {})
    if llm_out:
        conf_str = llm_out.get("confidence", "中")
        conf_map = {"高": 0.9, "中高": 0.8, "中": 0.6, "中低": 0.4, "低": 0.3}
        confidence = conf_map.get(conf_str, 0.6)

    ftseek = analysis.get("_ftseek", {})
    vr = ftseek.get("voting_result", {})
    conditions = vr.get("conditions", [])
    entry_price = vr.get("entry_price", 0)
    sl_price = vr.get("stop_loss", 0)
    tp_price = vr.get("take_profit", 0)

    # 获取strategy memory hint
    hint = strategy_memory.get_strategy_hint(symbol=symbol, direction=direction)

    reasons = []
    quality_score = 50  # 基础分
    hist_penalty = 0  # 2026-07-13: 个股历史扣分(soft), 供终判"永不单独BLOCK/不否决强信号"覆盖
    risk_notes = []
    strategy_hint = {
        "recommended_hold": "mid(2-12h)",
        "recommended_exit": "",
        "position_size_hint": "normal",
        "risk_notes": [],
    }

    # ── 0. 方向冲突检测 (2026-07-13 用户A: _scanner_direction 已改为该股真实动量MA排列) ──
    # 真实动量(多头/空头排列)与LLM方向明确相反 → 记 dir_conflict (F2 起仅留痕不降档; 破位硬买 G1 仍拦).
    dir_conflict = False
    scanner_direction = analysis.get("_scanner_direction", "")
    if scanner_direction and direction in ("BUY", "SELL_SHORT"):
        conflict_map = {"bearish": "SELL_SHORT", "bullish": "BUY"}
        scanner_expected = conflict_map.get(scanner_direction, "")
        if scanner_expected and scanner_expected != direction:
            dir_conflict = True
            reasons.append(
                f"方向冲突: 真实动量={scanner_direction}但LLM={direction}"
            )
            risk_notes.append(f"真实动量与LLM方向明确相反")

    # ── 1. 个股历史评估 ──
    # 映射方向：BUY→LONG, SELL_SHORT→SHORT（symbol_memory存的是FTSeek格式）
    dir_map = {"BUY": "LONG", "SELL_SHORT": "SHORT"}
    sym_dir_key = dir_map.get(direction, direction)

    sym_hist = hint.get("symbol_history", {})
    sym_dir_hist = sym_hist.get(sym_dir_key, {})
    if sym_dir_hist:
        trades = sym_dir_hist["trades"]
        wr = sym_dir_hist["win_rate"]
        pnl = sym_dir_hist["total_pnl"]

        if trades >= 3 and wr < 0.3 and pnl < 0:
            # 本股同方向历史3+笔且胜率<30% → 降分(soft: 永不单独BLOCK, 见终判覆盖)
            quality_score -= 15
            hist_penalty = -15
            reasons.append(
                f"本股{symbol}同方向{trades}笔WR={wr*100:.0f}%PnL=${pnl}，历史表现差"
            )
            strategy_hint["position_size_hint"] = "small"
            risk_notes.append(f"本股{direction}历史{trades}笔WR={wr*100:.0f}%")
        elif trades >= 2 and wr >= 0.6:
            # 本股同方向胜率高 → 加分
            quality_score += 15
            reasons.append(
                f"本股{symbol}同方向{trades}笔WR={wr*100:.0f}%，历史表现好"
            )

    # ── 2. Pattern匹配 ──
    win_patterns = hint.get("win_patterns", [])
    loss_patterns = hint.get("loss_patterns", [])

    # 优先个股历史pattern，无记录时fallback到全市场pattern
    sym_hist_all = sym_hist.get(sym_dir_key, {})
    has_symbol_history = bool(sym_hist_all)

    # 检查当前方向是否匹配赚钱pattern
    # pattern_memory存LONG/SHORT格式，需映射
    matched_win = None
    for p in win_patterns:
        if p["direction"] == sym_dir_key:
            matched_win = p
            # 置信度检查：低置信pattern只加分不推荐退出
            conf = p.get("confidence", "low")
            if conf in ("very_low", "low"):
                quality_score += 5  # 减半加分（原10→5）
                pattern_src = "个股" if has_symbol_history else "全市场"
                reasons.append(
                    f"匹配赚钱pattern({pattern_src},低置信): {p['direction']}+{p['exit_reason']} "
                    f"WR={p['win_rate']*100:.0f}% ({p['trades']}笔,样本不足仅参考)"
                )
                # 不推荐退出方式——样本不足
            else:
                quality_score += 10
                reasons.append(
                    f"匹配赚钱pattern: {p['direction']}+{p['exit_reason']} "
                    f"WR={p['win_rate']*100:.0f}%"
                )
                strategy_hint["recommended_exit"] = p["exit_reason"]
                if p["avg_hold"] and p["avg_hold"] > 12:
                    strategy_hint["recommended_hold"] = "long(12h+)"
                elif p["avg_hold"] and p["avg_hold"] < 2:
                    strategy_hint["recommended_hold"] = "short(<2h)"
            break

    # 检查是否匹配亏钱pattern
    matched_loss = None
    for p in loss_patterns:
        if p["direction"] == sym_dir_key:
            matched_loss = p
            quality_score -= 10
            pattern_src = "个股" if has_symbol_history else "全市场"
            reasons.append(
                f"匹配亏钱pattern({pattern_src}): {p['direction']}+{p['exit_reason']} "
                f"PnL=${p['pnl']}"
            )
            risk_notes.append(
                f"此方向+{p['exit_reason']}历史PnL=${p['pnl']}"
            )
            break

    # ── 3. 信号质量评估 ──
    if score >= 8:
        quality_score += 15
        reasons.append(f"LLM评分{score}/10，高确信度")
    elif score >= 6:
        quality_score += 5
    elif score < 4:
        quality_score -= 15
        reasons.append(f"LLM评分{score}/10，低确信度")

    if confidence >= 0.8:
        quality_score += 5
    elif confidence < 0.5:
        quality_score -= 10

    # ── 4. 风险检查 ──
    # 止损/止盈比
    if entry_price and sl_price and tp_price:
        risk = abs(entry_price - sl_price)
        reward = abs(tp_price - entry_price)
        if risk > 0:
            rr = reward / risk
            if rr >= 2.0:
                quality_score += 10
                reasons.append(f"盈亏比{rr:.1f}:1，良好")
            elif rr < 1.0:
                quality_score -= 15
                reasons.append(f"盈亏比{rr:.1f}:1，风险>收益")
                risk_notes.append(f"盈亏比{rr:.1f}:1偏低")
            strategy_hint["risk_reward"] = round(rr, 2)

    # conditions检查
    if not conditions and direction in ("BUY", "SELL_SHORT"):
        quality_score -= 5
        reasons.append("无conditions，退出策略将用default")

    # ── 5. 退出效果推荐 ──
    exit_eff = hint.get("exit_effectiveness", [])
    if exit_eff and not strategy_hint["recommended_exit"]:
        # 选PnL最高的退出方式，但必须置信度足够
        best_exit = max(exit_eff, key=lambda x: x["pnl"])
        conf = best_exit.get("confidence", "low")
        if best_exit["pnl"] > 0 and conf not in ("very_low", "low"):
            strategy_hint["recommended_exit"] = best_exit["exit_reason"]
            reasons.append(
                f"推荐退出: {best_exit['exit_reason']} "
                f"(WR={best_exit['win_rate']*100:.0f}% PnL=${best_exit['pnl']} "
                f"{best_exit['trades']}笔)"
            )
        elif best_exit["pnl"] > 0 and conf in ("very_low", "low"):
            # 低置信——只提示不强推
            reasons.append(
                f"退出参考(低置信): {best_exit['exit_reason']} "
                f"PnL=${best_exit['pnl']} 但仅{best_exit['trades']}笔样本不足"
            )

    # ── 6. 教训检查 ──
    lessons = hint.get("recent_lessons", [])
    for lesson in lessons:
        if "HIGH" in lesson and direction in lesson:
            risk_notes.append(f"近期教训: {lesson[:100]}")

    # ── 6.5 论据有效性检查 ──
    # 从claim IC缓存读取，检查LLM用的论据是否历史验证有效
    claim_ic = _load_claim_ic_for_gate()
    if claim_ic:
        ineffective = claim_ic.get("ineffective_claims", [])
        effective = claim_ic.get("effective_claims", [])
        if ineffective or effective:
            # 解析LLM输出中的claim_type
            # 注意: ic_writer._classify_claim输出的claim_type(如valuation_cheap)
            # 与voting_llm的factors_json里的condition名(如pe_below_industry)命名不同
            # 需要建立映射关系统一比较
            _CLAIM_NAME_MAP = {
                # ic_writer claim_type → voting_llm condition名 (只映射真正等价的)
                "valuation_cheap": ["pe_below_industry"],
                "valuation_expensive": ["pe_above_industry"],
                "insider_bearish": ["insider_net_sell"],
                "insider_bullish": ["insider_net_buy"],
                # technical_breakout只映射above_ma20，不覆盖macd_golden_cross/rsi_oversold
                # 因为这些在voting_llm里有独立的IC统计，不该被technical_breakout别名覆盖
                "technical_breakout": ["above_ma20"],
                "technical_breakdown": ["below_ma20"],
                "earnings_beat": ["revenue_growth_high", "roe_high", "earnings_beat_streak"],
                "product_catalyst": ["news_positive"],
                "macro_headwind": ["news_negative"],
            }

            llm_out = analysis.get("_llm_output", {})
            used_claims = set()
            for case_key in ("bull_case", "bear_case"):
                for r in llm_out.get(case_key, []):
                    ct = r.get("claim_type") or _infer_claim_type(
                        r.get("thesis", ""), r.get("source_type", ""), r.get("evidence", "")
                    )
                    if ct:
                        used_claims.add(ct)

            # 把used_claims展开为所有可能的别名，再和effective/ineffective交叉
            used_aliases = set()
            for ct in used_claims:
                # 同时保留原生 claim_type (匹配 deep_analysis-only 缓存) + legacy 别名 (向后兼容池化缓存)
                used_aliases.add(ct)
                used_aliases.update(_CLAIM_NAME_MAP.get(ct, []))

            bad_claims = used_aliases & set(ineffective)
            good_claims = used_aliases & set(effective)

            if bad_claims:
                quality_score -= 10
                reasons.append(
                    f"使用了历史超额为负的论据: {', '.join(bad_claims)} "
                    f"(平均跑输大盘，建议用其他论据支撑)"
                )
                risk_notes.append(f"论据有效性⚠️: {', '.join(bad_claims)}历史超额为负")

            if good_claims:
                quality_score += 5
                reasons.append(
                    f"使用了历史验证有效论据: {', '.join(good_claims)}"
                )

    strategy_hint["risk_notes"] = risk_notes

    # ── 6.7 来源验证检查 (2026-08-04 接线: _verify_sourced_numbers 计算结果此前零消费) ──
    # llm_synth._verify_sourced_numbers 已把 LLM 输出数字与输入数据比对, 结果随
    # _llm_output 传入 (deep_analyzer._apply_llm_result → asdict)。此处消费:
    # 未验证数字 ≥1 → 扣分 + 风险提示 (幻觉风险软拦截, 不单独 BLOCK)。
    sv = (llm_out or {}).get("_source_verification")
    if sv:
        uv = sv.get("unverified_count", 0)
        flagged = sv.get("flagged_claims", [])
        if uv >= 3:
            quality_score -= 15
            reasons.append(f"来源验证: {uv}个数字未在输入数据中溯源 (幻觉风险)")
            risk_notes.append(f"LLM输出{uv}个未验证数字，可能幻觉")
        elif uv >= 1:
            quality_score -= 10
            reasons.append(f"来源验证: {uv}个数字未在输入数据中溯源")
            risk_notes.append(f"LLM输出{uv}个未验证数字")
        for f in list(dict.fromkeys(flagged))[:2]:
            # [M3 2026-08-29, DEB-20260829] flagged 去重 — 同一"未验证论据"可重复出现
            #   (8/28 ESTC 实测连打两遍), dict.fromkeys 保序去重后取前2。
            reasons.append(f"未验证论据: {str(f)[:60]}")

    # ── 6.8 市场环境检查 (2026-08-04 接线: 回测实证 cautious 是最大亏损源) ──
    # 数据: cautious 61笔 WR=54% PnL=-$341 (TIME_EXIT 15笔 -$400 + MFE_STALL 8笔 -$251
    #   为亏损主力); risk_off 67% +$15 / RANGE 67% +$9 / UNKNOWN 45% +$83.
    # 软降权: 不 BLOCK (cautious 下仍有 SL_TRAIL_LOCK 11笔 100% +$211 等好退出),
    #   只降分 + 缩仓, 与 hist_penalty 同语义.
    # 优先用 pipeline 注入的 analysis["_regime"] (算一次, 避免逐股重复网络拉取);
    # 无注入时 lazy 调用 MarketRegimeGate (120s 类缓存兜底).
    regime = analysis.get("_regime") or _load_regime_for_gate()
    if regime == "cautious" and direction in ("BUY", "SELL_SHORT"):
        quality_score -= 10
        reasons.append(f"市场环境谨慎(cautious): 历史DA成交61笔WR=54% PnL=$-341, 降权")
        risk_notes.append("cautious 环境下历史胜率偏低, 建议缩仓")
        if strategy_hint["position_size_hint"] == "normal":
            strategy_hint["position_size_hint"] = "small"

    # ── 7. 最终决策 ──
    quality_score = max(0, min(100, quality_score))

    # ── decision-confidence: 用双模型辩论一致度 (live), 替代 LLM 自评 (2026-07-18, 用户) ──
    #   证据: LLM 自评 confidence 与胜率 r=-0.211(负相关, 越自信越不准),
    #         双模型一致度 r=+0.102(唯一正相关)。adapter._compute_confidence 早已弃自评,
    #         此处 gate 分级同步切换, 消除"gate 用自评 / DB 用辩论"的口径矛盾。
    #   算法与 adapter._compute_confidence 同基准同三态 (基准0.50, 独立一致+0.20, 分歧-0.15),
    #   但**已知两处实现差异** (2026-10-27 B2 实测勘误, 原注释"完全一致"不成立):
    #     ① 弃权分支: gate 按 score/10 抬升, adapter 保持 0.50 (同事件两个 conf, 见 US.META 2026-10-27);
    #     ② 分数差衰减 -(Δ-3)×0.015 只在 adapter 侧。
    #   本批只修"明确反对被当弃权抬升"一处 (见下), 不动 ①② 其余差异。
    _decision_conf = 0.50
    _dbt = llm_out.get("_debate", {}) if llm_out else {}
    if _dbt:
        _cd = str(_dbt.get("challenger_direction", "")).upper()
        _od = str(llm_out.get("direction", "")).upper()
        _ag = _dbt.get("challenger_agreed", False)
        _oc = str(llm_out.get("debate_outcome", "")).upper()
        _fb = bool(_dbt.get("challenger_fallback"))
        if _cd == _od:
            if (_ag or "AGREE" in _oc) and not _fb:
                _decision_conf += 0.20
        elif "SKIP" in (_cd, _od):
            # 2026-07-18 根因修复: 一方弃权(SKIP) != 真反向, 中性不罚 (与 adapter 同步)。
            # 2026-08-06 (用户指示, sim 验证期): 弃权时用主模型 score/10 抬升分级 —
            #   挑战者弃权率高 (8/4: 72%, 8/6: 16/16=100%) → decision_conf 恒 0.50 →
            #   tier 上限=中(WARN) → 全 WARN → 落库 conf 全被 WARN 降权压到 35 → 无分层.
            #   弃权≠反对, 主模型方向+score 是唯一可用信号 → score≥7 恢复"优/PASS".
            #   回滚: 本行改回 pass。
            # [2026-10-27 B2 修复] 抬升只对**真弃权**生效: 挑战者 verdict=DISAGREE 却把
            #   my_direction 填成 SKIP ⇒ 输出自相矛盾 (Prompt 要求 DISAGREE 必给反方向),
            #   但它**明确表达了反对**。旧实现不区分二者, 一律按 score/10 抬到 0.6~0.8
            #   ⇒ tier 良/优 ⇒ PASS ⇒ "明确反对"反而拿最高档 (实测 2026-10-27 US.META:
            #   DISAGREE+SKIP → decision_conf 0.80 / tier 优 / PASS; 全账 2308 行中 10 行同形)。
            #   本段原注释「弃权≠反对」本就是要区分二者, 只是实现漏判 verdict。
            #   处置: 明确反对 ⇒ 不抬升 (保持基准 0.50), 交由 score/tier 正常分级;
            #   tier 最低到"中/WARN", 不会硬 BLOCK, 供给不灭 (只降级不删除)。
            #   回滚: DA_GATE_DISAGREE_NO_LIFT=0 (或删本段)。
            _vd = str(_dbt.get("challenger_verdict", "")).upper()
            _self_debate = bool(_dbt.get("challenger_self_debate"))
            if (os.environ.get("DA_GATE_DISAGREE_NO_LIFT", "1") == "1"
                    and _vd == "DISAGREE" and not _self_debate):
                reasons.append(
                    "弃权抬升抑制: 挑战者明确DISAGREE但未给反方向(输出自相矛盾) → "
                    f"不按score抬升conf (2026-10-27 B2; 旧口径conf={max(0.50, score / 10.0):.2f})"
                )
            else:
                _decision_conf = max(_decision_conf, score / 10.0)
        else:
            _decision_conf -= 0.15  # 真反向
    _decision_conf = max(0.10, min(0.95, _decision_conf))

    # ── 分级: score(live) + decision_conf(live 辩论一致度) (F2后方向冲突只记录不降档) ──
    if direction not in ("BUY", "SELL_SHORT"):
        tier = "SKIP"
    elif score >= 7 and _decision_conf >= 0.7:
        tier = "优"
    elif score >= 6 and _decision_conf >= 0.6:
        tier = "良"
    elif score >= 5 and _decision_conf >= 0.5:
        tier = "中"
    else:
        tier = "差"

    # 择时记录 (DEB-20261008 F2, 2026-10-08 用户裁决): 方向冲突降为纯记录 — 实测该闸
    #   净压空头 (近15日 SHORT 存活率 66.1% vs BUY 78.7%), 与「多空不人为拦截」裁决冲突,
    #   故只留痕不降档。G1 破位硬买门 (下方) 保留 (防接飞刀, 用户裁决保留)。
    #   回滚: 恢复 tier 降2档分支 (见 references/CHANGELOG.md v0.95 条目)。
    if dir_conflict and tier in ("优", "良", "中"):
        reasons.append("择时记录: 真实动量与LLM方向明确相反 (仅留痕不降档, DEB-20261008 F2)")

    # 2026-07-22 (用户B): 明确破位(空头排列)却给BUY → 直接 SKIP(不硬买下跌趋势, 也不追跌做空).
    #   根因: 原仅降2档, 高质量价值叙事仍能以 WARN/tiny 出 BUY = 接飞刀. DA 定位优质多头选股器,
    #   遇到"动量已明确转空"应观望等回稳, 而非逢跌硬买. 做空机会交由 UE 不设限浮现负责.
    #   仅对 bearish 动量 + BUY 生效; 多头排列做空(bullish+SELL_SHORT)不在本门拦。
    #   DEB-20261008 F2 后方向冲突只留痕不降档 (见上方 §择时记录), 勿按旧注释理解。
    if scanner_direction == "bearish" and direction == "BUY":
        tier = "SKIP"
        reasons.append("破位硬买拦截: 真实动量=空头排列但LLM=BUY → SKIP(不接飞刀, 做空交由UE浮现)")

    # tier → decision + 仓位
    _tier_map = {
        "优": ("PASS", "normal"),
        "良": ("PASS", "small"),
        "中": ("WARN", "tiny"),
        "差": ("BLOCK", "tiny"),
        "SKIP": ("BLOCK", "normal"),
    }
    decision, _pos = _tier_map[tier]
    if tier != "SKIP":
        strategy_hint["position_size_hint"] = _pos
    reasons.append(
        f"分析结论排序={tier}(score={score}/10 decision_conf={_decision_conf:.2f} [辩论一致度]; "
        f"纯标的分析不计RR/pattern/claim-IC/历史; 方向冲突仅留痕(DEB-20261008 F2))"
    )

    # 2026-08-04 (P6): BLOCK/SKIP 的真正原因排首位 — 原 reasons 顺序把"推荐退出"
    # 等次要信息排在前面, 阅读日志时误判拦截原因 (实证: 8/4 37条BLOCK 首条全是
    # "推荐退出: SL_TRAIL_LOCK", 真正原因"分析结论排序=SKIP"在最后).
    if decision == "BLOCK" and len(reasons) > 1:
        # 找出最后一条排序原因 (tier 判定), 移到首位
        for i in range(len(reasons) - 1, 0, -1):
            if "分析结论排序=" in reasons[i]:
                _verdict = reasons.pop(i)
                reasons.insert(0, _verdict)
                break

    # ── 影子记录: 若仍用旧的 LLM 自评 confidence 分级会如何 (供回溯对比) ──
    if direction not in ("BUY", "SELL_SHORT"):
        _shadow_tier = "SKIP"
    elif score >= 7 and confidence >= 0.7:
        _shadow_tier = "优"
    elif score >= 6 and confidence >= 0.6:
        _shadow_tier = "良"
    elif score >= 5 and confidence >= 0.5:
        _shadow_tier = "中"
    else:
        _shadow_tier = "差"
    if dir_conflict and _shadow_tier in ("优", "良", "中"):
        _ld = ["差", "中", "良", "优"]
        _shadow_tier = _ld[max(0, _ld.index(_shadow_tier) - 2)]
    _shadow_decision = {"优": "PASS", "良": "PASS", "中": "WARN",
                        "差": "BLOCK", "SKIP": "BLOCK"}[_shadow_tier]

    # ── P0 影子双写 (DEB-20260814 §9.4 修正②, 2026-08-14): 四态细分 conf 的
    #   record-only 对照。live decision/tier/conf 零变更 (上方逻辑未动), 仅多算
    #   一遍"若同向 PARTIAL_AGREE 给 0.60 (良/PASS small)"的影子 tier/decision,
    #   随 gate jsonl 落盘。n≥30 且 ≥10 交易日后按 §9.5 判据 (供给+edge 双指标)
    #   裁决是否转 live。实证依据: PARTIAL_AGREE:AGREE=21:2 (8/1+ bridge),
    #   WARN组不劣于PASS组 (§9.2)。回滚: DA_GATE_P0_SHADOW=0 或删除本段。
    _p0_shadow = None
    if os.environ.get("DA_GATE_P0_SHADOW", "1") == "1" and _dbt:
        try:
            _vd = str(_dbt.get("challenger_verdict", "")).upper()
            _fb = bool(_dbt.get("challenger_fallback"))
            _v2_conf = _decision_conf
            if (_cd == _od and "PARTIAL_AGREE" in _vd and not _fb
                    and not (_ag or "AGREE" in _oc)):
                _v2_conf = min(0.95, _decision_conf + 0.10)  # 0.50→0.60
            if direction not in ("BUY", "SELL_SHORT"):
                _v2_tier = "SKIP"
            elif score >= 7 and _v2_conf >= 0.7:
                _v2_tier = "优"
            elif score >= 6 and _v2_conf >= 0.6:
                _v2_tier = "良"
            elif score >= 5 and _v2_conf >= 0.5:
                _v2_tier = "中"
            else:
                _v2_tier = "差"
            if dir_conflict and _v2_tier in ("优", "良", "中"):
                _ld2 = ["差", "中", "良", "优"]
                _v2_tier = _ld2[max(0, _ld2.index(_v2_tier) - 2)]
            _p0_shadow = {
                "conf": round(_v2_conf, 2),
                "tier": _v2_tier,
                "decision": {"优": "PASS", "良": "PASS", "中": "WARN",
                             "差": "BLOCK", "SKIP": "BLOCK"}[_v2_tier],
            }
        except Exception:
            _p0_shadow = None

    return {
        "quality_score": quality_score,
        "decision": decision,
        "tier": tier,
        "reasons": reasons,
        "strategy_hint": strategy_hint,
        "pattern_match": {
            "similar_win": matched_win,
            "similar_loss": matched_loss,
        },
        "decision_conf": round(_decision_conf, 2),
        "shadow_llm_self_tier": _shadow_tier,
        "shadow_llm_self_decision": _shadow_decision,
        "llm_self_conf": round(confidence, 2),
        "p0_shadow": _p0_shadow,
    }


def format_gate_report(gate_result: Dict, symbol: str) -> str:
    """格式化gate报告（人类可读）"""
    lines = []
    decision = gate_result["decision"]
    emoji = "✅" if decision == "PASS" else "⚠️" if decision == "WARN" else "🚫"

    lines.append(f"{emoji} Signal Gate: {symbol} | {decision} | 质量分={gate_result['quality_score']}")

    if gate_result["reasons"]:
        lines.append("理由:")
        for r in gate_result["reasons"]:
            lines.append(f"  • {r}")

    hint = gate_result.get("strategy_hint", {})
    if hint:
        lines.append(f"策略推荐: 持仓={hint.get('recommended_hold','')} "
                     f"退出={hint.get('recommended_exit','')} "
                     f"仓位={hint.get('position_size_hint','')}")
        if hint.get("risk_notes"):
            lines.append("风险提示:")
            for r in hint["risk_notes"]:
                lines.append(f"  ⚠️ {r}")

    return "\n".join(lines)


def main():
    import argparse
    parser = argparse.ArgumentParser(description="Signal Gate")
    parser.add_argument("--symbol", required=True)
    parser.add_argument("--action", choices=["summary", "hint"], default="hint")
    args = parser.parse_args()

    if args.action == "hint":
        h = strategy_memory.get_strategy_hint(symbol=args.symbol)
        print(strategy_memory.format_hint_for_prompt(h, symbol=args.symbol))


if __name__ == "__main__":
    main()
