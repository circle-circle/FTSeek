#!/usr/bin/env python3
"""
Alpha Backfill — 剥离大盘的alpha IC + 论据级IC
================================================

职责:
  1. 给 signal_snapshots.db 加列: spy_close_t0/t1/t5/t20, spy_ret_t1/t5/t20, alpha_t1/t5/t20
  2. 拉SPY日K线，回填SPY收益和个股alpha
  3. 论据级IC统计: 按 claim_type 分解 IC，验证哪个论点真有预测力

设计原则:
  - 不碰FTSeek运行时代码 (冻结期7/24前)
  - 只import FTSeek的 get_daily_closes (只读函数)
  - 复用 backfill_forward_returns.py 已拉好的个股日K
  - 独立DB列，不修改现有fwd_ret_t1/t5/t20

用法:
  python alpha_backfill.py --add-columns       # 一次性: 加DB列
  python alpha_backfill.py --backfill          # 回填SPY收益和alpha
  python alpha_backfill.py --claim-ic          # 论据级IC统计
  python alpha_backfill.py --all               # 全部执行
"""

import sqlite3
import json
import sys
import os
import math
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Tuple
from collections import defaultdict

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import config

# FTSeek路径 (只读import)
FTSEEK_ROOT = "/opt/ftseek/FTSeek-US"
sys.path.insert(0, FTSEEK_ROOT)

SPY_SYMBOL = "US.SPY"
DB_PATH = "/opt/ftseek/FTSeek-US/data/signal_snapshots.db"

# Alpha列定义
ALPHA_COLUMNS = [
    ("spy_close_t0",  "REAL"),
    ("spy_close_t1",  "REAL"),
    ("spy_close_t5",  "REAL"),
    ("spy_close_t20", "REAL"),
    ("spy_ret_t1",    "REAL"),
    ("spy_ret_t5",    "REAL"),
    ("spy_ret_t20",   "REAL"),
    ("alpha_t1",      "REAL"),
    ("alpha_t5",      "REAL"),
    ("alpha_t20",     "REAL"),
    ("market_context_json", "TEXT"),  # 板块/宏观上下文快照 (Phase 3预留)
]


def _get_db_path() -> str:
    """获取signal_snapshots.db路径"""
    db_path = config.FTSEEK_DB.replace("ftseek_us.db", "signal_snapshots.db")
    if not os.path.exists(db_path):
        db_path = DB_PATH
    return db_path


# ── Claim IC 缓存 (供 llm_synth / signal_gate 读取) ──
_CACHE_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "claim_ic_cache.json")

# Claim 有效性分类阈值 (2026-07-10 修复: 改用 avg_alpha 符号而非 score-IC)
#   根因: compute_claim_ic 的 IC = Spearman(strength, alpha), 而 strength=综合评分,
#         同一信号所有 claim 共享同一 x → IC 测的是"评分 vs alpha", 而非"该 claim 的预测力".
#   实测: 缓存中 IC 符号与 avg_alpha 系统性相反 (volume_expansion IC+0.32 但 α−0.65%,
#         insider_bearish IC−0.24 但 α+0.47%), 导致 gate/prompt 反向惩罚了真正赚钱的论据.
#   修法: 用方向已调整的 avg_alpha_t1 符号分类 (α>0=真跑赢, α<0=真跑输),
#         并提高最小样本量, 滤掉 theme 别名(n=7)/macro(n=5) 等小样本噪声.
_CLAIM_MIN_N = 10          # 分类所需最小样本量
_CLAIM_ALPHA_TH = 0.002    # T+1 超额收益阈值 (±0.2%): |avg_alpha| < 阈值视为噪声, 不分类
_PRODUCTION_STRATEGY = "deep_analysis"  # claim IC 只统计该策略(生产消费方), 隔离已禁用的 voting_llm(taxonomy不相交)


def _write_claim_ic_cache(ic_result: Dict):
    """跑完claim IC后写缓存文件，供 llm_synth / signal_gate 读取"""
    try:
        # 只缓存关键信息：每个claim_type的IC和avg_alpha
        cache = {
            "updated_at": datetime.now().isoformat(),
            "strategy_id": ic_result.get("strategy_id", "_pooled"),
            "total_samples": ic_result.get("total_samples", 0),
            "overall_ic_t1": ic_result.get("overall_ic_t1_alpha"),
            "overall_ic_t5": ic_result.get("overall_ic_t5_alpha"),
            "claims": {},
        }
        for ct, data in ic_result.get("by_claim_type", {}).items():
            cache["claims"][ct] = {
                "ic_t1": data.get("ic_t1"),
                "ic_t5": data.get("ic_t5"),
                "avg_alpha_t1": data.get("avg_alpha_t1"),
                "avg_alpha_t5": data.get("avg_alpha_t5"),
                "count": data.get("count", 0),
            }
        # 2026-08-26 审计修复: 直接覆写非原子, 进程中断会留下截断JSON导致消费方
        # (llm_synth/signal_gate)解析失败。先写同目录tmp文件再os.replace()原子替换。
        _tmp_path = _CACHE_PATH + ".tmp"
        with open(_tmp_path, "w") as f:
            json.dump(cache, f, indent=2, ensure_ascii=False)
            f.flush()
            os.fsync(f.fileno())
        os.replace(_tmp_path, _CACHE_PATH)
        print(f"[Claim IC] 缓存已写入: {_CACHE_PATH}")
    except Exception as e:
        print(f"[Claim IC] 缓存写入失败: {e}")


def load_claim_ic() -> Optional[Dict]:
    """读取claim IC缓存 (供 llm_synth / signal_gate 调用)

    Returns: {
        "updated_at": "...",
        "overall_ic_t1": 0.1,
        "claims": {"volume_expansion": {"ic_t1": 0.3, ...}, ...},
        "effective_claims": ["volume_expansion", ...],   # avg_alpha_t1 > +阈值
        "ineffective_claims": ["pe_below_industry", ...], # avg_alpha_t1 < -阈值
    } or None
    """
    if not os.path.exists(_CACHE_PATH):
        return None
    try:
        with open(_CACHE_PATH) as f:
            cache = json.load(f)
        # 分类：有效/无效论据 — 用 avg_alpha_t1(方向已调整的真实超额)符号, 非 score-IC (见文件头 _CLAIM_* 常量)
        claims = cache.get("claims", {})
        effective = [ct for ct, d in claims.items()
                     if d.get("avg_alpha_t1") is not None
                     and d["avg_alpha_t1"] > _CLAIM_ALPHA_TH and d.get("count", 0) >= _CLAIM_MIN_N]
        ineffective = [ct for ct, d in claims.items()
                       if d.get("avg_alpha_t1") is not None
                       and d["avg_alpha_t1"] < -_CLAIM_ALPHA_TH and d.get("count", 0) >= _CLAIM_MIN_N]
        cache["effective_claims"] = effective
        cache["ineffective_claims"] = ineffective
        return cache
    except Exception as e:
        print(f"[Claim IC] 缓存读取失败: {e}")
        return None


def _conn() -> sqlite3.Connection:
    conn = sqlite3.connect(_get_db_path(), timeout=10)
    conn.row_factory = sqlite3.Row
    # 2026-08-26 审计修复: 本脚本为外部进程, 按 SKILL.md 纪律不设 journal_mode (WAL 是持久化属性, 外部设置会干扰主进程可见性)
    conn.execute("PRAGMA synchronous=NORMAL")
    return conn


def add_alpha_columns():
    """给 signal_snapshots 表加 alpha 相关列 (幂等)"""
    conn = _conn()
    added = 0
    for col_name, col_type in ALPHA_COLUMNS:
        try:
            conn.execute(f"ALTER TABLE signal_snapshots ADD COLUMN {col_name} {col_type}")
            added += 1
            print(f"  ✅ 加列: {col_name} ({col_type})")
        except sqlite3.OperationalError:
            pass  # 列已存在
    conn.commit()
    conn.close()
    print(f"[Alpha Backfill] 加列完成: {added} 新列, {len(ALPHA_COLUMNS)-added} 已存在")


def _get_spy_closes() -> Optional[Dict[str, float]]:
    """拉SPY日K收盘价 (复用FTSeek的get_daily_closes，只读)

    2026-08-24 修复: Futu 历史K线偶发挂起 (无超时) 导致 cron 连续3天超时
    (8/20-8/22 全挂) — 用线程+120s join 兜底, 超时即放弃本次 (明天再试),
    不阻塞整个回填链.
    """
    import threading
    _result = [None]

    def _fetch():
        try:
            from scripts.backfill_forward_returns import get_daily_closes
            _result[0] = get_daily_closes(SPY_SYMBOL, extra_days=30)
        except Exception as e:
            print(f"[Alpha Backfill] 拉SPY日K失败: {e}")

    t = threading.Thread(target=_fetch, daemon=True)
    t.start()
    t.join(timeout=120)
    if t.is_alive():
        print("[Alpha Backfill] ⚠️ 拉SPY日K超时(120s), 放弃本次回填 (明日重试)")
        return None

    closes = _result[0]
    if closes and len(closes) >= 5:
        print(f"[Alpha Backfill] SPY日K: {len(closes)} 天, 最新={list(closes.keys())[-1]}")
        return closes
    print(f"[Alpha Backfill] ⚠️ SPY日K不足: {len(closes) if closes else 0} 天")
    return None


def _get_symbol_closes_from_db(conn, symbol: str) -> Optional[Dict[str, float]]:
    """从已有的close_t0/t1/t5/t20列反推个股日K (零API开销)。

    如果FTSeek backfill已经跑过，close_t0~t20都有值了。
    我们不需要重新拉个股日K，直接用已回填的close计算alpha。
    """
    rows = conn.execute("""
        SELECT trade_date, close_t0, close_t1, close_t5, close_t20
        FROM signal_snapshots
        WHERE symbol = ? AND close_t0 IS NOT NULL
        ORDER BY trade_date
    """, (symbol,)).fetchall()

    if not rows:
        return None

    # 返回 {trade_date: {t0, t1, t5, t20}} 格式
    result = {}
    for r in rows:
        result[r["trade_date"]] = {
            "t0": r["close_t0"],
            "t1": r["close_t1"],
            "t5": r["close_t5"],
            "t20": r["close_t20"],
        }
    return result


def backfill_spy_alpha():
    """回填SPY收益和个股alpha"""
    conn = _conn()

    # 0. 先查待回填量 (本地DB, 零API) — pending=0 直接返回, 不碰 Futu
    #    (2026-08-15 修复: FutuLV3 历史K线偶发挂起导致 cron 连续超时,
    #     而 alpha 列已 100% 填充时拉 SPY 日K 纯属浪费)
    pending_cnt = conn.execute(
        "SELECT COUNT(*) FROM signal_snapshots "
        "WHERE fwd_ret_t1 IS NOT NULL AND alpha_t1 IS NULL"
    ).fetchone()[0]
    if pending_cnt == 0:
        print("[Alpha Backfill] 待回填alpha: 0 条, 跳过 (无需拉SPY日K)")
        conn.close()
        return

    # 1. 拉SPY日K
    spy_closes = _get_spy_closes()
    if not spy_closes:
        print("[Alpha Backfill] 无法获取SPY日K, 退出")
        conn.close()
        return

    sorted_dates = sorted(spy_closes.keys())
    date_to_idx = {d: i for i, d in enumerate(sorted_dates)}

    # 2. 找所有需要回填alpha的信号 (有fwd_ret_t1但没alpha_t1的)
    #    覆盖所有策略，不只deep_analysis — voting_llm的历史数据也能验证alpha逻辑
    pending = conn.execute("""
        SELECT decision_id, symbol, direction, trade_date, strategy_id,
               close_t0, close_t1, close_t5, close_t20,
               fwd_ret_t1, fwd_ret_t5, fwd_ret_t20,
               spy_ret_t1, alpha_t1
        FROM signal_snapshots
        WHERE fwd_ret_t1 IS NOT NULL
          AND alpha_t1 IS NULL
        ORDER BY trade_date
    """).fetchall()

    print(f"[Alpha Backfill] 待回填alpha: {len(pending)} 条")

    filled = 0
    for snap in pending:
        trade_date = snap["trade_date"]

        # 找SPY在trade_date的位置 (只往前找，不用后一天——避免前视偏差)
        # 前视偏差根因: 如果trade_date=7/1但SPY数据没有7/1(假日/非交易日),
        # offset=1会匹配7/2——但7/2的SPY收盘价在7/1信号时刻是未来数据。
        # 正确逻辑: 只用当天或之前最近的交易日。
        spy_idx = None
        for offset in [0, -1, -2, -3]:
            check_date = (datetime.strptime(trade_date, "%Y-%m-%d") + timedelta(days=offset)).strftime("%Y-%m-%d")
            if check_date in date_to_idx:
                spy_idx = date_to_idx[check_date]
                break

        if spy_idx is None:
            print(f"  ⚠️ {snap['symbol']} {trade_date}: SPY未找到对应交易日")
            continue

        # SPY的T+0/T+1/T+5/T+20收盘
        spy_t0 = spy_closes.get(sorted_dates[spy_idx])
        spy_t1 = spy_closes.get(sorted_dates[spy_idx + 1]) if spy_idx + 1 < len(sorted_dates) else None
        spy_t5 = spy_closes.get(sorted_dates[spy_idx + 5]) if spy_idx + 5 < len(sorted_dates) else None
        spy_t20 = spy_closes.get(sorted_dates[spy_idx + 20]) if spy_idx + 20 < len(sorted_dates) else None

        # SPY收益率 (不带方向 — alpha是相对大盘的, 不论多空)
        def _calc_ret(t0, tn):
            if t0 is None or tn is None or t0 == 0:
                return None
            return (tn / t0) - 1.0

        spy_ret_t1 = _calc_ret(spy_t0, spy_t1)
        spy_ret_t5 = _calc_ret(spy_t0, spy_t5)
        spy_ret_t20 = _calc_ret(spy_t0, spy_t20)

        # Alpha = 个股fwd_ret - SPY_ret (已方向调整)
        # 注意: fwd_ret_t1已经按方向调整过了 (LONG=正涨, SHORT=正跌)
        # SPY_ret不带方向 (大盘涨跌)
        # alpha = 信号方向收益 - 大盘收益 = 超额收益
        alpha_t1 = None
        alpha_t5 = None
        alpha_t20 = None

        if snap["fwd_ret_t1"] is not None and spy_ret_t1 is not None:
            alpha_t1 = round(snap["fwd_ret_t1"] - spy_ret_t1, 6)
        if snap["fwd_ret_t5"] is not None and spy_ret_t5 is not None:
            alpha_t5 = round(snap["fwd_ret_t5"] - spy_ret_t5, 6)
        if snap["fwd_ret_t20"] is not None and spy_ret_t20 is not None:
            alpha_t20 = round(snap["fwd_ret_t20"] - spy_ret_t20, 6)

        # 写回DB
        conn.execute("""
            UPDATE signal_snapshots
            SET spy_close_t0 = ?, spy_close_t1 = ?, spy_close_t5 = ?, spy_close_t20 = ?,
                spy_ret_t1 = ?, spy_ret_t5 = ?, spy_ret_t20 = ?,
                alpha_t1 = ?, alpha_t5 = ?, alpha_t20 = ?
            WHERE decision_id = ?
        """, (spy_t0, spy_t1, spy_t5, spy_t20,
              spy_ret_t1, spy_ret_t5, spy_ret_t20,
              alpha_t1, alpha_t5, alpha_t20,
              snap["decision_id"]))
        filled += 1

        if filled % 100 == 0:
            print(f"  ... 已回填 {filled}/{len(pending)}")

    conn.commit()
    conn.close()
    print(f"[Alpha Backfill] ✅ alpha回填完成: {filled}/{len(pending)}")


def compute_claim_ic(strategy_id: Optional[str] = _PRODUCTION_STRATEGY) -> Dict[str, Any]:
    """论据级IC统计: 按 claim_type 分解 alpha

    strategy_id: 只统计该策略的信号 (默认 'deep_analysis' — 生产消费方).
        根因(2026-07-10): 缓存曾混入 voting_llm(已禁用) 样本, 且两套 taxonomy 几乎不相交
        (deep_analysis 用 claim_type 枚举, voting_llm 用 above_ma20 等 condition 名),
        导致 deep_analysis 的 prompt/gate 读到自己根本不产出的 legacy 论据名.
        限定本策略后: 只用 deep_analysis 自己的样本+自己的 taxonomy,
        theme 别名(各<MIN_N)被自动滤除. 传 None = 全策略池化 (仅供调试对比).

    核心逻辑: 遍历有alpha_t1的信号 → 解析factors_json的claim_type → 按claim_type分组算IC/avg_alpha.
    """
    conn = _conn()

    _base_sql = """
        SELECT decision_id, symbol, direction, strength, confidence, strategy_id,
               factors_json, fwd_ret_t1, fwd_ret_t5,
               alpha_t1, alpha_t5, spy_ret_t1, spy_ret_t5
        FROM signal_snapshots
        WHERE factors_json IS NOT NULL
          AND alpha_t1 IS NOT NULL
    """
    if strategy_id:
        rows = conn.execute(_base_sql + " AND strategy_id = ? ORDER BY trade_date",
                            (strategy_id,)).fetchall()
    else:
        rows = conn.execute(_base_sql + " ORDER BY trade_date").fetchall()

    conn.close()

    _prov = strategy_id or "_pooled"
    if not rows:
        print(f"[Claim IC] 无可用样本 (strategy={_prov}, 需要先backfill alpha)")
        return {"error": "no_samples", "total": 0, "strategy_id": _prov}

    print(f"[Claim IC] 样本: {len(rows)} 条 (strategy={_prov}, 有alpha_t1 + factors_json)")

    # 按 claim_type 收集 (strength, alpha_t1, alpha_t5)
    claim_data = defaultdict(lambda: {"confs": [], "alpha_t1": [], "alpha_t5": [], "symbols": set()})

    # 同时收集 overall
    overall_t1 = []
    overall_t5 = []

    for row in rows:
        factors_json = row["factors_json"]
        try:
            factors = json.loads(factors_json) if isinstance(factors_json, str) else factors_json
        except (json.JSONDecodeError, TypeError):
            continue

        if not isinstance(factors, list):
            # v0.23: factors_json现在是dict with "claims" key (结构化)
            if isinstance(factors, dict) and "claims" in factors:
                factors = factors["claims"]
            # 旧格式 (source_type列表) — 降级处理
            elif isinstance(factors_json, str):
                factors = [factors_json]
            else:
                continue

        strength = row["strength"] or 50
        alpha_t1 = row["alpha_t1"]
        alpha_t5 = row["alpha_t5"]

        overall_t1.append((strength, alpha_t1))
        if alpha_t5 is not None:
            overall_t5.append((strength, alpha_t5))

        # 每个claim_type只计一次 (一个信号可能有多个相同claim_type)
        seen_types = set()
        for f in factors:
            if isinstance(f, dict):
                ct = f.get("claim_type", "unclassified")
            elif isinstance(f, str):
                ct = f  # 旧格式
            else:
                continue

            if ct in seen_types:
                continue
            seen_types.add(ct)

            claim_data[ct]["confs"].append(strength)
            claim_data[ct]["alpha_t1"].append(alpha_t1)
            if alpha_t5 is not None:
                claim_data[ct]["alpha_t5"].append(alpha_t5)
            claim_data[ct]["symbols"].add(row["symbol"])

    # 计算IC
    def _spearman(x, y):
        if len(x) < 5:
            return None, None
        pairs = [(a, b) for a, b in zip(x, y)
                 if not (math.isnan(a) or math.isnan(b) or math.isinf(a) or math.isinf(b))]
        if len(pairs) < 5:
            return None, None
        _x = [p[0] for p in pairs]
        _y = [p[1] for p in pairs]

        try:
            from scipy.stats import spearmanr
            rho, pvalue = spearmanr(_x, _y)
            if math.isnan(rho):
                return None, None
            return float(rho), float(pvalue) if pvalue and not math.isnan(pvalue) else None
        except ImportError:
            # Pure Python fallback
            return _spearman_fallback(_x, _y)

    def _spearman_fallback(x, y):
        n = len(x)
        if n < 5:
            return None, None
        xr = _rank(x)
        yr = _rank(y)
        mx = sum(xr) / n
        my = sum(yr) / n
        cov = sum((a - mx) * (b - my) for a, b in zip(xr, yr))
        vx = sum((a - mx) ** 2 for a in xr)
        vy = sum((b - my) ** 2 for b in yr)
        if vx == 0 or vy == 0:
            return None, None
        return float(cov / math.sqrt(vx * vy)), None

    def _rank(values):
        indexed = sorted(range(len(values)), key=lambda i: values[i])
        ranks = [0.0] * len(values)
        i = 0
        while i < len(indexed):
            j = i
            while j + 1 < len(indexed) and values[indexed[j + 1]] == values[indexed[i]]:
                j += 1
            avg_rank = (i + 1 + j + 1) / 2.0
            for k in range(i, j + 1):
                ranks[indexed[k]] = avg_rank
            i = j + 1
        return ranks

    # Overall IC
    overall_ic_t1, overall_p_t1 = _spearman(
        [v[0] for v in overall_t1], [v[1] for v in overall_t1]
    ) if len(overall_t1) >= 5 else (None, None)

    overall_ic_t5, overall_p_t5 = _spearman(
        [v[0] for v in overall_t5], [v[1] for v in overall_t5]
    ) if len(overall_t5) >= 5 else (None, None)

    # 按claim_type分解
    by_claim = {}
    for ct, data in claim_data.items():
        if len(data["confs"]) < 3:
            continue  # 样本太少

        ic_t1, p_t1 = _spearman(data["confs"], data["alpha_t1"])
        ic_t5, p_t5 = _spearman(data["confs"], data["alpha_t5"]) if data["alpha_t5"] else (None, None)

        # 平均alpha (不看IC, 看绝对超额收益)
        avg_alpha_t1 = sum(data["alpha_t1"]) / len(data["alpha_t1"]) if data["alpha_t1"] else None
        avg_alpha_t5 = sum(data["alpha_t5"]) / len(data["alpha_t5"]) if data["alpha_t5"] else None

        by_claim[ct] = {
            "count": len(data["confs"]),
            "symbols": len(data["symbols"]),
            "ic_t1": round(ic_t1, 4) if ic_t1 is not None else None,
            "ic_t1_p": round(p_t1, 4) if p_t1 is not None else None,
            "ic_t5": round(ic_t5, 4) if ic_t5 is not None else None,
            "ic_t5_p": round(p_t5, 4) if p_t5 is not None else None,
            "avg_alpha_t1": round(avg_alpha_t1, 4) if avg_alpha_t1 is not None else None,
            "avg_alpha_t5": round(avg_alpha_t5, 4) if avg_alpha_t5 is not None else None,
        }

    # 按IC排序
    sorted_claims = sorted(by_claim.items(), key=lambda x: x[1]["ic_t1"] or -999, reverse=True)

    result = {
        "strategy_id": _prov,
        "total_samples": len(rows),
        "overall_ic_t1_alpha": round(overall_ic_t1, 4) if overall_ic_t1 is not None else None,
        "overall_ic_t1_p": round(overall_p_t1, 4) if overall_p_t1 is not None else None,
        "overall_ic_t5_alpha": round(overall_ic_t5, 4) if overall_ic_t5 is not None else None,
        "overall_ic_t5_p": round(overall_p_t5, 4) if overall_p_t5 is not None else None,
        "by_claim_type": {k: v for k, v in sorted_claims},
    }

    # 写缓存文件供 llm_synth / signal_gate 读取
    _write_claim_ic_cache(result)

    return result


def print_claim_ic_report(result: Dict):
    """打印论据级IC报告"""
    if "error" in result:
        print(f"\n⚠️ {result['error']}")
        return

    print(f"\n{'='*70}")
    print(f"📊 论据级IC报告 (alpha剥离大盘)")
    print(f"{'='*70}")
    print(f"样本: {result['total_samples']} 条")
    print()

    ic_t1 = result.get("overall_ic_t1_alpha")
    ic_t5 = result.get("overall_ic_t5_alpha")

    def _ic_emoji(ic):
        if ic is None: return "⏳ 不足"
        if ic > 0.05: return f"✅ {ic:+.4f}"
        if ic > -0.05: return f"🟡 {ic:+.4f}"
        return f"🔴 {ic:+.4f}"

    print(f"整体Alpha IC:  T+1={_ic_emoji(ic_t1)}  T+5={_ic_emoji(ic_t5)}")
    print()

    by_claim = result.get("by_claim_type", {})
    if by_claim:
        print(f"{'claim_type':<25s} {'n':>4s} {'IC_T1':>8s} {'IC_T5':>8s} {'α_T1':>8s} {'α_T5':>8s}")
        print("-" * 70)
        for ct, data in by_claim.items():
            ic1 = data.get("ic_t1")
            ic5 = data.get("ic_t5")
            a1 = data.get("avg_alpha_t1")
            a5 = data.get("avg_alpha_t5")
            print(f"{ct:<25s} {data['count']:>4d} {_ic_emoji(ic1):>8s} {_ic_emoji(ic5):>8s}"
                  f" {f'{a1:+.4f}' if a1 else 'N/A':>8s}"
                  f" {f'{a5:+.4f}' if a5 else 'N/A':>8s}")
    else:
        print("  无claim_type分组数据")

    print(f"\n{'='*70}")
    print("解读:")
    print("  IC > 0.05: 该论据类型有预测力 (信号方向正确)")
    print("  IC ≈ 0:    该论据是噪声 (方向随机)")
    print("  IC < 0:    该论据反向 (信号方向错误, 需调整)")
    print("  avg_alpha: 该论据出现时的平均超额收益 (正=跑赢大盘)")


def main():
    import argparse
    parser = argparse.ArgumentParser(description="Alpha Backfill + Claim IC")
    parser.add_argument("--add-columns", action="store_true", help="加DB列")
    parser.add_argument("--backfill", action="store_true", help="回填SPY收益和alpha")
    parser.add_argument("--claim-ic", action="store_true", help="论据级IC统计")
    parser.add_argument("--all", action="store_true", help="全部执行")
    args = parser.parse_args()

    if args.all:
        args.add_columns = True
        args.backfill = True
        args.claim_ic = True

    if args.add_columns:
        print("\n[1/3] 加DB列...")
        add_alpha_columns()

    if args.backfill:
        print("\n[2/3] 回填SPY收益和alpha...")
        backfill_spy_alpha()

    if args.claim_ic:
        print("\n[3/3] 论据级IC统计...")
        result = compute_claim_ic()
        print_claim_ic_report(result)


if __name__ == "__main__":
    # 退出挂起根因修复 (2026-08-26, cron 连续 3 天 rc=124): Futu SDK 内部
    # callback_executor 线程为非 daemon (futu/common/callback_executor.py:22),
    # 取数完成后仍阻止解释器退出 → 进程挂死直到被 600s timeout 杀掉。
    # 8/24 的 120s 线程守卫只修了取数挂起, 没修退出挂起 (实测: 取数 2s 完成,
    # 进程仍不退, 60s 被杀)。
    # 2026-08-26 审计二次修正: 原实现无条件 os._exit(0), 把任何失败也伪装成
    # 成功(rc=0, cron 无法告警), 且异常路径同样会被非 daemon 线程挂死。
    # 改为条件化退出:
    #   1. 先捕获 main() 的异常/argparse SystemExit, 得到真实退出码;
    #   2. 仅当存在非 daemon 残留线程(Futu callback_executor 等)阻止自然退出时,
    #      才 os._exit(真实码);
    #   3. 无残留线程则正常 SystemExit(真实码)。
    # 回滚: 恢复本块为裸 main() 调用即可。
    try:
        main()
        _rc = 0
    except SystemExit as _e:
        _rc = _e.code if isinstance(_e.code, int) else (0 if _e.code is None else 1)
    except BaseException:
        import traceback
        traceback.print_exc()
        _rc = 1

    import threading as _threading
    _leftover = [t for t in _threading.enumerate()
                 if t is not _threading.main_thread() and not t.daemon and t.is_alive()]
    if _leftover:
        print(f"[Alpha Backfill] 强制退出 rc={_rc} (绕过 {len(_leftover)} 个非 daemon "
              f"残留线程: {[t.name for t in _leftover]})", flush=True)
        sys.stdout.flush()
        sys.stderr.flush()
        os._exit(_rc)
    raise SystemExit(_rc)
