#!/usr/bin/env python3
"""
Adapter — deep_analysis 输出 → FTSeek 完整接口适配
=====================================================
解决6个接口不匹配:
1. direction: BUY→LONG, SELL_SHORT→SHORT, SKIP不传
2. source_type: DEEP_ANALYSIS→PLAYBOOK_SIM (走playbook pipeline)
3. confidence: 0-100 → 0.0-1.0
4. SignalScore必需字段: 补signal_id/strategy_id/strength
5. exit_rules meta: 补cohort/peak_price
6. IC tracker: 调record_signal_snapshot

输出3种格式:
- to_voting_result(): FTSeek _submit_order的voting_result参数
- to_signal_score(): FTSeek SignalScore dataclass兼容dict
- to_exit_meta(): FTSeek _check_playbook_exit_rules的meta参数
- to_ic_snapshot(): FTSeek record_signal_snapshot的参数
"""

import json
import uuid
import time
from typing import Dict, Any, List


def _direction_to_ftseek(direction: str) -> str:
    """BUY→LONG, SELL_SHORT→SHORT, SKIP→不交易"""
    if direction == "BUY":
        return "LONG"
    elif direction == "SELL_SHORT":
        return "SHORT"
    return "NEUTRAL"


# claim_type → 合法 condition 映射 (#4, 2026-07-10)
#   根因: LLM 100% 标注 claim_type(见 ic_writer._VALID_CLAIM_TYPES), 且 #2 证实其有 alpha;
#         原关键词匹配在同一文本上重做更差的推断, 大量塌缩到 above_ma20/below_ma20 默认,
#         丢弃了 claim_type 的预测力. 修法: 优先用 LLM claim_type 直接映射, 缺失才 fallback 关键词.
#   方向安全: bull 映射只产出 bullish/neutral condition, bear 只产出 bearish/neutral,
#            不会给方向冲突门(pipeline.py L907)引入反向 condition.
_CLAIM_TYPE_TO_BULLISH_COND = {
    "product_catalyst":   "news_positive",        # 事件催化(合约/产品/FDA), 无专用枚举
    "earnings_beat":      "earnings_beat_streak",  # 财报超预期
    "valuation_cheap":    "pe_below_industry",     # 低估
    "technical_breakout": "above_ma20",            # 突破/站上均线
    "insider_bullish":    "insider_net_buy",       # 内部人增持
    "macro_tailwind":     "news_positive",         # 宏观顺风, 无专用枚举
}
_CLAIM_TYPE_TO_BEARISH_COND = {
    "valuation_expensive": "pe_above_industry",    # 高估
    "insider_bearish":     "insider_net_sell",     # 内部人减持
    "technical_breakdown": "below_ma20",           # 破位/跌破均线
    "macro_headwind":      "news_negative",        # 宏观逆风, 无专用枚举
    "sentiment_crowded":   "sentiment_bearish",    # 散户拥挤 = 逆向看空
    "product_catalyst":    "news_negative",        # bear_case 中的催化 = 利空事件
}


def _map_bullish_conditions(llm_out: Dict[str, Any]) -> List[str]:
    """从bull_case映射到BULLISH conditions（用于LONG信号的退出策略匹配）。

    优先用 LLM 标注的 claim_type 直接映射(准确+对齐 claim IC taxonomy),
    claim_type 缺失或不在映射表时 fallback 到关键词匹配。
    """
    conditions = []

    for r in llm_out.get("bull_case", [])[:5]:
        # #4: 优先 claim_type 直接映射
        _ct = r.get("claim_type")
        _mapped = _CLAIM_TYPE_TO_BULLISH_COND.get(_ct) if _ct else None
        if _mapped:
            conditions.append(_mapped)
            continue

        st = r.get("source_type", "")
        thesis = r.get("thesis", "").lower()
        evidence = r.get("evidence", "").lower()
        text = thesis + " " + evidence

        if st == "technical":
            if "ma" in text and ("上方" in text or "above" in text or "突破" in text):
                conditions.append("above_ma20")
            elif "金叉" in text or "golden" in text:
                conditions.append("macd_golden_cross")
            elif "放量" in text or "volume" in text or "量" in text:
                conditions.append("volume_expansion")
            elif "rsi" in text and ("超卖" in text or "oversold" in text):
                conditions.append("rsi_oversold")
            elif "布林" in text or "bollinger" in text:
                conditions.append("bollinger_upper")
            else:
                conditions.append("above_ma20")

        elif st == "fundamental":
            if "营收" in text or "revenue" in text:
                if "增长" in text or "growth" in text:
                    conditions.append("revenue_growth_high")
            elif "roe" in text:
                conditions.append("roe_high")
            elif "pe" in text and ("低" in text or "below" in text):
                conditions.append("pe_below_industry")
            elif "盈利" in text or "earnings" in text or "beat" in text:
                conditions.append("earnings_beat_streak")
            else:
                conditions.append("revenue_growth_high")

        elif st == "news":
            conditions.append("news_positive")

        elif st == "sentiment":
            conditions.append("sentiment_bullish")

        elif st == "macro":
            conditions.append("news_positive")

    return list(dict.fromkeys(conditions))


def _map_bearish_conditions(llm_out: Dict[str, Any]) -> List[str]:
    """从bear_case映射到BEARISH conditions（用于SHORT信号的退出策略匹配）。

    优先用 LLM 标注的 claim_type 直接映射, 缺失时 fallback 到关键词匹配。
    """
    conditions = []

    for r in llm_out.get("bear_case", [])[:5]:
        # #4: 优先 claim_type 直接映射
        _ct = r.get("claim_type")
        _mapped = _CLAIM_TYPE_TO_BEARISH_COND.get(_ct) if _ct else None
        if _mapped:
            conditions.append(_mapped)
            continue

        st = r.get("source_type", "")
        text = (r.get("thesis", "") + " " + r.get("evidence", "")).lower()

        if st == "sentiment" and ("卖出" in text or "bearish" in text or "net_sell" in text or "mspr" in text):
            conditions.append("insider_net_sell")
        elif st == "sentiment" and ("看空" in text or "bearish" in text):
            conditions.append("sentiment_bearish")
        elif st == "news" and ("负面" in text or "negative" in text or "利空" in text):
            conditions.append("news_negative")
        elif st == "technical" and ("破位" in text or "below" in text or "空头" in text or "死叉" in text):
            conditions.append("below_ma20")
        elif st == "technical" and ("超买" in text or "overbought" in text):
            conditions.append("rsi_overbought")
        elif st == "fundamental" and "pe" in text and ("高" in text or "above" in text):
            conditions.append("pe_above_industry")
        elif st == "fundamental" and ("营收" in text or "revenue" in text) and ("下降" in text or "decline" in text):
            conditions.append("near_52w_low")
        else:
            conditions.append("below_ma20")  # 看空默认

    return list(dict.fromkeys(conditions))


def _map_conditions(llm_out: Dict[str, Any]) -> List[str]:
    """根据direction只输出方向一致的conditions。

    根因修复：原代码把bull_case和bear_case的conditions混在一起输出，
    导致BUY信号带bearish conditions（insider_net_sell/below_ma20），
    虽然FTSeek方向感知退出规则会跳过不一致的condition，但：
    1. 方向冲突检查可能触发SKIP（IC样本增加后风险放大）
    2. 语义错误：bear_case是"看空理由"不是"退出条件"
    3. factor_ic统计会把bearish condition的收益算到LONG头上，污染IC

    正确做法：
    - direction=BUY → 只输出bullish conditions
    - direction=SELL_SHORT → 只输出bearish conditions
    - direction=SKIP → 输空列表（SKIP信号不进_submit_order）
    """
    direction = llm_out.get("direction", "SKIP")

    if direction == "BUY":
        conditions = _map_bullish_conditions(llm_out)
        # 兜底：如果bull_case映射为空，给一个合法的bullish默认
        if not conditions:
            conditions = ["above_ma20"]
    elif direction == "SELL_SHORT":
        conditions = _map_bearish_conditions(llm_out)
        # 兜底：如果bear_case映射为空，给一个合法的bearish默认
        if not conditions:
            conditions = ["below_ma20"]
    else:
        # SKIP信号不进_submit_order，不需要conditions
        conditions = []

    return conditions


def _compute_confidence(analysis: Dict[str, Any]) -> float:
    """从辩论结果合成 confidence (0.0-1.0)。

    第一性原理: confidence = P(trade profitable | signal)
    数据验证: LLM自评confidence无预测力(r=-0.211), 数据质量分无预测力(r=-0.073)
    唯一弱正相关信号: 模型一致度(r=+0.102)

    设计: 用辩论结果(唯一有预测力的信号)作为confidence核心
      - 基准: 0.50 (中性, 无辩论数据时)
      - 2模型一致+AGREE: +0.20 → 0.70 (通过gate)
      - 2模型方向分歧: -0.15 → 0.35 (不通过gate, 正确行为)
      - 无辩论数据: 0.50 (默认, 通过gate)

    YAGNI: 不用LLM定性confidence(无预测力), 不用市场5维(无预测力+77%未触发)
    """
    llm_out = analysis.get("_llm_output", {})
    confidence = 0.50  # 中性基准

    debate = llm_out.get("_debate", {})
    if debate:
        agreed = debate.get("challenger_agreed", False)
        chall_dir = str(debate.get("challenger_direction", "")).upper()
        orig_dir = str(llm_out.get("direction", "")).upper()
        outcome = llm_out.get("debate_outcome", "")
        _fallback = bool(debate.get("challenger_fallback"))  # P1: 主模型自我辩论=非独立

        if chall_dir == orig_dir:
            if (agreed or "AGREE" in outcome.upper()) and not _fallback:
                confidence += 0.20  # 2模型(独立)一致确认
            # 方向一致但有质疑, 或挑战者非独立 → 不加成

            # ── Phase 0 (2026-08-23): score 差值衰减, 打破 conf 恒=0.70 ──
            # 挑战者几乎恒 agree (8/21 全 13 条) → conf 恒=0.70, 下游无区分力。
            # 引入 |analyst_score - challenger_score| 差值: 差值大 = "形式同意但确信度分歧大"
            # → 降 conf, 使 confidence 恢复连续性。回滚: 删除本段。
            # (2026-08-24 修复①: 原补丁插在 if/elif 链中间, try/except 截断 elif →
            #  整个 adapter 模块 SyntaxError 不可导入, Stage4 KeyError 崩掉 Stage6 bridge。
            #  现移回"方向一致"分支内部, 语义不变。)
            # (2026-08-24 修复②: 键名bug — debate.get("score") 恒 0 (_debate 字典无
            #  "score" 键, 分析师分数在 analysis 顶层) → diff=挑战者分数本身, 逻辑反转:
            #  挑战者越确信衰减越大 (8/24 实弹: 真一致全扣到 0.64, 真分歧反拿满 0.70)。
            #  修正: 分析师分数从 llm_out/analysis 顶层读; 任一分缺失则不衰减
            #  (缺数据=回退 0.70 旧行为, 不再制造反向惩罚)。)
            try:
                _analyst_score = llm_out.get("score")
                if _analyst_score is None:
                    _analyst_score = analysis.get("score")
                _chall_score = debate.get("challenger_score")
                if _analyst_score is not None and _chall_score is not None:
                    _score_diff = abs(float(_analyst_score) - float(_chall_score))
                    if _score_diff > 3.0:
                        _score_diff_decay = (_score_diff - 3.0) * 0.015
                        confidence -= _score_diff_decay  # score_diff_decay
            except Exception:
                pass
        elif "SKIP" in (chall_dir, orig_dir):
            # 2026-07-18 根因修复: 一方弃权(SKIP) != 真反向。弃权是"一方观望", 非"唱反调"。
            #   IC 证据只支持"独立一致=正信号", 未支持"弃权=负信号"。故中性不罚(保持0.50)。
            #   (7/17 实证: 14条'一方SKIP'被误当方向分歧降conf→35, 压进tiny/BLOCK档。)
            pass
        else:
            confidence -= 0.15  # 真反向分歧 (BUY↔SELL_SHORT)

    return max(0.10, min(0.95, confidence))


def to_voting_result(analysis: Dict[str, Any]) -> Dict[str, Any]:
    """
    FTSeek _submit_order 的 voting_result 参数格式。
    source_type=PLAYBOOK_SIM 走playbook pipeline (冻结期允许)。
    """
    llm_out = analysis.get("_llm_output", {})
    plan = llm_out.get("execution_plan", {})
    kl = llm_out.get("key_levels", {})
    score = float(analysis.get("score", 5.0))
    direction = analysis.get("action", "SKIP")

    # 具体价位
    entry_price = plan.get("entry_price", 0) or kl.get("current", 0)
    stop_loss_price = plan.get("stop_loss_price", 0)
    take_profit_price = plan.get("take_profit_price", 0)

    if not stop_loss_price and kl.get("support"):
        stop_loss_price = kl["support"][0] if kl["support"] else 0
    if not take_profit_price and kl.get("resistance"):
        take_profit_price = kl["resistance"][0] if kl["resistance"] else 0

    # conditions — 用合法枚举映射
    conditions = _map_conditions(llm_out)

    # confidence — 从分析链路合成 (不再等于score/10)
    confidence = _compute_confidence(analysis)

    return {
        "symbol": analysis.get("symbol", ""),
        "source_type": "PLAYBOOK_SIM",
        "direction": direction,
        "confidence": confidence,
        "thesis": analysis.get("conclusion", ""),
        "conditions": conditions,
        "risks": analysis.get("risks", []),
        "rating": analysis.get("rating", ""),
        "score": score,
        "entry_price": entry_price,
        "stop_loss": stop_loss_price,
        "take_profit": take_profit_price,
        "position_suggestion": {
            "stop_loss_pct": (abs(stop_loss_price - entry_price) / entry_price * 100) if entry_price and stop_loss_price else 2.5,
            "take_profit_pct": (abs(take_profit_price - entry_price) / entry_price * 100) if entry_price and take_profit_price else 5.0,
        },
        "entry_strategy": plan.get("entry_strategy", ""),
        # [DEB-20260901] 结构化入场语义透传 (双轨: LLM直出优先, skill pipeline 层
        #   对缺失字段做确定性兜底解析; 消费方: FTSeek Phase B 影子+未来archetype路由)
        "entry_archetype": plan.get("entry_archetype") or None,
        "confirmation": plan.get("confirmation") or None,
        "chase_cap_price": plan.get("chase_cap_price") or None,
        "invalidation": plan.get("invalidation", ""),
        # P2 (2026-08-14): 结构化证伪条件, 供盘后复盘核销与IC审计
        "tripwires": plan.get("tripwires", []),
        # [DEB-20260825 r15 P10接线] 机器可核销失效条件 — 本股可判定
        #   (metric限收盘价/量比/5日涨跌/盘前涨跌幅, operator限</>, value纯数字).
        #   消费方: FTSeek scripts/tripwire_checker.py evaluate_invalidation_triggers
        #   当前只做影子评估; 是否核销由 tripwire_checker_enforce 控制.
        "invalidation_triggers": plan.get("invalidation_triggers", []),
        "strategy_id": "deep_analysis",
        "_raw_llm": {
            "bull_case": llm_out.get("bull_case", []),
            "bear_case": llm_out.get("bear_case", []),
            "constraints": llm_out.get("constraints", []),
            "causal_chain": llm_out.get("causal_chain", ""),
        },
    }


def to_signal_score(analysis: Dict[str, Any]) -> Dict[str, Any]:
    """
    FTSeek SignalScore dataclass 兼容格式。
    _submit_order读: signal_id/strategy_id/symbol/direction/strength/confidence/metadata
    """
    score = float(analysis.get("score", 5.0))
    direction = analysis.get("action", "SKIP")
    llm_out = analysis.get("_llm_output", {})
    plan = llm_out.get("execution_plan", {})

    # 复用已计算的voting_result的conditions，不重复计算
    vr = to_voting_result(analysis)
    conditions = vr.get("conditions", [])

    # confidence — 从分析链路合成 (不再等于score/10)
    confidence = _compute_confidence(analysis)

    return {
        "signal_id": str(uuid.uuid4()),
        "trace_id": f"deep_analysis_{int(time.time())}",
        "strategy_id": "deep_analysis",
        "symbol": analysis.get("symbol", ""),
        "direction": _direction_to_ftseek(direction),  # LONG/SHORT/NEUTRAL
        "strength": int(score * 10),  # 0-100
        "confidence": confidence,  # 0.0-1.0
        "risk_reward_estimate": float(llm_out.get("execution_plan", {}).get("risk_reward", 0) or 0),
        "metadata": {
            "source_type": "PLAYBOOK_SIM",
            "source": "deep_analysis",
            "thesis": analysis.get("conclusion", ""),
            "conditions": conditions,
            "entry_strategy": plan.get("entry_strategy", ""),
            "invalidation": plan.get("invalidation", ""),
            "bull_reasons": analysis.get("bull_reasons", []),
            "bear_reasons": analysis.get("bear_reasons", []),
            "llm_raw": llm_out,
        },
    }


def to_exit_meta(analysis: Dict[str, Any]) -> Dict[str, Any]:
    """
    FTSeek _check_playbook_exit_rules 的 meta 参数格式。
    exit_rules读: cohort/_skip_allowed/_log_tag/_symbol/conditions/stop_loss/peak_price
    """
    llm_out = analysis.get("_llm_output", {})
    plan = llm_out.get("execution_plan", {})
    kl = llm_out.get("key_levels", {})
    entry_price = plan.get("entry_price", 0) or kl.get("current", 0)
    stop_loss = plan.get("stop_loss_price", 0)

    # 复用voting_result的conditions，不重复计算
    vr = to_voting_result(analysis)
    conditions = vr.get("conditions", [])

    return {
        "cohort": "A",  # A=日内可隔夜, B=日内平仓
        "_skip_allowed": False,  # 盈利仓不跳过EOD
        "_log_tag": "deep_analysis",
        "_symbol": analysis.get("symbol", ""),
        "conditions": conditions,
        "stop_loss": stop_loss,
        "peak_price": entry_price,  # 初始peak = entry
        "entry_time": time.strftime("%Y-%m-%dT%H:%M:%S"),
        "horizon": "short",
    }


def to_ic_snapshot(analysis: Dict[str, Any]) -> Dict[str, Any]:
    """
    FTSeek record_signal_snapshot 参数格式。
    IC tracker读: decision_id/symbol/direction/strength/confidence/strategy_id/factors

    2026-07-05: factors从简单source_type列表升级为结构化claim对象。
    兼容策略: 如果ic_writer._extract_claim_factors可用则用它，否则降级为旧格式。
    """
    score = float(analysis.get("score", 5.0))
    direction = analysis.get("action", "SKIP")
    llm_out = analysis.get("_llm_output", {})

    # 论据级IC: 结构化claim对象 (与ic_writer._extract_claim_factors一致)
    try:
        from ic_writer import _extract_claim_factors
        factors = _extract_claim_factors(llm_out)
    except ImportError:
        # 降级: 旧格式 (source_type列表)
        factors = []
        for r in llm_out.get("bull_case", [])[:3]:
            st = r.get("source_type", "")
            if st:
                factors.append(st)

    # confidence — 从分析链路合成 (不再等于score/10)
    confidence = _compute_confidence(analysis)

    return {
        "decision_id": f"DA_{analysis.get('symbol','')}_{int(time.time())}",
        "symbol": analysis.get("symbol", ""),
        "direction": _direction_to_ftseek(direction),  # LONG/SHORT
        "strength": int(score * 10),  # 0-100
        "confidence": confidence,  # 0.0-1.0
        "strategy_id": "deep_analysis",
        "factors": factors,
    }


def analysis_to_instruction(analysis: Dict[str, Any]) -> Dict[str, Any]:
    """向后兼容: 返回voting_result格式"""
    return to_voting_result(analysis)


def main():
    import sys
    analysis = json.load(sys.stdin)
    result = {
        "voting_result": to_voting_result(analysis),
        "signal_score": to_signal_score(analysis),
        "exit_meta": to_exit_meta(analysis),
        "ic_snapshot": to_ic_snapshot(analysis),
    }
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
