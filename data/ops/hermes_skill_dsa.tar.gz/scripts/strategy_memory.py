#!/usr/bin/env python3
"""
Strategy Memory — 交易策略记忆库
================================
从每笔已平仓交易中提取pattern，持久化积累为策略经验。

数据流:
  盘后feedback_loop → update_from_trade() → 提取pattern → 写入memory.db
  盘前signal_gate → get_strategy_hint() → 读memory → 注入LLM prompt

核心表:
  - pattern_memory: direction×exit_reason×strength_bucket 聚合统计
  - symbol_memory: 单股历史表现
  - lesson_log: 每日复盘教训日志（人类可读）
"""

import sqlite3
import json
import os
import sys
from datetime import datetime, timedelta, timezone
from typing import Dict, List, Optional, Any
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import config

DB_PATH = os.path.join(os.path.dirname(config.FTSEEK_DB), "strategy_memory.db")

# ET时区 — 2026-08-26 审计修复: get_strategy_hint 内两处原按月份近似DST
# (3-11月视为EDT/UTC-4), 在3月第2个周日之前、11月第1个周日之后错位1小时,
# 导致30天滚动窗口的cut日期偏移一天。改为真实时区, 全文件统一复用本定义:
# zoneinfo为主(stdlib, 实测venv与系统python3均可用), pytz兜底(仅venv安装)。
try:
    from zoneinfo import ZoneInfo
    ET_TZ = ZoneInfo("America/New_York")
except Exception:  # pragma: no cover - 兜底路径
    from pytz import timezone as _tz
    ET_TZ = _tz("America/New_York")

# 2026-07-13: 个股历史滚动窗口 (天). 与 pattern_memory 的 30 天窗口对齐.
#   根因: 全时段累计会让"过去时"的旧策略成交永久拦截新信号(gate -15).
#   窗口内新老成交一视同仁, 超窗一律不计 -> 新策略成交回补窗口, gate 用近期数据重新学.
SYMBOL_HISTORY_WINDOW_DAYS = 30

# 2026-10-23: 旧 feedback_loop 按入场日/毛额/只看 wins 生成 lesson, 存在
# "7胜0负实为10胜1负"等假事实。保留 lesson_log 原文供审计, 但修复前生成的
# lesson 不再注入 DA Prompt; 新 lesson 从本日起按退出日+净额生成。
LESSON_TRUTH_START = "2026-10-23"


def _ensure_db():
    """初始化memory数据库"""
    conn = sqlite3.connect(DB_PATH)
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS pattern_memory (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            direction       TEXT NOT NULL,
            exit_reason     TEXT NOT NULL,
            strength_bucket TEXT NOT NULL,
            total_trades    INTEGER DEFAULT 0,
            wins            INTEGER DEFAULT 0,
            total_pnl       REAL DEFAULT 0,
            avg_hold_hours  REAL DEFAULT 0,
            avg_pnl         REAL DEFAULT 0,
            win_rate        REAL DEFAULT 0,
            last_updated    TEXT,
            last_trade_date TEXT,
            UNIQUE(direction, exit_reason, strength_bucket)
        );

        CREATE TABLE IF NOT EXISTS symbol_memory (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            symbol          TEXT NOT NULL,
            direction       TEXT NOT NULL,
            total_trades    INTEGER DEFAULT 0,
            wins            INTEGER DEFAULT 0,
            total_pnl       REAL DEFAULT 0,
            avg_pnl         REAL DEFAULT 0,
            win_rate        REAL DEFAULT 0,
            best_win        REAL,
            worst_loss      REAL,
            last_trade_date TEXT,
            last_updated    TEXT,
            UNIQUE(symbol, direction)
        );

        CREATE TABLE IF NOT EXISTS lesson_log (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            date            TEXT NOT NULL,
            lesson_type     TEXT NOT NULL,   -- win_pattern / loss_pattern / symbol_insight / market_regime
            content         TEXT NOT NULL,
            evidence        TEXT,
            impact          TEXT,            -- high / medium / low
            created_at      TEXT NOT NULL
        );

        CREATE INDEX IF NOT EXISTS idx_pattern ON pattern_memory(direction, exit_reason);
        CREATE INDEX IF NOT EXISTS idx_symbol ON symbol_memory(symbol);
        CREATE INDEX IF NOT EXISTS idx_lesson ON lesson_log(date);
    """)
    conn.commit()
    conn.close()


def _strength_bucket(strength) -> str:
    """信号强度分桶"""
    try:
        s = int(strength)
    except (TypeError, ValueError):
        return "unknown"
    if s >= 80:
        return "80+"
    elif s >= 70:
        return "70-80"
    elif s >= 60:
        return "60-70"
    elif s >= 50:
        return "50-60"
    else:
        return "<50"


def update_from_trade(trade: Dict[str, Any]):
    """从一笔已平仓交易更新pattern memory。

    trade: trade_records行的dict，需包含:
        symbol, direction, exit_reason, realized_pnl,
        holding_hours, signal_strength, trade_date
    """
    _ensure_db()
    conn = sqlite3.connect(DB_PATH, timeout=5)
    # 2026-08-26 审计修复: 本脚本为外部进程, 按 SKILL.md 纪律不设 journal_mode (WAL 是持久化属性, 外部设置会干扰主进程可见性)

    direction = trade.get("direction", "")
    exit_reason = trade.get("exit_reason", "unknown")
    pnl = float(trade.get("pnl_net") if trade.get("pnl_net") is not None
                else (trade.get("realized_pnl", 0) or 0))
    hold = float(trade.get("holding_hours", 0) or 0)
    strength = trade.get("signal_strength", 0)
    bucket = _strength_bucket(strength)
    symbol = trade.get("symbol", "")
    trade_date = trade.get("trade_date", "")
    is_win = 1 if pnl > 0 else 0
    now = datetime.now().isoformat()

    # ── pattern_memory: direction×exit_reason×strength ──
    conn.execute("""
        INSERT INTO pattern_memory (direction, exit_reason, strength_bucket,
                                    total_trades, wins, total_pnl, avg_hold_hours,
                                    avg_pnl, win_rate, last_updated, last_trade_date)
        VALUES (?, ?, ?, 1, ?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(direction, exit_reason, strength_bucket) DO UPDATE SET
            total_trades = total_trades + 1,
            wins = wins + ?,
            total_pnl = total_pnl + ?,
            avg_hold_hours = (avg_hold_hours * (total_trades - 1) + ?) / total_trades,
            avg_pnl = total_pnl / total_trades,
            win_rate = CAST(wins AS REAL) / total_trades,
            last_updated = ?,
            last_trade_date = ?
    """, (direction, exit_reason, bucket,
          is_win, pnl, hold, pnl, is_win if is_win else 0,
          now, trade_date,
          is_win, pnl, hold, now, trade_date))

    # ── symbol_memory: 单股×方向 ──
    conn.execute("""
        INSERT INTO symbol_memory (symbol, direction, total_trades, wins, total_pnl,
                                   avg_pnl, win_rate, best_win, worst_loss,
                                   last_trade_date, last_updated)
        VALUES (?, ?, 1, ?, ?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(symbol, direction) DO UPDATE SET
            total_trades = total_trades + 1,
            wins = wins + ?,
            total_pnl = total_pnl + ?,
            avg_pnl = total_pnl / total_trades,
            win_rate = CAST(wins AS REAL) / total_trades,
            best_win = MAX(best_win, ?),
            worst_loss = MIN(worst_loss, ?),
            last_trade_date = ?,
            last_updated = ?
    """, (symbol, direction, is_win, pnl, pnl,
          is_win if is_win else 0, pnl if is_win else 0, pnl if not is_win else 0,
          trade_date, now,
          is_win, pnl, pnl if is_win else 0, pnl if not is_win else 0,
          trade_date, now))

    conn.commit()
    conn.close()


# feedback_loop._get_closed_trades 的过滤 (SSOT, 两处必须一致)
_EXCLUDE_STRATEGY = ("manual", "manual_sync", "reconciler", "futu_sync", "broker_reconcile")
_EXCLUDE_SOURCE = ("SCALPING", "ORB_ENGINE", "PLAYBOOK_SHADOW", "MAIN_PIPELINE")


def rebuild_from_trade_records() -> Dict[str, int]:
    """从 trade_records 全量重建 symbol_memory + pattern_memory (幂等)。

    根因修复: update_from_trade() 是非幂等的增量 +1 累加器, backfill 重跑会
    重复累计 (历史实测 766 次 vs 真实 251 次, 虚高约 3 倍), 且过滤条件中途
    变更导致旧亏损单漏记。strategy_memory 本质是 trade_records 的投影, 故改为
    每次全量重算: 清空聚合表 → 从真源重新聚合。可反复运行, 结果恒定。

    lesson_log 不动 (append-only 人类日志, 非聚合)。
    """
    _ensure_db()
    ft = sqlite3.connect(config.FTSEEK_DB, timeout=10)
    ft.row_factory = sqlite3.Row
    ph_strat = ",".join("?" * len(_EXCLUDE_STRATEGY))
    ph_src = ",".join("?" * len(_EXCLUDE_SOURCE))
    _sql = f"""
        SELECT trade_date, symbol, direction,
               COALESCE(pnl_net, realized_pnl) AS realized_pnl,
               holding_hours, signal_strength, exit_reason
        FROM trade_records
        WHERE realized_pnl IS NOT NULL
          AND strategy_id NOT IN ({ph_strat})
          AND source_type NOT IN ({ph_src})
    """
    _params = (*_EXCLUDE_STRATEGY, *_EXCLUDE_SOURCE)
    try:
        rows = ft.execute(
            _sql + " AND COALESCE(data_quality,'') IN ('clean','real')"
            " ORDER BY trade_date ASC, id ASC", _params).fetchall()
    except sqlite3.OperationalError:
        rows = ft.execute(_sql + " ORDER BY trade_date ASC, id ASC", _params).fetchall()
    ft.close()

    sym: Dict[Any, Dict] = {}
    pat: Dict[Any, Dict] = {}
    for r in rows:
        pnl = float(r["realized_pnl"] or 0)
        hold = float(r["holding_hours"] or 0)
        is_win = pnl > 0
        td = r["trade_date"] or ""

        sk = (r["symbol"] or "", r["direction"] or "")
        s = sym.setdefault(sk, {"total_trades": 0, "wins": 0, "total_pnl": 0.0,
                                "best_win": None, "worst_loss": None, "last_trade_date": ""})
        s["total_trades"] += 1
        s["wins"] += 1 if is_win else 0
        s["total_pnl"] += pnl
        if is_win:
            s["best_win"] = pnl if s["best_win"] is None else max(s["best_win"], pnl)
        else:
            s["worst_loss"] = pnl if s["worst_loss"] is None else min(s["worst_loss"], pnl)
        if td > s["last_trade_date"]:
            s["last_trade_date"] = td

        pk = (r["direction"] or "", r["exit_reason"] or "unknown",
              _strength_bucket(r["signal_strength"]))
        p = pat.setdefault(pk, {"total_trades": 0, "wins": 0, "total_pnl": 0.0,
                                "hold_sum": 0.0, "last_trade_date": ""})
        p["total_trades"] += 1
        p["wins"] += 1 if is_win else 0
        p["total_pnl"] += pnl
        p["hold_sum"] += hold
        if td > p["last_trade_date"]:
            p["last_trade_date"] = td

    now = datetime.now().isoformat()
    conn = sqlite3.connect(DB_PATH, timeout=10)
    # 2026-08-26 审计修复: 本脚本为外部进程, 按 SKILL.md 纪律不设 journal_mode (WAL 是持久化属性, 外部设置会干扰主进程可见性)
    conn.execute("DELETE FROM symbol_memory")
    conn.execute("DELETE FROM pattern_memory")
    for (symbol, direction), s in sym.items():
        tt = s["total_trades"]
        conn.execute("""
            INSERT INTO symbol_memory (symbol, direction, total_trades, wins, total_pnl,
                                       avg_pnl, win_rate, best_win, worst_loss,
                                       last_trade_date, last_updated)
            VALUES (?,?,?,?,?,?,?,?,?,?,?)
        """, (symbol, direction, tt, s["wins"], round(s["total_pnl"], 4),
              round(s["total_pnl"] / tt, 4) if tt else 0,
              round(s["wins"] / tt, 4) if tt else 0,
              s["best_win"] if s["best_win"] is not None else 0,
              s["worst_loss"] if s["worst_loss"] is not None else 0,
              s["last_trade_date"], now))
    for (direction, exit_reason, bucket), p in pat.items():
        tt = p["total_trades"]
        conn.execute("""
            INSERT INTO pattern_memory (direction, exit_reason, strength_bucket,
                                        total_trades, wins, total_pnl, avg_hold_hours,
                                        avg_pnl, win_rate, last_updated, last_trade_date)
            VALUES (?,?,?,?,?,?,?,?,?,?,?)
        """, (direction, exit_reason, bucket, tt, p["wins"], round(p["total_pnl"], 4),
              round(p["hold_sum"] / tt, 4) if tt else 0,
              round(p["total_pnl"] / tt, 4) if tt else 0,
              round(p["wins"] / tt, 4) if tt else 0,
              now, p["last_trade_date"]))
    conn.commit()
    conn.close()
    return {"trades": len(rows), "symbols": len(sym), "patterns": len(pat)}


def _confidence_level(trades: int) -> str:
    """样本量置信度标注。
    <5笔: very_low (不作为推荐依据)
    5-19笔: low (仅参考，不作为Gate强推荐)
    20-49笔: medium
    50+笔: high
    """
    if trades < 5:
        return "very_low"
    elif trades < 20:
        return "low"
    elif trades < 50:
        return "medium"
    else:
        return "high"


def _window_patterns(cutoff: str) -> List[Dict]:
    """真实滚动窗口 pattern (净额). 2026-10-23 修复.

    旧实现读 pattern_memory (全史累计) 再按 last_trade_date 筛"最近活跃组",
    把 3 个月毛收益标成"近 30 天". 现直接聚合窗口内 trade_records:
      - trade_date >= cutoff (底层样本窗, 不是分组最后活跃日);
      - COALESCE(pnl_net, realized_pnl) (净额优先);
      - A10: data_quality in ('clean','real'); 旧库缺列时回退只按日期.
    """
    _ex_s = ("manual", "manual_sync", "reconciler", "futu_sync", "broker_reconcile")
    _ex_t = ("SCALPING", "ORB_ENGINE", "PLAYBOOK_SHADOW", "MAIN_PIPELINE")
    base = """
        SELECT direction, exit_reason, signal_strength,
               COALESCE(pnl_net, realized_pnl) AS pnl, holding_hours
        FROM trade_records
        WHERE trade_date >= ? AND realized_pnl IS NOT NULL
          AND strategy_id NOT IN ({s})
          AND source_type NOT IN ({t})
    """.format(s=",".join("?" * len(_ex_s)), t=",".join("?" * len(_ex_t)))
    params = (cutoff, *_ex_s, *_ex_t)
    conn = sqlite3.connect(config.FTSEEK_DB, timeout=3)
    conn.row_factory = sqlite3.Row
    try:
        try:
            rows = conn.execute(
                base + " AND COALESCE(data_quality,'') IN ('clean','real')", params
            ).fetchall()
        except sqlite3.OperationalError:
            rows = conn.execute(base, params).fetchall()
    finally:
        conn.close()

    agg: Dict[Any, Dict] = {}
    for r in rows:
        key = (r["direction"] or "", r["exit_reason"] or "unknown",
               _strength_bucket(r["signal_strength"]))
        a = agg.setdefault(key, {"n": 0, "wins": 0, "pnl": 0.0, "hold": 0.0})
        pnl = float(r["pnl"] or 0)
        a["n"] += 1
        a["wins"] += 1 if pnl > 0 else 0
        a["pnl"] += pnl
        a["hold"] += float(r["holding_hours"] or 0)
    out = []
    for (d, er, bucket), a in agg.items():
        out.append({
            "direction": d, "exit_reason": er, "strength": bucket,
            "trades": a["n"], "wins": a["wins"],
            "win_rate": round(a["wins"] / a["n"], 3) if a["n"] else 0.0,
            "pnl": round(a["pnl"], 2),
            "avg_hold": round(a["hold"] / a["n"], 1) if a["n"] else 0.0,
            "confidence": _confidence_level(a["n"]),
        })
    return out


def get_strategy_hint(symbol: str = "", direction: str = "") -> Dict:
    """获取策略提示，注入LLM prompt。

    返回:
        {
            "symbol_history": {symbol: {direction: {trades, wins, pnl, ...}}},
            "win_patterns": [{direction, exit_reason, win_rate, pnl, ...}],
            "loss_patterns": [{direction, exit_reason, pnl, ...}],
            "exit_effectiveness": [{exit_reason, win_rate, pnl}],
            "recent_lessons": [str, ...],
            "window_days": 30, "window_cutoff": "YYYY-MM-DD",
        }
    """
    _ensure_db()
    conn = sqlite3.connect(DB_PATH, timeout=3)
    conn.row_factory = sqlite3.Row

    result = {}

    # 1. 个股历史 — 30天滚动窗口 (2026-07-13), 2026-10-23 改净额+A10
    if symbol:
        try:
            _cut = (datetime.now(ET_TZ)
                    - timedelta(days=SYMBOL_HISTORY_WINDOW_DAYS)).strftime("%Y-%m-%d")
            _tconn = sqlite3.connect(config.FTSEEK_DB, timeout=3)
            _tconn.row_factory = sqlite3.Row
            _sql = """
                SELECT direction,
                       COUNT(*) AS trades,
                       SUM(CASE WHEN COALESCE(pnl_net, realized_pnl) > 0 THEN 1 ELSE 0 END) AS wins,
                       ROUND(SUM(COALESCE(pnl_net, realized_pnl)), 2) AS total_pnl,
                       ROUND(AVG(COALESCE(pnl_net, realized_pnl)), 2) AS avg_pnl,
                       MAX(COALESCE(pnl_net, realized_pnl)) AS best_win,
                       MIN(COALESCE(pnl_net, realized_pnl)) AS worst_loss,
                       MAX(trade_date) AS last_date
                FROM trade_records
                WHERE symbol = ? AND realized_pnl IS NOT NULL
                  AND trade_date >= ?
                  AND strategy_id NOT IN ('manual','manual_sync','reconciler','futu_sync','broker_reconcile')
            """
            _tail = " GROUP BY direction"
            try:
                _trows = _tconn.execute(
                    _sql + " AND COALESCE(data_quality,'') IN ('clean','real')" + _tail,
                    (symbol, _cut)).fetchall()
            except sqlite3.OperationalError:
                _trows = _tconn.execute(_sql + _tail, (symbol, _cut)).fetchall()
            _tconn.close()
            if _trows:
                result["symbol_history"] = {
                    r["direction"]: {
                        "trades": r["trades"],
                        "wins": r["wins"],
                        "win_rate": round((r["wins"] / r["trades"]) if r["trades"] else 0.0, 3),
                        "total_pnl": r["total_pnl"] or 0.0,
                        "avg_pnl": r["avg_pnl"] or 0.0,
                        "best_win": r["best_win"],
                        "worst_loss": r["worst_loss"],
                        "last_date": r["last_date"],
                        "window_days": SYMBOL_HISTORY_WINDOW_DAYS,
                    }
                    for r in _trows
                }
        except Exception:
            pass

    # 2-4. pattern / 退出效果 — 同一真实窗口, 净额
    et_now = datetime.now(ET_TZ)
    cutoff_30d = (et_now - timedelta(days=30)).strftime("%Y-%m-%d")
    pats = _window_patterns(cutoff_30d)
    win_pats = sorted([p for p in pats if p["trades"] >= 2 and p["pnl"] > 0],
                      key=lambda p: p["pnl"], reverse=True)[:3]
    loss_pats = sorted([p for p in pats if p["trades"] >= 2 and p["pnl"] < 0],
                       key=lambda p: p["pnl"])[:3]
    result["win_patterns"] = win_pats
    result["loss_patterns"] = loss_pats

    by_exit: Dict[str, Dict] = {}
    for p in pats:
        e = by_exit.setdefault(p["exit_reason"], {"trades": 0, "wins": 0, "pnl": 0.0})
        e["trades"] += p["trades"]
        e["wins"] += p["wins"]
        e["pnl"] += p["pnl"]
    exits = [{
        "exit_reason": k, "trades": v["trades"],
        "win_rate": round(v["wins"] / v["trades"], 3) if v["trades"] else 0,
        "pnl": round(v["pnl"], 2),
        "confidence": _confidence_level(v["trades"]),
    } for k, v in by_exit.items() if v["trades"] >= 2]
    result["exit_effectiveness"] = sorted(exits, key=lambda x: x["pnl"], reverse=True)[:5]

    # 5. 最近教训 — 用ET时区与lesson_log.date对齐
    cutoff = (et_now - timedelta(days=7)).strftime("%Y-%m-%d")
    # 修复前 lesson 的日期可能仍落在 7 日窗内, 但生成逻辑已证伪; 不注入.
    lesson_cutoff = max(cutoff, LESSON_TRUTH_START)
    lessons = conn.execute("""
        SELECT content, impact, date FROM lesson_log
        WHERE date >= ?
        ORDER BY date DESC
        LIMIT 5
    """, (lesson_cutoff,)).fetchall()
    result["recent_lessons"] = [
        f"[{r['date']}][{r['impact']}] {r['content']}"
        for r in lessons
    ]
    result["window_days"] = 30
    result["window_cutoff"] = cutoff_30d

    conn.close()
    return result


def add_lesson(date: str, lesson_type: str, content: str,
               evidence: str = "", impact: str = "medium"):
    """添加一条复盘教训"""
    _ensure_db()
    conn = sqlite3.connect(DB_PATH, timeout=5)
    conn.execute("""
        INSERT INTO lesson_log (date, lesson_type, content, evidence, impact, created_at)
        VALUES (?, ?, ?, ?, ?, ?)
    """, (date, lesson_type, content, evidence, impact, datetime.now().isoformat()))
    conn.commit()
    conn.close()


def format_hint_for_prompt(hint: Dict, symbol: str = "") -> str:
    """把strategy hint格式化为LLM可读的文本 (2026-10-23: 明示真实窗口+净额)."""
    parts = []
    _win = int(hint.get("window_days") or SYMBOL_HISTORY_WINDOW_DAYS)

    # 个股历史
    sym_hist = hint.get("symbol_history", {})
    if sym_hist:
        for d, h in sym_hist.items():
            conf = _confidence_level(h["trades"])
            conf_tag = f" [置信度:{conf}]" if conf in ("very_low", "low") else ""
            parts.append(
                f"本股{symbol}近{_win}日{d}: {h['trades']}笔{h['wins']}胜 "
                f"WR={h['win_rate']*100:.0f}% PnL=${h['total_pnl']} "
                f"最佳=${h['best_win']} 最差=${h['worst_loss']}{conf_tag}"
            )
    else:
        parts.append(f"本股{symbol}无历史交易记录")

    # pattern/退出段恒为全市场范围 (不按 symbol 过滤)。无个股历史时必须标注来源,
    # 否则紧跟"本股无历史"会被读成本股 pattern (SKILL.md #35 同款处置)。
    scope = "" if sym_hist else "(全市场参考,非本股)"

    # 赢的pattern
    win_pats = hint.get("win_patterns", [])
    if win_pats:
        win_text = "; ".join([
            f"{p['direction']}+{p['exit_reason']}({p['strength']}) "
            f"{p['trades']}笔 WR={p['win_rate']*100:.0f}% PnL=${p['pnl']} hold={p['avg_hold']}h"
            f"{' [低置信,仅参考]' if p.get('confidence') in ('very_low','low') else ''}"
            for p in win_pats
        ])
        parts.append(f"赚钱pattern(近{_win}日净额){scope}: {win_text}")

    # 亏的pattern
    loss_pats = hint.get("loss_patterns", [])
    if loss_pats:
        loss_text = "; ".join([
            f"{p['direction']}+{p['exit_reason']}({p['strength']}) "
            f"{p['trades']}笔 PnL=${p['pnl']} hold={p['avg_hold']}h"
            f"{' [低置信,仅参考]' if p.get('confidence') in ('very_low','low') else ''}"
            for p in loss_pats
        ])
        parts.append(f"亏钱pattern(近{_win}日净额){scope}: {loss_text}")

    # 退出效果
    exits = hint.get("exit_effectiveness", [])
    if exits:
        exit_text = "; ".join([
            f"{e['exit_reason']}({e['trades']}笔 WR={e['win_rate']*100:.0f}% PnL=${e['pnl']})"
            f"{' [低置信]' if e.get('confidence') in ('very_low','low') else ''}"
            for e in exits
        ])
        parts.append(f"退出效果(近{_win}日净额){scope}: {exit_text}")

    # 教训
    lessons = hint.get("recent_lessons", [])
    if lessons:
        parts.append(f"近期教训{scope}:\n" + "\n".join(f"  {l}" for l in lessons))

    return "\n".join(parts)


def get_memory_summary() -> Dict:
    """获取memory摘要（供dashboard/报告用）"""
    _ensure_db()
    conn = sqlite3.connect(DB_PATH, timeout=3)
    conn.row_factory = sqlite3.Row

    pat_count = conn.execute("SELECT COUNT(*) FROM pattern_memory").fetchone()[0]
    sym_count = conn.execute("SELECT COUNT(*) FROM symbol_memory").fetchone()[0]
    lesson_count = conn.execute("SELECT COUNT(*) FROM lesson_log").fetchone()[0]

    top_win = conn.execute("""
        SELECT direction, exit_reason, strength_bucket, total_trades, wins,
               total_pnl, win_rate
        FROM pattern_memory WHERE total_trades >= 2 AND total_pnl > 0
        ORDER BY total_pnl DESC LIMIT 3
    """).fetchall()

    top_loss = conn.execute("""
        SELECT direction, exit_reason, strength_bucket, total_trades,
               total_pnl
        FROM pattern_memory WHERE total_trades >= 2 AND total_pnl < 0
        ORDER BY total_pnl ASC LIMIT 3
    """).fetchall()

    conn.close()

    return {
        "pattern_count": pat_count,
        "symbol_count": sym_count,
        "lesson_count": lesson_count,
        "top_win_patterns": [dict(r) for r in top_win],
        "top_loss_patterns": [dict(r) for r in top_loss],
    }


def main():
    import argparse
    parser = argparse.ArgumentParser(description="Strategy Memory")
    parser.add_argument("--action", choices=["summary", "hint"], default="summary")
    parser.add_argument("--symbol", default="")
    args = parser.parse_args()

    if args.action == "summary":
        s = get_memory_summary()
        print(json.dumps(s, ensure_ascii=False, indent=2, default=str))
    elif args.action == "hint":
        h = get_strategy_hint(symbol=args.symbol)
        print(format_hint_for_prompt(h, symbol=args.symbol))


if __name__ == "__main__":
    main()
