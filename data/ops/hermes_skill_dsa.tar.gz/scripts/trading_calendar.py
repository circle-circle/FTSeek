"""美股交易日历适配层 — 消灭 DA 侧的平行假日表 (2026-09-07, SKILL.md pitfall -6)

立项根因
--------
`ic_writer._get_et_trade_date()` 自带一份 6 条硬编码 `known_holidays`
(`(7,3)(7,4)(12,25)(1,1)(11,26)(11,27)`)，**漏劳动节**以及 MLK / 总统日 /
耶稣受难日 / 阵亡将士日 / 六月节 共 6 个 NYSE 全日休市日。而仓内本有 SSOT
`app/utils/holiday_calendar.py`(Futu `request_trading_days` 权威 + 2026-2028
硬编码降级 + 周末兜底)，DA 侧**零引用** → 典型平行真源漂移。

后果(2026-09-07 劳动节首次实弹): `trade_date` 被写成非交易日 → FTSeek
`backfill_forward_returns.py` 找不到该日日K → `close_t0/t1` 恒 NULL →
该批 snapshot **静默永久退出 IC 样本**(不报错)。

三层降级 (上层优先；每层独立 try，任一层给出答案即返回)
----------------------------------------------------
L1 `ftseek_ssot`  `app.utils.holiday_calendar.get_holiday_calendar().is_trading_day("US", d)`
                  —— 权威。内部已是 Futu API → 硬编码 2026-2028 → 仅周末 三级兜底。
L2 `rule`         按 NYSE 假日规则**现算**(零漂移：不复制任何日期表)。
                  注意 NYSE 在哥伦布日/退伍军人日**照常开盘**，故规则里不含这两天。
L3 `legacy`       ic_writer 原 6 条表 + 周末判断 —— 只为"上层全灭时不改变既有行为"。
                  **不要往这里加日期**(会重新制造平行真源)，要补请改 L2 规则。

失败语义
--------
三层全灭 → 返回 `True`(视为交易日) = **fail-open**，与 UE
`llm_universe_scan._is_us_trading_day_today()` / FTSeek
`app/playbook/pipeline.py::_is_trading_day_today()` 同口径("宁可跑不可漏")。
调用方若需 fail-close，请显式检查 `resolve()` 返回的 `layer` 是否为 `"fail-open"`。

回滚
----
删本文件 + 恢复 `ic_writer._get_et_trade_date()` 与 `pipeline.main()` 原实现。
本模块**纯函数、零 IO 副作用**(L1 首次调用会触发 Futu 缓存查询，由 SSOT 内部持锁)。
"""

from __future__ import annotations

import os
import sys
from datetime import date, timedelta
from functools import lru_cache
from typing import Optional, Set, Tuple

_FTSEEK_ROOT = os.environ.get("FTSEEK_ROOT", "/opt/ftseek/FTSeek-US")

# L3: ic_writer 原表，逐字保留(含原注释语义)。已知不完整。
_LEGACY_KNOWN_HOLIDAYS: Set[Tuple[int, int]] = {
    (7, 3),    # Independence Day observed (7/4=周六→observed周五7/3)
    (7, 4),    # Independence Day
    (12, 25),  # Christmas
    (1, 1),    # New Year
    (11, 26),  # Thanksgiving 2026 (4th Thu of Nov = 11/26)
    (11, 27),  # day after Thanksgiving
}


def _nth_weekday(year: int, month: int, weekday: int, n: int) -> date:
    """该月第 n 个 weekday (weekday: 0=Mon … 6=Sun)。"""
    first = date(year, month, 1)
    offset = (weekday - first.weekday()) % 7
    return first + timedelta(days=offset + 7 * (n - 1))


def _last_weekday(year: int, month: int, weekday: int) -> date:
    """该月最后一个 weekday。"""
    if month == 12:
        last = date(year, 12, 31)
    else:
        last = date(year, month + 1, 1) - timedelta(days=1)
    return last - timedelta(days=(last.weekday() - weekday) % 7)


def _easter(year: int) -> date:
    """匿名格里高利算法算复活节(周日)。Good Friday = 复活节 − 2 天。"""
    a = year % 19
    b, c = divmod(year, 100)
    d, e = divmod(b, 4)
    f = (b + 8) // 25
    g = (b - f + 1) // 3
    h = (19 * a + b - d - g + 15) % 30
    i, k = divmod(c, 4)
    l = (32 + 2 * e + 2 * i - h - k) % 7
    m = (a + 11 * h + 22 * l) // 451
    month, day = divmod(h + l - 7 * m + 114, 31)
    return date(year, month, day + 1)


def _observed(d: date, year: int) -> Optional[date]:
    """固定日期假日的 NYSE observed 平移: 周六→前一日周五, 周日→后一日周一。

    特例: 1/1 落周六时 NYSE **不设**补休(前一日周五照常开盘) → 返回 None。
    """
    if d.weekday() == 5:  # Sat
        if d.month == 1 and d.day == 1:
            return None
        return d - timedelta(days=1)
    if d.weekday() == 6:  # Sun
        return d + timedelta(days=1)
    return d


def rule_holidays(year: int) -> Set[date]:
    """L2: 按规则现算该年 NYSE 全日休市日(不含临时全国哀悼日 —— 那类只有 L1 Futu 知道)。"""
    out: Set[date] = set()

    def add(d: Optional[date]) -> None:
        if d is not None:
            out.add(d)

    add(_observed(date(year, 1, 1), year))                       # New Year's Day
    add(_nth_weekday(year, 1, 0, 3))                             # MLK Day (1月第3个周一)
    add(_nth_weekday(year, 2, 0, 3))                             # Presidents Day (2月第3个周一)
    add(_easter(year) - timedelta(days=2))                       # Good Friday
    add(_last_weekday(year, 5, 0))                               # Memorial Day (5月最后一个周一)
    add(_observed(date(year, 6, 19), year))                      # Juneteenth
    add(_observed(date(year, 7, 4), year))                       # Independence Day
    add(_nth_weekday(year, 9, 0, 1))                             # Labor Day (9月第1个周一)
    add(_nth_weekday(year, 11, 3, 4))                            # Thanksgiving (11月第4个周四)
    add(_observed(date(year, 12, 25), year))                     # Christmas
    return out

# ── 口径说明 (诚实标注；L2 与 L1 的差异是**已核实的事实**，不是待修 bug) ──────────
# 1) L2 规则**不含** 12/24 圣诞夜：NYSE 该日是**提前收盘(13:00 ET)而非全日休市**，
#    按"是否交易日"口径应为 True。实测 L1 在 **Futu 可用**时对 2026-12-24 也返回
#    True(`ftseek_ssot`) ⇒ L1 权威路径与 L2 一致。
#    ⚠️ 但 L1 的**离线硬编码** `US_HOLIDAYS` 里 2026-12-24 被列为假日 ⇒ FTSeek SSOT
#    自身在 12/24 上"Futu 路径 True / 离线路径 False"**自相矛盾**。这是**仓内侧**的
#    口径不一致(非本模块问题)，已登记 handoff；本模块不掩盖它、也不去"修正"它。
# 2) L2 **不含**哥伦布日(10月第2个周一)与退伍军人日(11/11)：NYSE 这两日**照常开盘**。
#    实测 L1 亦返回 True ⇒ 一致。(注意: 它们是联邦假日, 债市休市, 别拿债市日历套股市。)
# 3) L2 **不含**临时全国哀悼日(如总统逝世)：那类无规则可算，只有 L1 的 Futu 权威源知道。
#    ⇒ 这是 L1 不可被 L2 完全替代的根本原因，也是为什么 L1 必须排在最前。



def _l1_ftseek(d: date) -> Optional[bool]:
    try:
        if _FTSEEK_ROOT not in sys.path:
            sys.path.insert(0, _FTSEEK_ROOT)
        from app.utils.holiday_calendar import get_holiday_calendar
        return bool(get_holiday_calendar().is_trading_day("US", d))
    except Exception:
        return None


def _l2_rule(d: date) -> Optional[bool]:
    try:
        if d.weekday() >= 5:
            return False
        return d not in rule_holidays(d.year)
    except Exception:
        return None


def _l3_legacy(d: date) -> Optional[bool]:
    try:
        if d.weekday() >= 5:
            return False
        return (d.month, d.day) not in _LEGACY_KNOWN_HOLIDAYS
    except Exception:
        return None


@lru_cache(maxsize=512)
def resolve(d: date) -> Tuple[bool, str]:
    """返回 (是否交易日, 由哪一层给出答案)。

    layer ∈ {"ftseek_ssot", "rule", "legacy", "fail-open"}。
    `fail-open` 表示三层全灭、按"视为交易日"兜底(调用方应把它当异常看待)。

    memo: 同一日期的答案不随时间变化，缓存掉 L1 的重复调用(进程内单例日历虽有
    ~90 天缓存，但窗口外日期会触发 Futu 重查+重连，见 `_ensure_cache`)。
    """
    for layer, fn in (("ftseek_ssot", _l1_ftseek), ("rule", _l2_rule), ("legacy", _l3_legacy)):
        ans = fn(d)
        if ans is not None:
            return bool(ans), layer
    return True, "fail-open"


def is_us_trading_day(d: date) -> bool:
    """便捷布尔口径(fail-open)。等价 UE `_is_us_trading_day_today()` 的语义。"""
    return resolve(d)[0]


def latest_trading_day(d: date, max_back: int = 12) -> Tuple[date, str]:
    """从 d 起(含 d)向前找最近的真实交易日。

    周末与假日统一由 `is_us_trading_day` 判定，取代原 ic_writer 里
    "周末前推" + "假日表前推" 两套分叉逻辑。`max_back` 防死循环
    (NYSE 最长连续休市 = 周末 + 假日，12 天足够宽松)。

    返回 (交易日, layer)；若 max_back 内找不到(理论上不会发生) → 返回原 d + "exhausted"。
    """
    cur = d
    layer = "fail-open"
    for _ in range(max_back + 1):
        ok, layer = resolve(cur)
        if ok:
            return cur, layer
        cur = cur - timedelta(days=1)
    return d, "exhausted"


# ── ET 口径便捷函数 (与 ic_writer._ET_TZ 同源: zoneinfo 主 + pytz 兜底) ──────────
try:
    from zoneinfo import ZoneInfo as _ZoneInfo
    ET_TZ = _ZoneInfo("America/New_York")
except Exception:  # pragma: no cover - 兜底路径
    from pytz import timezone as _pytz_tz
    ET_TZ = _pytz_tz("America/New_York")


def now_et():
    """当前 ET 时刻 (aware)。"""
    from datetime import datetime
    return datetime.now(ET_TZ)


def today_et() -> date:
    """当前 ET 日期。

    为什么必须有这个而不是 `date.today()`: 容器时区是 CST(UTC+8)，
    CST 周一凌晨 = ET 周日晚 —— 直接用 `date.today()` 会把 ET 周日判成周一。
    FTSeek 侧 `holiday_calendar.is_trading_day()` 的缺省分支已于 2026-07-27
    修过同款漏网，本函数是 DA 侧的对齐实现。
    """
    return now_et().date()
