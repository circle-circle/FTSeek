#!/usr/bin/env python3
"""入场质量门禁预注册裁决器 (2026-08-14) — 死胎攒样器的自动裁决层

定位: deadfetus_collector 攒样, 本脚本裁决。n>=100 时对 5 个入场特征维度
(volume_ratio/rsi/entry_session/chase_pct/source) 做双窗分离度检验,
满足预注册门槛才输出门禁候选; 否则只报进度。

预注册判据 (看数据前写死, 不许事后调):
  1. 总样本 n >= 100
  2. 每窗候选桶 n >= 10, 对照桶 n >= 10
  3. 双窗死胎率差均 >= 15pp 且同向 (与攒样器口径一致)
  4. 形状检查: 候选桶在维度内须"方向可解释" —
     - 若维度桶序有自然序 (chase_pct 从回踩到重追, rsi 从低到高), 候选桶
       的死胎率序列须单调趋势 (Spearman |rho|>=0.5), 否则标记 NON_MONOTONIC
       并降级为"仅观察, 不列门禁候选" (2026-08-14 实证: chase 非单调,
       重追死胎率反而最低 — 非单调维度上的单桶门禁无机制支撑)
  5. 误杀检查: 候选桶内实盘盈利笔占比 > 40% 且盈利金额 > |桶净亏| → 降级
     (门禁会杀掉这些赢家)
  6. 冻结源检查 (2026-10-06): 桶内最新样本落后全池最新样本 > 14 天 → 降级
     FROZEN_SOURCE。背景: REENTRY 通道 9/17 已被数据裁决关停 (config enabled:false,
     566344bda), 其 26 笔历史样本随全池增长被双窗切分重新对齐, 10/6 在 n=390 处
     首次凑齐"双窗各≥10 + gap≥15pp"而触发 GATE_CANDIDATES_FOUND — 这是对已裁决
     关停通道的延迟回声 (同期对照 ≤9/15 内 REENTRY vs 其余 gap 仅 13.6pp, 未达阈;
     w2 gap 15.9pp 靠 9/16 后低死胎期压低对照基线放大)。门禁保护的是未来入场,
     停更通道的桶无未来样本可保护; 通道重启须重新预注册攒样 (skill 既有纪律),
     冻结桶不得直接复活为门禁候选。

产出: deadfetus_adjudication.json (幂等覆盖) + 控制台摘要。
回滚: 删本文件 + cron Step 1.7, 攒样器不受影响。
用法: python3 deadfetus_adjudicator.py
"""
import json
import sys
from datetime import date as _date
from pathlib import Path

SAMPLES = Path(__file__).parent / "deadfetus_samples.jsonl"
OUT = Path(__file__).parent / "deadfetus_adjudication.json"

TARGET_N = 100
MIN_BUCKET_N = 10
MIN_GAP_PP = 15.0
MAX_FALSE_KILL_WIN_RATIO = 0.40  # 桶内盈利笔占比上限
FROZEN_SOURCE_LAG_DAYS = 14  # 判据6: 桶最新样本落后全池最新样本超此天数 = 冻结源

# 维度桶定义 (与 deadfetus_collector.split_dims 同源口径)
DIMS = {
    "volume_ratio": [
        ("<0.1", lambda s: s["volume_ratio"] is not None and s["volume_ratio"] < 0.1),
        ("0.1-0.3", lambda s: s["volume_ratio"] is not None and 0.1 <= s["volume_ratio"] < 0.3),
        (">=0.3", lambda s: s["volume_ratio"] is not None and s["volume_ratio"] >= 0.3),
    ],
    "rsi": [
        ("<60", lambda s: s["rsi"] is not None and s["rsi"] < 60),
        ("60-70", lambda s: s["rsi"] is not None and 60 <= s["rsi"] < 70),
        (">=70", lambda s: s["rsi"] is not None and s["rsi"] >= 70),
    ],
    "entry_session": [
        ("开盘30min", lambda s: s["entry_hhmm"] <= "09:59"),
        ("上午10-12", lambda s: "10:00" <= s["entry_hhmm"] <= "11:59"),
        ("午后", lambda s: s["entry_hhmm"] >= "12:00"),
    ],
    "chase_pct": [
        ("回踩(<-0.5%)", lambda s: s.get("chase_pct") is not None and s["chase_pct"] < -0.5),
        ("贴计划", lambda s: s.get("chase_pct") is not None and -0.5 <= s["chase_pct"] < 0.5),
        ("顺偏(0.5~1.5%)", lambda s: s.get("chase_pct") is not None and 0.5 <= s["chase_pct"] < 1.5),
        ("追(1.5~3%)", lambda s: s.get("chase_pct") is not None and 1.5 <= s["chase_pct"] < 3.0),
        ("重追(>=3%)", lambda s: s.get("chase_pct") is not None and s["chase_pct"] >= 3.0),
    ],
    "source": [
        (src, lambda s, _x=src: s["source"] == _x)
        for src in ("DA", "UE", "REENTRY", "TFB")
    ],
}
ORDERED_DIMS = {"rsi", "chase_pct", "volume_ratio", "entry_session"}  # source 无序不查单调


def dead_rate(sub):
    n = len(sub)
    if not n:
        return None, 0
    return 100 * sum(1 for s in sub if s["label"] == "DEAD") / n, n


def spearman_rho(xs, ys):
    """小样本 Spearman (无 scipy 依赖)."""
    n = len(xs)
    if n < 3:
        return 0.0
    def rank(v):
        order = sorted(range(n), key=lambda i: v[i])
        rk = [0.0] * n
        for pos, idx in enumerate(order):
            rk[idx] = pos
        return rk
    rx, ry = rank(xs), rank(ys)
    mx, my = sum(rx) / n, sum(ry) / n
    num = sum((a - mx) * (b - my) for a, b in zip(rx, ry))
    dx = sum((a - mx) ** 2 for a in rx) ** 0.5
    dy = sum((b - my) ** 2 for b in ry) ** 0.5
    return num / (dx * dy) if dx * dy > 0 else 0.0


def adjudicate(samples):
    n = len(samples)
    result = {
        "n": n, "target_n": TARGET_N,
        "verdict": "INSUFFICIENT_SAMPLES" if n < TARGET_N else None,
        "gate_candidates": [], "observe_only": [], "details": {},
    }
    if n < TARGET_N:
        return result

    half = n // 2
    first, second = samples[:half], samples[half:]

    for dim, buckets in DIMS.items():
        bucket_stats = []
        for bname, pred in buckets:
            d1, n1 = dead_rate([s for s in first if pred(s)])
            d2, n2 = dead_rate([s for s in second if pred(s)])
            rest1 = [s for s in first if not pred(s)]
            rest2 = [s for s in second if not pred(s)]
            r1, _ = dead_rate(rest1)
            r2, _ = dead_rate(rest2)
            sub_all = [s for s in samples if pred(s)]
            wins = [s for s in sub_all if s["pnl_net"] > 0]
            win_amt = sum(s["pnl_net"] for s in wins)
            net_amt = sum(s["pnl_net"] for s in sub_all)
            bucket_stats.append({
                "bucket": bname, "n": len(sub_all), "n_w1": n1, "n_w2": n2,
                "dr_w1": d1, "dr_w2": d2, "gap_w1": None if d1 is None or r1 is None else round(d1 - r1, 1),
                "gap_w2": None if d2 is None or r2 is None else round(d2 - r2, 1),
                "win_ratio": round(len(wins) / len(sub_all), 2) if sub_all else None,
                "win_amt": round(win_amt, 1), "net_amt": round(net_amt, 1),
            })
        result["details"][dim] = bucket_stats

        # 判据 2+3: 双窗 gap >= 15pp 同向, 桶量达标
        for bs in bucket_stats:
            g1, g2 = bs["gap_w1"], bs["gap_w2"]
            if g1 is None or g2 is None:
                continue
            if bs["n_w1"] < MIN_BUCKET_N or bs["n_w2"] < MIN_BUCKET_N:
                continue
            if abs(g1) < MIN_GAP_PP or abs(g2) < MIN_GAP_PP or g1 * g2 <= 0:
                continue
            direction = "higher_dead" if g1 > 0 else "lower_dead"
            cand = {"dim": dim, "bucket": bs["bucket"], "direction": direction,
                    "gap_w1": g1, "gap_w2": g2, **bs}
            # 判据 5: 误杀检查 (只对 higher_dead 候选有意义 — 门禁是拦桶)
            demoted = None
            if direction == "higher_dead":
                if bs["win_ratio"] is not None and bs["win_ratio"] > MAX_FALSE_KILL_WIN_RATIO \
                        and bs["win_amt"] > abs(min(bs["net_amt"], 0)):
                    demoted = "FALSE_KILL_RISK(盈利占比>40%且盈利额>净亏)"
            # 判据 6: 冻结源检查 (2026-10-06) — 桶内最新样本落后全池 >14 天
            #   ⇒ 通道已停更 (如 REENTRY 9/17 被裁关), 门禁无未来样本可保护;
            #   历史桶随全池增长的窗切分漂移会延迟回声出候选, 不构成新证据。
            if not demoted:
                pool_latest = max(s["date"] for s in samples)
                cand_pred = dict(DIMS[dim])[bs["bucket"]]
                bucket_dates = [s["date"] for s in samples if cand_pred(s)]
                if bucket_dates:
                    lag = (_date.fromisoformat(pool_latest)
                           - _date.fromisoformat(max(bucket_dates))).days
                    if lag > FROZEN_SOURCE_LAG_DAYS:
                        demoted = f"FROZEN_SOURCE(桶最新{max(bucket_dates)}落后全池{lag}天>14, 通道已停更)"
            # 判据 4: 单调形状检查 (有序维度)
            if dim in ORDERED_DIMS and not demoted:
                preds = dict(DIMS[dim])  # bucket_name → 谓词函数
                seq_all = [(b["bucket"], sum(1 for s in samples if preds[b["bucket"]](s)
                             and s["label"] == "DEAD") / max(1, b["n"]) * 100)
                           for b in bucket_stats if b["n"] > 0]
                if len(seq_all) >= 3:
                    rho = spearman_rho(list(range(len(seq_all))), [x[1] for x in seq_all])
                    cand["monotonic_rho"] = round(rho, 2)
                    if abs(rho) < 0.5:
                        demoted = f"NON_MONOTONIC(rho={rho:.2f}, 维度内死胎率无单调趋势)"
            if demoted:
                cand["demote_reason"] = demoted
                result["observe_only"].append(cand)
            else:
                result["gate_candidates"].append(cand)

    result["verdict"] = ("GATE_CANDIDATES_FOUND" if result["gate_candidates"]
                         else "NO_CANDIDATE_KEEP_SAMPLING")
    return result


def main():
    samples = []
    if SAMPLES.exists():
        for line in SAMPLES.read_text().splitlines():
            try:
                samples.append(json.loads(line))
            except Exception:
                pass
    res = adjudicate(samples)
    OUT.write_text(json.dumps(res, ensure_ascii=False, indent=1))

    print(f"[裁决器] n={res['n']}/{TARGET_N} → {res['verdict']}")
    if res["verdict"] == "INSUFFICIENT_SAMPLES":
        print(f"  继续攒样 (差 {TARGET_N - res['n']} 笔), 不做裁决")
        return
    if res["gate_candidates"]:
        print("  🚩 门禁候选 (已过全部预注册判据):")
        for c in res["gate_candidates"]:
            print(f"    - {c['dim']}={c['bucket']} {c['direction']} "
                  f"双窗gap {c['gap_w1']:+.1f}/{c['gap_w2']:+.1f}pp "
                  f"桶净{c['net_amt']:+.0f} 盈利占比{c['win_ratio']}")
        print("  → 提交 DEB 立项流程 (不直接进门禁)")
    else:
        print("  无门禁候选 — 维持现状继续攒样")
    if res["observe_only"]:
        print("  👀 仅观察 (双窗达标但被降级):")
        for c in res["observe_only"]:
            print(f"    - {c['dim']}={c['bucket']}: {c['demote_reason']}")


if __name__ == "__main__":
    main()
