#!/usr/bin/env python3
"""decision_conf 校准链 (2026-08-14) — 评分质量验收基建

目的: 回答"gate 的 PASS/WARN/BLOCK 判定 + decision_conf + LLM评分,
  到底对 T+1 方向化收益有没有预测力" — 此前 model_performance 等校准表
  7/15 后停更=死链, 评分产出后无人验收。

三源 JOIN:
  da_gate_decisions.jsonl → decision / decision_conf / challenger_verdict /
                             llm_score(reasons) / intended direction  [主表]
  playbook_instructions   → PASS/WARN 行的方向化 fwd_return + 成交 realized pnl
  signal_snapshots.db     → BLOCK 行的 fwd_ret_t1 (NEUTRAL, 需按 intended
                             direction 手工方向化) + PASS/WARN 兜底
原则: 纯记账零干预; upsert by (trade_date|symbol); fwd 延迟到达可更新。
回滚: 删本文件 + dc_calibration_samples.jsonl + cron附录步骤, 零残留。

口径警示:
  1. dc=0.70 含两来源 — 挑战者真一致(+0.20) 与 弃权但score≥7后门抬升,
     故 challenger_verdict 为主维度(但历史多为None, 8/14起才有效), dc 为副维度。
  2. 【口径统一 2026-08-14 修正】PASS/WARN 行 instructions.fwd_return 是
     entry_price→close_t1 (含日内段, 实测日内段均值+2.06pp 与两源差异 corr=0.999),
     BLOCK 行无成交价只有 close_t0→close_t1 — 两基线混算会把 regime 日内涨幅
     记在 PASS 头上 (+2pp 假信号)。主口径统一为 close_t0→close_t1 (snapshot源),
     entry 基线仅作副列。NEUTRAL 快照是原始收益, 须×intended direction 方向化。
报告纪律: n>=100 出正式结论; 候选结论需时间双窗(前后各半)同向且差>=15pp。

2026-08-27 (用户裁: 记账双口径): 成交侧新增两列 —
  strategy_net_pct: 策略实际退出净收益% (COALESCE(pnl_net,realized_pnl)/notional,
    即现行退出逻辑——保本/回撤锁利/SL/TP——真实落袋口径);
  shadow_variants: metadata._exit_shadow 里各"peak后回撤"变体的反事实出场
    (gross%, 变体恒比生产更紧故触发可观测, 未触发=跟随实盘出场)。
  报告 ⑥双口径对账 + ⑦变体反事实。双窗门禁比较仍只用统一收盘口径 —
  BLOCK 行无成交无退出路径, 策略口径不可得, 这是可辨识性约束不是bug。

2026-09-23 (配对补齐): 同一 decision_id 在 playbook_instructions 可落两行 —
  分析日行 (executed=0, entry_*/fwd 全 NULL) 与执行日行 (executed=1, 有 fwd)。
  按 (date|symbol) 取指令会取到分析日那行 ⇒ fwd_ret_t1_entry 永为 NULL,
  已成交却"待T+1回填"永久挂账 (实测 8/31 BABA/BWXT/LLY/META 4 笔,
  docstring 里的 decision_id 关联只在 trade_records 侧做过)。
  修法: 指令索引补 decision_id 维度, 取到无 fwd 的行时回落到同 decision_id
  的"有 fwd 那行"; 主口径(close0→close1)/副口径(entry→close_t1)语义零变更。

2026-09-23 (测量系统指纹): 样本行补抄 gate 行的 prompt_hash / challenger_prompt_hash,
  报告新增 ⓪ 分桶段。背景: 本文件自订纪律"prompt 再改则 MIN_TRADE_DATE 前移、旧样本
  作废重攒", 但 9/14(v0.80)/9/21(temp0) 指纹已两度切换而日期未前移 ⇒ 台账实际混着
  ≥3 届测量系统。经裁决改用**按指纹分桶**替代作废重攒 (保留样本量, 桶内可比):
  双窗判据裁决只在同指纹桶内做; "无指纹(旧样本)"桶 = 8/14~指纹落盘前, 仅作历史参考。
"""
import json
import re
import sqlite3
import statistics
import sys
import pathlib

sys.path.insert(0, str(pathlib.Path(__file__).parent))
import config

HERE = pathlib.Path(__file__).parent
OUT = HERE / "dc_calibration_samples.jsonl"
GATE_JSONL = "/opt/ftseek/FTSeek-US/data/da_gate_decisions.jsonl"
SIGNAL_DB = "/opt/ftseek/FTSeek-US/data/signal_snapshots.db"
MIN_N_REPORT = 100
# 攒样起点 (2026-08-14 用户裁): DA/UE prompt 当日升级 (P1新闻事实流/P2 tripwires/
#   P3反虚构), 历史样本属旧测量系统不可比 → 只收 8/14 及以后。
#   若未来再改 prompt, 此日期同步前移, 旧样本作废重攒。
MIN_TRADE_DATE = "2026-08-14"


def _better_row(a, b):
    """同 decision_id 两行取更可用的一行: 有 fwd > 已执行 > 日期更晚。

    2026-09-23: 分析日行与执行日行同 id, 必须确定性地取到有 fwd 的那行,
    否则配对半边永久缺失 (且"取最后读到的一行"依赖查询返回顺序 = 不确定)。
    """
    if b is None:
        return True
    if (a["fwd_return_t1"] is not None) != (b["fwd_return_t1"] is not None):
        return a["fwd_return_t1"] is not None
    if bool(a["executed"]) != bool(b["executed"]):
        return bool(a["executed"])
    return str(a["date"]) >= str(b["date"])


def _load_gate_rows():
    """gate jsonl → 按 (trade_date|symbol) 去重保留最后一条, 只要 BUY/SELL_SHORT 方向行。"""
    rows = {}
    for line in open(GATE_JSONL):
        line = line.strip()
        if not line:
            continue
        try:
            r = json.loads(line)
        except Exception:
            continue
        if str(r.get("direction", "")).upper() not in ("BUY", "SELL_SHORT"):
            continue
        td = str(r.get("trade_date") or "")[:10]
        sym = str(r.get("symbol") or "")
        if not td or not sym:
            continue
        if td < MIN_TRADE_DATE:  # prompt升级日闸: 旧测量系统样本作废
            continue
        key = f"{td}|{sym}"
        if key not in rows or str(r.get("datetime", "")) >= str(rows[key].get("datetime", "")):
            rows[key] = r
    return rows


def _llm_score(g):
    for reason in (g.get("reasons") or []):
        m = re.search(r"score=([\d.]+)/10", reason)
        if m:
            return float(m.group(1))
    return None


def _verdict_bucket(verdict, direction, challenger_direction):
    """AGREE / OPPOSE / ABSTAIN / NO_VERDICT (历史None)"""
    v = str(verdict or "").strip().upper()
    if not v or v == "NONE":
        return "NO_VERDICT"
    if v in ("AGREE", "PASS"):
        return "AGREE"
    if "DISAGREE" in v or "OPPOSE" in v or "REJECT" in v:
        return "OPPOSE"
    cd = str(challenger_direction or "").upper()
    if cd in ("BUY", "SELL_SHORT") and direction and cd != direction:
        return "OPPOSE"
    return "ABSTAIN"


def collect():
    gate_rows = _load_gate_rows()
    if not gate_rows:
        print("[dc校准] gate jsonl 无可校准行")
        return

    # ── 源1: instructions (PASS/WARN 方向化收益 + 成交) ──
    fcon = sqlite3.connect(config.FTSEEK_DB, timeout=10)
    fcon.row_factory = sqlite3.Row
    inst = {}
    inst_by_did = {}
    for r in fcon.execute(
        "SELECT date, symbol, decision_id, direction, triggered, executed, "
        "fwd_return_t1, fwd_return_t3, fwd_return_intraday, pnl "
        "FROM playbook_instructions WHERE decision_id LIKE 'DA-%'"
    ):
        d = dict(r)
        inst[f"{r['date']}|{r['symbol']}"] = d
        did = d.get("decision_id")
        if did:
            cur = inst_by_did.get(did)
            inst_by_did[did] = d if _better_row(d, cur) else cur
    realized = {}
    # 2026-08-27 双口径: 多取 entry_price/quantity/metadata_json 算策略净收益% + 影子变体
    for r in fcon.execute(
        "SELECT decision_id, pnl_net, realized_pnl, entry_price, quantity, "
        "exit_reason, metadata_json FROM trade_records "
        "WHERE decision_id LIKE 'DA-%' ORDER BY exit_time ASC"
    ):
        d = dict(r)
        # 策略实际退出净收益% — COALESCE(pnl_net, realized_pnl)/notional (8/20净口径)
        net = d["pnl_net"] if d["pnl_net"] is not None else d["realized_pnl"]
        notional = float(d["entry_price"] or 0) * float(d["quantity"] or 0)
        d["strategy_net_pct"] = round(net / notional * 100, 4) if (net is not None and notional > 0) else None
        # 影子变体反事实出场 (peak后回撤/保本变体, gross%, 未触发键不存在)
        variants = {}
        try:
            sh = (json.loads(d["metadata_json"] or "{}").get("_exit_shadow") or {})
            for vname, v in sh.items():
                if isinstance(v, dict) and v.get("profit_pct") is not None:
                    variants[vname] = {
                        "profit_pct": v["profit_pct"],
                        "held_minutes": v.get("held_minutes"),
                    }
        except Exception:
            pass
        d["shadow_variants"] = variants
        realized[r["decision_id"]] = d
    fcon.close()

    # ── 源2: signal_snapshots (BLOCK 对照组的 fwd_ret_t1, NEUTRAL原始收益) ──
    snap = {}
    try:
        scon = sqlite3.connect(SIGNAL_DB, timeout=10)
        scon.row_factory = sqlite3.Row
        for r in scon.execute(
            "SELECT substr(created_at,1,10) d, symbol, fwd_ret_t1, fwd_ret_t5 "
            "FROM signal_snapshots WHERE strategy_id='deep_analysis'"
        ):
            snap[f"{r['d']}|{r['symbol']}"] = dict(r)
        scon.close()
    except Exception as e:
        print(f"[dc校准] signal_snapshots 读取失败(BLOCK对照组缺失): {e}")

    # ── 已有样本 upsert ──
    samples = {}
    if OUT.exists():
        for line in OUT.open():
            try:
                s = json.loads(line)
                samples[s["key"]] = s
            except Exception:
                pass

    added = updated = 0
    n_block_with_fwd = 0
    for key, g in gate_rows.items():
        decision = g.get("decision")
        direction = g["direction"]
        sign = 1.0 if direction == "BUY" else -1.0
        irow = inst.get(key)
        srow = snap.get(key)

        # 主口径 (统一): close_t0→close_t1, 全部来自 snapshot (BLOCK也可比)
        fwd_close0 = None
        # 副口径: entry→close_t1, 仅 PASS/WARN 有 (BLOCK无成交价)
        fwd_entry = fwd_entry_intraday = None
        decision_id = triggered = executed = None

        if srow is not None and srow["fwd_ret_t1"] is not None:
            fwd_close0 = round(sign * srow["fwd_ret_t1"], 6)
        if irow is not None:
            # 2026-09-23: 取到的是无 fwd 的分析日行时, 回落到同 decision_id 的执行日行
            if irow["fwd_return_t1"] is None:
                _alt = inst_by_did.get(irow["decision_id"])
                if _alt is not None and _alt["fwd_return_t1"] is not None:
                    irow = _alt
            decision_id = irow["decision_id"]
            triggered = bool(irow["triggered"])
            executed = bool(irow["executed"])
            fwd_entry = irow["fwd_return_t1"]
            fwd_entry_intraday = irow["fwd_return_intraday"]
        if decision == "BLOCK" and fwd_close0 is not None:
            n_block_with_fwd += 1

        rz = realized.get(decision_id) if decision_id else None
        row = {
            "key": key,
            "trade_date": g["trade_date"],
            "symbol": g["symbol"],
            "decision_id": decision_id,
            "direction": direction,
            "gate_decision": decision,
            "llm_score": _llm_score(g),
            "decision_conf": g.get("decision_conf"),
            "challenger_verdict": str(g.get("challenger_verdict") or ""),
            "verdict_bucket": _verdict_bucket(
                g.get("challenger_verdict"), direction,
                g.get("challenger_independent_direction") or g.get("challenger_direction")),
            "p0_shadow": g.get("p0_shadow"),
            # 测量系统指纹 (2026-09-23 复查批 P1): gate 行自带 prompt_hash, 抄进样本行。
            #   9/14(v0.80 飞刀几何) / 9/21(temp0) PROMPT_HASH 已两度切换而 MIN_TRADE_DATE
            #   未前移 ⇒ 台账混着 ≥3 届测量系统。指纹落行后报告按桶分列 (⓪段), 双窗判据
            #   (n>=100 + 15pp) 裁决时须用同指纹桶内数据, 不得跨桶混算。
            "prompt_hash": g.get("prompt_hash"),
            "challenger_prompt_hash": g.get("challenger_prompt_hash"),
            # 主口径: close0→close1 (统一, BLOCK可比) — 报告/双窗一律用它
            "fwd_ret_t1": fwd_close0,
            # 副口径: entry基线 (仅成交侧有, 含日内段, 只供归因不做门禁)
            "fwd_ret_t1_entry": fwd_entry,
            "fwd_ret_intraday": fwd_entry_intraday,
            "triggered": triggered,
            "executed": executed,
            "realized_pnl_net": rz["pnl_net"] if rz else None,
            "exit_reason": rz["exit_reason"] if rz else None,
            # 2026-08-27 双口径: 策略实际退出净收益% (现行退出逻辑真实落袋)
            # + 各"peak后回撤"影子变体的反事实出场 (未触发=跟随实盘, 键不存在)
            "strategy_net_pct": rz.get("strategy_net_pct") if rz else None,
            "shadow_variants": rz.get("shadow_variants") if rz else None,
        }
        prev = samples.get(key)
        samples[key] = row
        if prev is None:
            added += 1
        elif (prev.get("fwd_ret_t1") != fwd_close0
              or prev.get("strategy_net_pct") != row["strategy_net_pct"]
              or prev.get("shadow_variants") != row["shadow_variants"]):
            updated += 1

    with OUT.open("w") as f:
        for s in sorted(samples.values(), key=lambda x: (x["trade_date"], x["symbol"])):
            f.write(json.dumps(s, ensure_ascii=False) + "\n")

    n_t1 = sum(1 for s in samples.values() if s["fwd_ret_t1"] is not None)
    print(f"[dc校准] 新增{added} 更新{updated} | 累计{len(samples)} 样本 "
          f"{n_t1}有T+1回填 (其中BLOCK对照组带fwd={n_block_with_fwd})")
    report(list(samples.values()))


def _stat(rows, valkey):
    vs = [r[valkey] for r in rows if r.get(valkey) is not None]
    if not vs:
        return None
    return {"n": len(vs), "mean": round(sum(vs) / len(vs) * 100, 3),
            "wr": round(sum(1 for v in vs if v > 0) / len(vs), 3)}


def _print_block(title, rows, split_fn):
    print(f"  -- {title} (方向化T+1收益%) --")
    groups = {}
    for s in rows:
        groups.setdefault(split_fn(s), []).append(s)
    for k in sorted(groups, key=lambda x: str(x)):
        st = _stat(groups[k], "fwd_ret_t1")
        if st:
            print(f"    {str(k):14s} n={st['n']:4d} mean={st['mean']:+.3f}% WR={st['wr']:.3f}")


def report(samples):
    have = [s for s in samples if s["fwd_ret_t1"] is not None]
    n = len(have)
    print(f"[dc校准报告] 可校准样本(T+1已回填) n={n}")
    if n < MIN_N_REPORT:
        print(f"  ⚠️ 样本未达{MIN_N_REPORT}, 初步预览禁用于门禁决策")

    _print_block("⓪ prompt测量系统分桶 (2026-09-23 起落指纹; 跨桶样本不可混算双窗判据)",
                 have, lambda s: s.get("prompt_hash") or "无指纹(旧样本)")
    _print_block("① gate判定", have, lambda s: s["gate_decision"])
    _print_block("② decision_conf档", have, lambda s: (
        "dc>=0.7" if (s["decision_conf"] or 0) >= 0.7
        else "dc 0.5-0.7" if (s["decision_conf"] or 0) >= 0.5 else "dc<0.5"))
    _print_block("③ LLM评分档", have, lambda s: (
        "score>=7" if (s["llm_score"] or 0) >= 7
        else "score 5-7" if (s["llm_score"] or 0) >= 5 else "score<5"))
    _print_block("④ 挑战者投票(8/14起)", have, lambda s: s["verdict_bucket"])

    exec_rows = [s for s in samples if s["realized_pnl_net"] is not None]
    if exec_rows:
        pnl = sum(s["realized_pnl_net"] for s in exec_rows)
        print(f"  -- ⑤ DA成交子集 n={len(exec_rows)} 净盈亏=${pnl:+.2f} --")

    # ── ⑥ 双口径对账 (2026-08-27): 收盘价口径 vs 策略实际退出口径 ──
    # 收盘价口径 = entry→close_t1 (方向化, 含日内+隔夜, 假设持有到次日收盘);
    # 策略口径 = 现行退出逻辑真实落袋 (保本/回撤锁利/SL/TP, 净%).
    # 一致率回答"评分预测的是收盘价收益还是策略真能落袋的收益".
    dual = [s for s in samples if s.get("strategy_net_pct") is not None
            and s.get("fwd_ret_t1_entry") is not None]
    if dual:
        close_vals = [s["fwd_ret_t1_entry"] * 100 for s in dual]
        strat_vals = [s["strategy_net_pct"] for s in dual]
        same_dir = sum(1 for s in dual
                       if (s["fwd_ret_t1_entry"] > 0) == (s["strategy_net_pct"] > 0))
        # capture = 策略实际落袋 / 收盘价口径 (仅收盘口径>0时, 衡量截留效率)
        # 2026-09-23 口径修正: 值/值 指标不得用 mean(v_i/d_i) — 小分母笔会拉飞
        #   (同一子集实测 均值比 0.47-0.50 / 中位 0.11 / Σ/Σ 0.19)。改报 Σ/Σ + 中位。
        pos = [s for s in dual if s["fwd_ret_t1_entry"] > 0.001]
        print(f"  -- ⑥ 双口径对账 (n={len(dual)} 成交笔, 收盘价口径 vs 策略实际退出) --")
        print(f"    收盘价口径(entry→close_t1) mean={sum(close_vals)/len(close_vals):+.3f}% "
              f"WR={sum(1 for v in close_vals if v > 0)/len(close_vals):.3f}")
        print(f"    策略实际退出(净落袋)      mean={sum(strat_vals)/len(strat_vals):+.3f}% "
              f"WR={sum(1 for v in strat_vals if v > 0)/len(strat_vals):.3f}")
        tail = (f" 截留率Σ/Σ={sum(s['strategy_net_pct'] for s in pos) / sum(s['fwd_ret_t1_entry'] * 100 for s in pos):.2f}"
                f" 中位={statistics.median(s['strategy_net_pct'] / (s['fwd_ret_t1_entry'] * 100) for s in pos):.2f}"
                f" (n={len(pos)})") if pos else ""
        print(f"    方向一致率={same_dir}/{len(dual)} ({same_dir/len(dual)*100:.0f}%){tail}")

    # ── ⑦ 影子变体反事实 (2026-08-27): "peak后回撤X%" 变体出场价 ──
    # 变体恒比生产更紧 → 触发点必在实盘退出前, 反事实可观测;
    # 未触发的笔 = 实盘先退出, 变体跟随实盘价 (不计入变体均值, 只计触发子集).
    var_names = {}
    for s in samples:
        for vn in (s.get("shadow_variants") or {}):
            var_names[vn] = var_names.get(vn, 0) + 1
    if var_names:
        print(f"  -- ⑦ 影子变体反事实出场 (gross%, 仅统计已触发笔; 未触发=跟随实盘) --")
        for vn in sorted(var_names, key=lambda x: -var_names[x]):
            triggered = [s["shadow_variants"][vn]["profit_pct"]
                         for s in samples if vn in (s.get("shadow_variants") or {})]
            if not triggered:
                continue
            print(f"    {vn:28s} 覆盖{var_names[vn]:3d}笔 触发{len(triggered):3d}笔 "
                  f"触发均值={sum(triggered)/len(triggered):+.3f}%")

    # 双窗: PASS vs BLOCK 差值
    if n >= MIN_N_REPORT:
        have.sort(key=lambda s: s["trade_date"])
        half = len(have) // 2
        diffs = []
        for seg in (have[:half], have[half:]):
            p = _stat([s for s in seg if s["gate_decision"] == "PASS"], "fwd_ret_t1")
            b = _stat([s for s in seg if s["gate_decision"] == "BLOCK"], "fwd_ret_t1")
            if p and b:
                diffs.append(round(p["mean"] - b["mean"], 3))
        if len(diffs) == 2:
            same = (diffs[0] > 0) == (diffs[1] > 0)
            cand = same and min(abs(d) for d in diffs) >= 15.0
            print(f"  [双窗] PASS-BLOCK差值: 前{diffs[0]:+.3f}% 后{diffs[1]:+.3f}% "
                  f"{'同向✅' if same else '反向❌'} {'|差|≥15pp达候选门槛' if cand else '(未达)'}")


if __name__ == "__main__":
    collect()
