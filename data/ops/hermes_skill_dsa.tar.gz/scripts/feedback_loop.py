#!/usr/bin/env python3
"""
Feedback Loop — 盘后自动复盘 + 策略记忆更新
=============================================
每个交易日收盘后自动运行：
  1. 扫描当日已平仓交易
  2. 逐笔更新strategy_memory
  3. 提取当日赢/亏pattern教训
  4. 写入lesson_log
  5. 生成复盘报告

数据流:
  trade_records(当日) → update_from_trade() → strategy_memory.db
                     → extract_lessons() → lesson_log
                     → format_report() → 飞书推送

调用方式:
  python feedback_loop.py                    # 当日复盘
  python feedback_loop.py --date 2026-07-02  # 指定日期
  python feedback_loop.py --backfill 7       # 回填最近7天
"""

import sqlite3
import json
import os
import sys
from datetime import datetime, timedelta, date
from typing import Dict, List, Optional, Any

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import config
import strategy_memory

# ET时区 — 2026-08-26 审计修复: _get_et_today / run_backfill 两处原按月份近似DST
# (3-11月视为EDT/UTC-4), 在3月第2个周日之前、11月第1个周日之后错位1小时,
# 导致复盘日期与 trade_records.trade_date 错位。改为真实时区, 全文件统一复用本定义:
# zoneinfo为主(stdlib, 实测venv与系统python3均可用), pytz兜底(仅venv安装)。
try:
    from zoneinfo import ZoneInfo
    ET_TZ = ZoneInfo("America/New_York")
except Exception:  # pragma: no cover - 兜底路径
    from pytz import timezone as _tz
    ET_TZ = _tz("America/New_York")


_NET_EXIT = os.environ.get("DA_FEEDBACK_NET_EXIT", "1") != "0"


def _get_ftseek_conn():
    return sqlite3.connect(config.FTSEEK_DB, timeout=5)


def _get_et_today() -> str:
    """返回ET时区的今天日期(YYYY-MM-DD)。
    
    与FTSeek的trade_records.trade_date对齐——该字段用ET日期。
    CST 5:00 = ET 17:00同一天，但如果cron时间偏移或非交易日跑，
    用ET时区确保日期一致。
    """
    # 2026-08-26 审计修复: month-based DST 近似 → 真实时区 ET_TZ (见文件头定义)
    et_now = datetime.now(ET_TZ)
    return et_now.strftime("%Y-%m-%d")


def _get_today_trades(target_date: str = None) -> List[Dict]:
    """获取指定日期的已平仓交易"""
    if target_date is None:
        target_date = _get_et_today()

    conn = _get_ftseek_conn()
    conn.row_factory = sqlite3.Row
    # 2026-10-23: 日报按**退出日**归属, 不是入场日. 旧写法 trade_date=?
    # 会漏掉隔夜仓 (D 入场 / D+1 平仓), 10-22 实测漏 4 笔、含当日唯一亏损.
    if not _NET_EXIT:
        # 回滚: DA_FEEDBACK_NET_EXIT=0 → 旧口径 (入场日 + 毛额)
        rows = conn.execute("""
            SELECT trade_date, symbol, direction, entry_price, exit_price,
                   realized_pnl, pnl_pct, exit_reason, holding_hours,
                   signal_strength, signal_confidence, strategy_id, source_type,
                   entry_reason, factor_detail
            FROM trade_records
            WHERE trade_date = ? AND realized_pnl IS NOT NULL
              AND strategy_id NOT IN ('manual','manual_sync','reconciler','futu_sync','broker_reconcile')
              AND source_type NOT IN ('SCALPING','ORB_ENGINE','PLAYBOOK_SHADOW','MAIN_PIPELINE')
            ORDER BY realized_pnl DESC
        """, (target_date,)).fetchall()
    else:
        rows = conn.execute("""
            SELECT trade_date, exit_time, symbol, direction, entry_price, exit_price,
                   realized_pnl, pnl_net, pnl_pct, exit_reason, holding_hours,
                   signal_strength, signal_confidence, strategy_id, source_type,
                   entry_reason, factor_detail
            FROM trade_records
            WHERE ((exit_time IS NOT NULL AND date(exit_time) = ?)
                   OR (exit_time IS NULL AND trade_date = ? AND exit_price IS NOT NULL))
              AND realized_pnl IS NOT NULL
              AND strategy_id NOT IN ('manual','manual_sync','reconciler','futu_sync','broker_reconcile')
              AND source_type NOT IN ('SCALPING','ORB_ENGINE','PLAYBOOK_SHADOW','MAIN_PIPELINE')
            ORDER BY COALESCE(pnl_net, realized_pnl) DESC
        """, (target_date, target_date)).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def _pnl(t: Dict) -> float:
    """净额优先; 缺 pnl_net 时才回退 realized_pnl. 回滚=DA_FEEDBACK_NET_EXIT=0."""
    v = t.get("pnl_net") if _NET_EXIT else None
    if v is None:
        v = t.get("realized_pnl")
    try:
        return float(v or 0)
    except (TypeError, ValueError):
        return 0.0


def update_memory_from_trades(trades: List[Dict]) -> int:
    """全量重建 strategy_memory (幂等)。

    根因修复 (2026-07-18): 原实现逐笔 update_from_trade() 是非幂等增量 +1,
    backfill/重跑会重复累计 (历史实测虚高约 3 倍) 且旧亏损单漏记。改为每次
    从 trade_records 全量重建, strategy_memory 恒为真源投影, 反复跑结果不变。
    入参 trades 保留仅为兼容旧调用签名, 实际以 DB 全量为准。
    """
    stats = strategy_memory.rebuild_from_trade_records()
    return stats.get("trades", 0)


def extract_lessons(trades: List[Dict], target_date: str) -> List[Dict]:
    """从当日交易中提取教训

    自动识别:
    - win_pattern: 赚钱的setup特征
    - loss_pattern: 亏钱的setup特征
    - symbol_insight: 个股级洞察
    - market_regime: 市场环境特征
    """
    lessons = []
    if not trades:
        return lessons

    wins = [t for t in trades if _pnl(t) > 0]
    losses = [t for t in trades if _pnl(t) < 0]
    total_pnl = sum(_pnl(t) for t in trades)

    # ── 赢钱pattern ──
    if wins:
        # 找最大盈利交易的特征
        best_win = max(wins, key=lambda x: _pnl(x))
        win_direction = best_win["direction"]
        win_reason = best_win["exit_reason"]
        win_hold = best_win.get("holding_hours", 0) or 0
        win_pnl = _pnl(best_win)

        lessons.append({
            "date": target_date,
            "type": "win_pattern",
            "content": f"{win_direction}+{win_reason} 净赚${win_pnl:.0f} "
                       f"持{win_hold:.1f}h {best_win['symbol']}",
            "evidence": json.dumps({
                "symbol": best_win["symbol"],
                "direction": win_direction,
                "exit_reason": win_reason,
                "pnl": win_pnl,
                "hold_hours": win_hold,
            }),
            "impact": "high" if win_pnl > 100 else "medium",
        })

        # 2026-10-23: "全胜"必须以该方向**完整母体**为分母; 旧写法只看 wins,
        # 同向有亏损时仍写"全胜" (10-22 实测 7胜0负 实为 10胜1负).
        win_dirs = [t["direction"] for t in wins]
        if len(win_dirs) >= 1 and len(set(win_dirs)) == 1:
            _dir = win_dirs[0]
            _dir_all = [t for t in trades if t["direction"] == _dir]
            _dir_wins = [t for t in _dir_all if _pnl(t) > 0]
            _dir_pnl = sum(_pnl(t) for t in _dir_all)
            if len(_dir_all) >= 2:
                _label = "全胜" if len(_dir_wins) == len(_dir_all) else \
                    f"{len(_dir_wins)}胜{len(_dir_all) - len(_dir_wins)}负"
                lessons.append({
                    "date": target_date,
                    "type": "win_pattern",
                    "content": f"当日{len(_dir_all)}笔{_dir} {_label} "
                               f"净PnL=${_dir_pnl:.0f}",
                    "evidence": json.dumps({
                        "count": len(_dir_all),
                        "wins": len(_dir_wins),
                        "direction": _dir,
                        "total_pnl": _dir_pnl,
                        "symbols": [t["symbol"] for t in _dir_all],
                    }),
                    "impact": "high",
                })

    # ── 亏钱pattern ──
    if losses:
        worst_loss = min(losses, key=lambda x: _pnl(x))
        loss_direction = worst_loss["direction"]
        loss_reason = worst_loss["exit_reason"]
        loss_hold = worst_loss.get("holding_hours", 0) or 0
        loss_pnl = _pnl(worst_loss)

        lessons.append({
            "date": target_date,
            "type": "loss_pattern",
            "content": f"{loss_direction}+{loss_reason} 净亏${loss_pnl:.0f} "
                       f"持{loss_hold:.1f}h {worst_loss['symbol']}",
            "evidence": json.dumps({
                "symbol": worst_loss["symbol"],
                "direction": loss_direction,
                "exit_reason": loss_reason,
                "pnl": loss_pnl,
                "hold_hours": loss_hold,
            }),
            "impact": "high" if abs(loss_pnl) > 100 else "medium",
        })

        # 止损被打是最常见的亏损
        sl_hits = [t for t in losses if "sl_hit" in (t.get("exit_reason") or "").lower()
                   or "SL_ATR" in (t.get("exit_reason") or "")
                   or "BREAKEVEN_STOP" in (t.get("exit_reason") or "")]
        if len(sl_hits) >= 2:
            lessons.append({
                "date": target_date,
                "type": "loss_pattern",
                "content": f"当日{len(sl_hits)}笔被止损打 "
                           f"净亏${sum(_pnl(t) for t in sl_hits):.0f} "
                           f"可能入场时机偏早或止损偏紧",
                "evidence": json.dumps({
                    "count": len(sl_hits),
                    "total_pnl": sum(_pnl(t) for t in sl_hits),
                    "symbols": [t["symbol"] for t in sl_hits],
                }),
                "impact": "high",
            })

    # ── 个股洞察 ──
    symbol_pnl = {}
    for t in trades:
        sym = t["symbol"]
        if sym not in symbol_pnl:
            symbol_pnl[sym] = {"pnl": 0, "trades": 0, "wins": 0}
        symbol_pnl[sym]["pnl"] += _pnl(t)
        symbol_pnl[sym]["trades"] += 1
        if _pnl(t) > 0:
            symbol_pnl[sym]["wins"] += 1

    # 连续亏损的个股
    for sym, d in symbol_pnl.items():
        if d["trades"] >= 2 and d["wins"] == 0:
            lessons.append({
                "date": target_date,
                "type": "symbol_insight",
                "content": f"{sym} 当日{d['trades']}笔全亏 PnL=${d['pnl']:.0f} "
                           f"该股当前setup不利，后续需谨慎",
                "evidence": json.dumps({"symbol": sym, **d}),
                "impact": "medium",
            })

    # ── 市场环境 ──
    if total_pnl > 0 and len(wins) > len(losses):
        lessons.append({
            "date": target_date,
            "type": "market_regime",
            "content": f"当日整体净盈利${total_pnl:.0f} "
                       f"{len(wins)}胜{len(losses)}负，市场环境有利于当前策略",
            "evidence": json.dumps({
                "total_pnl": total_pnl,
                "wins": len(wins),
                "losses": len(losses),
            }),
            "impact": "low",
        })
    elif total_pnl < 0 and len(losses) > len(wins):
        lessons.append({
            "date": target_date,
            "type": "market_regime",
            "content": f"当日整体净亏损${total_pnl:.0f} "
                       f"{len(wins)}胜{len(losses)}负，市场环境不利，"
                       f"明日考虑降低仓位或偏向{('SHORT' if sum(1 for t in losses if t['direction']=='LONG') > sum(1 for t in losses if t['direction']=='SHORT') else 'LONG')}",
            "evidence": json.dumps({
                "total_pnl": total_pnl,
                "wins": len(wins),
                "losses": len(losses),
            }),
            "impact": "high",
        })

    return lessons


def save_lessons(lessons: List[Dict]):
    """保存教训到lesson_log"""
    for l in lessons:
        strategy_memory.add_lesson(
            date=l["date"],
            lesson_type=l["type"],
            content=l["content"],
            evidence=l.get("evidence", ""),
            impact=l.get("impact", "medium"),
        )


def format_daily_report(trades: List[Dict], lessons: List[Dict],
                        target_date: str) -> str:
    """生成每日复盘报告（飞书Markdown）"""
    if not trades:
        return f"📊 {target_date} 复盘\n\n无交易记录"

    wins = [t for t in trades if _pnl(t) > 0]
    losses = [t for t in trades if _pnl(t) < 0]
    total_pnl = sum(_pnl(t) for t in trades)
    wr = len(wins) / len(trades) * 100 if trades else 0

    lines = [
        f"📊 {target_date} 盘后复盘",
        f"交易: {len(trades)}笔 | {len(wins)}胜{len(losses)}负 | WR={wr:.0f}%",
        f"总净P&L: ${total_pnl:.2f}",
        "",
    ]

    # 赢的
    if wins:
        lines.append("🟢 盈利交易:")
        for t in wins[:5]:
            hold = t.get("holding_hours", 0) or 0
            lines.append(
                f"  {t['symbol']} {t['direction']} "
                f"+${_pnl(t):.0f} "
                f"reason={t['exit_reason']} "
                f"hold={hold:.1f}h"
            )

    # 亏的
    if losses:
        lines.append("\n🔴 亏损交易:")
        for t in losses[:5]:
            hold = t.get("holding_hours", 0) or 0
            lines.append(
                f"  {t['symbol']} {t['direction']} "
                f"${_pnl(t):.0f} "
                f"reason={t['exit_reason']} "
                f"hold={hold:.1f}h"
            )

    # 教训
    if lessons:
        lines.append("\n📝 策略教训:")
        for l in lessons:
            emoji = "💡" if l["type"] == "win_pattern" else "⚠️" if l["type"] == "loss_pattern" else "🔍"
            lines.append(f"  {emoji} [{l['impact']}] {l['content']}")

    # memory摘要
    mem = strategy_memory.get_memory_summary()
    lines.append(f"\n🧠 策略记忆库: {mem['pattern_count']}个pattern "
                 f"{mem['symbol_count']}只股票 "
                 f"{mem['lesson_count']}条教训")

    if mem.get("top_win_patterns"):
        tw = mem["top_win_patterns"][0]
        lines.append(f"  最赚pattern: {tw['direction']}+{tw['exit_reason']} "
                     f"WR={tw['win_rate']*100:.0f}% PnL=${tw['total_pnl']:.0f}")

    if mem.get("top_loss_patterns"):
        tl = mem["top_loss_patterns"][0]
        lines.append(f"  最亏pattern: {tl['direction']}+{tl['exit_reason']} "
                     f"PnL=${tl['total_pnl']:.0f}")

    return "\n".join(lines)


def run_backfill(days: int = 7) -> Dict:
    """回填最近N天的交易到strategy_memory"""
    stats = {"days_processed": 0, "trades_processed": 0, "lessons_extracted": 0}
    all_trades = []

    # 用ET时区计算起始日期，与trade_records.trade_date对齐
    # 2026-08-26 审计修复: month-based DST 近似 → 真实时区 ET_TZ (见文件头定义)
    et_now = datetime.now(ET_TZ)

    for i in range(days):
        target = (et_now - timedelta(days=i)).strftime("%Y-%m-%d")
        trades = _get_today_trades(target)
        if not trades:
            continue

        update_memory_from_trades(trades)
        lessons = extract_lessons(trades, target)
        save_lessons(lessons)

        stats["days_processed"] += 1
        stats["trades_processed"] += len(trades)
        stats["lessons_extracted"] += len(lessons)
        all_trades.extend(trades)

    # v0.23: 用回填的全部交易生成exit_param_override
    if all_trades:
        pass  # [stopped 2026-07-11 measurement-first] _write_exit_param_override(all_trades) 退役

    return stats


def _get_all_closed_trades() -> List[Dict]:
    """获取全部已平仓交易，用于exit_param_override的全样本分析."""
    conn = _get_ftseek_conn()
    conn.row_factory = sqlite3.Row
    rows = conn.execute("""
        SELECT trade_date, symbol, direction, entry_price, exit_price,
               realized_pnl, pnl_pct, exit_reason, holding_hours,
               signal_strength, signal_confidence, strategy_id, source_type,
               entry_reason, factor_detail
        FROM trade_records
        WHERE realized_pnl IS NOT NULL
          AND strategy_id NOT IN ('manual','manual_sync','reconciler','futu_sync','broker_reconcile')
          AND source_type NOT IN ('SCALPING','ORB_ENGINE','PLAYBOOK_SHADOW','MAIN_PIPELINE')
        ORDER BY trade_date DESC
    """).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def _write_exit_param_override(trades: List[Dict]):
    """根据持续亏损pattern写exit_param_override.json, 供FTSeek调整退出参数.

    只对样本≥10且PnL持续为负的pattern生成override, 避免小样本过拟合.
    FTSeek pipeline启动时读此文件, 覆盖factor_exit_rules对应字段.
    """
    from collections import defaultdict
    import os as _os

    # 按direction+exit_reason分组统计
    pattern_stats = defaultdict(lambda: {"count": 0, "wins": 0, "pnl": 0.0, "hold_hours": []})
    for t in trades:
        key = f"{t.get('direction', '')}+{t.get('exit_reason', '')}"
        s = pattern_stats[key]
        s["count"] += 1
        s["pnl"] += t.get("realized_pnl", 0) or 0
        if (t.get("realized_pnl", 0) or 0) > 0:
            s["wins"] += 1
        hold = t.get("holding_hours", 0) or 0
        if hold:
            s["hold_hours"].append(hold)

    overrides = {}
    for key, s in pattern_stats.items():
        if s["count"] < 10:
            continue  # 样本不足
        wr = s["wins"] / s["count"]
        if s["pnl"] < 0 and wr < 0.45:
            # 持续亏损pattern: 放宽time_exit + 关闭trailing
            avg_hold = sum(s["hold_hours"]) / len(s["hold_hours"]) if s["hold_hours"] else 4.0
            overrides[key] = {
                "count": s["count"],
                "win_rate": round(wr, 3),
                "pnl": round(s["pnl"], 2),
                "avg_hold_hours": round(avg_hold, 1),
                # override建议
                "time_exit_hours": min(avg_hold * 1.5, 8.0),  # 放宽50%
                "trailing_enabled": False,  # 亏损pattern不适合trailing
                "breakeven_at_pct": 2.0,  # 提高保本阈值
            }

    out_path = "/opt/ftseek/FTSeek-US/data/exit_param_override.json"
    out_data = {
        "generated_at": _get_et_today(),
        "total_patterns_analyzed": len(pattern_stats),
        "overrides_count": len(overrides),
        "overrides": overrides,
    }
    try:
        with open(out_path, "w") as f:
            json.dump(out_data, f, ensure_ascii=False, indent=2)
        print(f"[FeedbackLoop] exit_param_override.json: {len(overrides)}个亏损pattern override")
    except Exception as e:
        print(f"[FeedbackLoop] exit_param_override写入失败: {e}")


def run_daily(target_date: str = None) -> str:
    """执行当日复盘，返回报告文本"""
    if target_date is None:
        target_date = _get_et_today()  # 用ET时区而非CST

    trades = _get_today_trades(target_date)

    # v0.23: 写exit_param_override.json (持续亏损pattern→FTSeek退出参数调整)
    # 2026-07-09: 用全部历史交易而非只当天，避免小样本无法达到≥10阈值
    # 2026-07-09: 移到early return之前，即使当天无交易也更新override (P0修复)
    all_trades = _get_all_closed_trades()
    # [stopped 2026-07-11 measurement-first] _write_exit_param_override(all_trades) 退役

    if not trades:
        return f"📊 {target_date} 复盘\n\n无交易记录"

    update_memory_from_trades(trades)
    lessons = extract_lessons(trades, target_date)
    save_lessons(lessons)

    return format_daily_report(trades, lessons, target_date)


def main():
    import argparse
    parser = argparse.ArgumentParser(description="Feedback Loop")
    parser.add_argument("--date", help="指定日期(YYYY-MM-DD)")
    parser.add_argument("--backfill", type=int, help="回填最近N天")
    parser.add_argument("--json", action="store_true", help="JSON输出")
    args = parser.parse_args()

    if args.backfill:
        stats = run_backfill(args.backfill)
        if args.json:
            print(json.dumps(stats, ensure_ascii=False))
        else:
            print(f"回填完成: {stats['days_processed']}天 "
                  f"{stats['trades_processed']}笔交易 "
                  f"{stats['lessons_extracted']}条教训")
    else:
        report = run_daily(args.date)
        print(report)


if __name__ == "__main__":
    main()
