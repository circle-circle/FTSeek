#!/usr/bin/env python3
"""
IC Writer — 把 deep_analysis 信号写入 FTSeek 的 signal_snapshots.db
==============================================================
直接写入 SQLite，不调 FTSeek 运行代码，不需要重启服务。
FTSeek 的 backfill_forward_returns.py cron 会自动回填 T1/T5/T20 收益。
"""

import sqlite3
import json
import time
import os
import sys
from datetime import datetime, timezone, timedelta
from typing import Dict, Any, Optional, List

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import config

# ET时区定义 — 与FTSeek的app.utils.timezone.get_trade_date()一致
# 2026-08-26 审计修复: 原实现按月份近似DST(3-11月视为EDT/UTC-4), 在3月第2个周日
# 之前、11月第1个周日之后会错位1小时, 跨午夜时段可能算错trade_date。
# 改为真实时区: zoneinfo为主(stdlib, 实测venv与系统python3均可用), pytz兜底(仅venv安装)。
try:
    from zoneinfo import ZoneInfo
    _ET_TZ = ZoneInfo("America/New_York")
except Exception:  # pragma: no cover - 兜底路径
    from pytz import timezone as _tz
    _ET_TZ = _tz("America/New_York")


def _get_et_trade_date() -> str:
    """返回最近的ET交易日日期(YYYY-MM-DD)。

    根因修复1 (v0.12): 原代码用datetime.now()(CST)生成trade_date，
    CST比ET快12-13小时，导致日期错位。

    根因修复2 (v0.12): 原代码返回当前ET日期，但周末/假日运行时
    trade_date=非交易日（如周六/周日），FTSeek backfill
    找不到该日的日K线→IC永远不回填。

    根因修复3 (2026-09-07, SKILL.md pitfall -6 / handoff「下一步」0-假日):
    **修复2 的假日表本身是漏的** —— 原实现自带 6 条硬编码 `known_holidays`
    `(7,3)(7,4)(12,25)(1,1)(11,26)(11,27)`，**不含劳动节**，也不含 MLK /
    总统日 / 耶稣受难日 / 阵亡将士日 / 六月节。而仓内本有 SSOT
    `app/utils/holiday_calendar.py`(Futu `request_trading_days` 权威 +
    2026-2028 硬编码降级 + 周末兜底)，DA 侧零引用 → 平行真源必然漂移。
    实测: 2026-09-07(劳动节, 周一) 原实现返回 `2026-09-07`(非交易日)
    → 该批 snapshot 的 close_t0/t1 恒 NULL → 静默永久退出 IC 样本。

    现改为委托 `trading_calendar.latest_trading_day()`(三层降级:
    FTSeek SSOT → NYSE 规则现算 → legacy 6 条表)，并把"周末前推"与
    "假日前推"两套分叉逻辑合并成单一循环(周末与假日同口径判定)。
    **legacy 表逐字保留在 trading_calendar._LEGACY_KNOWN_HOLIDAYS**，
    作为上层全灭时的兜底，不删(删了就失去"不改变既有行为"的退路)。

    口径变更影响面(数据口径七律: 新旧基线须切分): **历史 0 条**。
    实测 `signal_snapshots` 中落在美股假日的行仅 5 条 `voting_llm`@2026-07-03
    (FTSeek 侧路径)，**DA 零条** —— DA 7/9 上线至 2026-09-06 区间美股假日为
    零个(7/3 在上线前，下一个即 9/7) ⇒ 本修复不追溯改写任何既有 trade_date，
    无需基线切分。首个受影响日 = 2026-09-07。

    回滚: 恢复本函数原实现(见 git 历史 / SKILL.md pitfall -6)。
    """
    et_now = datetime.now(_ET_TZ)
    try:
        import trading_calendar
        d, layer = trading_calendar.latest_trading_day(et_now.date())
        if layer in ("fail-open", "exhausted"):
            # 三层日历全灭 = 异常状态，留痕但不阻塞(与 fail-open 语义一致)
            print(f"[ic_writer] ⚠️ 交易日历三层全灭(layer={layer}), "
                  f"trade_date 按 ET 当日 {et_now.date()} 兜底", file=sys.stderr)
            return et_now.strftime("%Y-%m-%d")
        return d.strftime("%Y-%m-%d")
    except Exception as e:  # 日历模块本身不可用 → 退回纯周末前推(不改既有语义)
        print(f"[ic_writer] ⚠️ trading_calendar 不可用({e}), 退回周末前推兜底",
              file=sys.stderr)
        weekday = et_now.weekday()
        if weekday == 5:      # Sat → Fri
            et_now = et_now - timedelta(days=1)
        elif weekday == 6:    # Sun → Fri
            et_now = et_now - timedelta(days=2)
        return et_now.strftime("%Y-%m-%d")


def _get_et_now_iso() -> str:
    """返回ET时区的ISO格式时间戳"""
    return datetime.now(_ET_TZ).isoformat()


def _classify_claim(thesis: str, source_type: str, evidence: str = "") -> str:
    """从论点文本推断claim_type（泛化分类，适用于任何股票）。

    分类规则按优先级匹配，先命中先返回。
    """
    text = (thesis + " " + evidence).lower()

    # 内部人交易
    if any(k in text for k in ["mspr", "净卖出", "净买入", "高管减持", "高管增持",
                                "insider", "套现", "内部人"]):
        if any(k in text for k in ["卖出", "减持", "套现", "net_sell", "bearish", "negat"]):
            return "insider_bearish"
        return "insider_bullish"

    # 估值
    if any(k in text for k in ["pe", "pb", "估值", "valuation"]):
        if any(k in text for k in ["低于", "below", "便宜", "cheap", "低估"]):
            return "valuation_cheap"
        if any(k in text for k in ["高于", "above", "贵", "expensive", "高估"]):
            return "valuation_expensive"

    # 财报/盈利
    if any(k in text for k in ["营收", "eps", "利润", "beat", "超预期", "revenue",
                                "earnings", "roe", "净利率", "增长"]):
        return "earnings_beat"

    # 产品/合约/IPO等公司独有事件
    if any(k in text for k in ["合约", "订单", "ipo", "分拆", "产品", "发布",
                                "批准", "fda", "管理层", "ceo", "cfo", "诉讼",
                                "contract", "deal", "partnership", "launch"]):
        return "product_catalyst"

    # 情绪拥挤
    if any(k in text for k in ["散户", "一边倒", "拥挤", "crowded", "retail"]):
        return "sentiment_crowded"

    # 宏观
    if any(k in text for k in ["降息", "加息", "fomc", "cpi", "利率", "rate",
                                "板块", "sector", "轮动", "rotation"]):
        if any(k in text for k in ["降息", "顺风", "tailwind", "利好"]):
            return "macro_tailwind"
        return "macro_headwind"

    # 技术面
    if any(k in text for k in ["突破", "金叉", "站上", "上方", "放量", "breakout",
                                "cross", "above"]):
        return "technical_breakout"
    if any(k in text for k in ["破位", "死叉", "跌破", "下方", "breakdown", "below"]):
        return "technical_breakdown"

    # 默认：按source_type兜底
    return f"unclassified_{source_type}" if source_type else "unclassified"


def _extract_claim_factors(llm_out: Dict[str, Any]) -> List[Dict]:
    """从LLM输出提取结构化论据claim对象。

    每个claim: {"thesis", "source_type", "claim_type", "strength", "side": "bull"/"bear"}

    优先用LLM直接标注的claim_type（更准确），fallback到关键词推断。
    用于论据级IC：T+N后回溯，哪个claim_type出现时信号预测力最强/最弱。
    """
    factors = []
    seen_claim_types = set()  # 同一claim_type去重，避免重复论据扭曲IC权重

    for side, case_key in [("bull", "bull_case"), ("bear", "bear_case")]:
        for r in llm_out.get(case_key, [])[:5]:
            thesis = r.get("thesis", "")
            source_type = r.get("source_type", "")
            evidence = r.get("evidence", "")
            strength = r.get("strength", "MEDIUM")

            # 优先用LLM标注的claim_type，没有才用关键词推断
            claim_type = r.get("claim_type")
            if not claim_type or claim_type not in _VALID_CLAIM_TYPES:
                claim_type = _classify_claim(thesis, source_type, evidence)

            # 去重：同side下同一claim_type只保留第一条（strength最高的优先）
            dedup_key = (side, claim_type)
            if dedup_key in seen_claim_types:
                continue
            seen_claim_types.add(dedup_key)

            factors.append({
                "thesis": thesis[:200],  # 截断防止factors_json过大
                "source_type": source_type,
                "claim_type": claim_type,
                "strength": strength,
                "side": side,
                "llm_labeled": r.get("claim_type") is not None,  # 标注来源
            })

    return factors


# 合法claim_type枚举 (与prompt中给LLM的枚举一致)
_VALID_CLAIM_TYPES = {
    "product_catalyst", "earnings_beat",
    "valuation_cheap", "valuation_expensive",
    "insider_bearish", "insider_bullish",
    "technical_breakout", "technical_breakdown",
    "sentiment_crowded",
    "macro_tailwind", "macro_headwind",
    "unclassified",
}


def write_signal_snapshot(analysis: Dict[str, Any]) -> Optional[str]:
    """
    把 deep_analysis 结果写入 FTSeek signal_snapshots.db。
    FTSeek 的 cron backfill_forward_returns.py 会自动回填前瞻收益。

    Returns: decision_id 或 None(失败)
    """
    db_path = config.FTSEEK_DB.replace("ftseek_us.db", "signal_snapshots.db")
    if not os.path.exists(db_path) and not os.environ.get("FTSEEK_DB"):
        # 信号DB路径不在默认位置，尝试直接路径
        # (2026-08-03 A/B隔离: 显式 FTSEEK_DB 覆盖时禁用生产回退, 防测试写穿到生产)
        db_path = "/opt/ftseek/FTSeek-US/data/signal_snapshots.db"

    score = float(analysis.get("score", 5.0))
    direction = analysis.get("action", "SKIP")

    # 映射方向
    if direction == "BUY":
        dir_str = "LONG"
    elif direction == "SELL_SHORT":
        dir_str = "SHORT"
    else:
        dir_str = "NEUTRAL"

    # 生成 decision_id (FTSeek 格式: DEC-YYYYMMDDHHMMSS-SYMBOL-xxxx)
    now = datetime.now()
    decision_id = f"DA-{now.strftime('%Y%m%d%H%M%S')}-{analysis.get('symbol','')}-{int(time.time())%0xffff:04x}"

    # 信号时刻价格
    snap = analysis.get("snapshot", {})
    price = snap.get("price", 0) or snap.get("last_price", 0)

    # 交易日 (ET) — 根因修复: 用ET日期而非CST, 与FTSeek backfill对齐
    trade_date = _get_et_trade_date()

    # factors (论据级IC) — 结构化claim对象，支持claim_type归因
    # 格式: [{"thesis": "...", "source_type": "news", "claim_type": "product_catalyst", "strength": "HIGH"}, ...]
    # claim_type分类（泛化到全市场任何股票）:
    #   product_catalyst: 产品/合约/IPO/管理层变动等公司独有事件
    #   earnings_beat:    营收/EPS/利润率超预期或高增长
    #   valuation_cheap:  PE/PB低于行业中枢
    #   valuation_expensive: PE/PB高于行业中枢
    #   insider_bearish:  MSPR净卖出/高管减持
    #   insider_bullish:  MSPR净买入/高管增持
    #   technical_breakout: 突破/金叉/站上均线
    #   technical_breakdown: 破位/死叉/跌破均线
    #   sentiment_crowded: 散户一边倒（反向警示）
    #   macro_tailwind:   降息/政策/板块轮动顺风
    #   macro_headwind:   加息/政策/板块轮动逆风
    llm_out = analysis.get("_llm_output", {})
    factors = _extract_claim_factors(llm_out)

    # v0.23: 把strategy_type/position_size_hint/conditions/signal_scores编码到factors_json
    # FTSeek门禁(627)查询时能读到这些字段, 用于退出策略选择和仓位调整
    # 2026-07-10: 补 debate_outcome + gate 字段, 让 alpha_backfill 能按辩论一致度/质量分
    # 分组计算 IC — 量化"哪种信号有效", 而不是只看全局 IC(被噪声稀释)。
    factors_enriched = {
        "claims": factors,
        "strategy_type": analysis.get("strategy_type", ""),
        "position_size_hint": analysis.get("position_size_hint", ""),
        "bucket_reason": analysis.get("bucket_reason", ""),
        "signal_scores": analysis.get("signal_scores", {}),
        "debate_outcome": llm_out.get("debate_outcome", ""),
        "gate_decision": (analysis.get("_signal_gate") or {}).get("decision", ""),
        "quality_score": (analysis.get("_signal_gate") or {}).get("quality_score", 0),
        "ue_origin": bool(analysis.get("_ue_origin")),
        "ue_direction": analysis.get("_ue_direction", ""),
        "ue_confidence": analysis.get("_ue_confidence"),
        "ue_scanned_at": analysis.get("_ue_scanned_at", ""),
    }
    # 也把adapter映射的conditions编码进去(方向一致的合法枚举)
    try:
        import adapter
        conditions = adapter._map_conditions(llm_out)
        if conditions:
            factors_enriched["conditions"] = conditions
    except Exception:
        pass

    factors_json = json.dumps(factors_enriched, ensure_ascii=False) if factors_enriched else None

    # strategy_id
    strategy_id = "deep_analysis"

    # 信号时间 — 用ET时区, 与FTSeek record_signal_snapshot一致
    created_at = _get_et_now_iso()

    try:
        conn = sqlite3.connect(db_path, timeout=5)
        # 2026-08-26 审计修复: 本脚本为外部进程, 按 SKILL.md 纪律不设 journal_mode (WAL 是持久化属性, 外部设置会干扰主进程可见性)
        conn.execute("PRAGMA synchronous=NORMAL")

        conn.execute("""
            INSERT OR IGNORE INTO signal_snapshots
            (decision_id, symbol, direction, strength, confidence,
             consensus_level, strategy_id, created_at, trade_date,
             price_at_signal, factors_json, created_at_snap,
             trade_mode, weight_version, realized)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0)
        """, (
            decision_id,
            analysis.get("symbol", ""),
            dir_str,
            int(score * 10),
            score / 10.0,
            score / 10.0,
            strategy_id,
            created_at,
            trade_date,
            price,
            factors_json,
            _get_et_now_iso(),  # created_at_snap — ET时区
            "simulate",       # trade_mode
            "v2",             # weight_version
        ))
        conn.commit()
        conn.close()

        print(f"[IC Writer] 写入 signal_snapshots: {decision_id} {dir_str} strength={int(score*10)}", file=sys.stderr)
        return decision_id

    except Exception as e:
        print(f"[IC Writer] 写入失败: {e}", file=sys.stderr)
        return None


def get_ic_summary(strategy_id: str = "deep_analysis") -> Dict:
    """读取 deep_analysis 信号的IC摘要（只读）— 含alpha IC和论据级IC"""
    db_path = "/opt/ftseek/FTSeek-US/data/signal_snapshots.db"
    if not os.path.exists(db_path):
        return {"error": "DB not found"}

    try:
        conn = sqlite3.connect(db_path, timeout=5)
        conn.row_factory = sqlite3.Row

        # 基础统计
        row = conn.execute("""
            SELECT COUNT(*) as total,
                   SUM(CASE WHEN fwd_ret_t1 IS NOT NULL THEN 1 ELSE 0 END) as t1_filled,
                   SUM(CASE WHEN fwd_ret_t5 IS NOT NULL THEN 1 ELSE 0 END) as t5_filled,
                   SUM(CASE WHEN fwd_ret_t20 IS NOT NULL THEN 1 ELSE 0 END) as t20_filled,
                   SUM(CASE WHEN alpha_t1 IS NOT NULL THEN 1 ELSE 0 END) as alpha_t1_filled,
                   SUM(CASE WHEN alpha_t5 IS NOT NULL THEN 1 ELSE 0 END) as alpha_t5_filled
            FROM signal_snapshots WHERE strategy_id = ?
        """, (strategy_id,)).fetchone()

        result = {
            "strategy_id": strategy_id,
            "total_signals": row["total"],
            "t1_filled": row["t1_filled"],
            "t5_filled": row["t5_filled"],
            "t20_filled": row["t20_filled"],
            "alpha_t1_filled": row["alpha_t1_filled"],
            "alpha_t5_filled": row["alpha_t5_filled"],
        }

        # 方向分布 — 含alpha
        rows = conn.execute("""
            SELECT direction, COUNT(*) as cnt,
                   AVG(CASE WHEN fwd_ret_t5 IS NOT NULL THEN fwd_ret_t5 END) as avg_ret_t5,
                   AVG(CASE WHEN alpha_t5 IS NOT NULL THEN alpha_t5 END) as avg_alpha_t5,
                   AVG(CASE WHEN fwd_ret_t1 IS NOT NULL THEN fwd_ret_t1 END) as avg_ret_t1,
                   AVG(CASE WHEN alpha_t1 IS NOT NULL THEN alpha_t1 END) as avg_alpha_t1
            FROM signal_snapshots WHERE strategy_id = ?
            GROUP BY direction
        """, (strategy_id,)).fetchall()

        result["by_direction"] = {}
        for r in rows:
            result["by_direction"][r["direction"]] = {
                "count": r["cnt"],
                "avg_return_t1": round(r["avg_ret_t1"], 4) if r["avg_ret_t1"] is not None else None,
                "avg_alpha_t1": round(r["avg_alpha_t1"], 4) if r["avg_alpha_t1"] is not None else None,
                "avg_return_t5": round(r["avg_ret_t5"], 4) if r["avg_ret_t5"] is not None else None,
                "avg_alpha_t5": round(r["avg_alpha_t5"], 4) if r["avg_alpha_t5"] is not None else None,
            }

        # 论据级IC: 按 claim_type 分解
        claim_rows = conn.execute("""
            SELECT factors_json, strength, alpha_t1, alpha_t5, symbol
            FROM signal_snapshots
            WHERE strategy_id = ? AND factors_json IS NOT NULL AND alpha_t1 IS NOT NULL
        """, (strategy_id,)).fetchall()

        if claim_rows:
            import math
            from collections import defaultdict
            claim_data = defaultdict(lambda: {"confs": [], "alpha_t1": [], "alpha_t5": [], "symbols": set()})

            for cr in claim_rows:
                try:
                    factors = json.loads(cr["factors_json"]) if isinstance(cr["factors_json"], str) else cr["factors_json"]
                except (json.JSONDecodeError, TypeError):
                    continue

                if not isinstance(factors, list):
                    # v0.23: factors_json现在是dict with "claims" key
                    if isinstance(factors, dict) and "claims" in factors:
                        factors = factors["claims"]
                    else:
                        continue

                strength = cr["strength"] or 50
                seen = set()
                for f in factors:
                    ct = f.get("claim_type", "unclassified") if isinstance(f, dict) else str(f)
                    if ct in seen:
                        continue
                    seen.add(ct)
                    claim_data[ct]["confs"].append(strength)
                    claim_data[ct]["alpha_t1"].append(cr["alpha_t1"])
                    if cr["alpha_t5"] is not None:
                        claim_data[ct]["alpha_t5"].append(cr["alpha_t5"])
                    claim_data[ct]["symbols"].add(cr["symbol"])

            # 计算IC
            def _rank(vals):
                indexed = sorted(range(len(vals)), key=lambda i: vals[i])
                ranks = [0.0] * len(vals)
                i = 0
                while i < len(indexed):
                    j = i
                    while j + 1 < len(indexed) and vals[indexed[j+1]] == vals[indexed[i]]:
                        j += 1
                    avg_r = (i + 1 + j + 1) / 2.0
                    for k in range(i, j+1):
                        ranks[indexed[k]] = avg_r
                    i = j + 1
                return ranks

            def _spearman(x, y):
                if len(x) < 5:
                    return None
                xr = _rank(x)
                yr = _rank(y)
                n = len(x)
                mx, my = sum(xr)/n, sum(yr)/n
                cov = sum((a-mx)*(b-my) for a, b in zip(xr, yr))
                vx = sum((a-mx)**2 for a in xr)
                vy = sum((b-my)**2 for b in yr)
                if vx == 0 or vy == 0:
                    return None
                return round(cov / math.sqrt(vx * vy), 4)

            result["by_claim_type"] = {}
            for ct, data in claim_data.items():
                if len(data["confs"]) < 3:
                    continue
                ic = _spearman(data["confs"], data["alpha_t1"])
                avg_a = sum(data["alpha_t1"])/len(data["alpha_t1"]) if data["alpha_t1"] else None
                result["by_claim_type"][ct] = {
                    "count": len(data["confs"]),
                    "symbols": len(data["symbols"]),
                    "ic_t1_alpha": ic,
                    "avg_alpha_t1": round(avg_a, 4) if avg_a is not None else None,
                }

        conn.close()
        return result

    except Exception as e:
        return {"error": str(e)}


def main():
    import argparse
    parser = argparse.ArgumentParser(description="IC Writer")
    parser.add_argument("--action", choices=["write", "summary"], default="summary")
    parser.add_argument("--symbol", help="标的(write模式)")
    args = parser.parse_args()

    if args.action == "summary":
        result = get_ic_summary()
        print(json.dumps(result, ensure_ascii=False, indent=2))
    elif args.action == "write":
        # 从 stdin 读分析结果
        analysis = json.load(sys.stdin)
        did = write_signal_snapshot(analysis)
        if did:
            print(json.dumps({"success": True, "decision_id": did}))
        else:
            print(json.dumps({"success": False}))


if __name__ == "__main__":
    main()
