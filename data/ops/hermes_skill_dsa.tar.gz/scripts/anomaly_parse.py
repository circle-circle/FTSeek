# -*- coding: utf-8 -*-
"""异动 provider payload 解析 — 单一真源 (v0.87, 2026-09-26)。

病根: futu 异动 provider 返回
    {"err_code": int, "retMsg": str, "time_range": str, "content": str}
其中 content 是【文本块】(带 "[timestamp: N]" 或 "M.D HH:MM，" 前缀的中文异动描述),
不是 list。旧代码 (deep_analyzer._analyze_anomalies / llm_synth 渲染段) 一律当 list 用:
    adata = data.get("data", [])     # → dict
    has_anomaly = bool(adata)        # 非空 dict → 恒 True (即使 err_code=1「无异常」)
    count = len(adata) if isinstance(adata, list) else 0   # → 恒 0
    len(adata) 渲染成「N条异动」      # → dict 键数=4, 谎报
真实 content 从未被读取 → 2026-09 实测 474/642 payload (74%) 的有效异动文本被静默丢弃。

中立模块: 不 import deep_analyzer / llm_synth (deep_analyzer 会 import llm_synth,
反向即循环)。两处消费方各自 import 本模块 ⇒ 尺子唯一。

err_code 语义 (实测分布, 642 payload):
    0        有异动 (content 非空) 或 success
    1        「XX面异动无异常」 → content 空
    -12301   provider 错误 (content 空, retMsg 空)
不信任 retMsg 文本匹配, 以 err_code + content 非空为准 (缺数据不编数据)。
"""

import re
from typing import Any, Dict, List

# content 内的条目分隔符: 技术/资金面用 [timestamp: N], 衍生品用 "9.24 03:40，" 行首
_TS_BLOCK = re.compile(r"\[timestamp:\s*(\d{9,11})\]")
_DERIV_LINE = re.compile(r"^\s*(\d{1,2}\.\d{1,2}\s+\d{1,2}:\d{2})", re.M)

# 渲染预算: deriv content p90=7.6k / max=15.9k, 不可裸渲染 (prompt 膨胀 + 噪声)。
# 每维最多 N 条 × 每条 M 字; 超出显式标注「另有K条」, 不静默截断。
MAX_ITEMS = 6
MAX_ITEM_CHARS = 160


def parse_anomaly_payload(payload: Dict[str, Any]) -> Dict[str, Any]:
    """解析单个异动 provider payload → 统一结构。

    Returns:
        {"status": "ok"|"empty"|"error",
         "count": int,               # 真实异动条数 (content 解析)
         "items": [str],             # 逐条文本 (已截断至 MAX_ITEM_CHARS)
         "omitted": int,             # 因 MAX_ITEMS 未渲染的条数
         "time_range": str,
         "detail": str|None}         # status=error 时的原因
    """
    out = {"status": "empty", "count": 0, "items": [], "omitted": 0, "time_range": "", "detail": None}
    if not isinstance(payload, dict):
        out["status"] = "error"
        out["detail"] = f"payload not dict ({type(payload).__name__})"
        return out

    data = payload.get("data")
    if not isinstance(data, dict):
        # 容错: 某些路径 payload 本身就是 {err_code,...}
        data = payload if "err_code" in payload or "content" in payload else None
    if not isinstance(data, dict):
        out["status"] = "error"
        out["detail"] = "no dict payload['data']"
        return out

    out["time_range"] = str(data.get("time_range") or "")
    err_code = data.get("err_code")
    content = (data.get("content") or "").strip()

    if err_code == -12301 or (err_code not in (0, 1) and not content):
        out["status"] = "error"
        out["detail"] = f"provider err_code={err_code}"
        return out
    if not content:
        # err_code=1「无异常」/ err_code=0 但 content 空 → 如实报"无异动", 不谎报 has_anomaly
        out["status"] = "empty"
        out["count"] = 0
        return out

    items = _split_items(content)
    if not items:
        # content 有文本但切不出条目 → 整段作一条 (不丢数据)
        items = [content]
    out["count"] = len(items)
    out["status"] = "ok" if items else "empty"
    kept = items[:MAX_ITEMS]
    out["items"] = [_clip(x) for x in kept]
    out["omitted"] = max(0, len(items) - len(kept))
    return out


def _split_items(content: str) -> List[str]:
    """把 content 切成逐条异动文本。单遍逐行, 支持混合格式 (deriv 实测同时含
    「期权大单异动：」标题 + "9.24 03:40，…" 日期行 + "[timestamp: N]" 块):
    - 行首 [timestamp: N]  → 新条目, 前缀 [ts N]
    - 行首 M.D HH:MM        → 新条目 (期权大单逐笔)
    - 纯标题行 (「…异动：」) → 跳过 (非数据)
    - 其他非空行            → 追加到当前条目 (跨行描述)
    """
    items: List[str] = []
    cur: List[str] = []

    def _flush():
        if cur:
            txt = " ".join(x.strip() for x in cur if x.strip())
            if txt:
                items.append(txt)
            cur.clear()

    for raw in content.split("\n"):
        ln = raw.strip()
        if not ln:
            continue
        m_ts = _TS_BLOCK.match(ln)
        if m_ts:
            _flush()
            cur.append(f"[ts {m_ts.group(1)}]")
            rest = ln[m_ts.end():].strip()
            if rest:
                cur.append(rest)
            continue
        if _DERIV_LINE.match(ln):
            _flush()
            cur.append(ln)
            continue
        # 纯标题行 (以「：」/「:」结尾且不含数据) → 跳过
        if (ln.endswith("：") or ln.endswith(":")) and not _DERIV_LINE.match(ln) and "[timestamp" not in ln:
            continue
        cur.append(ln)
    _flush()
    return items


def _clip(text: str) -> str:
    text = " ".join(str(text).split())
    if len(text) > MAX_ITEM_CHARS:
        return text[:MAX_ITEM_CHARS] + "…"
    return text


def render_anomaly_section(collected: Dict[str, Any]) -> str:
    """渲染 prompt 的「异动信号」段 (llm_synth 用)。返回 "" 表示无段。

    契约: 无数据/无异常 → 不产段 (缺数据不编数据); provider 错误 → 显式标注,
    与「无异常」严格区分 (旧代码三者都渲染成「4条异动」= 谎报)。
    """
    lines = []
    for label, key in [("技术面异动", "tech_anomaly"), ("资金面异动", "cap_anomaly"), ("衍生品异动", "deriv_anomaly")]:
        payload = collected.get(key, {})
        if not isinstance(payload, dict) or "_error" in payload:
            lines.append(f"  {label}: 采集失败(无数据)")
            continue
        p = parse_anomaly_payload(payload)
        if p["status"] == "error":
            lines.append(f"  {label}: 采集失败({p['detail']})")
        elif p["status"] == "empty":
            lines.append(f"  {label}: 无异动 ({p['time_range'] or '近7日'})")
        else:
            tr = f" ({p['time_range']})" if p["time_range"] else ""
            lines.append(f"  {label}: {p['count']}条{tr}")
            for it in p["items"]:
                lines.append(f"    - {it}")
            if p["omitted"]:
                lines.append(f"    - …另有{p['omitted']}条未展示")
    if not lines:
        return ""
    return "## 异动信号\n" + "\n".join(lines)
