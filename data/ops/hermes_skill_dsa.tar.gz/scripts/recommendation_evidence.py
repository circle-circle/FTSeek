#!/usr/bin/env python3
"""Deterministic, record-only evidence lineage for DA recommendations."""

import hashlib
import json
import re
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional
from zoneinfo import ZoneInfo


ET = ZoneInfo("America/New_York")


def _finite(value: Any) -> Optional[float]:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    return number if number == number and abs(number) != float("inf") else None


def _time_fields(value: Any) -> Dict[str, Any]:
    result = {
        "raw": str(value) if value not in (None, "") else None,
        "utc": None,
        "et": None,
        "status": "MISSING" if value in (None, "") else "UNPARSED",
    }
    if value in (None, ""):
        return result
    parsed = None
    try:
        timestamp = float(str(value))
        if timestamp > 1e12:
            timestamp /= 1000.0
        if timestamp > 1e9:
            parsed = datetime.fromtimestamp(timestamp, timezone.utc)
    except (TypeError, ValueError, OverflowError, OSError):
        text = str(value).strip()
        try:
            candidate = datetime.fromisoformat(text.replace("Z", "+00:00"))
            if candidate.tzinfo is not None:
                parsed = candidate.astimezone(timezone.utc)
            else:
                result["status"] = "TIMEZONE_UNKNOWN"
        except ValueError:
            pass
    if parsed is not None:
        result["utc"] = parsed.isoformat()
        result["et"] = parsed.astimezone(ET).isoformat()
        result["status"] = "PARSED"
    return result


def _source_key(item: Dict[str, Any]) -> str:
    from llm_synth import _source_key as source_key

    return source_key(item)


def _reference_id(prefix: str, value: str) -> str:
    digest = hashlib.sha256(value.encode("utf-8")).hexdigest()[:16]
    return f"{prefix}-{digest}"


def build_event_references(
    collected: Dict[str, Any], candidate: Optional[Dict[str, Any]] = None,
    user_prompt: Optional[str] = None,
) -> Dict[str, Any]:
    import config

    prompt_sections = {}
    if user_prompt is not None:
        for source, header in (("FUTU", "最新新闻"), ("FINNHUB", "Finnhub 新闻事实流")):
            section = re.search(r"^## " + header + r"[^\n]*\n(.*?)(?=^## |\Z)", user_prompt, re.M | re.S)
            prompt_sections[source] = section.group(1) if section else ""
    references: List[Dict[str, Any]] = []
    seen = set()
    failed_sources = []
    source_had_list = False
    for source_name, field_name in (("FUTU", "news"), ("FINNHUB", "news_v2")):
        items = collected.get(field_name)
        if isinstance(items, dict) and items.get("_error"):
            failed_sources.append(field_name)
            continue
        if not isinstance(items, list):
            continue
        source_had_list = True
        for index, item in enumerate(items):
            if not isinstance(item, dict):
                continue
            story_key = _source_key(item)
            if not story_key:
                continue
            prompt_visible = source_name == "FINNHUB" or getattr(config, "DA_INPUT_FULL", True) or index < 8
            if user_prompt is not None:
                prefix = r"^  \[[^\n\]]*\] "
                if source_name == "FINNHUB":
                    prefix += r"\(" + re.escape(str(item.get("source", ""))) + r"\)(?: \[与新闻同稿\])? "
                matched = re.search(prefix + re.escape(str(item.get("title") or "")) + r"$", prompt_sections[source_name], re.M)
                prompt_visible = matched is not None
                if matched is not None:
                    section = prompt_sections[source_name]
                    prompt_sections[source_name] = section[:matched.start()] + section[matched.end():]
            identity = f"{source_name}|{story_key}"
            if identity in seen:
                continue
            seen.add(identity)
            published = _time_fields(item.get("publish_time") or item.get("time"))
            references.append({
                "evidence_id": _reference_id("SRC", identity),
                "story_id": _reference_id("STORY", story_key),
                "source": source_name,
                "publisher": item.get("source") or None,
                "title": str(item.get("title") or ""),
                "url": item.get("url") or None,
                "published": published,
                "prompt_visible": prompt_visible,
                "semantic_role": "UNADJUDICATED",
            })
    if references:
        status = "PARTIAL" if failed_sources else "AVAILABLE"
    elif failed_sources:
        status = "PARTIAL" if source_had_list else "UNAVAILABLE"
    else:
        status = "EMPTY" if source_had_list else "UNAVAILABLE"
    result = {
        "status": status,
        "failed_sources": failed_sources,
        "semantics": "UNADJUDICATED_NEWS_REFERENCES_NOT_DIRECTIONAL_EVENTS",
        "reference_count": len(references),
        "prompt_visible_count": sum(bool(item["prompt_visible"]) for item in references),
        "visibility_basis": "OBSERVED_USER_PROMPT" if user_prompt is not None else "CURRENT_RENDER_VIEW_NOT_HISTORICAL_PROOF",
        "references": references,
    }
    candidate = candidate or {}
    if candidate.get("ue_causal_chain") or candidate.get("ue_event_meta"):
        result["candidate_context"] = {
            "origin": "UE_CANDIDATE_HYPOTHESIS",
            "batch_id": candidate.get("ue_batch_id") or None,
            "scanned_at": candidate.get("ue_scanned_at") or None,
            "direction_hint": candidate.get("ue_direction") or None,
            "causal_chain": candidate.get("ue_causal_chain") or None,
            "evidence": candidate.get("ue_evidence") or None,
            "event_meta": candidate.get("ue_event_meta") or {},
            "event_reaction": candidate.get("ue_event_reaction") or {},
            "counter_evidence": candidate.get("ue_counter_evidence") or None,
        }
    return result


def _signed_alignment(value: Optional[float], direction: str) -> str:
    if direction not in ("BUY", "SELL_SHORT"):
        return "NOT_APPLICABLE"
    if value is None:
        return "UNKNOWN"
    if value == 0:
        return "NEUTRAL"
    aligned = value > 0 if direction == "BUY" else value < 0
    return "ALIGNED" if aligned else "OPPOSED"


def build_price_alignment(collected: Dict[str, Any], analysis: Dict[str, Any]) -> Dict[str, Any]:
    from data_collector import session_price_fields

    llm_output = analysis.get("_llm_output") or {}
    direction = str(analysis.get("action") or llm_output.get("direction") or "SKIP").upper()
    price = session_price_fields(collected.get("snapshot") or {})
    technical = analysis.get("technical") or {}
    trend = str(technical.get("trend") or "")
    expected_trend = "多头排列" if direction == "BUY" else "空头排列" if direction == "SELL_SHORT" else ""
    trend_alignment = "NOT_APPLICABLE" if not expected_trend else (
        "ALIGNED" if trend == expected_trend else
        "OPPOSED" if trend in ("多头排列", "空头排列") else "UNKNOWN"
    )
    industry = collected.get("industry_peers") or {}
    verified_industry = industry.get("caliber_version") == "session_effective_v1"
    industry_average = _finite(industry.get("industry_avg_chg_today_pct")) if verified_industry else None
    change_pct = _finite(price.get("change_pct"))
    relative_change = round(change_pct - industry_average, 2) if change_pct is not None and industry_average is not None else None
    execution_plan = llm_output.get("execution_plan") or {}
    return {
        "direction_basis": "LLM_ANALYSIS_PRE_GATE",
        "direction": direction,
        "interpretation": "OBSERVED_ALIGNMENT_ONLY_NOT_ENTRY_CONFIRMATION",
        "effective_price": price.get("price"),
        "effective_change_pct": change_pct,
        "session": price.get("session"),
        "price_as_of": price.get("price_as_of"),
        "price_alignment": _signed_alignment(change_pct, direction),
        "technical_trend": trend or None,
        "technical_trend_alignment": trend_alignment,
        "industry_caliber": industry.get("caliber_version") or "LEGACY_UNVERIFIED",
        "industry_average_change_pct": industry_average,
        "industry_today_sample_count": industry.get("industry_chg_today_sample_count") if verified_industry else None,
        "relative_to_industry_pct": relative_change,
        "relative_alignment": _signed_alignment(relative_change, direction),
        "planned_confirmation": execution_plan.get("confirmation"),
        "planned_invalidation": execution_plan.get("invalidation") or None,
    }


def build_counter_evidence(analysis: Dict[str, Any], candidate: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    llm_output = analysis.get("_llm_output") or {}
    debate = llm_output.get("_debate") or {}
    items = []
    for claim in debate.get("challenged_claims") or []:
        if not isinstance(claim, dict):
            continue
        text = str(claim.get("counter_evidence") or claim.get("weakness") or "").strip()
        if text:
            items.append({
                "source": "CHALLENGER",
                "kind": "CHALLENGED_CLAIM",
                "original_thesis": claim.get("original_thesis") or None,
                "weakness": claim.get("weakness") or None,
                "text": text,
            })
    for risk in debate.get("missed_risks") or []:
        text = str(risk).strip()
        if text and not text.startswith("无实质反证"):
            items.append({"source": "CHALLENGER", "kind": "MISSED_RISK", "text": text})
    candidate = candidate or {}
    ue_counter = str(candidate.get("ue_counter_evidence") or "").strip()
    if ue_counter:
        items.append({"source": "UE_CANDIDATE", "kind": "COUNTER_HYPOTHESIS", "text": ue_counter})
    status = "AVAILABLE" if items else ("NONE_REPORTED" if debate or ue_counter else "UNAVAILABLE")
    return {
        "status": status,
        "items": items,
        "debate": {
            "verdict": debate.get("challenger_verdict"),
            "direction": debate.get("challenger_direction"),
            "independent_direction": debate.get("challenger_independent_direction"),
            "anchor_divergence": debate.get("challenger_anchor_divergence"),
            "fallback": debate.get("challenger_fallback"),
        },
        "evidence_gaps": list(llm_output.get("evidence_gaps") or []),
    }


def build_claim_lineage(events: Dict[str, Any], llm_output: Dict[str, Any]) -> Dict[str, Any]:
    references = events.get("references") or []
    claims = []
    for section in ("bull_case", "bear_case"):
        for index, claim in enumerate(llm_output.get(section) or []):
            if not isinstance(claim, dict):
                continue
            thesis = str(claim.get("thesis") or "")
            evidence_text = str(claim.get("evidence") or "")
            searchable = re.sub(r"\s+", " ", f"{thesis} {evidence_text}").strip().lower()
            linked_ids = []
            for reference in references:
                title = re.sub(r"\s+", " ", str(reference.get("title") or "")).strip().lower()
                url = str(reference.get("url") or "")
                exact_reference = (
                    reference["evidence_id"] in searchable
                    or reference["story_id"] in searchable
                    or bool(url and url in searchable)
                    or bool(len(title) >= 8 and title in searchable)
                )
                if exact_reference:
                    linked_ids.append(reference["evidence_id"])
            claims.append({
                "claim_id": _reference_id("CLAIM", f"{section}|{index}|{thesis}"),
                "section": section,
                "thesis": thesis,
                "link_status": "EXACT_SOURCE_MATCH" if linked_ids else "UNLINKED",
                "evidence_ids": linked_ids,
            })
    return {
        "matching": "EXACT_ID_URL_OR_FULL_TITLE_ONLY_NO_FUZZY_INFERENCE",
        "claim_count": len(claims),
        "linked_claim_count": sum(bool(item["evidence_ids"]) for item in claims),
        "unlinked_claim_count": sum(not bool(item["evidence_ids"]) for item in claims),
        "claims": claims,
    }


def build_market_timing(collected: Dict[str, Any]) -> Dict[str, Any]:
    market = collected.get("market_context") or {}
    vix = market.get("vix") or {}
    indices = {}
    for name in ("spy", "qqq"):
        index_data = market.get(name) or {}
        snapshot = index_data.get("snapshot") or {}
        indices[name] = {
            "daily_close_as_of": index_data.get("current_asof") or None,
            "session": snapshot.get("session") or None,
            "snapshot_as_of": snapshot.get("snapshot_time") or None,
        }
    industry = collected.get("industry_peers") or {}
    return {
        "collected": _time_fields(collected.get("_timestamp")),
        "vix": {
            "value": _finite(vix.get("current")),
            "proxy": vix.get("proxy") or None,
            "caliber": vix.get("caliber") or None,
            "as_of_basis": vix.get("as_of_basis") or None,
            "as_of": None,
            "status": "AVAILABLE_PROXY" if _finite(vix.get("current")) is not None else "UNAVAILABLE",
        },
        "indices": indices,
        "industry": {
            "caliber_version": industry.get("caliber_version") or "LEGACY_UNVERIFIED",
            "peer_count": industry.get("peer_count"),
            "today_sample_count": industry.get("industry_chg_today_sample_count"),
            "five_day_sample_count": industry.get("industry_chg_5d_sample_count"),
        },
    }


def build_recommendation_evidence(
    collected: Dict[str, Any],
    analysis: Dict[str, Any],
    candidate: Optional[Dict[str, Any]] = None,
    user_prompt: Optional[str] = None,
) -> Dict[str, Any]:
    llm_output = analysis.get("_llm_output") or {}
    if user_prompt is None:
        user_prompt = llm_output.get("_user_prompt")
    events = build_event_references(collected, candidate, user_prompt)
    return {
        "schema_version": "recommendation_evidence_v1",
        "symbol": collected.get("symbol") or analysis.get("symbol"),
        "event_references": events,
        "claim_lineage": build_claim_lineage(events, llm_output),
        "market_timing": build_market_timing(collected),
        "price_alignment": build_price_alignment(collected, analysis),
        "counter_evidence": build_counter_evidence(analysis, candidate),
    }


def canonical_json(evidence: Dict[str, Any]) -> str:
    return json.dumps(evidence, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
