#!/usr/bin/env python3
"""
Pipeline — 管线编排器
=====================
5阶段模块化, 每阶段可独立运行。

Signal → Filter → Output → Execute → Result
市场扫描   筛选    深度分析  适配FTSeek  (FTSeek追踪IC)

Signal追踪/IC由FTSeek已有的signal_ic_tracker + playbook/ic_tracker负责。
本管线不重复IC计算, 只输出适配器格式供FTSeek消费。
"""

import json
import re
import time
import sys
import os
import hashlib
import math
from typing import Any, Dict, List

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import config

# ────────────────────────────────────────────────────────────────────────
# [DEB-20260901] 结构化入场语义 — 确定性兜底解析 (双轨之"兜底轨")
#   LLM 直出字段优先; 缺失时从 entry_strategy/thesis 文本抽取。保守原则:
#   文本模式不明确 → None (FTSeek 侧按 BREAKOUT=现状行为处理, 零行为变更)。
#   消费方: FTSeek Phase B 影子 (pullback_limit_shadow) + 未来 archetype 路由。
# ────────────────────────────────────────────────────────────────────────
_CHASE_CAP_PATTERNS = (
    re.compile(r"禁止.*?[\$￥]?\s?([\d,]+(?:\.\d+)?)\s*(?:以上|上方)?\s*追涨"),
    re.compile(r"禁止追涨.*?[\$￥]?\s?([\d,]+(?:\.\d+)?)"),
    re.compile(r"禁止.*?追高.*?[\$￥]?\s?([\d,]+(?:\.\d+)?)"),
)
_FIRST_LEG_PRICE = re.compile(r"第[1一]批[^。;；\n]*?[\$￥@]\s?([\d,]+(?:\.\d+)?)")
_PULLBACK_WORDS = ("低吸", "回踩", "承接", "企稳接", "回调至", "回调企稳", "试多", "支撑区")
_BREAKOUT_WORDS = ("突破追入", "放量突破", "突破后追入", "放量上攻")
_FADE_WORDS = ("等反弹", "反弹至", "反弹做空", "逢反弹", "企稳后顺势做空", "逢高做空")
_VALID_ARCHS = ("BREAKOUT", "PULLBACK_LIMIT", "FADE_SHORT")


def _derive_entry_semantics(entry_strategy, thesis, direction,
                            llm_archetype=None, llm_confirmation=None, llm_chase_cap=None):
    """返回 (entry_archetype, confirmation, chase_cap_price)。LLM 值优先, 文本兜底。"""
    text = " ".join(str(x or "") for x in (entry_strategy, thesis))
    # chase_cap: "禁止在$X以上追涨" / "禁止追涨>$X"
    chase_cap = llm_chase_cap if isinstance(llm_chase_cap, (int, float)) else None
    if chase_cap is None:
        for _pat in _CHASE_CAP_PATTERNS:
            _m = _pat.search(text)
            if _m:
                try:
                    chase_cap = float(_m.group(1).replace(",", ""))
                    break
                except Exception:
                    pass
    # archetype
    arch = str(llm_archetype or "").upper() if llm_archetype else None
    if arch not in _VALID_ARCHS:
        arch = None
        if direction in ("SHORT", "SELL_SHORT"):
            if any(w in text for w in _FADE_WORDS):
                arch = "FADE_SHORT"
        else:
            if any(w in text for w in _PULLBACK_WORDS):
                arch = "PULLBACK_LIMIT"
            elif any(w in text for w in _BREAKOUT_WORDS):
                arch = "BREAKOUT"
    # confirmation: 首批确认位
    _conf = llm_confirmation if isinstance(llm_confirmation, dict) else {}
    lvl = None
    _raw_lvl = _conf.get("price_level")
    if _raw_lvl not in (None, "", "null"):
        try:
            lvl = float(str(_raw_lvl).replace(",", ""))
        except Exception:
            lvl = None
    if lvl is None:
        _m2 = _FIRST_LEG_PRICE.search(str(entry_strategy or ""))
        if _m2:
            try:
                lvl = float(_m2.group(1).replace(",", ""))
            except Exception:
                lvl = None
    if lvl is None and not _conf:
        confirmation = None
    else:
        _side = _conf.get("side") or (
            "above" if (arch == "FADE_SHORT" or (arch == "BREAKOUT" and direction in ("SHORT", "SELL_SHORT")))
            else ("below" if arch == "PULLBACK_LIMIT" else
                  ("above" if arch == "BREAKOUT" else ("above" if arch == "FADE_SHORT" else "below"))))
        try:
            _ttl = int(_conf.get("ttl_min") or 15)
        except Exception:
            _ttl = 15
        confirmation = {"price_level": lvl, "side": _side, "ttl_min": _ttl}
    return arch, confirmation, chase_cap



# ── 统一可交易性初筛 (2026-09-12, DEB-20260910 / proud-slope-falcon P1.4) ──
# 根因 (原"候选预过滤 2026-08-06"的位置错误, 不是规则错误):
#   旧 `_prefilter_candidates()` 在 Stage2 **截断之后**才跑 (原 line 526), 淘汰不补位 ⇒
#   ① [:top_n+2] 先丢掉最强空头/高分多头, 池内剩下的低波票再被剔 ⇒ 实际深分析数
#      长期低于预算 (白留名额);
#   ② `results["stages"]["filter"]["selected_symbols"]` 记的是**过滤前**名单,
#      与 Stage3 真正提交 LLM 的集合不符 ⇒ 审计/归因失真;
#   ③ 同一价格/ATR 判定在 DA 与 FTSeek 执行端各写一份, 口径会漂 (DA 2.9% vs 执行 3.0%)。
# 修后: 资格判定前置 → 在**合格队列**内按原预算取 K → 淘汰从剩余合格队列补位;
#   判定复用 FTSeek 仓内纯函数 (`compute_screening_atr` + `evaluate_candidate`),
#   DA 不再自带第二套 ATR 数学。分析名额不是成交配额, 允许零选取。
# ATR 口径: 原始日线 TR14 rolling-mean, **不含** VIX 缩放 / 三层底限 / 分钟 ATR 兜底
#   (那些是止损口径, `ATRProvider.get_atr/get_atr_pct` 未改动)。
# ⚠ 显式策略行为变更 (非零交易影响):
#   低 ATR 阈值 2.9% → 3.0% — 统一到执行端 `playbook.low_atr_gate_min_atr_pct` 单一
#   真源, 取消 0.1pp 缓冲。8/6 留缓冲的理由是"预过滤 3.0 会误杀边界票 (BABA atr=3.00%)";
#   实测该例 atr=3.00% **等于**阈值, 3.0% 门是 `atr < 3.0` 才拒 ⇒ 不误杀。真正受影响
#   的是 2.9% ≤ atr < 3.0% 区间: 修前 DA 放行 → 执行端拦 (白算 LLM); 修后 DA 直接拒。
#   即: 变化方向是"少烧 LLM", 不是"少交易"; 边界拒绝逐条打 stderr + 落候选漏斗。
#   分母口径同批变更: 旧实现用 `collect_kline` 末根收盘; 新实现优先**候选快照价**
#   (保证"筛过的价"与"写进指令的价"同源), 缺快照价才退末根已完成日线收盘。
# 回滚: env DA_CANDIDATE_SCREEN=0 (初筛退化为只标注不拒绝) 或还原本段 + Stage2。
_FTSEEK_REPO = "/opt/ftseek/FTSeek-US"
_FTSEEK_DATA_DIR = "/opt/ftseek/FTSeek-US/data"
_DA_SCREEN_MIN_PRICE_FALLBACK = 5.0        # 配置读不到时的回退 (与原 _PREFILTER_MIN_PRICE 同值)
_DA_SCREEN_MIN_ATR_PCT_FALLBACK = 3.0      # 2.9 → 3.0 (见上, 显式统一到执行端配置)
_DA_SCREEN_SOURCE = "da.data_collector.collect_kline"
_DA_SCREEN_WINDOW = "da_premarket"
_DEPS_STATE: Dict[str, object] = {"loaded": False, "deps": None}
_ATR_CACHE: Dict[str, Dict] = {}           # 单轮进程内缓存: (symbol|asof_date) → detail


def _ftseek_screening_deps():
    """惰性导入 FTSeek 仓内共用件; 任何失败 fail-open (返回 None, 不阻断 DA 主流程)。

    DA 是仓外 skill (`/root/.hermes/skills/deep-stock-analysis/scripts/`), 不能假设
    FTSeek 可导入。导入失败 ⇒ 初筛退化为"只标注 UNKNOWN, 不拒绝", 由执行端原有
    风险门 (admission / 低 ATR / quote gate) 全量兜底 —— 不静默改判定口径。
    """
    if _DEPS_STATE["loaded"]:
        return _DEPS_STATE["deps"]
    _DEPS_STATE["loaded"] = True
    try:
        # append (不是 insert(0)): FTSeek 仓根有 `config/` **包**, 而本 skill 用同名
        #   `config.py` 模块; 插到最前会让后续 `import config` 解析到仓库包, 静默换掉
        #   DA 自己的配置。本 skill 目录已在 sys.path[0] (文件头 insert), append 后
        #   DA 模块名恒优先, `app.*` 仍能解析。
        if _FTSEEK_REPO not in sys.path:
            sys.path.append(_FTSEEK_REPO)
        from app.core import atr_provider as _ap
        from app.playbook import candidate_eligibility as _ce
        from app.playbook import ue_batch as _ub
        _DEPS_STATE["deps"] = {
            "compute_screening_atr": _ap.compute_screening_atr,
            "evaluate_candidate": _ce.evaluate_candidate,
            # 2026-10-11 移除 "source_time": _ce._source_time —— 零消费者死注入。
            #   它由未登记 WIP 引入, 唯一用途是把 DA 扫描快照时戳换算成 quote_age_sec 灌进
            #   entry 级 90s 门 (见 _screen_da_candidates 内 source_asof 处批注)。随该特性一并回退。
            "load_candidate_policy": _ce.load_candidate_policy,
            "canonical_symbol": _ce.canonical_symbol,
            "select_candidates": _ce.select_candidates,
            "make_batch_id": _ce.make_batch_id,
            "record_candidate_batch": _ce.record_candidate_batch,
            "fingerprint": _ce._fingerprint,
            "latest_valid_batch": _ub.latest_valid_batch,
        }
    except Exception as _de:
        print(f"[Screen] FTSeek 初筛件导入失败 → 初筛 fail-open (只标注不拒绝, "
              f"交执行端原门兜底): {_de}", file=sys.stderr)
        _DEPS_STATE["deps"] = None
    return _DEPS_STATE["deps"]


def _et_now():
    """ET 当前时刻 (**tz-aware**) — 与 DA 既有 DST 口径同款 (3-11月 -4, 其余 -5)。

    必须带时区: FTSeek `screening_asof_date()` 显式拒绝 naive datetime
    (`app.utils.timezone.to_et()` 把 naive 当北京时间, 静默转换会移半天
    ⇒ 可能把当日未完成 bar 当成已完成日线算进 ATR)。
    """
    from datetime import datetime as _dt, timezone as _tz, timedelta as _td
    # 2026-10-06 修: 原按月份硬编码 offset (3<=month<=11 → -4) 在每年 3/1~3月第二个
    #   周日 (EDT 生效前) 把 EST 误读成 EDT, 钟快 1h ⇒ DA 主链窗 (0755-0815) 会错拒
    #   EST 季载体。与 llm_universe_scan._now_et 8/26 修复同款病灶, 换 zoneinfo 真源;
    #   仅 tzdata 缺失才回退旧月份近似 (容器双 python 均 3.11, 实测可用)。
    try:
        from zoneinfo import ZoneInfo as _zi
        return _dt.now(_zi("America/New_York"))
    except Exception:
        _off = _td(hours=-4) if 3 <= _dt.now().month <= 11 else _td(hours=-5)
        return _dt.now(_tz(_off))


def _da_batch_id() -> str:
    deps = _ftseek_screening_deps()
    now = _et_now()
    if deps:
        try:
            return str(deps["make_batch_id"]("DA", now))
        except Exception:
            pass
    return f"DA:{now.strftime('%Y%m%dT%H%M%S')}"


def _fallback_decision_id(trade_date: str, symbol: str) -> str:
    """Deterministic DA id when IC snapshot writing failed.

    A missing decision_id used to invalidate the whole bridge file (FTSeek
    schema requires it on every candidate) and left the DB row at priority 0,
    where a later TFB row could overwrite it. Keep the row DA-priority even
    when the IC sidecar failed; provenance is carried by the ``-noic`` suffix.
    """
    sym = _canon_symbol(symbol).replace("/", "_")
    return f"DA-{str(trade_date).replace('-', '')}-{sym}-noic"


def _ensure_decision_id(analysis: Dict, trade_date: str) -> str:
    did = str(analysis.get("_ic_decision_id") or "")
    if did:
        return did
    did = _fallback_decision_id(trade_date, analysis.get("symbol", ""))
    analysis["_ic_decision_id"] = did
    print(f"[Pipeline] {analysis.get('symbol')} IC decision_id 缺失 → fallback {did}",
          file=sys.stderr)
    return did



def _canon_symbol(value) -> str:
    """跨来源去重用的规范化标的 (与 FTSeek `normalize_symbol` 同源)。"""
    deps = _ftseek_screening_deps()
    if deps:
        try:
            return deps["canonical_symbol"](value)
        except Exception:
            pass
    sym = str(value or "").upper().strip()
    if not sym:
        return ""
    return sym if sym.startswith("US.") else f"US.{sym}"


def _da_screening_thresholds() -> Dict:
    """读 FTSeek 单一配置真源 (`get_playbook_config()` + `get_admission_config()`);
    读不到回退常量 —— 不猜阈值, 不新增一串 DA 侧永久开关。

    DA 侧只有扫描快照价, 没有实时盘口 / 借券数据 ⇒ 点差门与借券门恒不启用
    (缺数 ≠ 拒绝; 执行端 admission + quote gate 仍全量复核, 盘前快照不当实时行情用)。
    """
    out = {
        "version": "da_ue_v1",
        "min_price": _DA_SCREEN_MIN_PRICE_FALLBACK,
        "low_atr_enabled": True,
        "min_atr_ratio": _DA_SCREEN_MIN_ATR_PCT_FALLBACK / 100.0,
        "max_scan_age_hours": 3.0,
        "max_quote_age_sec": 90.0,
        "max_spread_ratio": 0.05,
        "quote_gate_enabled": False,
        "borrow_gate_enabled": False,
        "config_source": "fallback_constant",
    }
    deps = _ftseek_screening_deps()
    if not deps:
        return out
    try:
        policy = deps["load_candidate_policy"]()
        out.update({
            "version": policy.get("version") or out["version"],
            "min_price": float(policy.get("min_price", out["min_price"])),
            "low_atr_enabled": bool(policy.get("low_atr_enabled", True)),
            "min_atr_ratio": float(policy.get("min_atr_ratio", out["min_atr_ratio"])),
            "max_scan_age_hours": float(policy.get("max_scan_age_hours",
                                                   out["max_scan_age_hours"])),
            "max_quote_age_sec": float(policy.get("max_quote_age_sec",
                                                  out["max_quote_age_sec"])),
            "max_spread_ratio": float(policy.get("max_spread_ratio",
                                                 out["max_spread_ratio"])),
            "quote_gate_enabled": False,      # DA 无实时盘口 → 恒不启用 (见 docstring)
            "borrow_gate_enabled": False,     # 借券未知不当"可借", 也不当硬拒
            "config_source": "playbook+admission",
        })
    except Exception as _te:
        print(f"[Screen] 阈值读取失败 → 回退常量 (min_price=${out['min_price']:.2f}, "
              f"min_atr={out['min_atr_ratio'] * 100:.1f}%): {_te}", file=sys.stderr)
    return out


def _candidate_ref_price(cand: Dict):
    """候选快照的有效参考价: `price` (scanner 盘前时段已写 effective_price) 优先,
    缺则 last_price / premarket_price / close。非有限或非正 → None (不编造价格)。
    """
    for key in ("price", "last_price", "premarket_price", "prev_close", "close"):
        try:
            value = float(cand.get(key))
        except (TypeError, ValueError):
            continue
        if math.isfinite(value) and value > 0:
            return value
    return None


def _fetch_screening_atr(sym: str, ref_price=None, asof=None) -> Dict:
    """原始日线筛选 ATR + 比例 (纯函数口径, 复用 FTSeek `compute_screening_atr`)。

    - 取数走 DA 自有 `data_collector.collect_kline` — **不新建第二条行情连接**;
    - 15 根已完成日线 → 14 个 TR, rolling-mean 取末值; 交易日截断 (当日未完成 bar
      排除)、同日去重、拆股/复权断点 (>1.6x) 不跨算;
    - 分母 = 调用方候选快照价优先, 缺则 `ref_close` (末根已完成日线收盘),
      口径写在 `denominator` 里供审计;
    - 任何缺数/异常 → status=UNKNOWN + reason, **不外推、不返回 0、不编造 ATR**;
    - 单轮进程内按 (symbol, asof_date) 缓存: 主池/extras/UE/异动多阶段重叠标的零重复取数。
    """
    bare = str(sym or "").replace("US.", "")
    detail = {"atr": None, "status": "UNKNOWN", "reason": "deps_unavailable",
              "basis": None, "source": _DA_SCREEN_SOURCE, "adjustment": None,
              "bars_asof": None, "bars_used": 0, "ref_close": None,
              "denominator": None, "ratio": None, "ratio_pct": None}
    deps = _ftseek_screening_deps()
    if not deps or not bare:
        if not bare:
            detail["reason"] = "invalid_symbol"
        return detail
    now = asof if asof is not None else _et_now()
    try:
        from app.core.atr_provider import screening_asof_date
        asof_date = screening_asof_date(now)
    except Exception:
        asof_date = str(now)[:10]
    cache_key = f"US.{bare}|{asof_date}"
    hit = _ATR_CACHE.get(cache_key)
    if hit is not None:
        detail = dict(hit)
    else:
        try:
            import data_collector as _dc
            bars = _dc.collect_kline(f"US.{bare}", "1d", 40) or []
        except Exception as _ke:
            detail["reason"] = f"kline_unavailable:{type(_ke).__name__}"
            _ATR_CACHE[cache_key] = detail
            return dict(detail)
        try:
            got = deps["compute_screening_atr"](bars, now, symbol=f"US.{bare}",
                                                source=_DA_SCREEN_SOURCE)
        except Exception as _ae:
            detail["reason"] = f"atr_compute_failed:{type(_ae).__name__}"
            _ATR_CACHE[cache_key] = detail
            return dict(detail)
        # adjustment/bars_used 一并透传: 复权口径与有效根数是审计必需的量纲声明
        #   (AGENT.md 军规"新增落库字段必带单位/量纲声明")。
        for key in ("atr", "status", "reason", "basis", "adjustment",
                    "bars_asof", "bars_used", "ref_close"):
            detail[key] = got.get(key)
        detail["source"] = got.get("source") or _DA_SCREEN_SOURCE
        _ATR_CACHE[cache_key] = detail
        detail = dict(detail)
    # 分母在缓存外决定 (同一 ATR 可被不同参考价的候选复用)
    denom = None
    try:
        denom = float(ref_price)
        if not (math.isfinite(denom) and denom > 0):
            denom = None
    except (TypeError, ValueError):
        denom = None
    if denom is not None:
        detail["denominator"] = "candidate_snapshot_price"
    else:
        denom = detail.get("ref_close")
        detail["denominator"] = "last_completed_daily_close"
    atr = detail.get("atr")
    if detail.get("status") == "PASS" and atr and denom:
        try:
            ratio = float(atr) / float(denom)
            if math.isfinite(ratio) and ratio > 0:
                detail["ratio"] = ratio
                detail["ratio_pct"] = ratio * 100.0
        except (TypeError, ValueError, ZeroDivisionError):
            pass
    if detail.get("ratio") is None and detail.get("status") == "PASS":
        detail.update(status="UNKNOWN", reason="no_valid_denominator")
    return detail


def _fetch_atr_pct(sym: str, ref_price=None):
    """兼容入口: 筛选 ATR 百分比 (float|None)。原实现 = 20 根裸 TR 均值 / 末根收盘。

    口径变更 (2026-09-12): 换到 `compute_screening_atr` (15 根**已完成**日线 / 14 TR /
    交易日截断 / 同日去重 / 拆股断点不跨算), 分母优先候选快照价。失败仍返回 None
    (不拦截) —— 与原语义一致。
    """
    pct = _fetch_screening_atr(sym, ref_price=ref_price).get("ratio_pct")
    return pct if isinstance(pct, float) and math.isfinite(pct) and pct > 0 else None


def _da_direction_hint(cand: Dict, fallback: str = "") -> str:
    hint = str(cand.get("ue_direction") or cand.get("direction_hint")
               or cand.get("_scan_side") or fallback or "").upper()
    return {"BEARISH": "SHORT", "BULLISH": "LONG", "SELL_SHORT": "SHORT",
            "BUY": "LONG"}.get(hint, hint)


def _screen_da_candidates(cands: List[Dict], stage: str = "da_main_pool",
                          batch_id: str = None, direction_hint: str = "") -> List[Dict]:
    """逐个资格判定并附 `candidate_screening` — **只判定不截断** (预算由调用方消费)。

    输出 = 输入顺序不变的浅拷贝列表, 每行带与 FTSeek UE 侧**同一 schema** 的
    `candidate_screening` (symbol/price/status/reasons/missing_fields/policy_version/
    candidate_id/batch_id/source/observed_at + DA 侧 ATR 口径审计字段), 因此
    `select_candidates()` / `record_candidate_batch()` / 候选漏斗 JSONL 直接可消费。
    `symbol` 本身**不改写** (DA 下游 collect_all / bridge 依赖原格式)。
    """
    rows: List[Dict] = []
    deps = _ftseek_screening_deps()
    batch_id = batch_id or _da_batch_id()
    if os.environ.get("DA_CANDIDATE_SCREEN", "1") == "0" or not deps:
        for cand in cands or []:
            cand = dict(cand)
            cand["candidate_screening"] = {
                "symbol": _canon_symbol(cand.get("symbol")),
                "status": "UNKNOWN", "reasons": [],
                "missing_fields": ["screening_disabled_or_deps_unavailable"],
                "stage": stage, "batch_id": batch_id, "source": "DA",
                "policy_version": None,
            }
            rows.append(cand)
        return rows
    policy = _da_screening_thresholds()
    evaluate = deps["evaluate_candidate"]
    observed_at = _et_now().isoformat()
    missing_price = [str(c.get("symbol") or "") for c in (cands or [])
                     if _candidate_ref_price(c) is None]
    snapshot_rows = {}
    if missing_price:
        try:
            import data_collector as _dc
            _snaps = _dc.collect_snapshot_batch(missing_price)
            snapshot_rows = {str(s.get("code") or ""): s
                             for s in _snaps or [] if isinstance(s, dict)}
        except Exception:
            snapshot_rows = {}
    for cand in cands or []:
        cand = dict(cand)
        raw_sym = str(cand.get("symbol") or "")
        symbol = _canon_symbol(raw_sym)
        ref_price = _candidate_ref_price(cand)
        snapshot = snapshot_rows.get(raw_sym) or {}
        if ref_price is None:
            for _price_key in ("pre_price", "last_price", "prev_close_price", "prev_close"):
                try:
                    _price_value = float(snapshot.get(_price_key) or 0)
                except (TypeError, ValueError):
                    _price_value = 0.0
                if _price_value > 0:
                    ref_price = _price_value
                    break
        atr = _fetch_screening_atr(raw_sym, ref_price=ref_price)
        hint = _da_direction_hint(cand, direction_hint)
        facts = {
            "symbol": symbol,
            "price": ref_price,
            "quote_source": "da_scanner_snapshot",
            # 扫描快照不是实时行情: 不冒充 source_asof, 也不据此判 stale/future
            # (缺 bid/ask 不按零点差算; 执行端 admission/quote gate 全量复核)。
            # 2026-10-11 恢复 (回退未登记 WIP): 曾在此灌真值 source_asof/quote_age_sec,
            #   把 entry 级 90s 门 (entry_max_quote_age_sec) 套到盘前分钟级扫描快照上 ⇒
            #   10-09 那批 84 候选中 33 笔仅因 stale_quote 被拒 (ACN/MPC/VLO/NU 等正常票,
            #   quote_age_sec 中位 402s / max 1969s vs 门限 90s), selected 19.6→12 (−38.8%)。
            #   量纲错配: 该门语义是「下单前报价不得超 90s」, 筛选阶段拦掉 ⇒ 候选走不到执行端,
            #   真正为此设计的 admission/quote gate 永远看不到它们。
            #   若日后要给 DA 筛选补数据时效门, 用扫描数据的既有尺度
            #   candidate_scan_max_age_hours=3.0 (执行点 llm_universe_scan.py:3560), 不用 entry 级秒门。
            "source_asof": None,
            "quote_age_sec": None,
            "bid": None, "ask": None,
            "screening_atr_ratio": atr.get("ratio"),
            "screening_atr": atr.get("atr"),
            "atr_basis": atr.get("basis"),
            "atr_source": atr.get("source"),
            "atr_adjustment": atr.get("adjustment"),
            "atr_bars_used": atr.get("bars_used"),
            "atr_reason": atr.get("reason"),
            "bars_asof": atr.get("bars_asof"),
            "direction_hint": hint,
            "shortable": None,
        }
        if _da_skip_leveraged_etf() and _is_leveraged_etf_name(cand.get("name")):
            # 2026-10-22 [RFC-159]: 杠杆/反向 ETF 是结构性死票 (无财报事件,
            # 常缺 9 维数据); 前置 REJECT 省下数据采集 + 2 次 LLM, 不占 DA 预算.
            verdict = {"status": "REJECT", "reasons": ["leveraged_etf"],
                       "missing_fields": []}
        else:
            try:
                verdict = evaluate(facts, policy)
            except Exception as _ve:
                verdict = {"status": "UNKNOWN", "reasons": [],
                           "missing_fields": [f"evaluate_error:{type(_ve).__name__}"]}
        hashable = {k: v for k, v in facts.items() if k != "quote_age_sec"}
        try:
            input_hash = deps["fingerprint"]([hashable, policy])
        except Exception:
            input_hash = None
        cand["candidate_screening"] = {
            **facts, **verdict,
            "policy_version": policy.get("version"),
            "input_hash": input_hash,
            "candidate_id": f"{batch_id}:{symbol}:{hint or 'UNDECIDED'}",
            "batch_id": batch_id, "source": "DA", "scan_window": _DA_SCREEN_WINDOW,
            "trade_mode": "sim", "observed_at": observed_at, "fetched_at": observed_at,
            "stage": stage,
            "ref_price": ref_price,
            "atr_denominator": atr.get("denominator"),
            "atr_status": atr.get("status"),
            "atr_ratio_pct": atr.get("ratio_pct"),
            "min_price": policy.get("min_price"),
            "min_atr_pct": round(float(policy.get("min_atr_ratio") or 0) * 100, 4),
            "config_source": policy.get("config_source"),
            "policy": {k: v for k, v in policy.items() if k != "policy"},
        }
        rows.append(cand)
    return rows


def _select_eligible(screened: List[Dict], budget: int, stage: str = "",
                     already_selected=None, sort_key=None) -> List[Dict]:
    """在合格集合内按预算选取 —— 淘汰从**剩余合格队列**补位 (P1.4 核心)。

    - REJECT (价格地板 / 明确低 ATR / 非法标的) 出局且**不占名额**;
    - UNKNOWN (缺价 / 缺 ATR / 缺盘口) 仍放行进入研究阶段 —— 缺数 ≠ 拒绝,
      执行阶段仍受原风险门约束;
    - 已选 symbol 视为重复, 不占两个名额 (跨主池/extras/UE/异动统一去重)。
    deps 不可用时退化为等价本地实现 (同判定同顺序), 不因导入失败改变选择结果。
    """
    try:
        budget = max(0, int(budget))
    except (TypeError, ValueError):
        budget = 0
    consumed = {_canon_symbol(s) for s in (already_selected or []) if s}
    deps = _ftseek_screening_deps()
    if deps:
        try:
            return list(deps["select_candidates"](
                screened, budget, allow_unknown=True,
                already_selected=consumed, sort_key=sort_key))
        except Exception as _se:
            print(f"[Screen] select_candidates({stage}) 失败 → 退化实现: {_se}",
                  file=sys.stderr)
    selected: List[Dict] = []
    for index, row in enumerate(screened or []):
        screening = row.get("candidate_screening") or {}
        status = str(screening.get("status") or "UNKNOWN").upper()
        symbol = _canon_symbol(row.get("symbol"))
        row.pop("selection_rank", None)
        # allow_unknown 在 DA 全部调用点恒为 True: UNKNOWN (缺价/缺ATR/缺盘口) 与 PASS
        # 同样参与去重与预算 —— 缺数 != 拒绝, 执行阶段仍受原风险门约束。
        if status == "REJECT":
            row["selection_status"] = "rejected_ineligible"
        elif symbol in consumed:
            row["selection_status"] = "duplicate"
        elif len(selected) < budget:
            row["selection_status"] = "selected"
            row["selection_rank"] = len(selected) + 1
            consumed.add(symbol)
            selected.append(row)
        else:
            row["selection_status"] = "budget_cut"
        screening["selection_status"] = row["selection_status"]
        if "selection_rank" in row:
            screening["selection_rank"] = row["selection_rank"]
        row["candidate_screening"] = screening
    return selected


def _screening_summary(screened: List[Dict]) -> Dict:
    """候选漏斗计数 (资格三态 × 选择五态 × 拒绝原因 × 分阶段) — 纯函数, 供日志/审计。"""
    out = {"total": 0, "eligibility": {}, "selection": {}, "reason_codes": {},
           "missing_fields": {}, "by_stage": {}}
    for row in screened or []:
        screening = row.get("candidate_screening") or {}
        status = str(screening.get("status") or "UNKNOWN").upper()
        stage = str(screening.get("stage") or "?")
        chosen = str(row.get("selection_status") or "not_selected")
        out["total"] += 1
        out["eligibility"][status] = out["eligibility"].get(status, 0) + 1
        out["selection"][chosen] = out["selection"].get(chosen, 0) + 1
        stage_row = out["by_stage"].setdefault(stage, {"total": 0, "selection": {},
                                                       "reason_codes": {}})
        stage_row["total"] += 1
        stage_row["selection"][chosen] = stage_row["selection"].get(chosen, 0) + 1
        for code in screening.get("reasons") or []:
            out["reason_codes"][code] = out["reason_codes"].get(code, 0) + 1
            stage_row["reason_codes"][code] = stage_row["reason_codes"].get(code, 0) + 1
        for field in screening.get("missing_fields") or []:
            out["missing_fields"][field] = out["missing_fields"].get(field, 0) + 1
    return out


def _record_da_funnel(output_dir: str, screened: List[Dict], batch_id: str) -> None:
    """按批次落候选漏斗 JSONL (P1.1) — best-effort, 失败只留痕不阻断深分析。

    路径随 `output_dir` 走 ⇒ A/B 隔离目录不污染生产影子档; 默认 output_dir
    (`/opt/ftseek/FTSeek-US/data`) 下与 FTSeek 侧 `FUNNEL_PATH` 同一文件同一 schema。
    """
    deps = _ftseek_screening_deps()
    if not deps or not screened:
        return
    try:
        path = os.path.join(output_dir or _FTSEEK_DATA_DIR, "shadow",
                            "candidate_funnel.jsonl")
        deps["record_candidate_batch"](screened, batch_id=batch_id, source="DA",
                                       phase="da_selection", path=path)
    except Exception as _fe:
        print(f"[Screen] 候选漏斗落盘失败(不影响分析): {_fe}", file=sys.stderr)


def _reset_screening_cache() -> None:
    """每轮 run_full 开头清 ATR 缓存 (跨日/跨轮不复用; 轮内多阶段共享)。"""
    _ATR_CACHE.clear()


def _prefilter_candidates(cands: List[Dict]) -> List[Dict]:
    """深度分析前的源头过滤: 价格下限 + ATR 下限 (低波不做日内动量).

    [P1.4 2026-09-12] 保留为**兼容薄包装** —— 同一资格判定的过滤投影, 供仓外旧
    调用点/回滚使用。Stage2 不再用它做后置截断过滤 (改 `_screen_da_candidates`
    + `_select_eligible` 前置判定 + 预算内补位)。
    """
    out = []
    for cand in _screen_da_candidates(cands, stage="da_prefilter_compat"):
        screening = cand.get("candidate_screening") or {}
        if str(screening.get("status")) == "REJECT":
            print(f"[Prefilter] {cand.get('symbol')} → 剔除 "
                  f"({','.join(screening.get('reasons') or []) or 'unknown'})",
                  file=sys.stderr)
            continue
        out.append(cand)
    if len(out) < len(cands or []):
        print(f"[Prefilter] 剔除 {len(cands) - len(out)} 只 → 进入深度分析 {len(out)} 只",
              file=sys.stderr)
    return out


# ── 断点续跑 (2026-08-24): Stage 3 逐股 checkpoint ──────────────────────
# 根因 (8/24 实证): 26 只全部深度分析完 (~42min) 后 Stage4 KeyError 崩溃 →
#   analyses 只在内存, 全部作废, 从零重跑。
# 方案: 每只标的处理完 (分析+gate+IC+Obsidian+adapter) 落盘完整 analysis 到
#   {output_dir}/da_checkpoint/{ET日期}/{symbol}.json; 重跑命中即跳过该标的
#   的重活与全部 append 型副作用 (gate jsonl / IC snapshot / Obsidian)。
#   失败分析 (rating=错误) 不落盘 → 重跑自动重试。模型变更 → 缓存作废。
#   隔离复用现有 A/B 机制: 根目录 = self.output_dir。
# 回滚: DA_RESUME_CACHE=0 (或删 checkpoint 目录)。
_CKPT_KEEP_DAYS = 30


def _ckpt_policy_version() -> str:
    """候选策略口径指纹 — checkpoint 兼容性判据 (P1.4)。

    为什么需要: 本批改了**候选集本身**的产出口径 (完整分桶队列 + 空头 conviction
    排序 + 先过滤后预算 + 低 ATR 阈值 2.9→3.0)。旧 checkpoint 里的 analysis 是在
    不同候选集/不同阈值下产出的, 直接复用会:
      ① 把按新口径已淘汰标的的旧分析混回本轮 (绕过资格判定);
      ② 让"输入分布变化后受影响试验按新版本分段"无法在缓存层落地。
    故 checkpoint 除模型外, 还按策略口径校验; 口径变 → 缓存作废重新分析。
    代价: 部署后首轮全量重跑一次 (无缓存命中), 属预期。
    """
    thresholds = _da_screening_thresholds()
    try:
        import market_scanner as _ms
        bucket_order = str(getattr(_ms, "BUCKET_ORDER_VERSION", "") or "")
    except Exception:
        bucket_order = "unavailable"
    payload = {
        "policy_version": thresholds.get("version"),
        "config_source": thresholds.get("config_source"),
        "min_price": thresholds.get("min_price"),
        "min_atr_ratio": thresholds.get("min_atr_ratio"),
        "low_atr_enabled": thresholds.get("low_atr_enabled"),
        "bucket_order_version": bucket_order,
        "selection": "screen_before_budget_v1",
        "screening_disabled": os.environ.get("DA_CANDIDATE_SCREEN", "1") == "0",
        "prompt_hash": "unavailable",
        "truth_flags": {
            "prev_close_reconcile": os.environ.get(
                "DA_PREV_CLOSE_BAR_RECONCILE", "apply"),
            "source_truth_fix": os.environ.get("DA_SOURCE_TRUTH_FIX", "1"),
            "debate_state_fix": os.environ.get("DA_DEBATE_STATE_FIX", "1"),
        },
    }
    try:
        import llm_synth as _ls_ck
        payload["prompt_hash"] = str(getattr(_ls_ck, "PROMPT_HASH", "") or "")
    except Exception:
        pass
    # [RFC-208 bridge] 开关门控的 EventContext 注入也进入缓存兼容性判据。
    #   关 (默认) => event_injection_policy_hash() 返回 None => payload 逐字节
    #   不变, 历史 checkpoint 继续命中 (默认关必须零行为差异; 且不 import 仓内
    #   模块, 避免默认关路径多出 import 副作用)。
    #   开 => 注入身份 (contract version + brief_id + status/as_of/valid_until +
    #   合法性) 变化即作废旧缓存; 与 llm_synth 落盘的
    #   result["_event_context"]["injection_hash"] 是同一个值。
    _event_inject_on = str(
        config._read_env("DA_EVENT_CONTEXT_INJECT") or "0"
    ).strip().lower() in {"1", "true", "yes", "on"}
    if _event_inject_on:
        try:
            if _FTSEEK_REPO not in sys.path:
                sys.path.append(_FTSEEK_REPO)
            from app.event_stream.da_prompt_injection import (
                event_injection_policy_hash,
            )
            _event_injection_hash = event_injection_policy_hash()
            if _event_injection_hash:
                payload["event_injection_hash"] = _event_injection_hash
        except Exception:
            pass
    return hashlib.sha256(
        json.dumps(payload, sort_keys=True, default=str).encode()).hexdigest()[:16]


def _ckpt_dir(output_dir: str, trade_date: str) -> str:
    return os.path.join(output_dir, "da_checkpoint", trade_date)


def _atomic_write_json(path: str, payload: Dict) -> None:
    """原子落盘 (tmp+fsync+os.replace): 并发读端永远看到旧整文件或新整文件,
    不会读到半截文件。(2026-09-01 红队复查修复: 旧 open("w")+json.dump 非原子,
    蒸馏影子 21:40 采集读 raw.json/checkpoint 时思考模式 DA 仍可能在写 →
    半文件 json.load 失败 → 丢样/误判损坏。tmp/.bak 后缀不匹配任何消费方
    的 *.json / *.raw.json glob: daily_llm_token_report / distill 影子 / glm 影子
    均已核对。) 替换前旧文件留 .bak (每文件一份滚动覆盖, 随日期目录过期清理)。"""
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, default=str)
        f.flush()
        os.fsync(f.fileno())
    if os.path.exists(path):
        try:
            import shutil as _sh_bak
            _sh_bak.copyfile(path, path + ".bak")
        except Exception:
            pass  # 备份失败不阻断主路径
    os.replace(tmp, path)


def _ckpt_save(output_dir: str, trade_date: str, analysis: Dict) -> None:
    """落盘单只标的完整 analysis。任何失败静默 — 缓存只是优化, 不影响正确性。"""
    try:
        d = _ckpt_dir(output_dir, trade_date)
        os.makedirs(d, exist_ok=True)
        sym = str(analysis.get("symbol", "")).replace("/", "_")
        # [P1.4] 策略口径指纹随分析落盘 —— 写**副本**, 不污染 analyses/bridge/adapter
        #   输出 (无消费方的字段不进生产载荷)。
        _payload = dict(analysis)
        _payload["_ckpt_policy"] = _ckpt_policy_version()
        # [RFC-208 bridge] 注入元数据只进 checkpoint 副本, 不回写 analysis
        #   (Gate/订单/候选排序不得消费 _event_context)。
        _event_ctx = analysis.get("_event_context") or (
            (analysis.get("_llm_output") or {}).get("_event_context"))
        if _event_ctx:
            _payload["_event_context"] = _event_ctx
        _atomic_write_json(os.path.join(d, f"{sym}.json"), _payload)
        # 清理过期日期目录 (>_CKPT_KEEP_DAYS)
        import shutil
        from datetime import datetime as _dt_c, timedelta as _td_c
        _root = os.path.join(output_dir, "da_checkpoint")
        _cutoff = _dt_c.strptime(trade_date, "%Y-%m-%d") - _td_c(days=_CKPT_KEEP_DAYS)
        for _name in os.listdir(_root):
            try:
                if _dt_c.strptime(_name, "%Y-%m-%d") < _cutoff:
                    shutil.rmtree(os.path.join(_root, _name), ignore_errors=True)
            except ValueError:
                pass  # 非日期目录不动
    except Exception as _ce:
        print(f"[Checkpoint] 落盘失败(不影响): {analysis.get('symbol')}: {_ce}",
              file=sys.stderr)


def _ckpt_save_raw(output_dir: str, trade_date: str, symbol: str, collected: Dict,
                   user_prompt: str = None, event_context: Dict = None) -> None:
    """生料快照落盘 (2026-09-01 信息供应链审计建议①, 用户裁"按建议处理").

    背景: 检查点只存分析结论, 不存当天实际喂给 LLM 的 19 维原始采集数据 —
    出错时无法回溯"模型当时看到了什么"(陈旧新闻? 缺维? 空壳?)。
    独立 {symbol}.raw.json 文件: 零侵入 _ckpt_load (读侧只认 {symbol}.json),
    过期清理随日期目录整体继承 (_CKPT_KEEP_DAYS)。失败仅留痕不阻断。

    v2 (2026-09-01 复查收口, 首夜前修正): collected 只含采集数据+管线级注入
    (sector/UE); llm_synth 调用时拼装的 5 段动态注入 (交易经验/负向论据警示/
    条件黑名单/股性卡/成交档案) 不在其中 — 只存 collected 无法逐字节重放模型
    实际所见。分析完成后带 user_prompt 二次调用回写 (读-改-写, 保留首轮
    collected); 消费方以 user_prompt 字段存在性判快照完整 (缓存命中的续跑
    候选无此字段)。
    """
    try:
        from datetime import datetime as _dt_r, timezone as _tz_r
        d = _ckpt_dir(output_dir, trade_date)
        os.makedirs(d, exist_ok=True)
        sym = str(symbol).replace("/", "_")
        p = os.path.join(d, f"{sym}.raw.json")
        payload = {
            "symbol": symbol,
            "trade_date": trade_date,
            "saved_at": _dt_r.now(_tz_r.utc).isoformat(timespec="seconds"),
            "schema": "da_raw_inputs/v2",
            "collected": collected,
        }
        if user_prompt is not None:
            # 二次调用: 保留首轮采集，但合并本轮修正后的 collected。
            # 2026-10-23: 原实现无条件沿用首轮 collected，导致 prev_close_reconcile
            # 在 synthesize 中修正过的 snapshot 从未写回 raw.json —— 模型 Prompt
            # 看到 78.83，审计/回放却读到 78.65。这里优先本轮值，snapshot 逐键合并
            # 以保留首轮独有字段。
            try:
                with open(p, encoding="utf-8") as _f:
                    _old = json.load(_f)
                if isinstance(_old, dict) and _old.get("collected"):
                    _old_c = _old.get("collected")
                    if isinstance(_old_c, dict) and isinstance(collected, dict):
                        _merged_c = dict(_old_c)
                        for _k, _v in collected.items():
                            if (_k == "snapshot" and isinstance(_v, dict)
                                    and isinstance(_merged_c.get("snapshot"), dict)):
                                _merged_c["snapshot"] = {
                                    **_merged_c["snapshot"], **_v}
                            else:
                                _merged_c[_k] = _v
                        _old["collected"] = _merged_c
                    _old["saved_at"] = payload["saved_at"]
                    _old["schema"] = payload["schema"]
                    payload = _old
            except Exception:
                pass
            payload["user_prompt"] = user_prompt
        if event_context is not None:
            # [RFC-208 bridge] 生料档登记注入元数据 (consumer: raw checkpoint /
            #   quality evaluator only)。首轮调用无此参数, 保持旧 payload 不变。
            payload["event_context"] = event_context
        _atomic_write_json(p, payload)
    except Exception as _re:
        print(f"[Checkpoint] 生料快照落盘失败(不影响分析): {symbol}: {_re}",
              file=sys.stderr)


def _ckpt_load(output_dir: str, trade_date: str, symbol: str, expect_model: str,
               expect_policy: str = None):
    """命中且模型/策略口径一致 → 返回完整 analysis; 否则 None (重新分析)。

    `expect_policy=None` 保持旧调用点行为 (只校验模型)。旧 checkpoint 无
    `_ckpt_policy` 字段 ⇒ 传入 expect_policy 时一律作废 (口径已变, 见
    `_ckpt_policy_version`)。
    """
    try:
        p = os.path.join(_ckpt_dir(output_dir, trade_date),
                         f"{symbol.replace('/', '_')}.json")
        if not os.path.exists(p):
            return None
        with open(p, encoding="utf-8") as f:
            _a = json.load(f)
        if str(_a.get("_ckpt_model", "")) != str(expect_model):
            print(f"[Checkpoint] {symbol} 模型变更({_a.get('_ckpt_model')}→"
                  f"{expect_model}), 缓存作废", file=sys.stderr)
            return None
        if expect_policy is not None and str(_a.get("_ckpt_policy", "")) != str(expect_policy):
            print(f"[Checkpoint] {symbol} 候选策略口径变更({_a.get('_ckpt_policy') or 'legacy'}→"
                  f"{expect_policy}), 缓存作废 (不复用不兼容分析)", file=sys.stderr)
            return None
        return _a
    except Exception as _le:
        print(f"[Checkpoint] {symbol} 读取失败(重新分析): {_le}", file=sys.stderr)
        return None


# ── UE→DA 候选管道 (2026-08-03, 用户裁"直接执行") ──────────────────
# 时序 (2026-09-09 更正 — 原写"UE 05:10 ET → DA 06:00 ET, age ~1h"与现实相反):
#   真实旧态 = UE scan cron 21:10 CST (09:10 ET) 在 DA cron 20:00 CST (08:00 ET) **之后**,
#   故 DA 每天读到的是**前一交易日**的 UE 行 (age ≈ 20.9h), 而 30h 守卫恰好放行 ⇒
#   静默消费隔夜陈旧事件候选; 跨周末/假日 age > 30h ⇒ 全拒 ⇒ 长假后 A 路必然断供。
#   实证: bridge 内 origin="ue_candidate" 计数 9/2=0 · 9/3=2 · 9/4=0 · 9/8=0
#   (9/8 DA 读到 9/4 09:11 ET 那行, age ≈ 92.8h → 拒)。近 4 交易日只通 1 次。
#   修后 = UE 一天两跑: 19:40 CST (07:40 ET) `scan --da-feed` 专供本函数 (age ≈ 20min),
#   21:10 CST (09:10 ET) 原 `scan && inject && push` 不动 (盘前量价峰值 + 早晨 8-K 流)。
#   两跑同写主 jsonl, 本函数取 scans[-1] ⇒ DA 20:00 必得 19:40 那行; inject/push/confirm
#   取 today[-1] 或按 scan_window=="premarket" 过滤 ⇒ 仍得 21:10 那行, 执行面零变化。
# 只取 SHORT: DA LONG 已过量供给 (07-20 以来 140 BUY / 0 SHORT), UE SHORT 是
#   唯一在产正 edge 供给源 (9 笔 7 胜 +$65.6)。
# 冲突守卫全部复用现有机制, 零新增: UNIQUE(date,symbol)+UPSERT 物理消灭重复;
#   DA 先写 06:36 ET, UE inject 09:10 ET 自带让路守卫 (llm_universe_scan.py cmd_inject)。
# 溯源: 写库 raw_instruction.origin="ue_candidate" — 字面量已验证不含
#   "universe_expansion"/"topup_pool", scorecard src_expr() 仍归 DA 源 (DA·SHORT 轴可见)。
_UE_SCAN_JSONL = "/opt/ftseek/FTSeek-US/data/shadow/llm_universe_scan.jsonl"
_UE_CONFIG_PATH = "/opt/ftseek/FTSeek-US/config/unified_config.yaml"
# 30.0 → 3.0 (2026-09-09): 30h 恰好放行"前一交易日 09:10 ET"的行 (age 20.9h) ⇒ 陈旧候选
#   静默入池, 是本管道半死的直接成因。UE 早跑改到 19:40 CST 后正常 age ≈ 0.3h; 收到 3.0h
#   使"早跑失败/被假日守卫跳过"从**静默用昨日候选**变成**显式拒绝并打 [UE-FEED] 日志**。
#   周五→周一仍天然拒绝 (>3h)。回滚: 本常量改回 30.0。
_UE_FEED_MAX_AGE_H = 3.0
_UE_FEED_CAP = 3            # 每日注入上限: 每标的 ~1-2min 采集 + 2 次 LLM, 防时长膨胀

# 2026-10-22 [RFC-159]: DA 侧杠杆/反向 ETF 前置过滤.
#   证据: 10/22 28 条 gate 中 8 条是 "2倍做空/做多 ... ETF", 全部缺 9 维数据 SKIP;
#   ext_entry 已用 name 含 ETF 过滤 (6/6, 0 误伤). DA 只过滤带杠杆/反向关键词的 ETF,
#   不碰 SPY/QQQ 等宽基 ETF. 回滚: universe_expansion.da_skip_leveraged_etf=false.
_DA_LEVERAGED_ETF_KEYWORDS = (
    "2X", "3X", "2倍", "3倍", "BULL", "BEAR", "ULTRA", "INVERSE",
    "做空", "做多", "杠杆",
)
_DA_SKIP_LEVERAGED_ETF = None


def _is_leveraged_etf_name(name: str) -> bool:
    up = str(name or "").upper()
    return "ETF" in up and any(k in up for k in _DA_LEVERAGED_ETF_KEYWORDS)


def _da_skip_leveraged_etf() -> bool:
    """配置开关 universe_expansion.da_skip_leveraged_etf; 读不到 => False (保持原行为)."""
    global _DA_SKIP_LEVERAGED_ETF
    if _DA_SKIP_LEVERAGED_ETF is None:
        try:
            import yaml
            with open(_UE_CONFIG_PATH, encoding="utf-8") as f:
                cfg = yaml.safe_load(f) or {}
            _DA_SKIP_LEVERAGED_ETF = bool(
                (cfg.get("universe_expansion") or {}).get("da_skip_leveraged_etf", False))
        except Exception:
            _DA_SKIP_LEVERAGED_ETF = False
    return _DA_SKIP_LEVERAGED_ETF


def _load_ue_short_candidates(max_age_hours: float = _UE_FEED_MAX_AGE_H,
                              window: str = "da_feed") -> List[Dict]:
    """读 UE 最新一次 scan 的可交易候选 (裸 symbol → US. 前缀归一)。

    [RFC-117 2026-09-29, 用户裁"有助于提升交易质量的可以直接上"] SHORT+LONG 双向:
      修前只取 SHORT ("DA LONG 已过量供给"是 2026-08-03 的口径), 但 9/29 反事实实测
      UE LONG 直写通道 (cmd_inject) 三笔大亏 QCOM/UBER/RIVN 合计 −$646, 其中两笔是
      空头排列破位硬买 (DA 择时闸会 SKIP) — UE LONG 缺的正是 DA 的多轮分析+择时闸。
      接入后 UE LONG 候选与 SHORT 同走 DA 深分析 (方向仍由 DA LLM 独立判定, 可确认/
      翻转), 与 cmd_inject 侧 long_momentum_gate (RFC-117 A 部分) 形成双保险:
      da_feed 窗 (07:40 ET) 候选过 DA 全套, premarket 窗 (09:10 ET) 直写候选过动量闸。
      函数名保留 `_load_ue_short_candidates` 不重命名 (调用点/测试契约稳定), 语义已扩展。
      borrow_feasible 过滤只对 SHORT 有意义 (LONG 无需借券), 按方向分支。

    回滚开关: unified_config.yaml universe_expansion.da_candidate_feed=false (整体),
    或 universe_expansion.da_candidate_feed_long=false (只关 LONG, 恢复 8/3 语义)。
    任何读取失败返回 [] (不注入, 不阻塞 DA 主流程)。
    """
    out: List[Dict] = []
    window = str(window or "da_feed")
    if window not in ("da_feed", "premarket"):
        print(f"[UE-FEED] 非法窗口 {window!r} → 不注入", file=sys.stderr)
        return out
    _ue_max_streak = 99  # 默认99=零行为 (与 FTSeek cmd_inject 同键)
    _feed_long = True
    try:
        import yaml
        with open(_UE_CONFIG_PATH, encoding="utf-8") as _f:
            _cfg = yaml.safe_load(_f) or {}
        if not (_cfg.get("universe_expansion") or {}).get("da_candidate_feed", True):
            print("[UE-FEED] da_candidate_feed=false, 跳过注入", file=sys.stderr)
            return out
        _feed_long = bool((_cfg.get("universe_expansion") or {}).get("da_candidate_feed_long", True))
        _ue_max_streak = int((_cfg.get("universe_expansion") or {}).get("max_emergence_streak", 99) or 99)
    except Exception:
        pass  # 配置读不到 → 默认开 (与 YAML 默认值一致); streak 默认99零行为
    try:
        with open(_UE_SCAN_JSONL, encoding="utf-8") as f:
            recs = [json.loads(l) for l in f if l.strip()]
    except Exception as e:
        print(f"[UE-FEED] 读取失败 (不注入): {e}", file=sys.stderr)
        return out
    # ── [P1.4 2026-09-12] 显式批次消费: 只认 scan_window=="da_feed" 的最新**有效**批次 ──
    #   修前 `scans[-1]` 的三个洞:
    #     ① da_feed (07:40 ET) 与 premarket (09:10 ET) / midday 同写主 jsonl,
    #        "当日最后一条 scan" 可能误消费**异窗**批次 (职责错位);
    #     ② 空扫描原先不落批次 ⇒ 静默回用更早 (可能隔夜/过期) 的候选;
    #     ③ 只看 scanned_at 年龄, 不校验批次是否失败/是否被更晚的尝试作废。
    #   修后复用 FTSeek `ue_batch.latest_valid_batch(..., window="da_feed")` **同一语义**:
    #     最新 batch_id 的终态记录必须是 type=="scan" 且 batch_status=="complete";
    #     时间戳缺失/无时区/未来/超龄一律拒 (不静默回用旧候选);
    #     空批次 (surfaced=[]) 是"当日无机会"的正常结束, 按空处理而非失败。
    #   max_age 优先读 `playbook.candidate_scan_max_age_hours` (与 UE inject 同一显式键),
    #   读不到退回本模块 `_UE_FEED_MAX_AGE_H`。deps 不可导入时退回本地"最后一行
    #   da_feed + 年龄"判定 (仍带窗口过滤, 不退回全窗口 scans[-1])。
    _deps_ue = _ftseek_screening_deps()
    _now_et_ue = _et_now()
    _today_et = _now_et_ue.strftime("%Y-%m-%d")
    _age_cap = max_age_hours
    if _deps_ue:
        try:
            _age_cap = float(_da_screening_thresholds().get("max_scan_age_hours")
                             or max_age_hours)
        except Exception:
            _age_cap = max_age_hours
        last, _batch_reason = _deps_ue["latest_valid_batch"](
            recs, _today_et, _now_et_ue, _age_cap, window=window)
        if last is None:
            print(f"[UE-FEED] 无有效 {window} 批次 ({_batch_reason}) → 不注入; "
                  f"不回用其他窗口/过期候选", file=sys.stderr)
            return out
    else:
        scans = [r for r in recs if r.get("type") == "scan"
                 and str(r.get("scan_window", "premarket")) == window]
        if not scans:
            print(f"[UE-FEED] 无 {window} scan 记录 → 不注入 (不回用异窗候选)",
                  file=sys.stderr)
            return out
        last = scans[-1]
        from datetime import datetime, timezone
        try:
            _sa = datetime.fromisoformat(str(last.get("scanned_at", "")))
            _age_h = (datetime.now(timezone.utc) - _sa).total_seconds() / 3600
            if _age_h > max_age_hours:
                print(f"[UE-FEED] 最新 {window} scan age {_age_h:.1f}h > "
                      f"{max_age_hours:g}h, 跳过 (周末/陈旧)", file=sys.stderr)
                return out
        except Exception:
            return out
    for s in last.get("surfaced", []):
        _dirn = str(s.get("direction") or "").upper()
        if _dirn not in ("SHORT", "LONG"):
            continue
        # [RFC-117 2026-09-29] LONG 腿独立开关: 关闭即恢复 2026-08-03 只取 SHORT 的原语义
        if _dirn == "LONG" and not _feed_long:
            continue
        _sym = str(s.get("symbol") or "").upper().strip()
        if not _sym:
            continue
        # DEB-20260814 §十二 (2026-08-14): 源头过滤 — 死候选不烧 DA LLM 额度.
        #   a. borrow_feasible=False: 借不到券的 SHORT = 死指令 (与 AETN OTC 案同类, 源头拦截)
        #   [U3 2026-08-25 结案] 原 b 项 (critique.verdict=DROP 过滤) 已删除:
        #     critique 调用同结案删除 (T+1 倒挂持续 + 实际账本 DROP 桶反而盈利 $+85),
        #     双端一致。恢复: git show c82adc6:scripts/pipeline.py (DROP 块)。
        #   scan 层不动 (量测不污染), 仅消费端过滤; stderr 留痕可审计. 回滚: DA_UE_SOURCE_FILTER=0.
        #   [RFC-117] borrow_feasible 只对 SHORT 有意义 (LONG 无需借券), 按方向分支。
        if os.environ.get("DA_UE_SOURCE_FILTER", "1") == "1":
            if _dirn == "SHORT":
                _sc = s.get("short_check") or {}
                if _sc.get("provided") and _sc.get("borrow_feasible") is False:
                    print(f"[UE-FEED] {_sym} borrow_feasible=False, 跳过 (不可借券SHORT)", file=sys.stderr)
                    continue
            # [U7 2026-08-25, REVIEW-20260824 裁决GO] streak 硬闸消费端 (与 FTSeek
            #   cmd_inject 同规则同键). SHORT 轴 OOS 免疫 (33条streak=1+1条streak=2,
            #   从未≥3), 此行是架构对称防御非当下止损. 默认99=零行为.
            _stk = s.get("emergence_streak_days") or 1
            if _stk > _ue_max_streak:
                print(f"[UE-FEED] {_sym} streak={_stk} > {_ue_max_streak}, 跳过 (续期衰减硬闸)",
                      file=sys.stderr)
                continue
        out.append({
            "symbol": _sym if "." in _sym else f"US.{_sym}",
            "ue_direction": _dirn,
            "ue_confidence": s.get("confidence"),
            "ue_thesis": s.get("thesis", ""),
            "ue_causal_chain": s.get("causal_chain", ""),
            "ue_evidence": s.get("evidence_ref", ""),
            "ue_scanned_at": last.get("scanned_at", ""),
            "ue_batch_id": last.get("batch_id", ""),
            # §十二 信息透传: 事件驱动判断必需字段 — 此前全部丢失, DA 被迫重新推导.
            "ue_invalidation": s.get("invalidation", ""),
            "ue_horizon_hours": s.get("horizon_hours"),
            "ue_expected_move_pct": s.get("expected_move_pct"),
            "ue_self_tier": s.get("self_tier", ""),
            "ue_evidence_citation_state": s.get("evidence_citation_state", ""),
            "ue_confidence_basis": s.get("confidence_basis", ""),
            "ue_confidence_calibration": s.get("confidence_calibration") or {},
            "ue_counter_evidence": s.get("counter_evidence", ""),
            "ue_event_phase": s.get("event_phase", ""),
            "ue_move_basis": s.get("move_basis", ""),
            "ue_transmission_confirmation_required": bool(
                s.get("transmission_confirmation_required", False)),
            "ue_critique": (s.get("critique") or {}).get("weakest_link", ""),
            "ue_short_check": s.get("short_check") or {},
            "ue_event_meta": s.get("evidence_matched_event_meta") or {},
            "ue_event_reaction": s.get("evidence_matched_event_reaction") or {},
            "ue_streak_days": s.get("emergence_streak_days"),
        })
    return out


def _merge_ue_candidates(deep_candidates: List[Dict], ue_cands: List[Dict],
                         cap: int = _UE_FEED_CAP) -> int:
    """UE 候选 (SHORT+LONG, RFC-117 起双向) 并入深度分析池 (原地修改)。已在池中的 symbol 不重复注入。"""
    _seen = {c["symbol"] for c in deep_candidates}
    _added = 0
    for _uc in ue_cands:
        if _added >= cap:
            break
        if _uc["symbol"] in _seen:
            continue
        _uc = dict(_uc)
        _uc["_source"] = "ue_candidate"
        deep_candidates.append(_uc)
        _seen.add(_uc["symbol"])
        _added += 1
    return _added


# UE 归因字段白名单 —— **只收能真正落地的键**, 与 `_mount_ue_attribution` 的挂载集
# 逐键对齐 (16 键)。实测 2026-10-10: 挂载集 == bridge 文件实际落盘的 ue_* 键集
# (data/opportunity_scan_2026-10-09.json 的 13 个键), 双向零差。
#
# 为什么不含 ue_thesis / ue_invalidation / ue_horizon_hours / ue_expected_move_pct /
# ue_self_tier / ue_critique / ue_streak_days (7 键):
#   它们的唯一消费点是 prompt 注入分支 (1397/1400-1424), 而该分支门控是
#   `_source=='ue_candidate'`; 本修复**刻意不改 `_source`** (保 DA) 以维持零行为变更
#   ⇒ 对重叠票这 7 键既进不了 prompt, 也不被 `_mount_ue_attribution` 挂到 analysis
#   ⇒ 回填它们 = 纯死字段 (只增数据噪声与漂移面)。
#   若将来放宽 1397 门控让重叠票也吃因果链, 那是**行为变更须影子先行**, 届时再同步扩本表。
#
# 2026-10-21: ue_short_check / ue_event_meta / ue_event_reaction 加入白名单 —— 它们
#   仍是 prompt-only (不改 _source, 不影响 LLM 输入), 但 FTSeek 的 quality_shadow 与
#   ue_da_chain_health 需要从 raw_instruction 读到借券 basis/事件属性/事件后反应;
#   此前被丢弃导致 health 误报 "UE 输入未送达" (10/20 NBIS 实为 MATERIAL)。
#
# 显式列举而非 "startswith('ue_')" 前缀通配: 前缀通配会把生产端将来新增的任何 ue_*
# 中间量自动回填进 DA 行, 静默改变下游语义 (且无法被测试发现漂移)。
_UE_ATTR_KEYS = (
    "ue_direction", "ue_confidence", "ue_causal_chain", "ue_evidence",
    "ue_scanned_at", "ue_batch_id", "ue_evidence_citation_state",
    "ue_confidence_basis", "ue_confidence_calibration", "ue_counter_evidence",
    "ue_event_phase", "ue_move_basis", "ue_transmission_confirmation_required",
    "ue_short_check", "ue_event_meta", "ue_event_reaction",
)


def _merge_ue_attribution_into_overlap(deep_candidates: List[Dict],
                                       ue_rows: List[Dict]) -> int:
    """重叠票 (UE 与 DA 池撞车) 的 UE 归因回填 —— **纯归因, 零行为变更**。

    病灶 (2026-10-10 实测 22 批全历史): `_select_eligible` 把撞车的 UE 行标
    `duplicate` ⇒ 它不进 `_ue_taken` ⇒ `_merge_ue_candidates` 的 `_seen` 跳过 ⇒
    UE 花 LLM 额度得出的 21 个 `ue_*` 字段 (方向/因果链/证据/反证/失效条件/催化剂时效)
    被静默丢弃, bridge candidates 与 raw_instruction 里 `ue_direction` 为空 ⇒
    下游与审计者误判「UE→DA 注入断了」(已连续误导两个独立审计)。
    实测: 撞车 21 次, 其中 UE 侧带 LONG/SHORT 21 次、DA 侧留存行方向为空 14 次 (67%);
    撞车票 UE 方向 vs DA 最终判定 = 一致 7 / **相反 4** (可判定样本 36% 相反)
    ⇒ UE 的事件推理非冗余信息, 丢归因有实际代价。

    ⚠️ 只回填 `ue_*` 字段, **不动** `_source` / `direction_hint` / `candidate_screening`:
      · `_source` 保持 DA ⇒ Stage3 的 prompt 注入 (`_source=='ue_candidate' and
        ue_causal_chain`) 不触发 ⇒ **LLM 看到的内容逐字不变** = 零行为变更;
        把因果链喂给 LLM 会改 prompt 输入 ⇒ 属行为变更, 须影子先行 (未做);
      · `direction_hint` 已在 `_screen_da_candidates` 定档并写进 `candidate_id` 与
        候选漏斗, 事后改写 = 归因与漏斗两张皮;
      · `_ue_origin` 仍为 False —— 它标记「UE 独有候选」, 重叠票语义上确是 DA 自选
        且 UE 也命中, 冒认成 UE 独有会污染 source_attribution 归因统计。
      ⇒ 唯一效果: bridge candidates / raw_instruction 的 `ue_*` 不再为空。
      另记 `_ue_overlap=True` 供审计区分「UE 独有注入」与「UE∩DA 重叠」。

    Returns: 回填的行数 (= 重叠票数)。
    """
    _by_sym: Dict[str, Dict] = {}
    for _u in ue_rows or []:
        _s = _canon_symbol(_u.get("symbol"))
        if _s and str(_u.get("ue_direction") or "").strip().upper() in ("LONG", "SHORT"):
            # 同票多批次取首条 (ue_rows 已按批次内顺序, 不额外排序 = 不改既有语义)
            _by_sym.setdefault(_s, _u)
    _merged = 0
    for _c in deep_candidates or []:
        _s = _canon_symbol(_c.get("symbol"))
        _u = _by_sym.get(_s)
        if _u is None:
            continue
        # 已有 UE 归因的行 (_source=='ue_candidate' 的独有注入) 不覆盖 — 它是权威来源
        if _c.get("_source") == "ue_candidate":
            continue
        for _k in _UE_ATTR_KEYS:
            if _k in _u and _u[_k] not in (None, "", {}, []):
                _c[_k] = _u[_k]
        _c["_ue_overlap"] = True
        _merged += 1
    return _merged


def _mount_ue_attribution(analysis: Dict, candidate: Dict) -> None:
    """把 candidate 上的 `ue_*` 归因挂到 analysis (Stage6b bridge 只读 analysis)。

    ⚠️ **必须在两个分支都调**: Stage3 有 checkpoint 缓存分支 (`_ck_cached_map`),
    命中时 `analyses.append(cached)` 后直接 `continue`。归因回填发生在候选层
    (`_merge_ue_attribution_into_overlap`), 而缓存里的 analysis 是**旧 LLM 产物**,
    不含本轮 UE∩DA 重叠归因 ⇒ 只在非缓存分支挂载 = 同日重跑命中缓存时归因被
    静默吞掉 (死门形态③: 产物被丢弃, 且表现为"有时有有时没有")。

    缓存内容**仍然有效**, 无需 bump `_ckpt_policy_version`: prompt 注入的门控是
    `_source=='ue_candidate'`, 重叠票的 `_source` 保持 DA ⇒ LLM 输入不含 ue_*,
    故 LLM 输出与 ue_* 元数据无因果关系, 重挂元数据不改任何已缓存的判定。
    """
    # 字面量 ue_candidate 已验证不污染 scorecard src_expr (无 universe_expansion 子串)
    analysis["_ue_origin"] = (candidate.get("_source") == "ue_candidate")
    analysis["_ue_direction"] = str(candidate.get("ue_direction") or "").upper()
    analysis["_ue_confidence"] = candidate.get("ue_confidence")
    analysis["_ue_scanned_at"] = candidate.get("ue_scanned_at", "")
    analysis["_ue_batch_id"] = candidate.get("ue_batch_id", "")
    analysis["_ue_evidence"] = candidate.get("ue_evidence", "")
    analysis["_ue_causal_chain"] = candidate.get("ue_causal_chain", "")
    analysis["_ue_evidence_citation_state"] = candidate.get("ue_evidence_citation_state", "")
    analysis["_ue_confidence_basis"] = candidate.get("ue_confidence_basis", "")
    analysis["_ue_confidence_calibration"] = candidate.get("ue_confidence_calibration") or {}
    analysis["_ue_counter_evidence"] = candidate.get("ue_counter_evidence", "")
    analysis["_ue_event_phase"] = candidate.get("ue_event_phase", "")
    analysis["_ue_move_basis"] = candidate.get("ue_move_basis", "")
    analysis["_ue_transmission_confirmation_required"] = bool(
        candidate.get("ue_transmission_confirmation_required", False))
    analysis["_ue_short_check"] = candidate.get("ue_short_check") or {}
    analysis["_ue_event_meta"] = candidate.get("ue_event_meta") or {}
    analysis["_ue_event_reaction"] = candidate.get("ue_event_reaction") or {}


def _mount_supply_attribution(analysis: Dict, candidate: Dict) -> None:
    analysis["_supply_selection"] = dict(candidate.get("_supply_selection") or {})


def _attach_recommendation_evidence(analysis: Dict, collected: Dict, candidate: Dict = None) -> Dict:
    import recommendation_evidence

    try:
        analysis["recommendation_evidence"] = recommendation_evidence.build_recommendation_evidence(
            collected, analysis, candidate)
    except Exception as error:
        analysis["recommendation_evidence"] = {
            "schema_version": "recommendation_evidence_v1",
            "status": "ERROR",
            "error": f"{type(error).__name__}: {error}"[:500],
        }
        print(f"[Evidence] {analysis.get('symbol', '?')} 证据卡生成失败(不影响候选): {error}",
              file=sys.stderr)
    return analysis


def _select_deep_candidates(scan_result: Dict, extra_symbols: List[str],
                            ue_candidates: List[Dict], *, top_n: int,
                            output_dir: str = "", batch_id: str = None,
                            ue_only: bool = False) -> Dict:
    """先过滤后预算的深度分析候选选择 (P1.4) — Stage2 的唯一裁决入口。

    全部输入可注入 (scan_result / extra_symbols / ue_candidates / top_n /
    output_dir / batch_id), 因此契约测试不需要跑 scanner、LLM 或触网;
    行情取数仍走 `_fetch_screening_atr` → `data_collector.collect_kline`
    (测试 monkeypatch 该函数即可)。

    预算边界全部沿用旧值: 主池 top_n+2 / extras 全量(只去重) /
    UE ≤ _UE_FEED_CAP / 盘前异动 ≤ 2。变的是**顺序**: 资格判定前置, 淘汰补位。

    Returns:
        {"deep_candidates", "selected_symbols", "screened", "batch_id", "filter"}
        — `selected_symbols` = **过滤后**实际提交深分析的名单 (修前记过滤前);
          `screened` = 全阶段候选漏斗原始行 (candidate_screening + selection_status)。
    """
    # 2026-07-18 (用户): 不再人为设定多/空配额 (原 bullish[:top_n] + bearish[:2] 非对称),
    #   改为合并两桶后按"方向信念强度(conviction)"统一择优取前 N。
    #   bullish 桶按高分排序、bearish 桶按低分入桶(score<=4), 故原始 score 非对称,
    #   用 conviction = score(多) / 10-score(空) 归一为"方向强度", 让信号本身决定多空占比。
    # ── [P1.4 2026-09-12, DEB-20260910] 先过滤后预算 — 三处修正 ──
    #   ① 池源: scanner 展示用的 top_bullish/top_bearish (已 [:top_n*2] 截断)
    #      → 完整分桶队列 bullish_all/bearish_all。展示 TopN 与选择解耦,
    #      最强空头不再在进池前就被丢掉 (配合 market_scanner BUCKET_ORDER_VERSION
    #      = bearish_conviction_v1 的桶内方向强度排序)。scanner 未提供完整队列时
    #      (旧版 market_scanner) 回退 top_* ⇒ 行为不劣化。
    #   ② 顺序: 资格判定 (价格地板 + 低 ATR 门) 从"取 K **之后**"前置到"取 K
    #      **之前**", 淘汰从剩余合格队列补位 ⇒ 深分析数不再低于预算。
    #   ③ 审计: selected_symbols 记**过滤后**实际提交深分析的名单 (修前记过滤前,
    #      与 Stage3 真正烧 LLM 的集合不符)。
    #   预算边界全部不变: 主池 top_n+2 / extras 全量 / UE ≤ _UE_FEED_CAP / 异动 ≤ 2。
    _reset_screening_cache()
    _screen_batch_id = batch_id or _da_batch_id()
    _pool = []
    if not ue_only:
        for _c in (scan_result.get("bullish_all") or scan_result.get("top_bullish") or []):
            _c = dict(_c); _c["_scan_side"] = "bullish"
            _c["_conviction"] = float(_c.get("score", 5) or 5)
            _pool.append(_c)
        for _c in (scan_result.get("bearish_all") or scan_result.get("top_bearish") or []):
            _c = dict(_c); _c["_scan_side"] = "bearish"
            _c["_conviction"] = 10.0 - float(_c.get("score", 5) or 5)
            _pool.append(_c)
    # 稳定 tie-break: conviction 相同按 (原序, symbol) —— 同分候选不再随重跑换人,
    #   使"实际提交深分析名单"可复现 (checkpoint 命中率与 P4 排序 A/B 归因都依赖它)。
    _pool = [dict(_c, _pool_seq=_i) for _i, _c in enumerate(_pool)]
    _pool.sort(key=lambda x: (-float(x.get("_conviction", 0) or 0),
                              int(x.get("_pool_seq", 0)),
                              str(x.get("symbol") or "")))
    # 取前 (top_n + 2): 与原配额上限 (5+2) 总量对齐, 但多空比例由信号强度决定。
    #   —— 预算不变, 只在**合格**队列内取; 被拒者不占名额, 由后续合格候选补位。
    _pool_screened = _screen_da_candidates(_pool, stage="da_main_pool",
                                           batch_id=_screen_batch_id)
    deep_candidates = _select_eligible(
        _pool_screened, top_n + 2, stage="da_main_pool",
        sort_key=lambda r: -float(r.get("_conviction", 0) or 0))
    _all_screened = list(_pool_screened)
    # 合并额外标的 (playbook watchlist) — 确保与 voting_llm symbol 集合重叠
    _existing = {_canon_symbol(c["symbol"]) for c in deep_candidates}
    _extra_rows = [{"symbol": sym, "_source": "watchlist"}
                   for sym in (extra_symbols or []) if _canon_symbol(sym) not in _existing]
    _extra_screened = _screen_da_candidates(_extra_rows, stage="da_extra_watchlist",
                                            batch_id=_screen_batch_id)
    _all_screened.extend(_extra_screened)
    # extras 原本无名额上限 (全量追加, 只去重) ⇒ 预算 = 去重后条数, 只做资格过滤。
    deep_candidates.extend(_select_eligible(_extra_screened, len(_extra_rows),
                                            stage="da_extra_watchlist",
                                            already_selected=_existing))
    _existing = {_canon_symbol(c["symbol"]) for c in deep_candidates}
    # ── UE→DA 候选管道 (2026-08-03): UE 今晨 SHORT 候选进深度分析池 ──
    # [RFC-117 2026-09-29] 双向: LONG 候选同样进池 (三笔大亏反事实, 见 _load_ue_short_candidates docstring)。
    # UE 只出候选+因果链, 方向由 DA LLM 独立判定 (确认/加厚/翻转), 不预设 SHORT/LONG。
    _ue_cands = list(ue_candidates or [])
    # [P1.4] UE feed 同样先筛后消费 _UE_FEED_CAP: 低价/低波/不可借券的 UE 候选
    #   不再占用 DA 的 3 个分析名额, 空出的名额由后续合格 UE 候选补位。
    #   [RFC-117] direction_hint 不再硬编码 SHORT — 每候选自带 ue_direction
    #   (_da_direction_hint 优先读它), fallback 留空防 LONG 行被错标 SHORT 口径。
    _ue_screened = _screen_da_candidates(_ue_cands, stage="da_ue_feed",
                                         batch_id=_screen_batch_id,
                                         direction_hint="")
    _all_screened.extend(_ue_screened)
    _ue_taken = _select_eligible(_ue_screened, _UE_FEED_CAP, stage="da_ue_feed",
                                 already_selected=_existing)
    _ue_added = _merge_ue_candidates(deep_candidates, _ue_taken)
    # [2026-10-10] 重叠票归因回填: 撞车的 UE 行被标 duplicate ⇒ 不进 _ue_taken,
    #   故用 _ue_screened (全集) 而非 _ue_taken 做来源。纯归因, 不改 _source/hint/prompt。
    _ue_overlap_merged = _merge_ue_attribution_into_overlap(deep_candidates, _ue_screened)
    if _ue_added or _ue_overlap_merged:
        print(f"[Pipeline] UE候选注入: +{_ue_added} "
              f"({[c['symbol'] for c in deep_candidates if c.get('_source')=='ue_candidate']})"
              f" | UE∩DA 重叠归因回填: {_ue_overlap_merged} "
              f"({[c['symbol'] for c in deep_candidates if c.get('_ue_overlap')]})",
              file=sys.stderr)
    _existing = {_canon_symbol(c["symbol"]) for c in deep_candidates}
    # ── 盘前异动→DA 候选管道 (2026-08-11, LIF 盲区修复): ──
    #   盘前 |涨跌|≥8% 的标的是隔夜信息重定价, 当日趋势第一信号;
    #   暴跌/暴涨票四信号分通常被压到 watchlist/avoid → 永远进不了深分析,
    #   故强制注入 top 2 (方向由 LLM 判定: 顺势做空/博反弹/回避)。
    #   判定用 "premarket_movers" in _channels — 多渠道命中时 _source 保留首渠道,
    #   用 channels 判定不漏标。
    _pm_cands = [] if ue_only else [
        c for c in scan_result.get("all_scored", [])
        if "premarket_movers" in (c.get("channels") or [])
        and abs(c.get("premarket_chg_pct", 0) or 0) >= 8.0]
    _pm_cands.sort(key=lambda x: abs(x.get("premarket_chg_pct", 0)), reverse=True)
    # [P1.4] 全量送筛 (不再 [:2] 先截断): 已在主池的重复项不占名额, 被资格拒绝的
    #   由后续合格异动补位。ATR 走本轮进程内缓存 (`_ATR_CACHE`), 与主池/extras
    #   重叠标的零额外取数; 异动集合本身已被 |chg|≥8% 阈值界定, 规模有界。
    _pm_screened = _screen_da_candidates(_pm_cands, stage="da_premarket_mover",
                                         batch_id=_screen_batch_id)
    _all_screened.extend(_pm_screened)
    _pm_taken = _select_eligible(_pm_screened, 2, stage="da_premarket_mover",
                                 already_selected=_existing)
    for _pc in _pm_taken:
        _pc["_source"] = "premarket_mover"
    deep_candidates.extend(_pm_taken)
    _pm_added = len(_pm_taken)
    if _pm_added:
        print(f"[Pipeline] 盘前异动注入: +{_pm_added} "
              f"({[c['symbol'] for c in deep_candidates if c.get('_source')=='premarket_mover']})",
              file=sys.stderr)
    for _candidate in deep_candidates:
        _stage = str((_candidate.get("candidate_screening") or {}).get("stage") or "")
        _rank = _candidate.get("selection_rank")
        _is_main = _stage == "da_main_pool"
        _cohort = ("main_pool_expansion_r8_10" if _is_main and _rank and _rank > 7
                   else "main_pool_base_r1_7" if _is_main else "non_main_pool")
        _candidate["_supply_selection"] = {
            "schema": "da_supply_selection_v1",
            "screen_batch_id": _screen_batch_id,
            "stage": _stage,
            "selection_rank": _rank,
            "main_pool_top_n": top_n if _is_main else None,
            "main_pool_budget": top_n + 2 if _is_main else None,
            "baseline_main_pool_budget": 7 if _is_main else None,
            "cohort": _cohort,
        }
    # 候选漏斗: 按批次落 JSONL (与 FTSeek UE 侧同一 schema/同一文件), best-effort。
    _screen_summary = _screening_summary(_all_screened)
    _record_da_funnel(output_dir, _all_screened, _screen_batch_id)
    _filter_stats = {
        "input": scan_result.get("candidates_total", scan_result.get("candidate_count", 0)),
        "output": len(deep_candidates),
        # [P1.4] = **过滤后**实际提交深分析的名单 (Stage3 逐股循环消费同一列表)。
        "selected_symbols": [c["symbol"] for c in deep_candidates],
        "ue_candidate_injected": _ue_added,
        # [2026-10-10] 重叠票归因回填数 (埋点: 无此字段则修复生效与否不可审计)
        "ue_overlap_attributed": _ue_overlap_merged,
        "premarket_mover_injected": _pm_added,
        "screen_batch_id": _screen_batch_id,
        "screen_policy_version": _da_screening_thresholds().get("version"),
        "screen_thresholds": {
            "min_price": _da_screening_thresholds().get("min_price"),
            "min_atr_pct": round(float(_da_screening_thresholds().get("min_atr_ratio")
                                       or 0) * 100, 4),
            "config_source": _da_screening_thresholds().get("config_source"),
        },
        "bucket_order_version": scan_result.get("bucket_order_version"),
        "pool_size": len(_pool),
        "screening": _screen_summary,
    }
    print(f"[Pipeline] 筛选: 池 {len(_pool)} → 提交深分析 {len(deep_candidates)}只 "
          f"(资格拒绝 {_screen_summary['eligibility'].get('REJECT', 0)}, "
          f"预算外 {_screen_summary['selection'].get('budget_cut', 0)}, "
          f"重复 {_screen_summary['selection'].get('duplicate', 0)})", file=sys.stderr)
    return {
        "deep_candidates": deep_candidates,
        "selected_symbols": [c["symbol"] for c in deep_candidates],
        "screened": _all_screened,
        "batch_id": _screen_batch_id,
        "filter": _filter_stats,
    }


# ── 板块上下文 (2026-07-28 板块级联批; 2026-09-14 P1-1 加日期/新鲜度守卫) ──────
#   产出注入每个候选标的的 collected["sector_context"], 由 llm_synth 材料展示。
#   `today_et` / `pulse_path` 两个参数**仅为可测性注入** (生产走默认值) ——
#   仓内侧 tests/test_da_sector_pulse_freshness.py 用它构造"周一跨周末""脉搏
#   cron 挂掉"等时点, 否则守卫只能靠源码棘轮, 测不到行为。
def build_sector_context(scan_result: Dict, today_et=None, pulse_path: str = None) -> str:
    """构建"当前快照板块ETF涨跌 + 上一交易日盘中板块脉搏"文本 (可能为空串)。

    病根 (2026-09-14 盘前数据有效性审计 P1-1, 用户裁「全部处理」):
      DA 跑 08:00 ET **盘前**, 而 `data/sector_pulse.json` 由 sector_pulse.py 在
      **盘中 15:30 ET** 生成 ⇒ DA 看到的那份**永远是上一交易日**的脉搏 (周一更跨
      周末 = 3 天前); 若脉搏 cron 挂掉则是任意久的旧文件。原实现只要文件存在就注入,
      且标签写成 "盘中板块脉搏(15:30 ET)" —— **无日期**, 读起来就是"今天盘中"。
      后果: 模型把上一交易日尾盘的板块强弱当成今日实时轮动, 据此判个股板块顺风/逆风
      (同族病灶: LIF 盘前盲区 —— 时点不清的值直接喂给模型)。

    修法: ① 标签补日期并改称"上一交易日"; ② 只接受日期 == **上一个已收盘交易日**
      (当日 15:30 的脉搏此刻尚未产生) 的脉搏, 否则丢弃并在 stderr 具名报警。
      宁可无板块脉搏, 不可把旧脉搏冒充盘中。与 UE 侧 date 守卫
      (scripts/llm_universe_scan.py:996) 对齐。

    ⚠️ 刻意 fail-open: 交易日历不可用时**保留涨跌段、丢弃脉搏段** (DA 主链不因
      日历故障中断); 但绝不在日期未校验的情况下注入脉搏。
    回滚: pipeline.py.bak-deb20260914-vix (整段还原)。
    """
    import json as _pj
    import os as _po

    base = ""
    try:
        _sr0 = scan_result.get("sector_rotation", {}) or {}
        _chg0 = _sr0.get("sector_changes", {}) or {}
        if _chg0:
            _rk = sorted(_chg0.items(), key=lambda x: x[1])
            # scanner 的 sector_changes 来自板块ETF实时快照, 不是上一交易日收盘。
            # 只有下方 sector_pulse 才是上一交易日盘中脉搏, 两者必须分开标注。
            base = ("板块ETF涨跌(口径: last_price vs 前收 = **上一交易日日涨跌**, 非今日盘前; 弱→强): "
                    + ", ".join(f"{k}({v:+.2f}%)" for k, v in _rk))
            # [2026-11-06 口径修正+缺失外露] ①原标签"当前快照板块ETF涨跌"实为 last vs 前收
            #   (= 上一交易日日涨跌), 与下方 sector_pulse(昨收盘中脉搏) 口径不同却标签相似;
            #   ②缺失板块原实现写 0.00% 并参与排序 ⇒ 实测 XLK 真实 -8.00% 被写成"最强"。
            #   缺失必须显式声明且不得参与强弱判断。
            _miss_sec = _sr0.get("missing_sectors") or []
            if _miss_sec:
                _tot_sec = len(_chg0) + len(_miss_sec)
                base += (f" ⚠️ 板块快照不完整 {len(_chg0)}/{_tot_sec}, 缺失: "
                         f"{', '.join(_miss_sec)} — 缺失板块不参与强弱判断")

        _pulse_f = pulse_path or "/opt/ftseek/FTSeek-US/data/sector_pulse.json"
        if _po.path.exists(_pulse_f):
            with open(_pulse_f) as _pf:
                _pu = _pj.load(_pf)
            _pu_date = str(_pu.get("date", "") or "")
            try:
                import trading_calendar as _tc
                from datetime import timedelta as _td
                if today_et is None:
                    today_et = _tc.today_et()
                _want = _tc.latest_trading_day(today_et - _td(days=1))[0].isoformat()
            except Exception as _tce:
                _want = ""
                print(f"[Pipeline] 交易日历取值失败({_tce}) → 板块脉搏不注入", file=sys.stderr)
            if _pu.get("ranked") and _want and _pu_date == _want:
                base += (f"\n上一交易日({_pu_date})盘中板块脉搏"
                         f"({_pu.get('asof_et','?')} ET, 弱→强): "
                         + ", ".join(_pu["ranked"]))
            elif _pu.get("ranked"):
                print(f"[Pipeline] ⚠️ 板块脉搏过期/日期不符 (文件 date={_pu_date!r}, "
                      f"期望上一交易日={_want!r}) → 已丢弃, 不注入候选材料",
                      file=sys.stderr)
    except Exception as _sce:
        print(f"[Pipeline] 板块上下文构建失败(不影响): {_sce}", file=sys.stderr)
    return base


class Pipeline:
    """5阶段编排器 — 各阶段lazy import，单模块故障不阻塞其他阶段。"""
    def __init__(self, market: str = "US", scan_limit: int = 10, top_n: int = 5,
                 extra_symbols: list = None, output_dir: str = "",
                 db_write: bool = True, pool_write: bool = True,
                 ue_window: str = "da_feed", ue_only: bool = False):
        self.market = market
        self.scan_limit = scan_limit
        self.top_n = top_n
        self.extra_symbols = extra_symbols or []
        # 2026-08-03 A/B 隔离: output_dir 重定向 bridge/pool/blacklist/sector/gate-jsonl
        #   全部文件输出; db_write=False 跳过 PlaybookDB 指令直写 + IC snapshot +
        #   飞书推送 + Obsidian 归档; pool_write=False 跳过 daily_active_pool 落盘.
        #   默认全 True/生产目录 — 生产行为零变化.
        self.output_dir = output_dir or "/opt/ftseek/FTSeek-US/data"
        self.db_write = db_write
        self.pool_write = pool_write
        self.ue_window = ue_window
        self.ue_only = ue_only

    def run_full(self, scan_result: Dict = None) -> Dict:
        results = {"pipeline_start": time.time(), "stages": {}}

        # ── Stage 1: Signal (市场扫描) ──────────────
        if scan_result is None:
            print("\n" + "="*60, file=sys.stderr)
            print("STAGE 1: SIGNAL — 市场扫描", file=sys.stderr)
            print("="*60, file=sys.stderr)

            try:
                import market_scanner
                scanner = market_scanner.MarketScanner(self.market, self.scan_limit)
                scan_result = scanner.scan(self.top_n * 2)
            except Exception as e:
                scan_result = {"error": str(e), "market_condition": f"扫描失败: {e}",
                              "candidates_total": 0, "top_bullish": [], "top_bearish": [], "all_scored": []}
                print(f"[Pipeline] 扫描失败: {e}", file=sys.stderr)
        else:
            print("[Pipeline] fresh_event: 复用当日市场上下文, 跳过 Stage1 重扫", file=sys.stderr)
        results["stages"]["signal"] = {
            "market_condition": scan_result.get("market_condition", ""),
            "candidates_total": scan_result.get(
                "candidates_total", scan_result.get("candidate_count", 0)),
        }
        print(f"[Pipeline] 扫描完成: {results['stages']['signal']['candidates_total']}只候选", file=sys.stderr)

        # ── Stage 2: Filter (筛选) ──────────────────
        print("\n" + "="*60, file=sys.stderr)
        print("STAGE 2: FILTER — 筛选", file=sys.stderr)
        print("="*60, file=sys.stderr)

        # ── [P1.4 2026-09-12] Stage2 裁决收敛到单一可测入口 `_select_deep_candidates()` ──
        #   先过滤后预算 / 完整分桶队列 / 补位 / 跨来源去重 / 漏斗落盘 全在该函数内,
        #   run_full 只消费结果 ⇒ 契约测试可直接注入 scan_result, 无需跑 LLM/触网。
        _selection = _select_deep_candidates(
            scan_result, self.extra_symbols,
            _load_ue_short_candidates(window=self.ue_window),
            top_n=self.top_n, output_dir=self.output_dir,
            ue_only=self.ue_only)
        deep_candidates = _selection["deep_candidates"]
        results["stages"]["filter"] = _selection["filter"]
        # pool / bridge / DailyActivePool 消费同一候选裁决结果 (P1.4 ④)。
        _da_selected_symbols = _selection["selected_symbols"]

        # ── Stage 3: Output (深度分析) ──────────────
        print("\n" + "="*60, file=sys.stderr)
        print("STAGE 3: OUTPUT — 深度分析", file=sys.stderr)
        print("="*60, file=sys.stderr)

        # ── 2026-07-28 (板块级联批): 板块上下文构建 — scanner 的 rotation 此前只在
        #   尾部写文件给别人, 自己的个股分析全程没用 (07-27 明知 Technology 最弱仍 12/12 LONG)。
        #   注入每个标的的 collected["sector_context"], llm_synth 材料展示。
        #   2026-09-14 (P1-1): 逻辑抽到模块级 `build_sector_context()` —— 日期守卫
        #   需要可注入日期才测得了 (仓内侧 tests/test_da_sector_pulse_freshness.py)。
        _sector_ctx_base = build_sector_context(scan_result)
        _scan_market_condition = str(scan_result.get("market_condition", "") or "").strip()
        _symbol_sectors = (scan_result.get("sector_rotation", {}) or {}).get("symbol_sectors", {}) or {}

        analyses = []
        # scanner方向标记：bullish→做多侧, bearish→做空侧
        # 注入analysis供signal_gate检测方向冲突
        # ── 2026-07-28 (提速批): 两阶段执行 — 重活(数据采集+2次LLM)并发3, 落盘类
        #   副作用(gate jsonl/ic_writer sqlite/obsidian)留主线程串行 = 零并发写风险。
        #   1h42m 的结构 = 串行 for × ~25标的 × (采集1-2min + LLM×2); 并发3 预期 ~40min。
        #   质量零变化: 同模型同 prompt 同材料, 只改执行顺序。回滚: pipeline.py.bak-20260728_cascade。
        def _analyze_one(_idx, _cand):
            _sym = _cand["symbol"]
            try:
                import data_collector, deep_analyzer
                _data = data_collector.collect_all(_sym)
                if _sector_ctx_base:
                    _own = _symbol_sectors.get(_sym, "")
                    _data["sector_context"] = ((f"本股所属板块: {_own}\n" if _own else "")
                                               + _sector_ctx_base)
                if _scan_market_condition:
                    _market_context = _data.get("market_context")
                    if not isinstance(_market_context, dict):
                        _market_context = {}
                    else:
                        _market_context = dict(_market_context)
                    _market_context["scan_condition"] = _scan_market_condition
                    _data["market_context"] = _market_context
                # UE→DA 候选管道: UE 的因果链作为"待验证假设"注入材料, 方向仍由 LLM 独立判定
                if _cand.get("_source") == "ue_candidate" and _cand.get("ue_causal_chain"):
                    _ue_extra = []
                    # §十二 (2026-08-14): 事件驱动必需字段透传 — 催化剂时效/失效条件/期望波幅
                    if _cand.get("ue_horizon_hours"):
                        _ue_extra.append(f"催化剂时效: 约 {_cand['ue_horizon_hours']} 小时 (超时效事件失效, 逻辑不再成立)")
                    if _cand.get("ue_expected_move_pct") is not None:
                        _ue_extra.append(f"UE 期望波幅: {_cand['ue_expected_move_pct']:+.1f}%")
                    if _cand.get("ue_invalidation"):
                        _ue_extra.append(f"UE 失效条件: {_cand['ue_invalidation']}")
                    if _cand.get("ue_self_tier"):
                        _ue_extra.append(f"UE 事件层级: {_cand['ue_self_tier']}")
                    if _cand.get("ue_evidence_citation_state"):
                        _ue_extra.append(f"UE 引证关联: {_cand['ue_evidence_citation_state']}")
                    if _cand.get("ue_confidence_basis"):
                        _ue_extra.append(f"UE 置信依据: {_cand['ue_confidence_basis']}")
                    if _cand.get("ue_counter_evidence"):
                        _ue_extra.append(f"UE 反证: {_cand['ue_counter_evidence']} (必须正面回应)")
                    if _cand.get("ue_event_phase"):
                        _ue_extra.append(f"UE 事件阶段: {_cand['ue_event_phase']}")
                    if _cand.get("ue_move_basis"):
                        _ue_extra.append(f"UE 波幅依据: {_cand['ue_move_basis']}")
                    if _cand.get("ue_critique"):
                        _ue_extra.append(f"UE 自评最弱环: {_cand['ue_critique']} (独立核验此点)")
                    _em = _cand.get("ue_event_meta") or {}
                    if isinstance(_em, dict) and _em:
                        _ue_extra.append(
                            f"UE 事件属性: family={_em.get('event_family') or '?'} "
                            f"form={_em.get('form') or '?'}")
                    _er = _cand.get("ue_event_reaction") or {}
                    if isinstance(_er, dict):
                        try:
                            _er_pct = float(_er.get("post_event_move_pct"))
                        except (TypeError, ValueError):
                            _er_pct = None
                        if _er_pct is not None:
                            _er_age = _er.get("age_h")
                            _er_age_txt = (
                                f"{float(_er_age):.1f}h" if _er_age is not None else "?")
                            _ue_extra.append(
                                f"UE 事件反应: {_er_pct:+.2f}% "
                                f"({_er.get('reaction_basis') or '?'}, {_er_age_txt}前)")
                    _sc = _cand.get("ue_short_check") or {}
                    if _sc.get("provided"):
                        _ue_extra.append(f"UE SHORT三问: 可借券={_sc.get('borrow_feasible')} "
                                         f"basis={_sc.get('borrow_data_basis') or 'UNKNOWN'} "
                                         f"催化剂时效={_sc.get('downside_catalyst_expiry_hours')}h "
                                         f"逼空风险={_sc.get('squeeze_risk')}/5")
                    # [RFC-117 2026-09-29] 方向感知文案: feed 已双向 (SHORT+LONG),
                    # 对 LONG 候选谎称"SHORT候选"= 输入层失实 (llm-decision-input-audit 纪律)。
                    _ue_dirn = str(_cand.get("ue_direction") or "SHORT").upper()
                    _data["ue_candidate_context"] = (
                        f"事件扫描器(UE)今晨浮现该标的为{_ue_dirn}候选 (conf={_cand.get('ue_confidence')}):\n"
                        f"因果链: {_cand.get('ue_causal_chain')}\n"
                        f"证据: {_cand.get('ue_evidence')}\n"
                        + ("\n".join(_ue_extra) + "\n" if _ue_extra else "")
                        + f"注意: 这是待验证假设, 不是结论 — 用你采集的真实数据独立判断方向, "
                        f"可以确认/加厚/翻转。")
                # 生料快照(首轮): 采集数据+管线级注入 (sector/UE)
                # (_ck_date 闭包: 定义于 575 行, futures 590 行提交, 时序恒安全)
                _ckpt_save_raw(self.output_dir, _ck_date, _sym, _data)
                _analyzer = deep_analyzer.DeepAnalyzer(_data)
                _an = _analyzer.analyze()
                _attach_recommendation_evidence(_an, _data, _cand)
                # 生料快照 v2 补全 (2026-09-01 复查收口): llm_synth 拼装的最终
                # user_prompt (含 5 段调用时注入) 写回生料档; pop 防 {symbol}.json
                # 分析档膨胀。LLM 失败路径无 _user_prompt → 生料档留首轮 collected。
                _uprompt = ((_an or {}).get("_llm_output") or {}).pop("_user_prompt", None)
                if _uprompt:
                    # [RFC-208 bridge] 注入元数据随生料档落盘 (raw checkpoint
                    #   是登记消费方之一; Gate/订单不读)。
                    _event_ctx_raw = ((_an or {}).get("_llm_output") or {}).get(
                        "_event_context")
                    _ckpt_save_raw(self.output_dir, _ck_date, _sym, _data,
                                   user_prompt=_uprompt,
                                   event_context=_event_ctx_raw)
                print(f"[Pipeline] 重活完成 {_idx+1}/{len(deep_candidates)}: {_sym} OK", file=sys.stderr)
                return _idx, _an, _data.get("_quality", {}), None
            except Exception as _e:
                print(f"[Pipeline] 重活失败 {_idx+1}/{len(deep_candidates)}: {_sym} {_e}", file=sys.stderr)
                return _idx, None, {}, _e

        # 2026-07-28 v2 (用户点破 A2 原子性风险): 原 v1 "全部完成才落盘" — 并发段
        #   (~40min) 进程死亡丢整批 (旧串行只丢尾部)。改按序流式消费: futures 后台
        #   并发, 主循环按序等第 i 个完成即落盘第 i 个 → 逐股持久化原子性 = 旧模式,
        #   提速不变 (第 i 个落盘时 i+1/i+2 在后台跑)。
        from concurrent.futures import ThreadPoolExecutor
        # 2026-08-03 (任务#6 提速): 3→5, env DA_MAX_WORKERS 可调. 15 候选 ~30min → ~20min.
        #   每 worker = 数据采集 + 2 次 LLM (分析+辩论), 5 并发对 DashScope/Futu 配额安全.
        # 2026-11-17 (DEB-20261117-da-analyst-qwen4max): 5→8 — qwen4-max 分析师
        #   ~400s/候选 + 挑战者 ~240s, 32 候选/5 worker ≈ 68min 越 carrier 0857 ET
        #   死线 (08:00 发车, 57min 窗); 8 worker ≈ 43min 留 ~14min 余量.
        #   并发=8 路 DashScope 长请求 (QPM 远低于配额) + 8 路 Futu 采集.
        #   回滚: env DA_MAX_WORKERS=5 或本行默认值改回 (备份
        #   pipeline.py.bak-workers8-20261117).
        _workers = int(os.environ.get("DA_MAX_WORKERS", "8"))
        _pool_ex = ThreadPoolExecutor(max_workers=_workers, thread_name_prefix="da-analyze")

        # ── 断点续跑 (2026-08-24): 先判缓存, 只为未命中的提交重活 ──
        #   关键: 不能先提交全部 future 再跳过 — 那样已缓存的标的照样在后台烧
        #   数据采集+2次LLM, 违背续跑初衷。故先扫一遍缓存, 命中的直接复用,
        #    未命中的才 submit。ET 日期统一走 zoneinfo 真源 (`_et_now`)，
        #    不再用 3-11 月粗近似 (EST 过渡窗会错 1h)。
        _ck_date = _et_now().strftime("%Y-%m-%d")
        _ck_on = os.environ.get("DA_RESUME_CACHE", "1") != "0"
        # [P1.4] 候选策略口径指纹 (阈值/分桶排序/先过滤后预算 变了即作废全部缓存)
        _ck_policy = _ckpt_policy_version() if _ck_on else None
        _ck_cached_map = {}   # i -> analysis (命中缓存)
        if _ck_on:
            for _i, _c in enumerate(deep_candidates):
                _got = _ckpt_load(self.output_dir, _ck_date, _c["symbol"],
                                  config.LLM_MODEL, expect_policy=_ck_policy)
                if _got is not None:
                    _ck_cached_map[_i] = _got
            if _ck_cached_map:
                print(f"[Checkpoint] 命中缓存 {len(_ck_cached_map)}/{len(deep_candidates)} 只 "
                      f"(跳过重活+副作用): "
                      f"{[deep_candidates[i]['symbol'] for i in sorted(_ck_cached_map)]}",
                      file=sys.stderr)
        _ck_hits = len(_ck_cached_map)
        # 只为未命中的提交重活 (index 对齐 deep_candidates)
        _fut_map = {_i: _pool_ex.submit(_analyze_one, _i, _c)
                    for _i, _c in enumerate(deep_candidates) if _i not in _ck_cached_map}

        for i, candidate in enumerate(deep_candidates):
            symbol = candidate["symbol"]
            print(f"\n[Pipeline] 深度分析 {i+1}/{len(deep_candidates)}: {symbol}", file=sys.stderr)

            # ── checkpoint 命中: 完整 analysis 复用, 跳过重活与副作用 (不重复
            #    gate jsonl/IC/Obsidian 写入) ──
            if i in _ck_cached_map:
                _cached = _ck_cached_map[i]
                # [2026-10-10] 缓存命中也必须重挂 UE 归因: 缓存里是**旧 LLM 产物**,
                #   不含本轮 UE∩DA 重叠回填的 ue_* ⇒ 不重挂则同日重跑时归因静默丢失
                #   (死门形态③)。重挂安全: prompt 门控是 _source=='ue_candidate', 重叠票
                #   保持 DA ⇒ LLM 输入/输出与 ue_* 无因果, 缓存判定不被改写。
                _mount_ue_attribution(_cached, candidate)
                _mount_supply_attribution(_cached, candidate)
                analyses.append(_cached)
                print(f"  [Checkpoint] 命中缓存: {_cached.get('rating', '?')} "
                      f"({_cached.get('score', '?')}/10), 跳过重活", file=sys.stderr)
                continue

            scanner_dir = "bullish" if candidate in scan_result.get("top_bullish", []) else "bearish"

            try:
                # 2026-07-28 v2 (流式): 按序阻塞取本股结果 — 取到即落盘, 不等全批
                _idx_r, _pre_an, _pre_q, _pre_err = _fut_map[i].result()
                if _pre_err is not None or _pre_an is None:
                    raise _pre_err or RuntimeError("并发分析结果缺失")
                print(f"  数据采集: {_pre_q}", file=sys.stderr)
                analysis = _pre_an
                # 2026-07-13 (用户A): _scanner_direction 改用"该股真实动量"(MA5/10/20排列),
                # 不再用"是否在scanner top_bullish名单里"这个代理(对watchlist名单恒为bearish的bug).
                # 只有明确趋势(多头/空头排列)才给方向; 短期偏多/偏空/震荡/无数据→不判冲突(避免误伤).
                _trend = (analysis.get("technical") or {}).get("trend", "")
                if _trend == "多头排列":
                    analysis["_scanner_direction"] = "bullish"
                elif _trend == "空头排列":
                    analysis["_scanner_direction"] = "bearish"
                else:
                    analysis["_scanner_direction"] = ""
                # v0.23: 把scanner的strategy_type/position_size_hint/signal_scores注入analysis
                # 这样ic_writer写入factors_json时能带上这些字段
                # 修正: 如果LLM方向和scanner分桶矛盾, 用LLM方向重新判定strategy_type
                _llm_direction = analysis.get("action", "SKIP")
                _scanner_st = candidate.get("strategy_type", "")
                _scanner_bucket = candidate.get("bucket_reason", "")
                # 简单一致性检查: scanner=bearish桶(trend_short/avoid)但LLM=BUY → 降级为watch
                if _scanner_st in ("trend_short", "avoid") and _llm_direction == "BUY":
                    analysis["strategy_type"] = "watch"
                    analysis["position_size_hint"] = "small"
                    analysis["bucket_reason"] = f"LLM与scanner矛盾(scanner={_scanner_bucket},LLM=BUY)"
                elif _scanner_st in ("quality_breakout", "oversold_bounce") and _llm_direction == "SELL_SHORT":
                    analysis["strategy_type"] = "watch"
                    analysis["position_size_hint"] = "small"
                    analysis["bucket_reason"] = f"LLM与scanner矛盾(scanner={_scanner_bucket},LLM=SHORT)"
                else:
                    analysis["strategy_type"] = _scanner_st
                    analysis["position_size_hint"] = candidate.get("position_size_hint", "")
                    analysis["bucket_reason"] = _scanner_bucket
                analysis["signal_scores"] = candidate.get("signal_scores", {})
                # UE→DA 候选管道溯源 (2026-08-03; 2026-10-10 抽函数供缓存分支共用)
                _mount_ue_attribution(analysis, candidate)
            except Exception as e:
                analysis = {"symbol": symbol, "rating": "错误", "score": 0,
                           "conclusion": f"分析失败: {e}", "data_quality": {"ok":0,"total":0,"coverage_pct":0},
                           "bull_reasons": [], "bear_reasons": [], "constraints": [], "risks": [str(e)]}
                print(f"  分析失败: {e}", file=sys.stderr)
            _mount_supply_attribution(analysis, candidate)
            analyses.append(analysis)
            print(f"  评级: {analysis['rating']} ({analysis['score']}/10)", file=sys.stderr)

            # ── Signal Gate + IC写入 (gate先, ic_writer后, 让gate数据进factors_json) ──
            # 2026-07-10: 交换顺序 — gate必须在ic_writer之前, 这样factors_enriched能
            # 编码gate_decision+quality_score, 让alpha_backfill能按gate分组计算IC,
            # 量化"BLOCK掉的信号如果执行了会怎样"。
            # 2026-08-04 (P1): 算一次 regime 注入 analysis (gate 6.8 消费, 避免逐股重复
            # 网络拉取 MarketRegimeGate; 与 _write_bridge_file 的 _regime_fields 同源).
            try:
                import sys as _sys_rg2
                _sys_rg2.path.insert(0, "/opt/ftseek/FTSeek-US")
                from app.playbook.market_regime import MarketRegimeGate as _MRG2
                analysis["_regime"] = _MRG2().assess().regime.value
            except Exception:
                analysis["_regime"] = None
            try:
                import signal_gate
                gate_result = signal_gate.evaluate_signal(analysis)
                analysis["_signal_gate"] = gate_result
                print(f"  Gate: {gate_result['decision']} score={gate_result['quality_score']}", file=sys.stderr)
                # 2026-07-13: gate 决策落盘 (观测性) — 专用文件, 不碰 trade_guard 的 guard_decisions.jsonl
                try:
                    import json as _json_g
                    _et_g = _et_now()
                    # [DEB-20260825 第13轮 P6] 台账补字段所需的三个子结构
                    _lo_g = analysis.get("_llm_output") or {}
                    _dbg_g = _lo_g.get("_debate") or {}
                    _plan_g = _lo_g.get("execution_plan") or {}
                    _val_g = _dbg_g.get("challenger_validation") or {}
                    _rec_g = {
                        "datetime": _et_g.isoformat(),
                        "trade_date": _et_g.strftime("%Y-%m-%d"),
                        "symbol": analysis.get("symbol", ""),
                        "direction": analysis.get("action", "SKIP"),
                        "decision": gate_result.get("decision", ""),
                        "quality_score": gate_result.get("quality_score", 0),
                        "tier": gate_result.get("tier", ""),
                        "position_size_hint": gate_result.get("strategy_hint", {}).get("position_size_hint", ""),
                        "source": "deep_analysis",
                        "reasons": gate_result.get("reasons", []),
                        "decision_conf": gate_result.get("decision_conf"),
                        "supply_selection": analysis.get("_supply_selection") or {},
                        "shadow_llm_self_tier": gate_result.get("shadow_llm_self_tier", ""),
                        "shadow_llm_self_decision": gate_result.get("shadow_llm_self_decision", ""),
                        "llm_self_conf": gate_result.get("llm_self_conf"),
                        # 挑战者 v2 观测 (DEB-20260814 §十一): AGREE可达性+防锚定效果统计
                        "challenger_verdict": (analysis.get("_llm_output", {}).get("_debate") or {}).get("challenger_verdict", ""),
                        "challenger_direction": (analysis.get("_llm_output", {}).get("_debate") or {}).get("challenger_direction", ""),
                        "challenger_independent_direction": (analysis.get("_llm_output", {}).get("_debate") or {}).get("challenger_independent_direction"),
                        "challenger_anchor_divergence": (analysis.get("_llm_output", {}).get("_debate") or {}).get("challenger_anchor_divergence", False),
                        # P0 影子双写 (DEB-20260814): 四态细分 conf 的 record-only 对照,
                        #   {conf,tier,decision} — live 不受影响, 供 §9.5 判据裁决。
                        "p0_shadow": gate_result.get("p0_shadow"),
                        # ── [DEB-20260825 第13轮 P6] DA 决策台账补字段 (零行为变更, 纯观测) ──
                        #   动因: 本行此前只有 gate 侧 quality_score/decision, 缺 DA 自身的
                        #   score/rating/skip_reason/tripwire数/五维验证不通过维度/prompt 指纹
                        #   → 第11轮的验证项 (SKIP 理由分布 + SHORT 占比) 只能靠对 reasons
                        #   文本正则抠 "score=X/10", 且 prompt 改版前后无法切分 (口径七律#2)。
                        #   勘误: 第12轮曾断言"SKIP 决策零落盘", 实为**误判** — 本 jsonl 一直
                        #   逐候选写入含 SKIP (v2 窗 84/195 行), 详见第13轮 §勘误。
                        #   已知缺口: checkpoint 命中的标的在上游 continue, 不写本行 (同日重跑才发生)。
                        "rating": analysis.get("rating", ""),
                        "da_score": analysis.get("score"),
                        "skip_reason": str(_lo_g.get("skip_reason") or "")[:300],
                        # [第14轮 P8] score_band 观测: 新契约三档(HIGH/MEDIUM/LOW)与旧数字score对照,
                        #   判据=score分布方差是否从1.268(旧)显著上升。_score_band_applied=实际生效档。
                        "score_band": _lo_g.get("_score_band_applied") or str(_lo_g.get("score_band") or ""),
                        "da_score_legacy": _lo_g.get("score_legacy"),
                        "tripwire_count": len([_t for _t in (_plan_g.get("tripwires") or [])
                                               if isinstance(_t, dict)
                                               and str(_t.get("metric") or "").strip()
                                               and str(_t.get("threshold") or "").strip()]),
                        # [第14轮 P10] 机器可核销失效条件数 (本股可判定), 判据=30天后tripwire_checker核销率>0
                        "invalidation_trigger_count": len([
                            _t for _t in (_plan_g.get("invalidation_triggers") or [])
                            if isinstance(_t, dict)
                            and str(_t.get("metric") or "") in ("收盘价","量比","5日涨跌","盘前涨跌幅")
                            and str(_t.get("operator") or "") in ("<",">")]),
                        "challenger_score": _dbg_g.get("challenger_score"),
                        "challenger_validation_failed": [_k for _k, _v in _val_g.items()
                                                         if "不通过" in str(_v)],
                        "debate_outcome": (analysis.get("debate_outcome")
                                           or _lo_g.get("debate_outcome") or ""),
                        "contract_violations": (_lo_g.get("_contract") or {}).get("violations"),
                        "contract_violations_after": (_lo_g.get("_contract") or {}).get("violations_after"),
                        "contract_repaired": ((_lo_g.get("_contract") or {}).get("repair")
                                              or {}).get("applied"),
                        "finish_reason": _lo_g.get("_finish_reason"),
                        "usage": _lo_g.get("_usage"),
                        "prompt_hash": _lo_g.get("_prompt_hash"),
                        "challenger_prompt_hash": _dbg_g.get("challenger_prompt_hash"),
                        # [Hermes独立复核 2026-08-27] v0.71 归因字段接线: challenger_model
                        #   /challenger_model_reported 此前只存在于内存 _debate 字典
                        #   (llm_synth.py:1664/1675), 台账写入点未透传 → SKILL.md v0.71
                        #   声称"每条决策落盘, 新旧样本可切分"不兑现 (与 r14 P10 虚报同款
                        #   病灶: 字段写进了上游结构但观测点没接)。补两行, 零行为变更,
                        #   今晚 19:00 v0.71 首跑前接线否则模型切分判据必然判死。
                        "challenger_model": _dbg_g.get("challenger_model"),
                        "challenger_model_reported": _dbg_g.get("challenger_model_reported"),
                    }
                    with open(os.path.join(self.output_dir, "da_gate_decisions.jsonl"), "a", encoding="utf-8") as _fg:
                        _fg.write(_json_g.dumps(_rec_g, ensure_ascii=False) + "\n")
                except Exception as _le:
                    print(f"  Gate落盘失败(不影响): {_le}", file=sys.stderr)
            except Exception as e:
                print(f"  Gate失败(不影响): {e}", file=sys.stderr)

            try:
                import ic_writer
                decision_id = ic_writer.write_signal_snapshot(analysis)
                analysis["_ic_decision_id"] = decision_id
                print(f"  IC写入: {decision_id}", file=sys.stderr)
            except Exception as e:
                analysis["_ic_decision_id"] = None
                print(f"  IC写入失败: {e}", file=sys.stderr)

            # Obsidian per-symbol 深度分析归档 (best-effort, 不阻塞pipeline)
            try:
                import sys as _sys
                _sys.path.insert(0, "/opt/ftseek/FTSeek-US")
                from app.core.obsidian_writer import get_obsidian_writer
                _ow = get_obsidian_writer()
                _ow.write_symbol_analysis(analysis)
            except Exception as _e:
                print(f"  Obsidian写入失败(不影响): {_e}", file=sys.stderr)

            # ── FTSeek适配格式 ──
            try:
                import adapter
                analysis["_ftseek"] = {
                    "voting_result": adapter.to_voting_result(analysis),
                    "signal_score": adapter.to_signal_score(analysis),
                    "exit_meta": adapter.to_exit_meta(analysis),
                    "ic_snapshot": adapter.to_ic_snapshot(analysis),
                }
            except Exception as e:
                analysis["_ftseek_instruction"] = {"error": str(e)}

            # ── 断点续跑 (2026-08-24): 落盘完整 analysis — 失败分析不缓存 (留待重试) ──
            if _ck_on and analysis.get("rating") != "错误":
                analysis["_ckpt_model"] = config.LLM_MODEL
                _ckpt_save(self.output_dir, _ck_date, analysis)

        if _ck_hits:
            print(f"\n[Checkpoint] 本轮复用缓存 {_ck_hits} 只, 实际重活 {len(analyses) - _ck_hits} 只",
                  file=sys.stderr)

        _pool_ex.shutdown(wait=False)  # 2026-07-28 v2: 主循环已逐股消费完, 关池
        results["stages"]["output"] = {
            "analyses_count": len(analyses),
            "analyses": analyses,
        }

        # ── Stage 4: Execute (适配FTSeek格式) ───────
        print("\n" + "="*60, file=sys.stderr)
        print("STAGE 4: EXECUTE — 适配FTSeek Instruction格式", file=sys.stderr)
        print("="*60, file=sys.stderr)

        instructions = []
        for a in analyses:
            try:
                import adapter
                inst = adapter.analysis_to_instruction(a)
            except Exception as e:
                inst = {"symbol": a.get("symbol",""), "direction": "SKIP", "error": str(e)}
            instructions.append(inst)
            # 2026-08-24: 防御性 .get — adapter 失败回退字典无 confidence/conditions 键,
            #   此前 KeyError 崩掉整个 Stage4-6 (bridge文件+JSON输出丢失).
            print(f"  {inst.get('symbol','?')}: {inst.get('direction','SKIP')} conf={inst.get('confidence','N/A')} "
                  f"conditions={inst.get('conditions',[])}{(' err='+str(inst['error'])) if inst.get('error') else ''}", file=sys.stderr)

        results["stages"]["execute"] = {"instructions": instructions}
        print(f"[Pipeline] 生成 {len(instructions)} 个 Instruction", file=sys.stderr)

        # ── Stage 5: Result (提示FTSeek接管) ─────────
        print("\n" + "="*60, file=sys.stderr)
        print("STAGE 5: RESULT — FTSeek接管", file=sys.stderr)
        print("="*60, file=sys.stderr)
        print("[Pipeline] IC追踪由FTSeek signal_ic_tracker负责", file=sys.stderr)
        print("[Pipeline] entry/SL/TP由FTSeek instruction_generator计算", file=sys.stderr)
        print("[Pipeline] 退出由FTSeek _check_playbook_exit_rules执行", file=sys.stderr)

        results["stages"]["result"] = {
            "ic_tracker": "FTSeek signal_ic_tracker (已有)",
            "exit_rules": "FTSeek _check_playbook_exit_rules (已有)",
            "instruction_generator": "FTSeek compute_instruction_values (已有)",
            "note": "instructions 可写入 FTSeek decisions DB 或注入 playbook pipeline",
        }

        results["pipeline_end"] = time.time()
        results["pipeline_duration"] = round(results["pipeline_end"] - results["pipeline_start"], 1)

        # ── 挑战者弃权率监控 (2026-08-06, 用户指示): 弃权率 >80% 告警 ──
        #   8/4: 72% 弃权 (真实保守); 8/6: 16/16=100% → decision_conf 恒 0.50 → gate 无 PASS.
        #   连续 3 天 >80% → 辩论环节应降级 (省一半 LLM) 或换挑战者 prompt.
        try:
            _n_analyses = len(analyses)
            _n_decided = 0
            _n_abstain = 0
            _n_abstain_true = 0
            for _a in analyses:
                _llmo = _a.get("_llm_output", {}) or {}
                _dbt = _llmo.get("_debate", {}) or {}
                if not _dbt:
                    continue
                _n_decided += 1
                # [2026-11-06 口径修正] 原判据 "SKIP in (挑战者方向, 分析师方向)" 把**分析师自己**
                #   SKIP 也算成"挑战者弃权" ⇒ 11-06 报 50%(18/36), 而 checkpoint 实测
                #   AGREE 5 / PARTIAL 30 / DISAGREE 1, 挑战者真弃权 = 0。真弃权只认挑战者侧。
                #   challenger_abstain_rate 保持原口径不动 (下游有读取方), 真值另加一个键。
                _cd = str(_dbt.get("challenger_direction", "")).upper()
                _od = str(_llmo.get("direction", "")).upper()
                if "SKIP" in (_cd, _od):
                    _n_abstain += 1
                if _llmo.get("_challenger_abstained") is True or _cd == "SKIP":
                    _n_abstain_true += 1
            if _n_decided:
                _ar = 100.0 * _n_abstain / _n_decided
                _ar_true = 100.0 * _n_abstain_true / _n_decided
                results["challenger_abstain_rate"] = round(_ar, 1)
                results["challenger_abstain_rate_true"] = round(_ar_true, 1)
                print(f"[弃权监控] 任一方SKIP口径 {_ar:.0f}% ({_n_abstain}/{_n_decided}) | "
                      f"挑战者真弃权 {_ar_true:.0f}% ({_n_abstain_true}/{_n_decided})"
                      + (" — 连续3天>80%应降级辩论环节" if _ar_true > 80 else ""),
                      file=sys.stderr)
        except Exception as _abst_err:
            print(f"[弃权监控] 统计失败(忽略): {_abst_err}", file=sys.stderr)

        # ── Stage 6: FTSeek数据通道写入 (v0.23: 规划→执行分离) ──────────
        self._write_ftseek_data_channels(scan_result, analyses, _da_selected_symbols)
        self._write_bridge_file(scan_result, analyses)

        return results

    def _write_ftseek_data_channels(self, scan_result: Dict, analyses: List[Dict],
                                    selected_symbols: List[str] = None,
                                    trade_date: str = None):
        """把deep_analysis的规划输出写入FTSeek已读取的数据文件.

        3个文件通道 (全部best-effort, 失败只log不阻塞):
        1. data/daily_active_pool.json — scan候选追加, factor_engine自动读(0行FTSeek改动)
        2. data/dynamic_blacklist.json — avoid列表, risk_stage读(冻结后加3行)
        3. data/deep_sector_rotation.json — 板块轮动, plan_validator读(冻结后加3行)

        [P1.4 2026-09-12] `selected_symbols` = Stage2 过滤后**实际提交深分析**的合格
        名单。DailyActivePool 只消费它 + 合格 analyses; `scan_result` 降级为纯
        metadata 来源 (score/strategy_type 展示), **不再作为准入来源**。
        """
        import json as _json
        _now_et = _et_now()
        _today_str = trade_date or _now_et.strftime("%Y-%m-%d")
        # 2026-08-03 (任务#5): expires_at 必须带 ET 偏移 — 消费端 is_expired() 把 naive
        #   时间戳当 UTC (daily_active_pool.py), 裸 "T16:30:00" 会提前 4h (12:30 ET) 过期.
        _eod_str = _now_et.replace(hour=16, minute=30, second=0, microsecond=0).isoformat()  # ET收盘后过期

        data_dir = self.output_dir  # 2026-08-03 A/B隔离: 原硬编码 /opt/ftseek/FTSeek-US/data

        # ── 1. daily_active_pool.json: scan候选追加 ──
        try:
            pool_path = f"{data_dir}/daily_active_pool.json"
            pool = _json.loads(open(pool_path).read()) if os.path.exists(pool_path) else {"entries": [], "summary": {}}
            existing_codes = {e.get("code", "") for e in pool.get("entries", [])}

            # [P1.4 2026-09-12] 不再从 scanner top_bullish/top_bearish **重拼**活跃池 ——
            #   修前: pool = scanner Top (含已被资格判定拒绝的 DA 候选) + BUY/SELL_SHORT
            #   analyses ⇒ 最终候选裁决被绕过, 已拒标的重新出现在 factor_engine 读取的
            #   daily_active_pool 里 (DEB-20260910 问题④: "写 DailyActivePool 时重新拼
            #   scanner Top, 未必遵守最终候选裁决")。
            #   修后: pool = selected_symbols (实际提交深分析的合格名单) + 合格 analyses。
            #   scan_result 只用于取 metadata 展示, 不做准入; 未传 selected_symbols 时
            #   只用 analyses —— **绝不回退到 scanner Top**。
            _meta_rows = (scan_result.get("all_scored")
                          or (scan_result.get("bullish_all", [])
                              + scan_result.get("bearish_all", [])
                              + scan_result.get("watchlist_all", []))
                          or (scan_result.get("top_bullish", [])
                              + scan_result.get("top_bearish", [])))
            _meta_by_symbol = {}
            for _m in _meta_rows or []:
                if isinstance(_m, dict) and _m.get("symbol"):
                    _meta_by_symbol.setdefault(str(_m.get("symbol")), _m)
            if selected_symbols is None:
                print("[Pipeline] daily_active_pool: 未传 selected_symbols → 只按 analyses "
                      "落池 (不回退 scanner Top)", file=sys.stderr)
            scan_candidates = []
            for sym in [str(s) for s in (selected_symbols or []) if s]:
                if sym not in existing_codes:
                    scan_candidates.append(sym)
                    existing_codes.add(sym)

            # 追加deep_analysis候选(bridge候选) — 确保FTSeek watchlist包含bridge标的
            for a in analyses:
                if a.get("action") in ("BUY", "SELL_SHORT"):
                    sym = a.get("symbol", "")
                    if sym and sym not in existing_codes:
                        scan_candidates.append(sym)
                        existing_codes.add(sym)

            for sym in scan_candidates:
                # 找对应的分析结果取metadata
                _a = next((a for a in analyses if a.get("symbol") == sym), None)
                _s = _meta_by_symbol.get(str(sym))
                pool["entries"].append({
                    "code": sym,
                    "source": "SCAN",
                    "added_at": _now_et.isoformat(),
                    "expires_at": _eod_str,
                    "metadata": {
                        "strategy_type": (_a or _s or {}).get("strategy_type", ""),
                        "score": (_a or _s or {}).get("score", 0),
                    },
                })

            pool["summary"] = {
                "total": len(pool["entries"]),
                "breakdown": pool.get("summary", {}).get("breakdown", {}),
                "max_pool_size": 50,
                "scan_added": len(scan_candidates),
            }

            if self.pool_write:
                with open(pool_path, "w") as f:
                    _json.dump(pool, f, ensure_ascii=False, default=str)
                print(f"[Pipeline] daily_active_pool.json: +{len(scan_candidates)} scan候选 → {len(pool['entries'])}总", file=sys.stderr)
            else:
                print(f"[Pipeline] --no-pool-write: 跳过 daily_active_pool 落盘 (A/B 隔离)", file=sys.stderr)
        except Exception as e:
            print(f"[Pipeline] daily_active_pool写入失败(不影响): {e}", file=sys.stderr)

        # ── 2. dynamic_blacklist.json: avoid列表 ──
        try:
            bl_path = f"{data_dir}/dynamic_blacklist.json"
            avoid_list = []
            for s in scan_result.get("avoid", []):
                avoid_list.append({
                    "symbol": s.get("symbol", ""),
                    "reason": s.get("bucket_reason", ""),
                    "score": s.get("score", 0),
                    "change_5d": s.get("change_5d", 0),
                })
            # 也从analyses里取NEUTRAL且低分的标的
            for a in analyses:
                if a.get("action") == "SKIP" and a.get("score", 10) < 3:
                    sym = a.get("symbol", "")
                    if sym and not any(x["symbol"] == sym for x in avoid_list):
                        avoid_list.append({"symbol": sym, "reason": a.get("conclusion", "")[:100], "score": a.get("score", 0)})

            bl_data = {
                "date": _today_str,
                "generated_at": _now_et.isoformat(),
                "symbols": [a["symbol"] for a in avoid_list],
                "details": avoid_list,
            }
            with open(bl_path, "w") as f:
                _json.dump(bl_data, f, ensure_ascii=False, default=str)
            print(f"[Pipeline] dynamic_blacklist.json: {len(avoid_list)}只avoid标的", file=sys.stderr)
        except Exception as e:
            print(f"[Pipeline] dynamic_blacklist写入失败(不影响): {e}", file=sys.stderr)

        # ── 3. deep_sector_rotation.json: 板块轮动 ──
        try:
            sr_path = f"{data_dir}/deep_sector_rotation.json"
            sr = scan_result.get("sector_rotation", {})
            sr_data = {
                "date": _today_str,
                "generated_at": _now_et.isoformat(),
                "strongest": sr.get("strongest", []),
                "weakest": sr.get("weakest", []),
                "sector_changes": sr.get("sector_changes", {}),
                "symbol_sectors": sr.get("symbol_sectors", {}),
                "market_condition": scan_result.get("market_condition", ""),
            }
            with open(sr_path, "w") as f:
                _json.dump(sr_data, f, ensure_ascii=False, default=str)
            print(f"[Pipeline] deep_sector_rotation.json: strongest={sr.get('strongest', [])[:2]} weakest={sr.get('weakest', [])[:2]}", file=sys.stderr)
        except Exception as e:
            print(f"[Pipeline] deep_sector_rotation写入失败(不影响): {e}", file=sys.stderr)

    def _write_bridge_file(self, scan_result: Dict, analyses: List[Dict],
                           trade_date: str = None):
        """Stage 6b: 写 opportunity_scan_YYYYMMDD.json — bridge文件 + 直写instruction到DB.

        两个输出:
        1. bridge JSON文件: FTSeek _try_load_bridge()读取, BridgeVotingAdapter.vote()使用
        2. playbook_instructions DB表: FTSeek auto_execute直接消费 (P0修复 2026-07-09)

        P0根因: 之前只写bridge文件, 但run_playbook_generate有幂等检查(DB已有instruction就跳过),
        导致bridge候选永远不生成instruction, auto_execute永远不执行bridge候选。
        修复: bridge生成时同时写instruction到DB (UPSERT by date+symbol), 绕过run_playbook_generate。

        Ponytail: 复用FTSeek已有的PlaybookDB.save_instruction(), 不新建表/接口。
        """
        import json as _json
        import adapter as _adapter
        _now_et = _et_now()
        _today_str = trade_date or _now_et.strftime("%Y-%m-%d")

        # [DEB-20260723 P0.2-版本戳] bridge 归因地基, 前置一切 skill 侧变更;
        #   单一真源 = SKILL.md frontmatter version 字段; 解析失败落 unknown 不阻塞.
        _skill_version = "unknown"
        try:
            import re as _re_sv, pathlib as _pl_sv
            _sk = _pl_sv.Path(__file__).resolve().parents[1] / "SKILL.md"
            _m = _re_sv.search(r"(?m)^version:\s*(\S+)", _sk.read_text(encoding="utf-8"))
            if _m:
                _skill_version = _m.group(1)
        except Exception:
            pass

        data_dir = self.output_dir  # 2026-08-03 A/B隔离: 原硬编码 /opt/ftseek/FTSeek-US/data
        bridge_path = f"{data_dir}/opportunity_scan_{_today_str}.json"
        _symbol_sectors = (
            (scan_result.get("sector_rotation") or {}).get("symbol_sectors") or {}
        )

        # Fix②b (2026-07-12): 复用 FTSeek MarketRegimeGate 补齐归因列 (与 generate/DEC- 路径同口径).
        #   每轮算一次 (市场级上下文对当日所有候选一致); best-effort, 取不到不阻塞 pipeline.
        _regime_fields: Dict[str, Any] = {}
        try:
            import sys as _sys_rg
            _sys_rg.path.insert(0, "/opt/ftseek/FTSeek-US")
            from app.playbook.market_regime import MarketRegimeGate as _MRG
            _rc = _MRG().assess()
            _regime_fields = {
                "market_regime": _rc.regime.value,
                "vix_at_generation": _rc.vix,
                "spy_trend_at_generation": "above_ma20" if _rc.spy_ma20 >= _rc.spy_ma50 else "below_ma20",
            }
        except Exception as _rg_e:
            print(f"[Bridge] regime 补齐失败(非致命): {_rg_e}", file=sys.stderr)

        candidates = []
        db_written = 0
        for a in analyses:
            direction = a.get("action", "SKIP")
            if direction not in ("BUY", "SELL_SHORT"):
                continue
            # P0 (2026-07-10): signal_gate 接线 — BLOCK 信号不写 DB, 不进 auto_execute.
            # gate 已计算 quality_score/PASS/WARN/BLOCK (个股历史+pattern+claim IC+RR),
            # 但此前只打印日志不拦截. 此处接通:
            #   BLOCK → continue (不写 DB, 不执行)
            #   WARN  → 降低 confidence (执行端 _conf_factor 按 confidence 加权仓位, conf 低 → 仓小)
            #           不用 position_size_hint: (1) Stage3 已给 analysis 赋过值 → setdefault 不生效;
            #           (2) auto_execute 不读 raw_instruction.position_size_hint, 只读 confidence.
            _gate = a.get("_signal_gate", {})
            _gate_decision = _gate.get("decision", "PASS") if _gate else "PASS"
            if _gate_decision == "BLOCK":
                print(f"  [Gate] {a.get('symbol','?')} BLOCKED (score={_gate.get('quality_score',0)}): "
                      f"{_gate.get('reasons',[])}", file=sys.stderr)
                continue
            # 2026-10-23: IC 写失败时也必须保持 bridge schema 与 DA 行优先级
            _ensure_decision_id(a, _today_str)
            if _gate_decision == "WARN":
                _vr_pre = _adapter.to_voting_result(a)
                _warn_conf = max(0.25, _vr_pre.get("confidence", 0.5) - 0.15)
                a.setdefault("_warn_confidence_override", _warn_conf)
                # [DEB-20260723 P0.2-弃权语义 shadow] WARN 前的语义置信度双写 (弃权=0.50, 真反向=0.35);
                #   record-only 进 bridge, live confidence 不变, 仓位零影响; 离线按 decision_id join 测量两周.
                a["_semantic_confidence"] = _vr_pre.get("confidence", 0.5)
            try:
                vr = _adapter.to_voting_result(a)
                # direction: BUY→LONG, SELL_SHORT→SHORT (VotingCoordinator 格式)
                _dir_long_short = "LONG" if vr["direction"] == "BUY" else "SHORT"
                
                # WARN 降 confidence 覆盖 (执行端 _conf_factor 消费此值)
                _warn_conf = a.get("_warn_confidence_override")
                if _warn_conf is not None:
                    vr["confidence"] = _warn_conf
                
                # 2模型辩论结果 (v0.39) — 从_llm_output中取(llm_synth.synthesize()返回的result含_debate)
                _llm_out = a.get("_llm_output", {})
                _debate = _llm_out.get("_debate", {})
                _debate_outcome = _llm_out.get("debate_outcome", "")
                
                # anchor_dev_pct v2 (DEB-feedback-loop F1 补源, 2026-08-02):
                #   snapshot 缺价 (盘前 quote 失败) 回退 scan 候选价 (同一次运行, 分钟级, 同尺);
                #   同时注入 bridge 文件 cand (v1 仅 _inst 直写 DB, 文件侧 0 覆盖).
                _anchor_dev = None
                try:
                    _mkt = float((a.get("snapshot") or {}).get("price", 0) or 0)
                    if _mkt <= 0:
                        _spx = {str(c.get("symbol") or "").replace("US.", ""):
                                float(c.get("price") or c.get("last_price") or 0)
                                for c in (scan_result.get("candidates") or [])}
                        _mkt = _spx.get(str(vr.get("symbol") or "").replace("US.", ""), 0.0)
                    _e0 = float(vr.get("entry_price") or 0)
                    if _mkt > 0 and _e0 > 0:
                        _anchor_dev = round((_e0 - _mkt) / _mkt * 100, 3)
                except Exception:
                    _anchor_dev = None
                # hygiene (FTSeek DEB-ruler §六②, 2026-08-04): UE 注入候选 entry=scan 现价,
                #   anchor_dev 恒为构造性 0.0 (不携带锚时滞信息) — 置 None, 防与 DA 真零混读.
                #   实证: 08-03 全 3 行 0.0 均为 13:10 UE SHORT 批 (XOM/MU/RSSS).
                if a.get("_ue_origin") and _anchor_dev == 0.0:
                    _anchor_dev = None

                _arch, _conf_struct, _chase_cap = _derive_entry_semantics(
                    vr.get("entry_strategy"), vr.get("thesis"), _dir_long_short,
                    llm_archetype=vr.get("entry_archetype"),
                    llm_confirmation=vr.get("confirmation"),
                    llm_chase_cap=vr.get("chase_cap_price"))

                # ── [RFC-120 2026-09-30] 倒挂 chase_cap 源头归一化 (写入侧防线) ──
                # 病灶: LLM 常把 SHORT 的 cap 填成 invalidation 上破失效位 (上界语义) →
                #   执行层禁追门 (SHORT cap=下限) 出生即违例 = 结构性死锁。实证 9/4 enforce
                #   上线后 born-violated 空头 18/18 零执行 (对照合规组 24/33), 9/30
                #   BE/KMX/TSLA 三条空单全灭, TSLA 空转 37+ 轮; BUY 侧同病 18 条零执行。
                # 归一 SSOT = FTSeek app/playbook/entry_band.normalize_chase_cap (执行层
                #   chase 门同源同函数, 防双侧口径漂移); 导入失败走同款本地降级副本
                #   (与 v0.88 momentum 真源同纪律)。倒挂值零信息增量 (上破失效位已由
                #   stop_loss/invalidation 承担) → 确定性退回入场带顺势沿 (与 UE 约定
                #   LONG=entry_high/SHORT=entry_low 同口径)。锚=生成入场价 (本函数作用域内
                #   vr["entry_price"] 即生成值, 尚未被 reprice 污染)。
                if _chase_cap:
                    try:
                        try:
                            import sys as _sys_cc
                            if "/opt/ftseek/FTSeek-US" not in _sys_cc.path:
                                _sys_cc.path.insert(0, "/opt/ftseek/FTSeek-US")
                            from app.playbook.entry_band import normalize_chase_cap as _cc_norm
                        except Exception:
                            def _cc_norm(direction, entry_price, cap):  # 本地降级副本 (同口径)
                                try:
                                    c, e = float(cap), float(entry_price)
                                except (TypeError, ValueError):
                                    return cap, False
                                if c <= 0 or e <= 0:
                                    return cap, False
                                d = str(direction or "").upper()
                                if d in ("BUY", "LONG") and c <= e:
                                    return round(e * 1.05, 4), True
                                if d in ("SHORT", "SELL_SHORT") and c >= e:
                                    return round(e * 0.95, 4), True
                                return cap, False
                        _cap_new, _cap_flipped = _cc_norm(
                            _dir_long_short, vr.get("entry_price"), _chase_cap)
                        if _cap_flipped:
                            print(f"[RFC-120] {vr.get('symbol')} {_dir_long_short} chase_cap 倒挂归一: "
                                  f"{_chase_cap} → {_cap_new} (入场带顺势沿; 原值系 "
                                  f"invalidation 失效位误填, 出生即违例不可成交)", file=sys.stderr)
                            _chase_cap = _cap_new
                    except Exception as _ccn_e:
                        print(f"[RFC-120] {vr.get('symbol')} chase_cap 归一异常 (保留原值): {_ccn_e}",
                              file=sys.stderr)
                cand = {
                    "symbol": vr["symbol"],
                    "sector": a.get("sector", "") or _symbol_sectors.get(vr["symbol"], ""),
                    "direction": _dir_long_short,
                    "confidence": vr["confidence"],
                    "confidence_semantic": a.get("_semantic_confidence", vr["confidence"]),
                    "score": vr["score"],
                    "thesis": vr["thesis"],
                    "conditions": vr["conditions"],
                    "risks": vr["risks"],
                    "entry_price": vr["entry_price"],
                    "stop_loss": vr["stop_loss"],
                    "take_profit": vr["take_profit"],
                    "position_suggestion": vr["position_suggestion"],
                    "entry_strategy": vr["entry_strategy"],
                    # [DEB-20260901] 结构化入场语义 (LLM直出优先, 确定性兜底) — 消费方:
                    #   FTSeek Phase B 影子 (双轨: 自由文本照旧, 结构化字段新增, 零行为变更)
                    "entry_archetype": _arch,
                    "confirmation": _conf_struct,
                    "chase_cap_price": _chase_cap,
                    "invalidation": vr["invalidation"],
                    # [r15 P10接线] 机器可核销失效条件透传 (消费方: tripwire_checker)
                    "invalidation_triggers": vr.get("invalidation_triggers", []),
                    # P2 落库断点修复 (2026-08-14): adapter 已透传 tripwires 但 bridge
                    #   cand块漏拷 → 8/14首跑 0/18 落库。补齐, 供盘后复盘核销+IC审计。
                    "tripwires": vr.get("tripwires", []),
                    "strategy_id": "deep_analysis",
                    "decision_id": a.get("_ic_decision_id", ""),
                    "strategy_type": a.get("strategy_type", ""),
                    "position_size_hint": a.get("position_size_hint", ""),
                    "ue_direction": str(a.get("_ue_direction") or "").upper(),
                    "ue_confidence": a.get("_ue_confidence"),
                    "ue_scanned_at": a.get("_ue_scanned_at", ""),
                    "ue_batch_id": a.get("_ue_batch_id", ""),
                    "ue_evidence": a.get("_ue_evidence", ""),
                    "ue_causal_chain": a.get("_ue_causal_chain", ""),
                    "ue_evidence_citation_state": a.get("_ue_evidence_citation_state", ""),
                    "ue_confidence_basis": a.get("_ue_confidence_basis", ""),
                    "ue_confidence_calibration": a.get("_ue_confidence_calibration") or {},
                    "ue_counter_evidence": a.get("_ue_counter_evidence", ""),
                    "ue_event_phase": a.get("_ue_event_phase", ""),
                    "ue_move_basis": a.get("_ue_move_basis", ""),
                    "ue_transmission_confirmation_required": a.get(
                        "_ue_transmission_confirmation_required", False),
                    "ue_short_check": a.get("_ue_short_check") or {},
                    "ue_event_meta": a.get("_ue_event_meta") or {},
                    "ue_event_reaction": a.get("_ue_event_reaction") or {},
                    # UE→DA 候选管道溯源 (2026-08-03): "ue_candidate"=DA确认UE浮现的候选,
                    #   ""=DA自选。字面量不含 universe_expansion → scorecard 仍归 DA 源。
                    # [2026-10-14 RFC-136 execute转正·三源分账] fresh-event 批 (ue_only=True)
                    #   origin="ue_fresh_event": Path A (da_feed 并入 DA 主链) 与 Path B
                    #   (premarket fresh-event 批) 共用 _source="ue_candidate" 无法区分,
                    #   唯有 origin 值能分账两条供料链 (用户裁决 2026-10-14: 交易标的源头
                    #   分类)。source_attribution rfc117_v3 'DA-UE新事件' 腿消费此字面量
                    #   (CASE 序在 ue_candidate 腿之前)。字面量同样不含 universe_expansion。
                    "origin": ("ue_fresh_event" if self.ue_only else "ue_candidate") if a.get("_ue_origin") else "",
                    # v0.39: 辩论结果写入bridge
                    "debate_outcome": _debate_outcome,
                    "debate": _debate if _debate else None,
                    "anchor_dev_pct": _anchor_dev,
                    # DEB-20260819 §十七-L1/L2: 股性卡实际注入规则列表透传
                    #   (语义=注入标记; 判分分组用文本引用cited vs 注入未引用)
                    "pangan_injected": (_llm_out.get("pangan_injected") or []),
                    "supply_selection": a.get("_supply_selection") or {},
                    "recommendation_evidence": a.get("recommendation_evidence") or {},
                }
                candidates.append(cand)

                # ── P0修复: 同时写instruction到DB ──
                # 绕过run_playbook_generate的幂等检查, 让auto_execute直接消费
                # 2026-08-03 A/B隔离: --no-db-write 跳过 (候选已进 bridge 文件, 此处仅跳 DB 直写)
                if not self.db_write:
                    continue
                try:
                    import sys as _sys
                    _sys.path.insert(0, "/opt/ftseek/FTSeek-US")
                    from app.playbook.db import PlaybookDB
                    from app.playbook.entry_band import compute_entry_band as _compute_entry_band  # 单一真源, 防 band 漂移
                    _pb_db = PlaybookDB()
                    
                    # direction映射: LONG→BUY, SHORT→SELL_SHORT (instruction格式)
                    _inst_dir = "BUY" if _dir_long_short == "LONG" else "SELL_SHORT"
                    # 入场区间 band: 复用执行端同一真源 (app/playbook/entry_band.py), 防百分比漂移/记录冲突.
                    _eb_low, _eb_high = _compute_entry_band(vr.get("entry_price"), _dir_long_short == "SHORT")
                    
                    # risk_reward = |TP-entry| / |entry-SL| (b步骤1: 纯算术, 落库时已知;
                    #   risk_amount 依赖 position_size(执行时才定), 由 app 侧 re-price 落库).
                    _rr = None
                    try:
                        _e = float(vr["entry_price"]); _s = float(vr["stop_loss"]); _t = float(vr["take_profit"])
                        _rps = abs(_e - _s)
                        if _rps > 0:
                            _rr = round(abs(_t - _e) / _rps, 2)
                    except Exception:
                        _rr = None
                    _inst = {
                        "date": _today_str,
                        "symbol": vr["symbol"],
                        "direction": _inst_dir,
                        "entry_price": vr["entry_price"],
                        "stop_loss": vr["stop_loss"],
                        "take_profit": vr["take_profit"],
                        "risk_reward": _rr,
                        "anchor_dev_pct": _anchor_dev,
                        # Fix① (2026-07-12): 不可变入场区间 (band) — reprice 永不覆盖. 单一真源见 app/playbook/entry_band.py
                        #   (执行端 _check_intraday_trigger 与本处共用 compute_entry_band, 防百分比漂移).
                        "entry_low": _eb_low,
                        "entry_high": _eb_high,
                        "confidence": int(vr["confidence"] * 100),  # 0-100格式
                        "conditions": vr["conditions"],
                        "thesis": vr["thesis"][:500] if vr.get("thesis") else "",
                        "risks": vr["risks"],
                        "decision_id": a.get("_ic_decision_id", ""),
                        # 模型归因 (2026-08-03 任务#3): 指令级模型字段, scorecard 可按模型分层
                        "model_used": config.LLM_MODEL,
                        # Fix②a/②b (2026-07-12): 归因关键列提到顶层 (save_instruction 从顶层读).
                        "invalidation": vr["invalidation"],
                        "sector": a.get("sector", "") or _symbol_sectors.get(vr["symbol"], ""),
                        "market_regime": _regime_fields.get("market_regime"),
                        "vix_at_generation": _regime_fields.get("vix_at_generation"),
                        "spy_trend_at_generation": _regime_fields.get("spy_trend_at_generation"),
                        "raw_instruction": {
                            "source": "deep_analysis",
                            # 2026-10-21: 保留原始方向 — SKIP 行 DB direction 被改写后,
                            # 复盘/quality cohort 仍可追溯 DA 当初的 BUY/SHORT 意图。
                            "direction": _inst_dir,
                            "original_direction": _dir_long_short,
                            "strategy_type": a.get("strategy_type", ""),
                            "position_size_hint": a.get("position_size_hint", ""),
                            "ue_direction": str(a.get("_ue_direction") or "").upper(),
                            "ue_confidence": a.get("_ue_confidence"),
                            "ue_scanned_at": a.get("_ue_scanned_at", ""),
                            "ue_batch_id": a.get("_ue_batch_id", ""),
                            "ue_evidence": a.get("_ue_evidence", ""),
                            "ue_causal_chain": a.get("_ue_causal_chain", ""),
                            "ue_evidence_citation_state": a.get("_ue_evidence_citation_state", ""),
                            "ue_confidence_basis": a.get("_ue_confidence_basis", ""),
                            "ue_confidence_calibration": a.get("_ue_confidence_calibration") or {},
                            "ue_counter_evidence": a.get("_ue_counter_evidence", ""),
                            "ue_event_phase": a.get("_ue_event_phase", ""),
                            "ue_move_basis": a.get("_ue_move_basis", ""),
                            "ue_transmission_confirmation_required": a.get(
                                "_ue_transmission_confirmation_required", False),
                            "ue_short_check": a.get("_ue_short_check") or {},
                            "ue_event_meta": a.get("_ue_event_meta") or {},
                            "ue_event_reaction": a.get("_ue_event_reaction") or {},
                            # UE→DA 管道溯源落库 (2026-08-03): scorecard 可读
                            #   raw_instruction_json LIKE '%ue_candidate%' 切 DA·SHORT 的 UE 确认子集
                            # [2026-10-14] fresh-event 批 origin="ue_fresh_event" (三源分账, 见 bridge 处注释)
                            "origin": ("ue_fresh_event" if self.ue_only else "ue_candidate") if a.get("_ue_origin") else "",
                            "entry_strategy": vr["entry_strategy"],
                            # [DEB-20260901] 结构化入场语义落库 (Phase B 影子从
                            #   raw_instruction_json 读取; 双轨新增, 零行为变更)
                            "entry_archetype": _arch,
                            "confirmation": _conf_struct,
                            "chase_cap_price": _chase_cap,
                            "invalidation": vr["invalidation"],
                            # [r15 P10接线] 机器可核销失效条件落库 — tripwire_checker
                            #   从 raw_instruction_json.invalidation_triggers 读.
                            "invalidation_triggers": vr.get("invalidation_triggers", []),
                            # P2 落库断点修复 (2026-08-14): 与 cand 块同步透传
                            "tripwires": vr.get("tripwires", []),
                            "debate_outcome": _debate_outcome,
                            "score": vr["score"],
                            # [丙2 PROPOSAL-20260905 P1, 2026-09-05] score_band 落库 —
                            #   band 是打分区分度的真正载体 (HIGH/MEDIUM·0.9/MEDIUM·0.8 单调),
                            #   此前只在 checkpoint 里, 指令级不可 join → 修覆写后无法回测档位表现。
                            "score_band": (_llm_out.get("_score_band_applied")
                                           or _llm_out.get("score_band")),
                            # [丙1 配套] 挑战者影子分 (不再覆写 score) + "本会覆写"标记.
                            "challenger_score_shadow": _llm_out.get("_challenger_score_shadow"),
                            "score_lowered_by_challenger": bool(
                                _llm_out.get("_score_lowered_by_challenger")),
                            # [2026-07-25 信息源复盘] 语义置信度落库 — 顶层 confidence 被 gate WARN
                            #   罚后退化为常量 (近14天 89/95 条 <40), 分层能力归零;
                            #   bridge cand 块已双写但不落库 → 此处补齐, 供 P0.2 conf 校准修复归因.
                            "confidence_semantic": a.get("_semantic_confidence", vr["confidence"]),
                            # Fix③ (2026-07-12): 计划原值快照 — reprice 覆盖 entry/SL/TP 后, 计划值仍可从此 blob 复原.
                            "planned_entry": vr["entry_price"],
                            "planned_stop_loss": vr["stop_loss"],
                            "planned_take_profit": vr["take_profit"],
                            # DEB-20260819 §十七-L1/L2: 股性卡实际注入规则列表 (毕业判分依据)
                            "pangan_injected": (_llm_out.get("pangan_injected") or []),
                            # [E2 2026-08-31 DEB-20260830] 模型原始自评五档置信 (record-only,
                            #   不入任何门) — 辩论/adapter 覆盖前的原话, B2 校准取证前置.
                            "llm_self_confidence": _llm_out.get("_llm_self_confidence"),
                            "challenger_self_confidence": _llm_out.get("_challenger_self_confidence"),
                            # [DEB-20260907] evidence_gaps 落库 — 删 confidence 自评字段后的
                            #   不确定性出口 (record-only, 不入任何门): 消费方=SKIP 审计+
                            #   data_quality_note 对账; 护栏=SKIP 率相对基线升幅 ≤10pp。
                            "evidence_gaps": _llm_out.get("evidence_gaps", []),
                            "supply_selection": a.get("_supply_selection") or {},
                            "recommendation_evidence": a.get("recommendation_evidence") or {},
                        },
                        "horizon": "short",
                        "horizon_confidence": vr["confidence"],
                        "horizon_reasoning": _debate_outcome or vr.get("thesis", "")[:200],
                        # DEB-20260814 P6 (2026-08-14): gate 校准后 decision_conf (0-1) 独立落库,
                        #   不动共享 confidence 列 (FTSeek 执行端 _conf_factor 活消费).
                        "decision_conf": (a.get("_signal_gate") or {}).get("decision_conf"),
                        # [DA-B3 2026-08-29, DEB-20260829 M2] 数据覆盖统计透传 —
                        #   deep_analyzer._compute_data_quality 已算好 {total/ok/failed/coverage_pct},
                        #   但本处直写缺键 → playbook_instructions.ok_dimensions/data_quality_json
                        #   列全空 (8/28 17条实测)。FTSeek db.save_instruction 从顶层读
                        #   ok_dimensions + data_quality (json)。纯落库零行为。
                        "ok_dimensions": (a.get("data_quality") or {}).get("ok"),
                        "data_quality": a.get("data_quality") or {},
                    }
                    _pb_db.save_instruction(_inst)
                    db_written += 1
                except Exception as _db_e:
                    print(f"[Bridge] {vr['symbol']} DB写入失败(非致命): {_db_e}", file=sys.stderr)

            except Exception as e:
                print(f"[Bridge] {a.get('symbol','?')} adapter失败(跳过): {e}", file=sys.stderr)

        # 2026-07-10: JSON 累积合并 — 此前用 "w" 覆盖, 每轮只留当轮候选, 与 DB
        #   (save_instruction UPSERT 累积) 语义不一致 → JSON 候选数 < DB instruction 数,
        #   触发 scheduler "候选<3 覆盖不足" 误报, 且 BridgeVotingAdapter 只见最后一轮.
        #   修复: 合并当日已有候选 (按 symbol, 当轮新结果覆盖旧), 与 DB UPSERT 对齐.
        import os as _os
        _merged = {c["symbol"]: c for c in candidates}
        try:
            if _os.path.exists(bridge_path):
                with open(bridge_path) as _ef:
                    _existing = _json.load(_ef)
                if _existing.get("trade_date") == _today_str:
                    for _c in _existing.get("candidates", []):
                        _sym = _c.get("symbol")
                        if _sym and _sym not in _merged:
                            _merged[_sym] = _c
        except Exception as _merge_e:
            print(f"[Bridge] 合并当日已有候选失败(用当轮): {_merge_e}", file=sys.stderr)
        candidates = list(_merged.values())

        # ── 盘前异动股落盘 (2026-08-11 v0.64): 供盘后验证"盘前趋势→当日方向"延续率 ──
        # 口径与 market_scanner 叙事/Stage2注入一致 (|premarket_chg_pct|≥4%).
        # 记录的是 DA 决策时点 (scan 时刻) 的盘前快照 — 即可执行时刻的真实信息集.
        _pm_movers = []
        try:
            for _s in (scan_result.get("all_scored") or []):
                _pmc = _s.get("premarket_chg_pct") or 0
                if abs(_pmc) >= 4.0:
                    _pm_movers.append({
                        "symbol": _s.get("symbol", ""),
                        "premarket_chg_pct": _pmc,
                        "premarket_price": _s.get("premarket_price", 0),
                        "prev_close": _s.get("prev_close", 0),
                        "score": _s.get("score", 0),
                        "channels": _s.get("channels", []),
                    })
            _pm_movers.sort(key=lambda x: abs(x.get("premarket_chg_pct", 0)), reverse=True)
        except Exception as _pm_e:
            print(f"[Bridge] premarket_movers 落盘失败(非致命): {_pm_e}", file=sys.stderr)

        bridge_data = {
            "trade_date": _today_str,
            "generated_at": _now_et.isoformat(),
            "skill_version": _skill_version,
            "model_used": config.LLM_MODEL,
            "market_condition": scan_result.get("market_condition", ""),
            "candidate_count": len(candidates),
            "candidates": candidates,
            "premarket_movers": _pm_movers,
        }
        try:
            _atomic_write_json(bridge_path, bridge_data)
            print(f"[Bridge] 写入 {bridge_path}: {len(candidates)} candidates, {db_written} instructions写入DB", file=sys.stderr)
        except Exception as e:
            print(f"[Bridge] 写入失败: {e}", file=sys.stderr)

        # ── Stage 6c: Obsidian盘前归档 (2026-07-10 原为"飞书推送+归档";
        #   2026-09-02 移除飞书推送, 服务侧 run_playbook_morning_push 为唯一推送方) ──
        # 背景: 2026-07-10 时 run_playbook_generate 在 NullVotingAdapter 下跳过推送,
        #   skill 端直调 PlaybookPusher 补送; 次日(07-11)服务侧上线独立推送任务
        #   (持久化幂等标记+每轮重试)后本路径即冗余 → 2026-09-02 实锤同内容双推
        #   (skill 直推 19:28:01 + 服务循环 19:28:07, 两进程幂等标记互不可见,
        #    DEB-20260902 §八 P2 的通知面表现). 收敛为服务侧单点推送:
        #   无跨进程共享状态/无竞态窗口, 且消除双快照不一致 (VIX/SPY 各自评估).
        # Ponytail: DB已写入 = 指令已就绪, 推送只是通知, 失败不影响交易.
        # 2026-08-03 A/B隔离: --no-db-write 时跳过 (归档写生产obsidian).
        if not self.db_write:
            print("[Bridge] --no-db-write: 跳过Obsidian归档 (A/B 隔离)", file=sys.stderr)
            return {"candidates": len(candidates), "db_written": db_written}

        # Obsidian盘前计划归档
        try:
            import sys as _sys_obs
            _sys_obs.path.insert(0, "/opt/ftseek/FTSeek-US")
            from app.core.obsidian_writer import get_obsidian_writer
            _ow = get_obsidian_writer()
            _ow.write_daily_premarket({
                "date": _today_str,
                "market": "US",
                "generated_at": _now_et.isoformat(),
                "regime": scan_result.get("market_condition", "")[:60],
                "targets": [c.get("symbol", "") for c in candidates],
                "overall_bias": scan_result.get("overall_bias", "中性"),
            })
            print(f"[Bridge] Obsidian盘前归档: ✅ {_today_str}", file=_sys_obs.stderr)
        except Exception as _obs_e:
            print(f"[Bridge] Obsidian写入失败(不影响): {_obs_e}", file=sys.stderr)

        return {"candidates": len(candidates), "db_written": db_written}

    def run_scan_only(self) -> Dict:
        import market_scanner
        scanner = market_scanner.MarketScanner(self.market, self.scan_limit)
        return scanner.scan(self.top_n)

    def run_analyze_only(self, symbol: str, synth_mode: str = "llm") -> Dict:
        """synth_mode: 'llm' (默认,调LLM) | 'rule' (纯规则,不调LLM)"""
        import data_collector, deep_analyzer
        print(f"[Pipeline] 采集 {symbol} 全量数据...", file=sys.stderr)
        data = data_collector.collect_all(symbol)
        print(f"[Pipeline] 数据质量: {data.get('_quality', {})}", file=sys.stderr)

        synth = 'rule' if synth_mode == 'rule' else None
        analyzer = deep_analyzer.DeepAnalyzer(data, synth_module=synth)
        result = analyzer.analyze()

        # ── Signal Gate (先于ic_writer, 让gate数据进factors_json) ──
        try:
            import signal_gate
            gate_result = signal_gate.evaluate_signal(result)
            result["_signal_gate"] = gate_result
            print(f"[Pipeline] Signal Gate: {gate_result['decision']} "
                  f"score={gate_result['quality_score']}", file=sys.stderr)
        except Exception as e:
            print(f"[Pipeline] Signal Gate失败(不影响输出): {e}", file=sys.stderr)

        # 写入 FTSeek signal_snapshots.db (IC追踪, 不碰运行代码)
        # 2026-08-03 A/B隔离: --no-db-write 时跳过 (不写生产 signal_snapshots)
        if self.db_write:
            try:
                import ic_writer
                decision_id = ic_writer.write_signal_snapshot(result)
                result["_ic_decision_id"] = decision_id
            except Exception as e:
                result["_ic_decision_id"] = None
                print(f"[Pipeline] IC写入失败: {e}", file=sys.stderr)
        else:
            result["_ic_decision_id"] = None

        # Obsidian per-symbol 深度分析归档 (best-effort, 不阻塞pipeline)
        # 2026-08-03 A/B隔离: --no-db-write 时跳过 (不写生产 obsidian)
        if self.db_write:
            try:
                import sys as _sys
                _sys.path.insert(0, "/opt/ftseek/FTSeek-US")
                from app.core.obsidian_writer import get_obsidian_writer
                _ow = get_obsidian_writer()
                _ow.write_symbol_analysis(result)
            except Exception as _e:
                print(f"[Pipeline] Obsidian写入失败(不影响): {_e}", file=sys.stderr)

        # 输出4种FTSeek适配格式
        try:
            import adapter
            result["_ftseek"] = {
                "voting_result": adapter.to_voting_result(result),
                "signal_score": adapter.to_signal_score(result),
                "exit_meta": adapter.to_exit_meta(result),
                "ic_snapshot": adapter.to_ic_snapshot(result),
            }
            # 向后兼容
            result["_ftseek_instruction"] = result["_ftseek"]["voting_result"]
        except Exception as e:
            result["_ftseek_instruction"] = {"error": str(e)}

        return result


def format_full_report(result: Dict) -> str:
    lines = []
    lines.append("=" * 60)
    lines.append("📊 深度分析管线报告")
    lines.append(f"执行时间: {result['pipeline_duration']}s")
    lines.append("=" * 60)

    sig = result["stages"].get("signal", {})
    lines.append(f"\n【市况】{sig.get('market_condition', '')}")

    output = result["stages"].get("output", {})
    analyses = output.get("analyses", [])
    if analyses:
        lines.append(f"\n{'─'*60}")
        lines.append("深度分析结果")
        lines.append(f"{'─'*60}")
        for a in analyses:
            lines.append(f"\n{'━'*40}")
            lines.append(f"{a.get('name','')} {a['symbol']}｜{a['rating']}（{a['confidence']}信心）｜"
                        f"综合 {a['score']}/10")
            lines.append(f"现价: {a.get('snapshot',{}).get('price',0)} "
                        f"({a.get('snapshot',{}).get('change_pct',0):+.1f}%)")
            lines.append(f"结论: {a.get('conclusion','')}")

            if a.get("bull_reasons"):
                lines.append("\n看多理由:")
                for r in a["bull_reasons"][:5]:
                    lines.append(f"  • {r['text']} ({r['strength']})")

            if a.get("bear_reasons"):
                lines.append("\n看空理由:")
                for r in a["bear_reasons"][:5]:
                    lines.append(f"  • {r['text']} ({r['strength']})")

            if a.get("constraints"):
                lines.append("\n约束:")
                for r in a["constraints"][:5]:
                    lines.append(f"  ⚠️ {r['text']} ({r['strength']})")

            kl = a.get("key_levels", {})
            if kl:
                lines.append(f"\n关键位: 现价{kl.get('current',0)} | "
                           f"支撑{kl.get('support',[])} | 阻力{kl.get('resistance',[])}")

            if a.get("risks"):
                lines.append(f"风险: {', '.join(a['risks'][:3])}")

            dq = a.get("data_quality", {})
            lines.append(f"数据覆盖: {dq.get('ok',0)}/{dq.get('total',0)} "
                        f"({dq.get('coverage_pct',0)}%)")

    # Stage 4: Instructions
    exe = result["stages"].get("execute", {})
    insts = exe.get("instructions", [])
    if insts:
        lines.append(f"\n{'─'*60}")
        lines.append("FTSeek Instruction (适配后)")
        lines.append(f"{'─'*60}")
        for inst in insts:
            # 2026-08-24: 防御性 .get — 与 Stage4 同款失效类 (adapter 失败回退字典
            #   无 confidence/conditions 键), text 报告路径同样不得裸键崩溃.
            lines.append(f"  {inst.get('symbol','?')}: {inst.get('direction','SKIP')} | "
                        f"conf={inst.get('confidence','N/A')} | conditions={inst.get('conditions',[])}")

    # Stage 5
    res = result["stages"].get("result", {})
    lines.append(f"\n{'─'*60}")
    lines.append("后续由FTSeek接管:")
    lines.append(f"  IC追踪: {res.get('ic_tracker','')}")
    lines.append(f"  退出: {res.get('exit_rules','')}")
    lines.append(f"  entry/SL/TP: {res.get('instruction_generator','')}")

    return "\n".join(lines)


def _load_checkpoint_analyses(output_dir: str, trade_date: str) -> List[Dict]:
    """Load per-symbol analysis checkpoints for one ET date (no LLM, no scan)."""
    root = _ckpt_dir(output_dir, trade_date)
    if not os.path.isdir(root):
        return []
    out: List[Dict] = []
    for name in sorted(os.listdir(root)):
        if (not name.endswith(".json")
                or name.endswith((".raw.json", ".bak", ".tmp"))):
            continue
        path = os.path.join(root, name)
        try:
            with open(path, encoding="utf-8") as fh:
                analysis = json.load(fh)
        except Exception as exc:
            print(f"[Finalize] checkpoint unreadable {name}: {exc}", file=sys.stderr)
            continue
        if not isinstance(analysis, dict):
            continue
        if analysis.get("rating") == "错误":
            continue
        symbol = str(analysis.get("symbol") or name[:-5])
        analysis["symbol"] = symbol
        out.append(analysis)
    return out


def finalize_from_checkpoint(trade_date: str, output_dir: str,
                             db_write: bool = True,
                             pool_write: bool = True) -> Dict:
    """Recovery path: turn completed per-symbol checkpoints into bridge/DB.

    Used when the main pipeline is killed by the carrier deadline after some
    analyses finished. It deliberately does not scan, call an LLM, or rerun a
    gate; it only replays the already persisted analysis verdicts through the
    normal Stage 6 writers, with idempotent DB upserts.
    """
    analyses = _load_checkpoint_analyses(output_dir, trade_date)
    if not analyses:
        return {"finalized": False, "reason": "no_checkpoint_analyses",
                "trade_date": trade_date, "analyses_count": 0}
    for analysis in analyses:
        _ensure_decision_id(analysis, trade_date)
    scan_result = {
        "market_condition": "finalized_from_checkpoint",
        "overall_bias": "中性",
        "candidates_total": len(analyses),
        "top_bullish": [],
        "top_bearish": [],
        "all_scored": [],
        "sector_rotation": {},
    }
    pipeline = Pipeline(output_dir=output_dir, db_write=db_write,
                        pool_write=pool_write)
    pipeline._write_ftseek_data_channels(
        scan_result, analyses,
        [analysis.get("symbol", "") for analysis in analyses],
        trade_date=trade_date)
    bridge = pipeline._write_bridge_file(
        scan_result, analyses, trade_date=trade_date)
    return {"finalized": True, "trade_date": trade_date,
            "analyses_count": len(analyses),
            "bridge_candidates": (bridge or {}).get("candidates"),
            "db_written": (bridge or {}).get("db_written")}


def main():
    import argparse
    parser = argparse.ArgumentParser(description="Pipeline — 深度分析管线")
    parser.add_argument("--mode", choices=["full", "scan", "analyze", "finalize"],
                        default="scan", help="运行模式")
    parser.add_argument("--date", default="",
                        help="finalize 模式的 ET 交易日 YYYY-MM-DD (默认今日 ET)")
    parser.add_argument("--symbol", help="标的代码 (analyze模式)")
    parser.add_argument("--market", default="US")
    parser.add_argument("--limit", type=int, default=10)
    parser.add_argument("--top", type=int, default=5)
    parser.add_argument("--symbols", help="额外标的列表 (逗号分隔, 如 US.TSLA,US.NVDA)")
    parser.add_argument("--ue-window", choices=["da_feed", "premarket"], default="da_feed",
                        help="UE候选消费窗口: da_feed=常规早批; premarket=当日新鲜事件增量批")
    parser.add_argument("--fresh-event", action="store_true",
                        help="当日UE新鲜事件增量批: 复用主DA市场上下文, 只分析UE候选")
    parser.add_argument("--fresh-context-dir", default="/opt/ftseek/FTSeek-US/data",
                        help="fresh-event读取主DA opportunity_scan的市场上下文目录")
    parser.add_argument("--format", choices=["json", "text"], default="text")
    parser.add_argument("--synth", choices=["llm", "rule"], default="llm", help="合成模式: llm(默认) | rule(纯规则)")
    # 2026-08-03 A/B 隔离 (防 deepseek 测试污染生产复盘): 三件套 — 文件重定向 + DB写入开关 + pool开关.
    #   完整隔离用法: FTSEEK_DB=/tmp/ab.db FTSEEK_DB_FILE=/tmp/ab.db \
    #     python3.11 pipeline.py --mode full --output-dir /tmp/ab_out --no-db-write --no-pool-write
    #   (FTSEEK_DB → ic_writer 等直连 sqlite3; FTSEEK_DB_FILE → FTSeek db_pool/PlaybookDB)
    parser.add_argument("--output-dir", default="",
                        help="文件输出目录 (bridge/pool/blacklist/sector/gate-jsonl), 默认生产 data/")
    parser.add_argument("--no-db-write", action="store_true",
                        help="跳过 PlaybookDB 指令直写 + IC snapshot + 飞书推送 + Obsidian 归档")
    parser.add_argument("--no-pool-write", action="store_true",
                        help="跳过 daily_active_pool.json 落盘")
    parser.add_argument("--llm-model", default="",
                        help=f"覆盖分析模型 (默认 config.LLM_MODEL={config.LLM_MODEL}; A/B 用)")
    # 2026-09-07 交易日守卫 (SKILL.md pitfall -6 / handoff「下一步」0-假日, 用户裁"按建议执行"):
    #   cron `0 20 * * 1-5` 只排周末不排美股假日 → 假日照跑会白烧 LLM + 写陈旧指令
    #   + (修复前) 把 IC 快照 trade_date 写成非交易日导致静默丢样。
    #   逃逸口 --force: 人工在假日做单股复盘/调试时用。cron 不传 --force。
    parser.add_argument("--force", action="store_true",
                        help="跳过美股交易日守卫 (假日/周末强制运行; cron 不应使用)")
    args = parser.parse_args()

    if args.mode == "finalize":
        _date = args.date or _et_now().strftime("%Y-%m-%d")
        _out_dir = args.output_dir or "/opt/ftseek/FTSeek-US/data"
        _result = finalize_from_checkpoint(
            _date, _out_dir,
            db_write=not args.no_db_write,
            pool_write=not args.no_pool_write)
        if args.format == "json":
            print(json.dumps(_result, ensure_ascii=False, default=str, indent=2))
        else:
            print(json.dumps(_result, ensure_ascii=False, default=str))
        return

    if args.llm_model:
        config.LLM_MODEL = args.llm_model
        _ls = sys.modules.get("llm_synth")  # 已导入则同步补丁 (模块级 MODEL 在 import 时绑定)
        if _ls is not None:
            _ls.MODEL = args.llm_model

    # ── 交易日守卫 (2026-09-07) ──────────────────────────────────────────
    # 语义与 UE `llm_universe_scan._is_us_trading_day_today()` /
    # FTSeek `app/playbook/pipeline.py::_is_trading_day_today()` 对齐: **fail-open**
    # (日历不可用 → 视为交易日 → 照跑, "宁可跑不可漏")。
    # 非交易日 → 不构造 Pipeline、不扫描、不调 LLM、不写 DB/bridge/pool, 直接 0 退出。
    # 误交易风险本就已被 FTSeek 两道闸挡住(auto_execute 非交易日 return +
    # get_instructions_by_date 严格 WHERE date=?), 本守卫治的是**白跑 + 陈旧写入 + IC 丢样**。
    if not args.force:
        try:
            import trading_calendar as _tc
            # 必须用 ET 当日, 不能用 date.today(): 容器时区 CST(UTC+8),
            # CST 周一凌晨 = ET 周日晚 → date.today() 会把 ET 周日判成周一。
            # 实测 2026-09-07 06:47 CST: date.today()=09-07 而 today_et()=09-06。
            _today_et = _tc.today_et()
            _is_td, _layer = _tc.resolve(_today_et)
        except Exception as _guard_err:
            _today_et, _is_td, _layer = None, True, "fail-open"
            print(f"[Pipeline] ⚠️ 交易日守卫检查失败({_guard_err}), fail-open 照常运行",
                  file=sys.stderr)
        if not _is_td:
            _msg = (f"[Pipeline] {_today_et} (ET) 非美股交易日 (周末/节假日; 判定层={_layer}), "
                    f"跳过本轮深度分析 — 不扫描/不调LLM/不写DB。人工强制运行请加 --force。")
            print(_msg, file=sys.stderr)
            if args.format == "json":
                # 保持 JSON 契约: cron Step4 按 JSON 解析, 不能吐裸文本。
                # 2026-09-07 补强: cron `e0d574cc1a3c` 的 Step4 明文要提取
                # `candidates_total` / `analyses_count`, 二者在正常结果里位于
                # `stages.signal` / `stages.output` ⇒ 跳过时给出**同形状的空值**,
                # 让 Step4 的既定提取路径照常命中(得 0)而不是找不到键后自由发挥。
                print(json.dumps({
                    "skipped": True,
                    "skip_reason": "NON_TRADING_DAY",
                    "trade_date_et": (_today_et.strftime("%Y-%m-%d")
                                      if _today_et is not None else None),
                    "calendar_layer": _layer,
                    "stages": {
                        "signal": {"market_condition": f"跳过: {_today_et} (ET) 非美股交易日",
                                   "candidates_total": 0},
                        "output": {"analyses_count": 0, "analyses": []},
                    },
                    "message": _msg,
                }, ensure_ascii=False, indent=2))
            else:
                print(_msg)
            return

    # DST anchor for the scheduled DA main batch. Manual/full debugging can use --force.
    if args.mode == "full" and not args.fresh_event and not args.force:
        _now_da_window = _et_now()
        _hm = _now_da_window.hour * 100 + _now_da_window.minute
        if not 755 <= _hm <= 815:
            _window_msg = (
                f"[Pipeline] {_now_da_window} (ET) outside DA main window 07:55-08:15, "
                f"skip this scheduled firing — no scan/LLM/DB write. Manual run: --force.")
            print(_window_msg, file=sys.stderr)
            if args.format == "json":
                print(json.dumps({
                    "skipped": True,
                    "skip_reason": "DA_MAIN_ET_WINDOW",
                    "trade_date_et": _now_da_window.strftime("%Y-%m-%d"),
                    "et_hhmm": f"{_hm:04d}",
                    "message": _window_msg,
                }, ensure_ascii=False, indent=2))
            # 2026-10-06 复查P1-b (用户裁「请修复优化异常问题」): 窗拒绝退出码非对称 —
            #   hm<755 (过早) = DST 双季设计里 off-season 载体的预期发车 (如 EST 季
            #     20:00 CST agent job = 07:00 EST), 属契约内静默拒绝, exit 0 维持双季设计;
            #   hm>815 (过晚) = 活跃季内启动延迟越过窗尾 (10-06 实测余量仅 4.2min) ⇒
            #     DA 全天零指令, 必须响: exit 2, 不再与「跑了没事」同貌。
            #   退出码约定: 0=正常/契约内跳过, 1=异常, 2=DA_MAIN_ET_WINDOW 迟发拒绝, 124=timeout。
            if _hm > 815:
                sys.exit(2)
            return

    _extra = [s.strip() for s in args.symbols.split(",")] if args.symbols else []
    _ue_window = "premarket" if args.fresh_event else args.ue_window
    pipeline = Pipeline(args.market, args.limit, args.top, extra_symbols=_extra,
                        output_dir=args.output_dir,
                        db_write=not args.no_db_write,
                        pool_write=not args.no_pool_write,
                        ue_window=_ue_window, ue_only=args.fresh_event)

    if args.mode == "full":
        _scan_context = None
        if args.fresh_event:
            _context_path = os.path.join(
                args.fresh_context_dir,
                f"opportunity_scan_{_et_now().strftime('%Y-%m-%d')}.json")
            try:
                with open(_context_path, encoding="utf-8") as _ctx_file:
                    _scan_context = json.load(_ctx_file)
                print(f"[Pipeline] fresh_event market context: {_context_path}", file=sys.stderr)
            except Exception as _ctx_error:
                print(f"[Pipeline] fresh_event 市场上下文缺失({ _ctx_error }) → 使用最小上下文", file=sys.stderr)
                _scan_context = {
                    "market_condition": "fresh_event_context_unavailable",
                    "overall_bias": "中性",
                    "candidates_total": 0,
                    "top_bullish": [], "top_bearish": [], "all_scored": [],
                }
        result = pipeline.run_full(scan_result=_scan_context)
        if args.format == "json":
            print(json.dumps(result, ensure_ascii=False, default=str, indent=2))
        else:
            print(format_full_report(result))
    elif args.mode == "scan":
        result = pipeline.run_scan_only()
        if args.format == "json":
            print(json.dumps(result, ensure_ascii=False, default=str, indent=2))
        else:
            import market_scanner
            print(market_scanner.format_scan_result(result))
    elif args.mode == "analyze":
        if not args.symbol:
            print("Error: --symbol required", file=sys.stderr)
            sys.exit(1)
        result = pipeline.run_analyze_only(args.symbol, synth_mode=args.synth)
        print(json.dumps(result, ensure_ascii=False, default=str, indent=2))


# ════════════════════════════════════════════════════════════════════════
# 收尾防挂死 (2026-09-16 病灶修复, 用户裁「病灶修复」)
#
# 病灶: **活干完了, 进程却不退出**, cron agent 轮询数十分钟后判定卡死 → SIGTERM
#   → 把整条 pipeline 全量重跑一遍 (LLM 预算白烧一倍), 或留下长命孤儿。
#   实证:
#     - 2026-09-11 孤儿 PID 1075503/1075525: 20:18 产出落盘, 挂到 09-14 12:40
#       (2 天 16 小时), 取证 /tmp/orphan_forensics_20260914.txt;
#     - 2026-09-16 盘前: 第 1 轮 20:21 产出落盘 (opportunity_scan + 6 条 instruction
#       + Obsidian 归档全绿), 进程挂到 20:46 被 SIGTERM(PIPELINE_EXIT=143),
#       20:48 起第 2 轮全量重跑。
#
# 根因 (两层, 均实测复现):
#   ① futu SDK 的 CallbackExecutor 线程 **daemon=False**
#      (`futu/common/sys_config.py::SysConfig.ALL_THREAD_DAEMON` 默认 False,
#       线程在 `callback_executor.py:22` 创建, `run()` 永久阻塞在 `self._queue.get()`)。
#       ⇒ 进程内只要有**一个** OpenQuoteContext 没被 close, 解释器退出时
#       `threading._shutdown()` 会无限 join 该线程, 进程永不退出。
#       实测: 建连不 close 的最小脚本 → timeout 25s 仍未退出 (exit=124)。
#   ② DA 进程内的泄漏源 = `MarketRegimeGate` 链路上的 `FutuLV3Provider` 单例
#      (`app/data/futu_lv3_provider.py:442`, 长生命周期设计, 服务侧由
#       `reset_futu_lv3_provider()` 显式关闭; 短命 CLI 里**没人调用**它)。
#      pipeline.py 在 Stage 3(1356) / Stage 6b(1762) / signal_gate.py:49 都会
#      经它建连 ⇒ 每次 DA 运行必留一条 OpenD 连接 + 一个非 daemon 线程。
#      实测: 只 import 不调用是干净的(exit 0), 一旦 `assess()` 就挂死(exit=124)。
#
# 修法 (三层, 从根到兜底):
#   A. 建连前把所有 futu 内部线程设为 daemon —— 消灭"第三方线程拖住解释器"这一类,
#      而不只是当前这一个实例 (任何未来新增的泄漏点也一并免疫)。
#   B. 收尾显式释放 OpenD 单例 (真正的 connect/close 配对, 顺带还回 OpenD 槽位)。
#   C. 非 daemon 线程**有界等待**, 超时则 flush 后强退 —— 兜底闸, 保证 CLI 一定退出。
#
# 回滚: 删本段 + `if __name__` 恢复成裸 `main()` (三层各自独立, 可单独摘)。
# ════════════════════════════════════════════════════════════════════════

def _futu_threads_daemon() -> None:
    """A: 让 futu SDK 内部创建的所有线程变 daemon (默认非 daemon, 见上方根因①)。

    必须在任何 futu 建连**之前**调用 (main() 里 Stage 0 交易日守卫就会经
    holiday_calendar 建连)。失败不阻塞: 还有收尾兜底闸 C。
    """
    try:
        from futu.common import sys_config as _fsc
        _fsc.SysConfig.set_all_thread_daemon(True)
    except Exception as _e:
        print(f"[Pipeline] futu 线程 daemon 化跳过 (非致命): {_e}", file=sys.stderr)


def _release_opend_singleton() -> None:
    """B: 释放进程内 OpenD 单例连接 (与 A 互补: A 治"线程拖住不退", B 治"连接泄漏不退")。"""
    try:
        # append 不是 insert(0): 同 `_ftseek_screening_deps()` 的理由 (本 skill 目录
        #   已在 sys.path[0], DA 自己的 `config` 模块须优先于仓库 `config/` 包)。
        if _FTSEEK_REPO not in sys.path:
            sys.path.append(_FTSEEK_REPO)
        from app.data.futu_lv3_provider import reset_futu_lv3_provider as _reset_lv3
        _reset_lv3()
    except Exception as _e:
        print(f"[Pipeline] OpenD 单例释放跳过 (非致命): {_e}", file=sys.stderr)


def _futu_console_to_stderr() -> None:
    """把 futu SDK 的**控制台**日志从 stdout 改道到 stderr (数据通道净化)。

    病灶 (2026-09-16 实测): SDK 的 console handler 绑的是 `sys.stdout`
    (`futu/common/ft_logger.py:102`), 而 DA 链路在 Stage 0 交易日守卫
    (holiday_calendar) 就会建连 ⇒ `--format json` 的 stdout 前面被插进建连日志:
    `/tmp/da_verify.json` 前 2 行是日志、第 3 行才是 `{`, `json.load` 直接
    `Extra data` —— 而 cron Step 4 要按 JSON 取 candidates_total/analyses_count。

    选择**改道**而非静默: 信息一条不丢 (cron 的 Step 3 命令本就把 stderr 落进
    `logs/da_pipeline_stderr.log`), stdout 恢复"纯 JSON"契约; SDK 的**文件**日志
    (com.futunn.FutuOpenD/Log/py_*.log) 保持不动, 禁用 SDK 日志的 SSOT 仍在仓内
    (`app/data/futu_lv3_provider.silence_futu_sdk_logs`, 本函数不复制它)。

    必须早于任何 futu 建连 (Stage 0 守卫即会建连)。
    """
    try:
        import futu.common.ft_logger as _ftl
        _h = getattr(getattr(_ftl, "logger", None), "consoleHandler", None)
        if _h is None:
            _ftl.FTLog()  # 单例惰性建 handler: 强制初始化后再取
            _h = getattr(_ftl.logger, "consoleHandler", None)
        if _h is None or getattr(_h, "stream", None) is sys.stderr:
            return
        _h.stream = sys.stderr
    except Exception as _e:
        print(f"[Pipeline] futu 控制台日志改道跳过 (非致命): {_e}", file=sys.stderr)


def _cli_teardown(exit_code: int = 0) -> None:
    """B+C: CLI 收尾 — 释放 OpenD 后对非 daemon 线程做有界等待, 超时强退。"""
    import threading as _th
    import time as _t

    _release_opend_singleton()

    try:
        _grace = float(os.environ.get("DA_EXIT_GRACE_SEC", "10"))
    except ValueError:
        _grace = 10.0
    _deadline = _t.time() + max(0.0, _grace)

    for _thr in list(_th.enumerate()):
        if _thr is _th.current_thread() or _thr.daemon:
            continue
        _thr.join(max(0.0, _deadline - _t.time()))
        if _thr.is_alive():
            print(f"[Pipeline] ⚠️ 收尾: 非daemon线程 '{_thr.name}' 未在 {_grace:.0f}s 内退出 "
                  f"→ 强制退出 (绕过 threading._shutdown 的无限 join; "
                  f"调 DA_EXIT_GRACE_SEC 可改等待上限)", file=sys.stderr)
            for _s in (sys.stdout, sys.stderr):
                try:
                    _s.flush()
                except Exception:
                    pass
            os._exit(exit_code)
    # 线程全干净 ⇒ 正常返回, 走解释器标准收尾 (atexit/GC 照常执行)


if __name__ == "__main__":
    # 前置 (必须早于 main() 里任何 futu 建连 —— Stage 0 守卫即会建连):
    #   A 让 futu 内部线程全 daemon; 顺带把 SDK 控制台日志从 stdout 改道 stderr,
    #   保住 `--format json` 的纯 JSON 契约 (cron Step 4 按 JSON 取数)。
    _futu_threads_daemon()
    _futu_console_to_stderr()
    _exit_code = 0
    try:
        main()
    except SystemExit as _e:                      # 保留 sys.exit(1) 语义 (缺 --symbol 等)
        _exit_code = _e.code if isinstance(_e.code, int) else (0 if _e.code is None else 1)
    except KeyboardInterrupt:
        _exit_code = 130
    except BaseException:
        import traceback as _tb
        _tb.print_exc()
        _exit_code = 1
    _cli_teardown(_exit_code)
    # 2026-10-06 复查P1-b 根因修: 原收尾只算 _exit_code 不用 — _cli_teardown 仅在线程
    #   挂死时 os._exit(code), 线程干净则正常返回 ⇒ 解释器 exit 0, 所有失败路径
    #   (sys.exit(1)/未捕获异常/窗拒绝 exit 2) 全部被吞成"成功"。实测钉案:
    #   `--mode analyze` 缺 --symbol → sys.exit(1) → 修复前 exit=0。
    #   os._exit 路径不返回, 不受本行影响; 干净路径经 sys.exit 走标准收尾 (atexit/GC 照常)。
    sys.exit(_exit_code)
