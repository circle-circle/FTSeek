#!/usr/bin/env python3
"""死胎攒样器 (2026-08-14) — 入场质量 shadow 观测基建

目的: 为每笔成交累积"入场时技术态(ts_ctx) + 事后死胎标签",
  样本达 n>=100 自动出分离度报告, 供死胎过滤门禁立项裁决。
原则: 纯记账, 零实盘干预; 按 trade_records.id 去重 → 幂等可重跑, 漏跑自愈。
回滚: 删本文件 + deadfetus_samples.jsonl + cron附录步骤, 零残留。

标签口径 (mfe_pct 正数口径):
  DEAD: MFE < 0.3% (入场后方向从未兑现)
  WIN:  MFE >= 1.0%
  MID:  其余

报告判据 (攒够才出):
  n>=100 时按 volume_ratio/RSI/入场时段/来源 四维做死胎率分离度,
  并做时间双窗验证 (前后各半, 双窗方向一致且死胎率差>=15pp 才列为门禁候选)。
  n<100 只报进度 + 标注"初步勿用"的预览, 不给结论。

口径警示 (2026-08-14 Qoder 复查): 仓内并存三个"死胎"阈值, 用途不同勿混用 —
  本采集 0.3% (入场质量门禁攒样) / DEB-20260813 DEAD_SIGNAL_EXIT 0.2% (出场机制) /
  exit_replay_shadow V2 0.1%+浮亏0.3% (更严早退变体)。
"""
import json
import sqlite3
import sys
from collections import defaultdict
from datetime import datetime
from pathlib import Path

DB = "/opt/ftseek/FTSeek-US/data/ftseek_us.db"
SCAN_DIR = Path("/opt/ftseek/FTSeek-US/data")  # opportunity_scan_YYYY-MM-DD.json (DA 盘前原始计划价 SSOT)
OUT = Path(__file__).parent / "deadfetus_samples.jsonl"
MIN_TRADE_DATE = "2026-08-04"  # F2 ts_ctx快照部署日, 之前的交易无入场快照
TARGET_N = 100

_plan_cache = {}


def load_plans(date_str: str) -> dict:
    """读当日 DA opportunity_scan 的候选计划价: symbol → (plan_price, direction)."""
    if date_str in _plan_cache:
        return _plan_cache[date_str]
    plans = {}
    p = SCAN_DIR / f"opportunity_scan_{date_str}.json"
    if p.exists():
        try:
            d = json.loads(p.read_text())
            for c in d.get("candidates", []):
                ep = c.get("entry_price")
                sym = c.get("symbol")
                if ep and sym and float(ep) > 0:
                    plans[sym] = (float(ep), (c.get("direction") or "").upper())
        except Exception:
            pass
    _plan_cache[date_str] = plans
    return plans


def chase_pct(direction: str, actual: float, plan_price: float) -> float:
    """追入幅度%: LONG 实际高于计划为正(追高); SHORT 实际低于计划为正(顺势更优)."""
    if direction == "LONG":
        return (actual / plan_price - 1) * 100
    return (plan_price / actual - 1) * 100


def classify_source(decision_id: str) -> str:
    d = decision_id or ""
    if d.startswith("DA"):
        return "DA"
    if d.startswith("universe_expansion"):
        return "UE"
    if d.startswith("intraday_reentry"):
        return "REENTRY"
    if d.startswith("TFB"):
        return "TFB"
    return "OTHER" if d else "EMPTY"


def label_of(mfe: float) -> str:
    if mfe < 0.3:
        return "DEAD"
    if mfe >= 1.0:
        return "WIN"
    return "MID"


def collect():
    seen = set()
    if OUT.exists():
        for line in OUT.read_text().splitlines():
            try:
                seen.add(json.loads(line)["trade_id"])
            except Exception:
                pass
    con = sqlite3.connect(DB)
    con.row_factory = sqlite3.Row
    rows = con.execute(
        "SELECT id, symbol, trade_date, entry_time, entry_price, direction, decision_id, "
        "mfe_pct, pnl_net, exit_reason, factor_detail "
        "FROM trade_records WHERE entry_time >= ? AND exit_time IS NOT NULL "
        "AND exit_time != '' AND mfe_pct IS NOT NULL ORDER BY id",
        (MIN_TRADE_DATE,)).fetchall()
    added = 0
    with OUT.open("a") as f:
        for r in rows:
            if r["id"] in seen:
                continue
            try:
                fd = json.loads(r["factor_detail"] or "{}")
                tc = fd.get("ts_ctx") or {}
            except Exception:
                tc = {}
            if not tc.get("rsi") and not tc.get("volume_ratio"):
                continue  # 无入场快照的不记 (不可归因样本)
            hhmm = (r["entry_time"] or "")[11:16]
            # chase: 实际成交价 vs DA 盘前原始计划价 (UE/REENTRY 无计划价 → None)
            plans = load_plans(r["trade_date"])
            plan = plans.get(r["symbol"])
            chase = None
            if plan and plan[0] > 0:
                chase = round(chase_pct(r["direction"], float(r["entry_price"]), plan[0]), 2)
            sample = {
                "trade_id": r["id"],
                "symbol": r["symbol"],
                "date": r["trade_date"],
                "dir": r["direction"],
                "source": classify_source(r["decision_id"]),
                "entry_hhmm": hhmm,
                "entry_price": round(float(r["entry_price"]), 4),
                "plan_price": plan[0] if plan else None,
                "chase_pct": chase,
                "rsi": round(float(tc["rsi"]), 1) if tc.get("rsi") is not None else None,
                "volume_ratio": round(float(tc["volume_ratio"]), 2) if tc.get("volume_ratio") is not None else None,
                "atr_percent": round(float(tc["atr_percent"]), 2) if tc.get("atr_percent") is not None else None,
                "macd": round(float(tc["macd"]), 3) if tc.get("macd") is not None else None,
                "mfe_pct": round(float(r["mfe_pct"] or 0), 2),
                "label": label_of(float(r["mfe_pct"] or 0)),
                "pnl_net": round(float(r["pnl_net"] or 0), 1),
                "exit_reason": r["exit_reason"] or "",
            }
            f.write(json.dumps(sample, ensure_ascii=False) + "\n")
            added += 1
    total = len(seen) + added
    print(f"[死胎攒样] 新增{added}笔, 累计{total}/{TARGET_N}"
          + ("" if total < TARGET_N else " — 已达报告阈值"))
    return total


def load_samples():
    if not OUT.exists():
        return []
    out = []
    for line in OUT.read_text().splitlines():
        try:
            out.append(json.loads(line))
        except Exception:
            pass
    return out


def dead_rate(bucket_samples):
    n = len(bucket_samples)
    if not n:
        return None, 0
    dead = sum(1 for s in bucket_samples if s["label"] == "DEAD")
    return round(100 * dead / n, 1), n


def split_dims(samples):
    dims = {}
    dims["volume_ratio"] = [
        ("<0.1", lambda s: s["volume_ratio"] is not None and s["volume_ratio"] < 0.1),
        ("0.1-0.3", lambda s: s["volume_ratio"] is not None and 0.1 <= s["volume_ratio"] < 0.3),
        (">=0.3", lambda s: s["volume_ratio"] is not None and s["volume_ratio"] >= 0.3),
    ]
    dims["rsi"] = [
        ("<60", lambda s: s["rsi"] is not None and s["rsi"] < 60),
        ("60-70", lambda s: s["rsi"] is not None and 60 <= s["rsi"] < 70),
        (">=70", lambda s: s["rsi"] is not None and s["rsi"] >= 70),
    ]
    dims["entry_session"] = [
        ("开盘30min(<=09:59)", lambda s: s["entry_hhmm"] <= "09:59"),
        ("上午(10:00-11:59)", lambda s: "10:00" <= s["entry_hhmm"] <= "11:59"),
        ("午后(>=12:00)", lambda s: s["entry_hhmm"] >= "12:00"),
    ]
    dims["chase_pct"] = [
        ("回踩(<-0.5%)", lambda s: s.get("chase_pct") is not None and s["chase_pct"] < -0.5),
        ("贴计划(-0.5~0.5%)", lambda s: s.get("chase_pct") is not None and -0.5 <= s["chase_pct"] < 0.5),
        ("顺偏(0.5~1.5%)", lambda s: s.get("chase_pct") is not None and 0.5 <= s["chase_pct"] < 1.5),
        ("追(1.5~3%)", lambda s: s.get("chase_pct") is not None and 1.5 <= s["chase_pct"] < 3.0),
        ("重追(>=3%)", lambda s: s.get("chase_pct") is not None and s["chase_pct"] >= 3.0),
    ]
    dims["source"] = [
        (src, lambda s, _src=src: s["source"] == _src)
        for src in ("DA", "UE", "REENTRY", "TFB", "OTHER")
    ]
    return dims


def report(samples):
    n = len(samples)
    if n == 0:
        print("[死胎报告] 无样本")
        return
    overall, _ = dead_rate(samples)
    print(f"[死胎报告] n={n} 总体死胎率={overall}%")
    if n < TARGET_N:
        print(f"  ⚠️ 样本未达{TARGET_N}, 以下仅为初步预览, 禁止用于门禁决策")
    dims = split_dims(samples)
    candidates = []
    for dim_name, buckets in dims.items():
        print(f"  -- {dim_name} --")
        for bname, pred in buckets:
            sub = [s for s in samples if pred(s)]
            dr, cnt = dead_rate(sub)
            if dr is None:
                continue
            print(f"    {bname:22s} n={cnt:3d} 死胎率={dr}%")
    # 双窗验证 (仅 n>=TARGET_N 时给候选结论)
    if n >= TARGET_N:
        half = n // 2
        first, second = samples[:half], samples[half:]
        print(f"\n  双窗验证 (前{len(first)}笔 / 后{len(second)}笔, 双窗差>=15pp且同向才列候选):")
        for dim_name, buckets in dims.items():
            for bname, pred in buckets:
                d1, n1 = dead_rate([s for s in first if pred(s)])
                d2, n2 = dead_rate([s for s in second if pred(s)])
                if d1 is None or d2 is None or n1 < 10 or n2 < 10:
                    continue
                # 与全样本其余部分对比的方向一致性
                rest1 = [s for s in first if not pred(s)]
                rest2 = [s for s in second if not pred(s)]
                r1, _ = dead_rate(rest1)
                r2, _ = dead_rate(rest2)
                if r1 is None or r2 is None:
                    continue
                gap1, gap2 = d1 - r1, d2 - r2
                if abs(gap1) >= 15 and abs(gap2) >= 15 and gap1 * gap2 > 0:
                    direction = "更高" if gap1 > 0 else "更低"
                    candidates.append(f"{dim_name}={bname} 双窗死胎率{direction} ({gap1:+.1f}pp/{gap2:+.1f}pp)")
        if candidates:
            print("  🚩 门禁候选特征:")
            for c in candidates:
                print(f"    - {c}")
        else:
            print("  无双窗一致的候选特征 — 维持现状, 继续攒样")


def main():
    total = collect()
    samples = load_samples()
    report(samples)


if __name__ == "__main__":
    main()
