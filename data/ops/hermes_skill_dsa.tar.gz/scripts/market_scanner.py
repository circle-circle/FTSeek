#!/usr/bin/env python3
"""
MarketScanner — 市场扫描+Top排序模块
=====================================
从全市场扫描候选标的，多维度打分排序，输出 Top N。

扫描逻辑：
1. 涨幅榜/跌幅榜/成交量榜 → 候选池
2. 对候选池每只标的快速采集快照+K线
3. 多维度评分（趋势/资金/异动/估值/动量）
4. 排序输出 Top N + 操作建议（做多/做空/回避/观望）

与 DeepAnalyzer 的区别：
- MarketScanner: 宽度扫描（快），适合发现机会
- DeepAnalyzer: 深度分析（慢），适合确认决策
"""

import json
import time
import sys
import os
import concurrent.futures
from typing import List, Dict, Optional

# 同目录导入
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import data_collector


# [P1.4 2026-09-12] 分桶排序口径版本: 空头桶改按方向强度 (10-score) 排序 +
#   scan() 输出完整分桶队列。checkpoint / 漏斗审计据此分段, 不复用不兼容的旧分析。
BUCKET_ORDER_VERSION = "bearish_conviction_v1"


class MarketScanner:
    """市场扫描器"""

    def __init__(self, market: str = "US", limit: int = 10):
        self.market = market
        self.limit = limit

    def scan(self, top_n: int = 5) -> Dict:
        """
        执行市场扫描 (v0.23: 多渠道+四信号+板块叙事+操作分桶)
        返回：{
            "market_condition": str,      # 市况叙事(含板块轮动)
            "candidates": List[Dict],     # 全部候选(过质量闸)
            "top_bullish": List[Dict],    # 做多候选(质地/突破型)
            "top_bearish": List[Dict],    # 做空/回避候选
            "watchlist": List[Dict],      # 观望列表
            "sector_rotation": Dict,      # 板块轮动数据
            "data_quality": Dict,         # 渠道覆盖
            "timestamp": float,
        }
        """
        print(f"[Scanner] 开始多渠道扫描 {self.market} 市场...", file=sys.stderr)

        # 1. 多渠道采集
        channels = self._collect_multi_channel()
        raw_candidates = channels["candidates"]
        data_quality = channels["data_quality"]
        print(f"[Scanner] 渠道: {data_quality}", file=sys.stderr)

        # 2. 质量闸 (市值>$2B + 价格>$5 + 非杠杆ETF)
        gated = self._quality_gate(raw_candidates)
        print(f"[Scanner] 质量闸: {len(raw_candidates)} → {len(gated)}", file=sys.stderr)

        # 3. 四信号评分
        # 2026-10-23: 原来逐只串行 (snapshot + kline 两个 OpenD 子进程)，却只占
        # _OPEND_SEM 的 1/4 名额。按 4 个 worker 并行评分，仍由 data_collector 的
        # 全局信号量封顶 OpenD 连接；executor.map 保序，输出与串行完全同序。
        scored = []
        _scan_workers = max(1, min(4, int(os.environ.get("DA_SCAN_WORKERS", "4")),
                                   len(gated) or 1))

        def _score_one(indexed):
            i, c = indexed
            symbol = c.get("code", "")
            if not symbol:
                return None
            print(f"[Scanner] 评分 {i+1}/{len(gated)}: {symbol}", file=sys.stderr)
            try:
                return self._four_signal_score(symbol, c)
            except Exception as exc:
                # 单票采集异常不应打死全市场扫描；保留审计痕迹后跳过。
                print(f"[Scanner] 评分失败 {symbol}: {exc}", file=sys.stderr)
                return None

        with concurrent.futures.ThreadPoolExecutor(
                max_workers=_scan_workers, thread_name_prefix="da-scan") as ex:
            for row in ex.map(_score_one, enumerate(gated)):
                if row is not None:
                    scored.append(row)

        # 4. 板块叙事
        sector_rotation = self._collect_sector_data(scored)
        market_condition = self._sector_narrative(scored, sector_rotation)

        # 5. 操作分桶
        buckets = self._bucketing(scored)

        # 6. 排序
        scored.sort(key=lambda x: x.get("score", 0), reverse=True)

        return {
            "market_condition": market_condition,
            "candidates_total": len(scored),
            "top_bullish": buckets["bullish"][:top_n],
            "top_bearish": buckets["bearish"][:top_n],
            "watchlist": buckets["watchlist"][:top_n],
            # [P1.4 2026-09-12, DEB-20260910 / proud-slope-falcon] 展示 TopN 与完整
            #   分桶队列分离: 下游 (pipeline Stage2) 先做资格判定, 再在**合格队列**内
            #   按预算截断 → 被淘汰者可由完整队列补位。修前下游只拿到已截断的 top_*,
            #   再做价格/ATR 过滤 → 淘汰后不补位, 深分析名额空转。
            #   top_* 保留供展示与旧消费方兼容; 完整队列与 top_* 共享同一批 dict 对象
            #   (未深拷), 下游改字段前需自行 dict()。
            "bullish_all": buckets["bullish"],
            "bearish_all": buckets["bearish"],
            "watchlist_all": buckets["watchlist"],
            "bucket_order_version": BUCKET_ORDER_VERSION,
            "avoid": buckets["avoid"],
            "all_scored": scored,
            "sector_rotation": sector_rotation,
            "data_quality": data_quality,
            "timestamp": time.time(),
        }

    def _merge_candidates(self, gainers, losers, volume_leaders) -> List[Dict]:
        """合并三个榜单，去重 (v0.22 legacy, 保留为fallback)"""
        seen = set()
        candidates = []
        for source, items in [("gainer", gainers), ("loser", losers), ("volume", volume_leaders)]:
            for item in items:
                code = item.get("code", "")
                if code and code not in seen:
                    seen.add(code)
                    candidates.append({**item, "_source": source})
        return candidates

    def _collect_multi_channel(self) -> Dict:
        """多渠道采集: 涨幅榜+跌幅榜+量榜+财报超预期+内部人异动+夜盘.

        返回: {candidates: [...], data_quality: {channels_green, channels_empty, raw_count}}
        """
        channels = {}
        channel_names = ["gainers", "losers", "volume", "earnings_surprise", "insider_movers", "after_hours", "premarket_movers"]

        try:
            channels["gainers"] = data_collector.collect_top_gainers(self.market, self.limit)
        except Exception:
            channels["gainers"] = []
        try:
            channels["losers"] = data_collector.collect_top_losers(self.market, self.limit)
        except Exception:
            channels["losers"] = []
        try:
            channels["volume"] = data_collector.collect_top_volume(self.market, self.limit)
        except Exception:
            channels["volume"] = []
        try:
            channels["earnings_surprise"] = data_collector.collect_earnings_surprise(self.market, self.limit)
        except Exception:
            channels["earnings_surprise"] = []
        try:
            channels["insider_movers"] = data_collector.collect_insider_movers(self.market, self.limit)
        except Exception:
            channels["insider_movers"] = []
        try:
            channels["after_hours"] = data_collector.collect_after_hours_movers(self.market, self.limit)
        except Exception:
            channels["after_hours"] = []
        # 2026-08-11 (LIF 盲区修复): 真·盘前异动渠道 — 活跃股池批量快照按 |盘前涨跌|≥4% 过滤。
        #   盘前波动=当日趋势的第一个信号; 非榜单股(如 LIF 盘前-19.5%)此前完全不可见。
        try:
            channels["premarket_movers"] = data_collector.collect_premarket_movers(self.market, 100)
        except Exception:
            channels["premarket_movers"] = []

        # 合并去重, 记录渠道命中
        # 2026-08-11: premarket_movers 字段必须合并进已有候选 —
        #   LIF 型标的先经 earnings_surprise 进池, premarket_movers 后命中时
        #   若只追加渠道名不合并字段, premarket_chg_pct 恒 0 → Stage2 注入/盘前叙事全漏。
        _PM_FIELDS = ("premarket_chg_pct", "premarket_price", "premarket_volume", "overnight_chg_pct")
        seen = {}
        for ch_name, items in channels.items():
            for item in items:
                code = item.get("code", "")
                if not code:
                    continue
                if code not in seen:
                    seen[code] = {**item, "_channels": [ch_name], "_source": ch_name}
                else:
                    if ch_name not in seen[code]["_channels"]:
                        seen[code]["_channels"].append(ch_name)
                    for _f in _PM_FIELDS:
                        if item.get(_f) and not seen[code].get(_f):
                            seen[code][_f] = item[_f]

        candidates = list(seen.values())

        # 渠道质量
        green = [ch for ch in channel_names if channels.get(ch)]
        empty = [ch for ch in channel_names if not channels.get(ch)]

        return {
            "candidates": candidates,
            "data_quality": {
                "channels_green": green,
                "channels_empty": empty,
                "raw_count": len(candidates),
            },
        }

    def _quality_gate(self, candidates: List[Dict]) -> List[Dict]:
        """质量闸: 市值>$2B + 价格>$5 + 非杠杆/反向/宽基ETF.

        过滤理由: 参考报告252→137, 剔除<$5的45个 + 杠杆ETF 12个 + <$2B的5个.

        2026-08-12 闸门真正启用 (两处病灶修复):
        ① 单位纠错: 富途 market_val 实测单位=USD (AAPL 快照与 filter 口径均
           4.45e12), 原注释"人民币元 14e9≈$2B"是错的 → 实际阈值=$14B,
           比设计意图 $2B 严 7 倍 (2-14B 中盘被误杀)。
        ② mcap=0 漏洞堵住: earnings_surprise 等 Finnhub 渠道不带市值,
           原 `if mcap` 判断直接放行 (实测 33% 穿门者市值未知, 其中 69/97
           实为 <$2B 微盘)。改为: 批量快照回填缺失市值后再判。
        """
        # 杠杆/反向/宽基ETF前缀
        etf_prefixes = ("TQQQ", "SQQQ", "SOXL", "SOXS", "TNA", "TZA", "SPXL", "SPXS",
                        "SPY", "QQQ", "IWM", "DIA", "VTI", "VOO", "VEA", "VWO",
                        "XLK", "XLF", "XLE", "XLV", "XLI", "XLY", "XLP", "XLC", "XLU", "XLRE", "XLB",
                        "UVXY", "VIXY", "SQQQ", "PSQ")

        # ── 市值回填: 无市值的候选批量拉快照 (单连接分批, 秒级) ──
        # 回填失败保持 mcap=0 → 放行 (闸门失败不阻断扫描, 下游 DA 仍有门禁)
        missing = [c.get("code", "") for c in candidates
                   if c.get("code") and not (c.get("market_val") or c.get("market_cap") or 0)]
        if missing:
            try:
                snaps = data_collector.collect_snapshot_batch(missing)
                snap_by = {s.get("code"): s for s in snaps if isinstance(s, dict)}
                filled = 0
                for c in candidates:
                    mv = (snap_by.get(c.get("code")) or {}).get("total_market_val", 0) or 0
                    if mv > 0:
                        c["market_val"] = mv
                        filled += 1
                print(f"[Scanner] 质量闸市值回填: {filled}/{len(missing)}", file=sys.stderr)
            except Exception as e:
                print(f"[Scanner] 市值回填失败 (放行处理): {e}", file=sys.stderr)

        gated = []
        for c in candidates:
            code = c.get("code", "")
            bare = code.split(".")[-1] if "." in code else code

            # ETF过滤
            if bare in etf_prefixes or bare.startswith(("TQQQ", "SQQQ", "SOX", "SPX", "TNA", "TZA")):
                continue

            # 价格过滤 (从base_data取, 没有就放行让_quick_score处理)
            price = c.get("price", 0) or c.get("last_price", 0) or 0
            if price and price < 5:
                continue

            # 市值过滤 — 单位 USD (2026-08-12 实测 AAPL=4.45e12 锚定)
            mcap = c.get("market_val", 0) or c.get("market_cap", 0) or 0
            if mcap and mcap > 0:
                # 设计意图 $2B; 原 14e9 系"人民币"单位误读 (=实际 $14B)
                if mcap < 2e9:
                    continue

            gated.append(c)

        return gated

    def _four_signal_score(self, symbol: str, base_data: Dict) -> Dict:
        """四信号评分: catalyst + momentum + sentiment + value.

        替代旧_quick_score的单维度技术评分.
        每个信号0-10, 综合分=均权+渠道加成.
        """
        result = {
            "symbol": symbol,
            "name": base_data.get("name", ""),
            "price": base_data.get("price", 0) or base_data.get("last_price", 0) or 0,
            "change_pct": base_data.get("change_rate", 0) or base_data.get("change_pct", 0) or 0,
            "volume": base_data.get("volume", 0),
            "market_cap": base_data.get("market_val", 0) or base_data.get("market_cap", 0) or 0,
            "pe": base_data.get("pe", 0),
            "pb": base_data.get("pb", 0),
            "source": base_data.get("_source", ""),
            "channels": base_data.get("_channels", []),
            "score": 5.0,
            "signals": [],
            "signal_scores": {"catalyst": None, "momentum": None, "sentiment": None, "value": None},
        }

        # ── 采集快照+K线 ──
        snap = data_collector.collect_snapshot(symbol)
        if "_error" not in snap:
            _last = snap.get("last_price", 0) or 0
            _prev = snap.get("prev_close_price", 0) or 0
            result["pe_ttm"] = snap.get("pe_ttm_ratio", 0)
            result["high_52w"] = snap.get("highest52weeks_price", 0)
            result["low_52w"] = snap.get("lowest52weeks_price", 0)
            result["turnover_rate"] = snap.get("turnover_rate", 0)
            result["bid_ask_ratio"] = snap.get("bid_ask_ratio", 0)
            result["volume_ratio"] = snap.get("volume_ratio", 0)
            result["volume"] = snap.get("volume", 0)
            result["prev_close"] = _prev
            result["update_time"] = snap.get("update_time", "")
            # 2026-08-11 (LIF 盲区修复): change_pct/price 用 effective 口径 —
            #   盘前时段 last_price=昨收 (change 恒≈0), 真实异动在 pre_price。
            _eff = snap.get("effective_price", 0) or 0
            if snap.get("session") == "premarket" and _eff > 0:
                effective_change = snap.get("effective_chg_pct")
                result["change_pct"] = round(effective_change, 2) if effective_change is not None else None
                result["price"] = _eff
                result["premarket_chg_pct"] = round(snap.get("pre_change_rate", 0) or 0, 2)
            elif _last and _prev and _prev > 0:
                # 富途snapshot没有change_rate字段, 用last/prev计算
                result["change_pct"] = round((_last - _prev) / _prev * 100, 2)
            price = _eff or _last
            high52 = snap.get("highest52weeks_price", 0)
            low52 = snap.get("lowest52weeks_price", 0)
            if high52 and low52 and high52 > low52 and price:
                result["position_52w"] = round((price - low52) / (high52 - low52) * 100, 1)

        klines = data_collector.collect_kline(symbol, "1d", 20)
        closes = [k.get("close", 0) for k in klines] if klines else []
        volumes = [k.get("volume", 0) for k in klines] if klines else []

        # [prev_close 口径修复 2026-08-29] 富途快照盘前时段概率性返回两天前收盘
        #   (13天抽样 16/26 = 62% stale, 2026-08-29 日K交叉核验实锤; 例: RBRK
        #   scan_pc=96.13 实为 8/26 收盘, 真昨收 8/27=107.02)。盘前时段日K最后一根
        #   =最新完整交易日收盘=权威昨收, 且 klines 已在手 (零新增配额)。
        #   限盘前: 盘中/盘后最后一根是当日未完成(或当日)bar, 不能当昨收。
        #   premarket_chg_pct 来自快照 pre_change_rate (对真昨收计算, 已验证正确),
        #   不受影响; 此处只修落盘的 prev_close 基准字段。
        if (result.get("prev_close") and closes and closes[-1] > 0
                and snap.get("session") == "premarket" and "_error" not in snap):
            _true_pc = closes[-1]
            # 盘前 change_pct 同步用真昨收重算 — effective_chg_pct 受同一 stale
            #   prev_close 污染 (例: ESTC 显示 +24.7% 实为 +18.0%)
            _pre = snap.get("pre_price", 0) or 0
            if _pre > 0:
                result["change_pct"] = round((_pre - _true_pc) / _true_pc * 100, 2)
            result["prev_close"] = _true_pc

        # ════ Signal 1: Momentum (0-10) ════
        momentum_score = 5.0
        momentum_signals = []

        if len(closes) >= 20:
            ma5 = sum(closes[-5:]) / 5
            ma10 = sum(closes[-10:]) / 10
            ma20 = sum(closes[-20:]) / 20
            price = closes[-1]

            if ma5 > ma10 > ma20 and price > ma5:
                momentum_score += 3.0
                momentum_signals.append("多头排列")
            elif ma5 < ma10 < ma20 and price < ma5:
                momentum_score -= 3.0
                momentum_signals.append("空头排列")
            elif ma5 > ma10:
                momentum_score += 1.5
                momentum_signals.append("短期偏多")

            if len(closes) >= 6:
                chg5 = (closes[-1] - closes[-6]) / closes[-6] * 100
                result["change_5d"] = round(chg5, 2)
                if chg5 > 10:
                    momentum_score += 1.5
                    momentum_signals.append(f"5日+{chg5:.1f}%")
                elif chg5 < -10:
                    momentum_score -= 1.5
                    momentum_signals.append(f"5日{chg5:.1f}%")

            avg_vol = sum(volumes) / len(volumes) if volumes else 0
            if avg_vol and volumes:
                vol_ratio = volumes[-1] / avg_vol
                result["vol_ratio"] = round(vol_ratio, 2)
                if vol_ratio > 2.0:
                    momentum_score += 1.0
                    momentum_signals.append(f"放量{vol_ratio:.1f}x")

        momentum_score = max(0, min(10, momentum_score))
        result["signal_scores"]["momentum"] = round(momentum_score, 1)
        result["signals"].extend(momentum_signals)

        # ════ Signal 2: Value (0-10) ════
        value_score = 5.0
        value_signals = []

        pe = result.get("pe_ttm", 0) or result.get("pe", 0)
        if pe < 0:
            value_score -= 2.0
            value_signals.append(f"PE{pe:.1f}亏损")
        elif 0 < pe < 15:
            value_score += 3.0
            value_signals.append(f"PE{pe:.1f}低估值")
        elif 15 <= pe <= 35:
            pass  # 合理
        elif 35 < pe <= 60:
            value_score -= 1.0
        elif pe > 200:
            value_score -= 2.0
            value_signals.append(f"PE{pe:.0f}极度高估")
        elif pe > 60:
            value_score -= 1.5
            value_signals.append(f"PE{pe:.1f}高估值")

        # 52周位置: 低位=价值高, 高位=价值低
        pos = result.get("position_52w", 50)
        if pos < 20:
            value_score += 1.5
            value_signals.append("贴52周低")
        elif pos > 90:
            value_score -= 1.0
            value_signals.append("贴52周高")

        value_score = max(0, min(10, value_score))
        result["signal_scores"]["value"] = round(value_score, 1)
        result["signals"].extend(value_signals)

        # ════ Signal 3: Catalyst (0-10, 从渠道命中+财报超预期推断) ════
        catalyst_score = 5.0
        catalyst_signals = []

        channels = base_data.get("_channels", [])
        if "earnings_surprise" in channels:
            surprise = base_data.get("surprise_pct", 0) or 0
            if abs(surprise) > 20:
                catalyst_score += 3.0
                catalyst_signals.append(f"财报超预期{surprise:+.0f}%")
            elif abs(surprise) > 5:
                catalyst_score += 1.5
                catalyst_signals.append(f"财报beat{surprise:+.0f}%")

        if "after_hours" in channels:
            catalyst_score += 1.0
            catalyst_signals.append("夜盘异动")

        # 2026-08-11: 盘前异动渠道 — 当日趋势第一个信号, 涨跌都算催化。
        #   不预设方向 (跌≠做空, 可能是错杀; 涨≠做多, 可能是冲高回落),
        #   方向判定交给 LLM 深分析层 (prompt 有盘前段); 此处只做"值得深看"加成。
        if "premarket_movers" in channels:
            _pm_chg = base_data.get("premarket_chg_pct", 0) or 0
            catalyst_score += 2.0
            catalyst_signals.append(f"盘前{_pm_chg:+.1f}%")
            result["premarket_chg_pct"] = _pm_chg
            result["premarket_price"] = base_data.get("premarket_price", 0)
            result["premarket_volume"] = base_data.get("premarket_volume", 0)

        if "insider_movers" in channels:
            catalyst_score += 1.0
            catalyst_signals.append("内部人异动")

        # 渠道命中加成
        n_channels = len(channels)
        if n_channels >= 3:
            catalyst_score += 1.0
            catalyst_signals.append(f"多渠道命中({n_channels})")

        catalyst_score = max(0, min(10, catalyst_score))
        result["signal_scores"]["catalyst"] = round(catalyst_score, 1)
        result["signals"].extend(catalyst_signals)

        # ════ Signal 4: Sentiment (0-10, 从社区情绪推断) ════
        # 扫描层不做逐标的社区情绪采集(太慢), 用bid_ask_ratio+volume_ratio作为情绪代理
        sentiment_score = 5.0
        sentiment_signals = []

        bid_ask = result.get("bid_ask_ratio", 0) or 0
        if bid_ask > 1.5:
            sentiment_score += 1.5
            sentiment_signals.append("买盘占优")
        elif bid_ask < 0.5 and bid_ask > 0:
            sentiment_score -= 1.5
            sentiment_signals.append("卖盘占优")

        vol_ratio = result.get("volume_ratio", 0) or result.get("vol_ratio", 0) or 0
        if vol_ratio > 2.0:
            sentiment_score += 1.0
            sentiment_signals.append("交投活跃")

        sentiment_score = max(0, min(10, sentiment_score))
        if sentiment_signals:
            result["signal_scores"]["sentiment"] = round(sentiment_score, 1)
            result["signals"].extend(sentiment_signals)
        else:
            result["signal_scores"]["sentiment"] = None  # 无数据

        # ════ 综合分 ════
        # 均权, N/A不计分母
        valid_scores = [v for v in result["signal_scores"].values() if v is not None]
        if valid_scores:
            composite = sum(valid_scores) / len(valid_scores)
        else:
            composite = 5.0

        # 渠道加成 (每多一渠道+0.5, 封顶10)
        n_ch = len(base_data.get("_channels", []))
        composite += (n_ch - 1) * 0.5 if n_ch > 1 else 0

        # 市值加减分 (大盘股微加, 小盘微减)
        mcap = result.get("market_cap", 0) or 0
        if mcap:
            mcap_b = mcap / 1e9
            if mcap_b < 5:
                composite -= 0.5
                result["signals"].append(f"小盘${mcap_b:.1f}B")
            elif mcap_b >= 100:
                composite += 0.3
                result["signals"].append(f"大盘${mcap_b:.0f}B")

        # 主流标的微加
        bare = symbol.split(".")[-1] if "." in symbol else symbol
        mainstream_tickers = {
            "AAPL","MSFT","GOOGL","GOOG","AMZN","NVDA","META","TSLA","AVGO",
            "JPM","V","JNJ","WMT","MA","PG","HD","CVX","MRK","ABBV","KO","PEP","COST",
            "AMD","INTC","CRM","ADBE","NFLX","ORCL","PYPL","QCOM","DIS","NKE",
            "IBM","GS","MS","C","BAC","WFC","MO","T","VZ","UPS","ABT","MMM",
            "CSCO","ACN","MCD","TMO","DHR","TXN","LIN","SCHW","PNC","UNH","LOW",
            "NEE","PM","BMY","COF","SPGI","INTU","HON","DUK","TGT","CMG",
            "PLTR","SOFI","RIVN","COIN","HOOD","MSTR","SMCI","SNOW","CRWD","DDOG",
        }
        if bare in mainstream_tickers:
            composite += 0.2
            result["signals"].append("主流标的")

        result["score"] = round(max(0, min(10, composite)), 2)

        # 评级
        score = result["score"]
        if score >= 7:
            result["rating"] = "看多"
            result["action"] = "🟢做多"
        elif score >= 5.5:
            result["rating"] = "轻度看多"
            result["action"] = "🟢做多(小仓)"
        elif score >= 4.5:
            result["rating"] = "观望"
            result["action"] = "⚪观望"
        elif score >= 3:
            result["rating"] = "轻度看空"
            result["action"] = "🔴回避"
        else:
            result["rating"] = "看空"
            result["action"] = "🔴做空/回避"

        # featured override: momentum≥8且方向确定 → 即使综合分不够也单列
        if result["signal_scores"]["momentum"] and result["signal_scores"]["momentum"] >= 8:
            result["featured"] = True
            result["signals"].append("⭐featured(momentum≥8)")

        # value trap检测: PE低但5日跌>10% → 降value分
        if (result["signal_scores"]["value"] and result["signal_scores"]["value"] >= 7
                and result.get("change_5d", 0) < -10):
            result["signal_scores"]["value"] = 4.0
            result["signals"].append("⚠️value trap(板块de-rating)")
            # 重算综合分
            valid_scores = [v for v in result["signal_scores"].values() if v is not None]
            if valid_scores:
                result["score"] = round(max(0, min(10, sum(valid_scores) / len(valid_scores))), 2)

        return result

    def _collect_sector_data(self, scored: List[Dict]) -> Dict:
        """采集板块ETF涨跌排名 + 个股sector映射.

        复用FTSeek premarket_scanner的SPDR ETF列表.
        """
        etf_map = {
            "XLK": "Technology", "XLF": "Financials", "XLE": "Energy",
            "XLV": "Healthcare", "XLI": "Industrials", "XLY": "Consumer Discretionary",
            "XLP": "Consumer Staples", "XLC": "Communication", "XLU": "Utilities",
            "XLRE": "Real Estate", "XLB": "Materials",
        }

        # 采集板块ETF涨跌
        # [2026-11-06 输入保真] 原实现 `pct = ... else 0` 在 prev_close 缺失时 fail-soft 写 0.00,
        #   而下游 sorted() 把 0.00 当真实涨跌参与排序 ⇒ **缺失板块被排成 strongest**。
        #   实测(11-06): XLK 真实 -8.00% 被写成 +0.00%, "最强 Technology/Financials/Healthcare"
        #   全是缺失值, 该结论进了 DA prompt / UE prompt / deep_sector_rotation.json。
        #   缺失必须显式缺席, 不得伪装成 0 涨跌。
        sector_changes = {}
        missing_sectors = []
        for etf in etf_map:
            try:
                snap = data_collector.collect_snapshot(f"US.{etf}")
                if "_error" in snap:
                    missing_sectors.append(etf_map[etf])
                    continue
                _last = snap.get("last_price", 0) or 0
                _prev = snap.get("prev_close_price", 0) or snap.get("prev_close", 0) or 0
                if not (_prev and _prev > 0 and _last > 0):
                    missing_sectors.append(etf_map[etf])
                    continue
                sector_changes[etf_map[etf]] = round(((_last - _prev) / _prev) * 100, 2)
            except Exception:
                missing_sectors.append(etf_map[etf])

        # 排名: 名次只允许由真实涨跌产生; 覆盖率不足时**不出名次**
        _cov = (len(sector_changes) / len(etf_map)) if etf_map else 0.0
        if _cov >= 0.7 and len(sector_changes) >= 3:
            sorted_sectors = sorted(sector_changes.items(), key=lambda x: x[1], reverse=True)
            strongest = [s[0] for s in sorted_sectors[:3]]
            weakest = [s[0] for s in sorted_sectors[-3:]]
        else:
            strongest = []
            weakest = []

        # 个股sector映射 (从company_profile.industry)
        symbol_sectors = {}
        for s in scored:
            sym = s.get("symbol", "")
            if not sym:
                continue
            try:
                profile = data_collector.collect_company_profile(sym)
                if "_error" not in profile and profile.get("industry"):
                    symbol_sectors[sym] = profile["industry"]
            except Exception:
                pass

        return {
            "sector_changes": sector_changes,
            "strongest": strongest,
            "weakest": weakest,
            # [2026-11-06] 缺失板块显式外露 (消费者据此禁止讲轮动, 不再把缺失读成 0 涨跌)
            "missing_sectors": missing_sectors,
            "coverage": round(_cov, 2),
            "symbol_sectors": symbol_sectors,
        }

    def _sector_narrative(self, scored: List[Dict], sector_rotation: Dict) -> str:
        """生成KO级板块叙事 (替代旧_market_narrative).

        要素: ①方向定调 ②涨跌极值 ③板块轮动叙事 ④资金切换
        """
        if not scored:
            return "数据不足"

        changes = [s.get("change_pct") for s in scored if s.get("change_pct") is not None]
        up = [s for s in scored if s.get("change_pct") is not None and s.get("change_pct") > 0]
        down = [s for s in scored if s.get("change_pct") is not None and s.get("change_pct") < 0]
        flat = [s for s in scored if s.get("change_pct") == 0]
        unknown = len(scored) - len(changes)
        avg_change = sum(changes) / len(changes) if changes else None

        # ① 方向性定调
        up_ratio = len(up) / len(changes) * 100 if changes else 0
        if avg_change is None:
            tone = "涨跌数据不足"
        elif avg_change > 2 and up_ratio > 65:
            tone = "普涨行情"
        elif avg_change < -2 and (100 - up_ratio) > 65:
            tone = "普跌行情"
        elif len(flat) == len(scored):
            tone = "休市/盘前无变动"
        else:
            tone = "震荡分化"

        avg_text = f"{avg_change:+.1f}%" if avg_change is not None else "N/A"
        narrative = (f"扫描{len(scored)}只候选：{len(up)}涨{len(down)}跌{len(flat)}平"
                     f"{unknown}未知，平均{avg_text}，{tone}。")

        # ② 涨跌极值
        if up:
            top_gainer = max(up, key=lambda x: x.get("change_pct", 0))
            if abs(top_gainer.get("change_pct", 0)) >= 3:
                narrative += f" 涨幅领涨：{top_gainer['symbol']}({top_gainer.get('change_pct',0):+.1f}%)"
        if down:
            top_loser = min(down, key=lambda x: x.get("change_pct", 0))
            if abs(top_loser.get("change_pct", 0)) >= 3:
                narrative += f" 跌幅最深：{top_loser['symbol']}({top_loser.get('change_pct',0):+.1f}%)"

        # ③ 板块轮动叙事
        sector_changes = sector_rotation.get("sector_changes", {})
        _missing_sec = sector_rotation.get("missing_sectors") or []
        _tot_sec = len(sector_changes) + len(_missing_sec)
        if _missing_sec:
            # [2026-11-06] 缺失必须可见: 缺板块时不做强弱判断 (原实现用剩余/零值讲"均衡",
            #   实测 11-06 把 XLK 真实 -8.00% 的缺失写成"最强 Technology(+0.0%)")
            narrative += (f" 板块快照不完整({len(sector_changes)}/{_tot_sec} 缺失: "
                          f"{'/'.join(_missing_sec)})，不据此判断轮动。")
        elif sector_changes:
            strongest = sector_rotation.get("strongest", [])
            weakest = sector_rotation.get("weakest", [])
            if strongest and weakest:
                strong_chg = sector_changes.get(strongest[0], 0)
                weak_chg = sector_changes.get(weakest[-1] if weakest else "", 0)
                if abs(strong_chg - weak_chg) > 3:
                    narrative += f" 板块轮动：资金切向{'/'.join(strongest[:2])}"
                    if weak_chg < 0:
                        narrative += f"(+{strong_chg:.1f}%)，撤离{'/'.join(weakest[-2:])}({weak_chg:.1f}%)"
                    narrative += "。"
                else:
                    narrative += f" 板块表现均衡，最强{strongest[0]}({strong_chg:+.1f}%)。"

        # ④ 资金切换 (从signals推断)
        bullish_stocks = [s["symbol"] for s in scored
                          if any("多头" in sig or "放量" in sig or "低估值" in sig
                                 for sig in s.get("signals", []))]
        bearish_stocks = [s["symbol"] for s in scored
                          if any("空头" in sig or "高估值" in sig
                                 for sig in s.get("signals", []))]
        if bullish_stocks:
            narrative += f" 多头信号：{','.join(bullish_stocks[:3])}。"
        if bearish_stocks:
            narrative += f" 空头信号：{','.join(bearish_stocks[:3])}。"

        # ⑤ 量能
        high_volume = [s for s in scored if s.get("vol_ratio", 0) >= 2.0]
        if high_volume:
            narrative += f" 放量股：{','.join(s['symbol'] for s in high_volume[:3])}。"

        # ⑥ 盘前异动 (2026-08-11, LIF 盲区修复): 当日趋势第一信号, 显式呈现。
        _pm = [s for s in scored if abs(s.get("premarket_chg_pct", 0) or 0) >= 4.0]
        if _pm:
            _pm.sort(key=lambda x: abs(x.get("premarket_chg_pct", 0)), reverse=True)
            narrative += " 盘前异动：" + " ".join(
                f"{s['symbol']}({s['premarket_chg_pct']:+.1f}%)" for s in _pm[:4]) + "。"

        return narrative

    def _bucketing(self, scored: List[Dict]) -> Dict:
        """操作分桶: 质地/突破型, 超跌反弹型, 趋势空, 回避, 观望.

        参考报告5桶设计, 每桶有strategy_type和position_size_hint.
        """
        buckets = {"bullish": [], "bearish": [], "watchlist": [], "avoid": []}

        for s in scored:
            score = s.get("score", 5)
            momentum = s.get("signal_scores", {}).get("momentum", 5) or 5
            chg_5d = s.get("change_5d", 0)
            pos_52w = s.get("position_52w", 50)

            # 回避桶: 当日跌>5%且5日跌>15%
            chg_today = s.get("change_pct", 0)
            if chg_today is not None and chg_today < -5 and chg_5d < -15:
                s["strategy_type"] = "avoid"
                s["position_size_hint"] = "none"
                s["bucket_reason"] = "falling knife"
                buckets["avoid"].append(s)
                continue

            # 质地/突破型: score≥6 + momentum≥6 + 52周位置>30
            if score >= 6 and momentum >= 6 and pos_52w > 30:
                s["strategy_type"] = "quality_breakout"
                s["position_size_hint"] = "normal"
                s["bucket_reason"] = "质地/突破"
                buckets["bullish"].append(s)
                continue

            # 超跌反弹型: score≥5.5 + 5日跌>10% + 52周位置<20
            if score >= 5.5 and chg_5d < -10 and pos_52w < 20:
                s["strategy_type"] = "oversold_bounce"
                s["position_size_hint"] = "small"
                s["bucket_reason"] = "超跌反弹"
                buckets["bullish"].append(s)
                continue

            # 趋势空型: score≤4 + 空头排列(从signals判断)
            if score <= 4 and any("空头" in sig for sig in s.get("signals", [])):
                s["strategy_type"] = "trend_short"
                s["position_size_hint"] = "small"
                s["bucket_reason"] = "趋势空"
                buckets["bearish"].append(s)
                continue

            # 观望桶: 4<score<5.5 或 方向打架
            s["strategy_type"] = "watch"
            s["position_size_hint"] = "none"
            s["bucket_reason"] = "方向未定"
            buckets["watchlist"].append(s)

        # 各桶内排序 ([P1.4 2026-09-12] 空头桶口径修正):
        #   bearish 桶的入桶条件是 score<=4 (分越低越空), 原"score 降序"= 把**最弱的
        #   空头**排在最前, 配合下游 [:top_n] 截断会先丢掉最强空头 (8/26 起多次
        #   出现"跌幅榜龙头进不了深分析"的直接成因之一)。改按方向强度 10-score 降序
        #   (= score 升序), 与 pipeline Stage2 的 conviction 口径一致。
        #   其余桶 (bullish/watchlist/avoid) 维持 score 降序, 排序含义不变。
        for key in buckets:
            if key == "bearish":
                buckets[key].sort(key=lambda x: 10.0 - float(x.get("score", 0) or 0),
                                  reverse=True)
            else:
                buckets[key].sort(key=lambda x: x.get("score", 0), reverse=True)

        return buckets

    def _quick_score(self, symbol: str, base_data: Dict) -> Dict:
        """快速评分（只看快照+少量K线）"""
        result = {
            "symbol": symbol,
            "name": base_data.get("name", ""),
            "price": base_data.get("price", 0),
            "change_pct": base_data.get("change_rate", 0),
            "volume": base_data.get("volume", 0),
            "market_cap": base_data.get("market_val", 0),
            "pe": base_data.get("pe", 0),
            "pb": base_data.get("pb", 0),
            "source": base_data.get("_source", ""),
            "score": 5.0,
            "signals": [],
        }

        # ── 市值过滤：对标KO示例($126亿)，低于$50亿的中小盘降分 ──
        mcap = base_data.get("market_val", 0) or 0
        if mcap and mcap > 0:
            mcap_b = mcap / 1e9
            if mcap_b < 5:
                # <50亿：小盘股，降分（不是不做，是降低优先级）
                result["score"] -= 0.5
                result["signals"].append(f"小盘${mcap_b:.1f}B")
            elif mcap_b >= 100:
                result["score"] += 0.3
                result["signals"].append(f"大盘${mcap_b:.0f}B")

        # ── 主流标的偏好：知名大盘股给予微小加分 ──
        # 不是硬编码白名单，而是识别市场关注度高的标的
        bare = symbol.split(".")[-1] if "." in symbol else symbol
        mainstream_tickers = {
            "AAPL","MSFT","GOOGL","GOOG","AMZN","NVDA","META","TSLA","AVGO","BRK.B",
            "JPM","V","JNJ","WMT","MA","PG","HD","CVX","MRK","ABBV","KO","PEP","COST",
            "AMD","INTC","CRM","ADBE","NFLX","ORCL","PYPL","QCOM","TMUS","DIS","NKE",
            "IBM","GS","MS","C","BAC","WFC","MO","T","VZ","CMCSA","UPS","ABT","MMM",
            "CSCO","ACN","MCD","TMO","WMT","DHR","TXN","LIN","SCHW","PNC","UNH","LOW",
            "RTI","NEE","PM","BMY","COF","SPGI","INTU","AMD","HON","DUK","TGT","CMG",
            "PLTR","SOFI","RIVN","COIN","HOOD","MSTR","SMCI","SNOW","CRWD","DDOG",
        }
        if bare in mainstream_tickers:
            result["score"] += 0.2
            result["signals"].append("主流标的")

        # 采集快照（获取更完整数据）
        snap = data_collector.collect_snapshot(symbol)
        if "_error" not in snap:
            result["pe_ttm"] = snap.get("pe_ttm_ratio", 0)
            result["high_52w"] = snap.get("highest52weeks_price", 0)
            result["low_52w"] = snap.get("lowest52weeks_price", 0)
            result["turnover_rate"] = snap.get("turnover_rate", 0)
            result["bid_ask_ratio"] = snap.get("bid_ask_ratio", 0)
            result["volume_ratio"] = snap.get("volume_ratio", 0)

            # 52周位置
            high52 = snap.get("highest52weeks_price", 0)
            low52 = snap.get("lowest52weeks_price", 0)
            price = snap.get("last_price", 0)
            if high52 and low52 and high52 > low52:
                pos = (price - low52) / (high52 - low52) * 100
                result["position_52w"] = round(pos, 1)

        # 采集K线（20天，快速判断趋势）
        klines = data_collector.collect_kline(symbol, "1d", 20)
        if klines:
            closes = [k.get("close", 0) for k in klines]
            volumes = [k.get("volume", 0) for k in klines]

            # MA
            ma5 = sum(closes[-5:]) / 5 if len(closes) >= 5 else 0
            ma10 = sum(closes[-10:]) / 10 if len(closes) >= 10 else 0
            ma20 = sum(closes[-20:]) / 20 if len(closes) >= 20 else 0

            price = closes[-1] if closes else 0
            # 在已有score（市值/主流标的加减分）基础上累加，不重置
            score = result.get("score", 5.0)
            signals = result.get("signals", [])

            # 趋势
            if ma5 > ma10 > ma20 and price > ma5:
                score += 1.0
                signals.append("多头排列")
            elif ma5 < ma10 < ma20 and price < ma5:
                score -= 1.0
                signals.append("空头排列")
            elif ma5 > ma10:
                score += 0.5
                signals.append("短期偏多")

            # 动量（5日涨幅）
            if len(closes) >= 6:
                chg5 = (closes[-1] - closes[-6]) / closes[-6] * 100
                result["change_5d"] = round(chg5, 2)
                if chg5 > 10:
                    score += 0.5
                    signals.append(f"5日+{chg5:.1f}%")
                elif chg5 < -10:
                    score -= 0.5
                    signals.append(f"5日{chg5:.1f}%")

            # 量价
            avg_vol_20 = sum(volumes) / len(volumes) if volumes else 0
            if avg_vol_20 and volumes:
                vol_ratio = volumes[-1] / avg_vol_20
                result["vol_ratio"] = round(vol_ratio, 2)
                if vol_ratio > 2.0:
                    score += 0.5
                    signals.append(f"放量{vol_ratio:.1f}x")

            # 52周位置
            pos = result.get("position_52w", 50)
            if pos > 95:
                score -= 0.3
                signals.append("贴近52周高")
            elif pos < 10:
                score += 0.3
                signals.append("贴52周低")

            # 估值 — KO示例对标：PE必须与行业中枢对比
            pe = result.get("pe_ttm", 0) or result.get("pe", 0)
            if pe < 0:
                # 亏损股：PE为负，标注高风险
                score -= 0.5
                signals.append(f"PE{pe:.1f}亏损")
            elif 0 < pe < 15:
                score += 0.3
                signals.append(f"PE{pe:.1f}低估值")
            elif 15 <= pe <= 35:
                # 合理估值区间，不加不减
                pass
            elif 35 < pe <= 60:
                # 偏高但有成长性可能
                score -= 0.1
            elif pe > 200:
                score -= 0.5
                signals.append(f"PE{pe:.0f}极度高估")
            elif pe > 60:
                score -= 0.3
                signals.append(f"PE{pe:.1f}高估值")

            result["score"] = round(max(0, min(10, score)), 2)
            result["signals"] = signals

        # 评级
        score = result["score"]
        if score >= 7:
            result["rating"] = "看多"
            result["action"] = "🟢做多"
        elif score >= 5.5:
            result["rating"] = "轻度看多"
            result["action"] = "🟢做多(小仓)"
        elif score >= 4.5:
            result["rating"] = "观望"
            result["action"] = "⚪观望"
        elif score >= 3:
            result["rating"] = "轻度看空"
            result["action"] = "🔴回避"
        else:
            result["rating"] = "看空"
            result["action"] = "🔴做空/回避"

        return result

    def _market_narrative(self, scored: List[Dict]) -> str:
        """根据扫描结果生成KO级市况叙事。

        KO示例对标：
        【市况】美股7/2收盘=「AI见顶恐慌」两日半导体估值重置：
        存储/半导体设备血洗（MRVL−12%、SNDK−16%、VICR/ACLS−19%），
        资金切向加密金融（MSTR/COIN/HOOD+8~12%）+优质防御（AAPL+4.8%、医疗/材料）。

        需要要素：①方向性定调 ②涨跌极值个股标注 ③资金切换叙事 ④板块特征
        """
        if not scored:
            return "数据不足"

        changes = [s.get("change_pct") for s in scored if s.get("change_pct") is not None]
        up = [s for s in scored if s.get("change_pct") is not None and s.get("change_pct") > 0]
        down = [s for s in scored if s.get("change_pct") is not None and s.get("change_pct") < 0]
        flat = [s for s in scored if s.get("change_pct") == 0]
        unknown = len(scored) - len(changes)
        avg_change = sum(changes) / len(changes) if changes else None

        # ① 方向性定调
        up_ratio = len(up) / len(changes) * 100 if changes else 0
        if avg_change is None:
            tone = "涨跌数据不足"
        elif avg_change > 2 and up_ratio > 65:
            tone = "普涨行情"
        elif avg_change < -2 and (100 - up_ratio) > 65:
            tone = "普跌行情"
        elif len(flat) == len(scored):
            tone = "休市/盘前无变动"
        else:
            tone = "震荡分化"

        avg_text = f"{avg_change:+.1f}%" if avg_change is not None else "N/A"
        narrative = (f"扫描{len(scored)}只候选：{len(up)}涨{len(down)}跌{len(flat)}平"
                     f"{unknown}未知，平均{avg_text}，{tone}。")

        # ② 涨跌极值个股标注（KO示例的"MRVL−12%、SNDK−16%"）
        if up:
            top_gainer = max(up, key=lambda x: x.get("change_pct", 0))
            if abs(top_gainer.get("change_pct", 0)) >= 3:
                narrative += f" 涨幅领涨：{top_gainer['symbol']}({top_gainer.get('change_pct',0):+.1f}%)"
        if down:
            top_loser = min(down, key=lambda x: x.get("change_pct", 0))
            if abs(top_loser.get("change_pct", 0)) >= 3:
                narrative += f" 跌幅最深：{top_loser['symbol']}({top_loser.get('change_pct',0):+.1f}%)"

        # ③ 资金切换叙事 — 从signals推断板块轮动
        bullish_sectors = []
        bearish_sectors = []
        for s in scored:
            for sig in s.get("signals", []):
                if "多头" in sig or "放量" in sig or "低估值" in sig:
                    bullish_sectors.append(s["symbol"])
                if "空头" in sig or "高估值" in sig:
                    bearish_sectors.append(s["symbol"])

        if bullish_sectors:
            narrative += f" 多头信号集中在{','.join(bullish_sectors[:3])}。"
        if bearish_sectors:
            narrative += f" 空头信号集中在{','.join(bearish_sectors[:3])}。"

        # ④ 量能特征
        high_volume = [s for s in scored if s.get("volume_ratio", 0) >= 2.0]
        if high_volume:
            narrative += f" 放量股：{','.join(s['symbol'] for s in high_volume[:3])}。"

        return narrative


def format_scan_result(result: Dict) -> str:
    """格式化扫描结果为可读文本 (v0.23: 含板块轮动+操作分桶)"""
    lines = []
    lines.append(f"🔍 机会扫描 · {time.strftime('%Y-%m-%d %H:%M:%S')}")
    lines.append(f"【市况】{result['market_condition']}")
    lines.append("")

    # 板块轮动
    sr = result.get("sector_rotation", {})
    if sr.get("sector_changes"):
        sc = sr["sector_changes"]
        sorted_sc = sorted(sc.items(), key=lambda x: x[1], reverse=True)
        lines.append("【板块轮动】" + " | ".join(f"{s}:{v:+.1f}%" for s, v in sorted_sc[:5]))
        lines.append("")

    # 渠道质量
    dq = result.get("data_quality", {})
    if dq:
        lines.append(f"【渠道】green: {dq.get('channels_green', [])} | empty: {dq.get('channels_empty', [])}")
        lines.append(f"【质量闸】{dq.get('raw_count', 0)} → {result.get('candidates_total', 0)}")
        lines.append("")

    # Top Bullish
    if result["top_bullish"]:
        lines.append("🟢 做多候选 Top:")
        for i, s in enumerate(result["top_bullish"], 1):
            ch = s.get("channels", [])
            sig_scores = s.get("signal_scores", {})
            lines.append(
                f"  {i}. {s.get('name','')} {s['symbol']}｜{s.get('rating','')}｜"
                f"综合 {s['score']}｜{s.get('bucket_reason','')}｜"
                f"M{sig_scores.get('momentum','?')} V{sig_scores.get('value','?')} "
                f"C{sig_scores.get('catalyst','?')} S{sig_scores.get('sentiment','?')}｜"
                f"渠道:{','.join(ch[:2])}"
            )
        lines.append("")

    # Top Bearish
    if result["top_bearish"]:
        lines.append("🔴 做空/回避 Top:")
        for i, s in enumerate(result["top_bearish"], 1):
            sig_scores = s.get("signal_scores", {})
            lines.append(
                f"  {i}. {s.get('name','')} {s['symbol']}｜{s.get('rating','')}｜"
                f"综合 {s['score']}｜{s.get('bucket_reason','')}｜"
                f"M{sig_scores.get('momentum','?')} V{sig_scores.get('value','?')}"
            )
        lines.append("")

    # Avoid
    if result.get("avoid"):
        lines.append("⚠️ 回避列表:")
        for s in result["avoid"]:
            lines.append(f"  · {s.get('name','')} {s['symbol']}｜{s.get('bucket_reason','')}｜{s['score']}")
        lines.append("")

    # Watchlist
    if result["watchlist"]:
        lines.append("⚪ 观望列表:")
        for s in result["watchlist"]:
            lines.append(f"  · {s.get('name','')} {s['symbol']}｜{s['score']}｜{s.get('bucket_reason','')}")
        lines.append("")

    lines.append(f"【数据】候选{result['candidates_total']}只，做多{len(result['top_bullish'])}，"
                 f"做空{len(result['top_bearish'])}，观望{len(result['watchlist'])}，"
                 f"回避{len(result.get('avoid',[]))}")
    return "\n".join(lines)


def main():
    import argparse
    parser = argparse.ArgumentParser(description="MarketScanner — 市场扫描")
    parser.add_argument("--market", default="US", help="市场 (US/HK)")
    parser.add_argument("--limit", type=int, default=10, help="每个榜单数量")
    parser.add_argument("--top", type=int, default=5, help="输出Top N")
    parser.add_argument("--format", choices=["json", "text"], default="text")
    args = parser.parse_args()

    scanner = MarketScanner(args.market, args.limit)
    result = scanner.scan(args.top)

    if args.format == "json":
        print(json.dumps(result, ensure_ascii=False, default=str, indent=2))
    else:
        print(format_scan_result(result))


if __name__ == "__main__":
    main()
