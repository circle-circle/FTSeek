#!/usr/bin/env python3
"""挑战者裁决规范状态 (纯函数, 2026-10-23).

病灶: 10/22 有 5 份 `verdict=PARTIAL_AGREE` 同时 `agreed=true`; 下游
signal_gate/adapter 以布尔值给一致度加成, 把"部分同意/有硬伤"当成"两模型一致".
本模块只产生规范状态; 原始字段由调用方保留, 不在这里改交易门.

优先级 (首个匹配):
  1 ANALYST_SKIP  — 分析师 SKIP, 不论挑战者
  2 UNAVAILABLE   — 挑战者失败/无可解析结果
  3 CONFLICT      — 方向/verdict 枚举无效或缺失
  4 ABSTAIN       — 挑战者有效 SKIP (即使 verdict=DISAGREE)
  5 AGREE         — 同向 + AGREE
  6 PARTIAL_AGREE — 同向 + PARTIAL_AGREE (agreed=true 不能升级)
  7 DISAGREE      — 反向 + DISAGREE
  8 CONFLICT      — 其余不自洽组合
"""
from __future__ import annotations

from typing import Any, Dict

VALID_DIRS = ("BUY", "SELL_SHORT", "SKIP")
VALID_VERDICTS = ("AGREE", "PARTIAL_AGREE", "DISAGREE")


def norm_direction(v: Any) -> str:
    d = str(v or "").strip().upper()
    return {"LONG": "BUY", "SHORT": "SELL_SHORT", "SELL": "SELL_SHORT"}.get(d, d)


def classify_debate(analyst_direction: Any, challenger_direction: Any,
                    verdict: Any, challenger_available: bool = True) -> Dict[str, Any]:
    a = norm_direction(analyst_direction)
    c = norm_direction(challenger_direction)
    v = str(verdict or "").strip().upper()
    if a == "SKIP":
        return {"state": "ANALYST_SKIP", "priority": 1,
                "reason": "analyst_skip_preserved"}
    if not challenger_available:
        return {"state": "UNAVAILABLE", "priority": 2,
                "reason": "challenger_unavailable"}
    if a not in VALID_DIRS or c not in VALID_DIRS or v not in VALID_VERDICTS:
        return {"state": "CONFLICT", "priority": 3,
                "reason": "invalid_direction_or_verdict"}
    if c == "SKIP":
        return {"state": "ABSTAIN", "priority": 4,
                "reason": "challenger_abstained"}
    if a == c and v == "AGREE":
        return {"state": "AGREE", "priority": 5, "reason": "same_direction_agree"}
    if a == c and v == "PARTIAL_AGREE":
        return {"state": "PARTIAL_AGREE", "priority": 6,
                "reason": "same_direction_partial"}
    if a != c and v == "DISAGREE":
        return {"state": "DISAGREE", "priority": 7,
                "reason": "opposite_direction_disagree"}
    return {"state": "CONFLICT", "priority": 8,
            "reason": "verdict_direction_mismatch"}
