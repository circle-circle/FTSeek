#!/usr/bin/env python3
"""
Config — 所有路径/密钥/模型配置的唯一定义
=================================================
任何模块需要路径或密钥，都从这里取，不硬编码。
改路径只改这一个文件。
"""

import os

# ── Python 环境 ──────────────────────────────────
# futu-api 10.05.6508 在 FTSeek venv 的 python3.11 下可用
PYTHON = "/opt/ftseek/FTSeek-US/venv/bin/python3.11"
OPEND_HOST = "127.0.0.1"
OPEND_PORT = "11111"

# ── 脚本路径 ──────────────────────────────────────
FUTUAPI_SCRIPTS = "/root/.hermes/skills/futuapi/scripts/quote"
ANOMALY_SCRIPTS = {
    "technical": "/root/.hermes/skills/futu-technical-anomaly/scripts/handle_technical_anomaly.py",
    "capital": "/root/.hermes/skills/futu-capital-anomaly/scripts/handle_capital_anomaly.py",
    "derivatives": "/root/.hermes/skills/futu-derivatives-anomaly/scripts/handle_derivatives_anomaly.py",
}
SKILL_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SCRIPTS_DIR = os.path.join(SKILL_DIR, "scripts")
DATA_DIR = os.path.join(SKILL_DIR, "data")

# ── HTTP API ──────────────────────────────────────
NEWS_BASE = "https://ai-news-search.futunn.com"
FINNHUB_BASE = "https://finnhub.io/api/v1"

# ── FTSeek 环境文件 (密钥来源) ────────────────────
FTSEEK_ENV = "/opt/ftseek/FTSeek-US/.env.us"
# 2026-08-03 (A/B 隔离): FTSEEK_DB 环境变量可覆盖 — A/B 测试指向临时库,
#   避免 ic_writer 等直连 sqlite3 模块污染生产. 默认不变.
FTSEEK_DB = os.environ.get("FTSEEK_DB", "") or "/opt/ftseek/FTSeek-US/data/ftseek_us.db"


def _read_env(key: str, filepath: str = "") -> str:
    """从环境变量或 .env 文件读取密钥"""
    val = os.environ.get(key, "")
    if val:
        return val
    fp = filepath or FTSEEK_ENV
    try:
        with open(fp) as f:
            for line in f:
                if f"{key}=" in line:
                    return line.split("=", 1)[1].strip()
    except Exception:
        pass
    return ""


# ── 密钥 ──────────────────────────────────────────
DASHSCOPE_KEY = _read_env("DASHSCOPE_API_KEY")
FINNHUB_KEY = _read_env("FINNHUB_API_KEY")

# ── LLM 配置 ──────────────────────────────────────
DASHSCOPE_URL = "https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions"
# 2026-08-03 (改进批 任务#3): LLM_MODEL 环境变量可覆盖 — A/B 换模型不再改源码.
# 2026-08-13 (统一配置获取): 改走 _read_env — 进程环境变量 > .env.us 文件 > 默认值.
#   修复缺口: os.environ.get 只读进程环境, DA cron(hermes终端,不经systemd)下写
#   .env.us 不生效; 现与密钥类同源, 配置位置统一为 /opt/ftseek/FTSeek-US/.env.us
# 2026-11-17 (用户裁决, DEB-20261117-da-analyst-qwen4max): 主分析 qwen3.7-max → qwen4-max.
#   诉求: 亏损严重/源头产出质量差, 换主分析模型. 可达性已实测 (2026-11-17 DashScope
#   实弹): /models 列表未收录但 chat 实弹回显 model=qwen4-max (列表滞后, 同 glm-5.3
#   先例); 生产同构回放 (AMD 2026-11-16 raw + SYSTEM_PROMPT + MAIN_EVENT_CONTRACT,
#   cache 数组格式 + json_object + temp0 + enable_thinking=True) 契约 23 键全在,
#   finish=stop. 配套三件 (同批, 缺一即切换空操作/超时): DA_THINKING_BUDGET
#   8192→16384 (见下) / llm_synth 分析师 timeout 240→600 / pipeline workers 5→8.
#   归因: 每行落 _model_reported + checkpoint _ckpt_model 按模型键控 (换模型自动
#   作废旧缓存), qwen4-max 时代 vs qwen3.7-max 时代样本天然可切分 (OKR-2026-11
#   主 KR = DA-only 净 bps/笔). 回滚: 本行改回 qwen3.7-max (备份
#   config.py.bak-llmmodel-qwen4max-20261117), 配套三件各自独立回滚.
LLM_MODEL = _read_env("LLM_MODEL") or "qwen4-max"
# 2026-08-13 (统一配置获取): 挑战者模型原硬编码在 llm_synth.py, 违背本文件
#   "所有模型配置唯一定义" 契约, 收归此处. 同 LLM_MODEL 模式.
#   分析师=综合策略师, 挑战者=风险审查官(天生偏空, 魔鬼代言人).
# 2026-08-27 (用户裁决): 默认挑战者 deepseek-v4-pro → deepseek-v4-pro-0813
#   (DashScope 日期快照, 固定版本防基别名静默升级)。原诉求 deepseek-v4-pro-0831
#   经 DashScope+官方API 双端实测不存在 (404/400); 0813 为现有唯一 pro 快照。
#   归因不受污染: 每条决策落 challenger_model/challenger_model_reported,
#   可按模型切分新旧样本。回滚: config.py.bak-challenger-0813-20260827。
#   [本节已被 2026-09-14 决定取代 — 保留原文供回滚对照, 现行值见下方赋值行]
# 2026-09-14 (用户裁决): DA 挑战者 deepseek-v4-pro-0813 → deepseek-v4.1-flash.
#   诉求: "DA 和 UE 中 deepseek 版本改 deepseek-v4.1-flash". UE 侧在
#   /opt/ftseek/FTSeek-US/config/unified_config.yaml (新增实体 deepseek-v41-flash,
#   只挂 universe_expansion_reasoning.fallback), 本文件是 DA 侧唯一改动点
#   (全文件仅此一处 deepseek — 已核).
#   ⚠️ 两点与 08-27 决定的口径差异 (记录在案, 非阻塞):
#   ① 无版本快照可 pin. 08-27 特意选日期快照 (-0813) 防"基别名静默升级";
#      DashScope 现无 deepseek-v4.1-flash 的日期快照变体 (实查 /models 只有裸名),
#      故本次无法沿用 pin 策略 — 上游换版对本地不可观测. 代偿: 归因字段仍在
#      (challenger_model/challenger_model_reported), 且 model_reported 回显会让
#      上游偷换暴露在 da_gate_decisions.jsonl 里 (基别名升级会改 reported 值).
#   ② 档位: pro→flash 降档 (v4.1 为 09-10 新代次, 但价/速属 flash 档). 挑战者位
#      的职责是"证伪+反证", 已按生产同构实弹核过不劣化 (见下).
#   生产同构实弹 (2026-09-14, 零生产写入直连 DashScope, 输入 8.0k tok ≈ 生产实测
#   7736-9490, enable_thinking=False + json_object + max_tokens=2000 + temp=0.4):
#     · v4.1-flash: 延迟 7.3s / finish=stop / JSON 合法 / 契约 12 键全在 / 无思考 token
#     · v4-pro-0813(现役): 延迟 16.9s / 同上全过
#     ⇒ 速度 2.3x, 契约满足无退化, 60s timeout 余量充足.
#   陷阱 (留给后来者): 挑战者调用点 (llm_synth.py _run_challenger) 不传 extra_body
#     ⇒ _call_llm 默认 enable_thinking=False ⇒ max_tokens=2000 全留给正文.
#     实弹反证: 若把 enable_thinking 打开, 两模型都会把 2000 全烧进 reasoning
#     (实测 completion=2000 且 reasoning=2000, content 为空 → JSON 解析必败 →
#     静默退化"同模型自我辩论"). 将来若要给挑战者开思考, 必须同时抬 max_tokens
#     (分析师现为 thinking_budget=2048 + max_tokens=6000).
#   回滚: config.py.bak-challenger-v41flash-20260914 (本行改回 -0813 即可).
CHALLENGER_MODEL = _read_env("CHALLENGER_MODEL") or "deepseek-v4.1-flash"
# 2026-09-18 (用户裁「做」): 挑战者**独立档 fallback** — 修复"失败即回落主模型 = 同模型自辩"
#   (违反 multi-model-debate SKILL:39「禁止一个模型自辩自裁」; 实测已转热: 全窗 5/109,
#    9/18 当日 3/23=13%)。三级链见 llm_synth._run_challenger。
#   家族约束: 分析师 = qwen 家族 (现 qwen4-max) ⇒ 两档 fallback 都必须**非 qwen 且彼此不同家族**
#   (T2 kimi = Moonshot, T3 glm = 智谱); 同家族/同 primary 家族一律不用。
#   选型依据 = 2026-09-18 五模型 × 两参数档实弹探针 (小 prompt, 只读):
#     kimi-k2.6   思考✅4.2s / 关思考✅1.1s  ← T2 (同参可比口径, 单价最低)
#     glm-5.2     思考✅5.4s / 关思考✅0.8s  ← T3 (关思考, 失败模式多样性)
#     glm-5.3     思考✅1.4s / **关思考 ✗ HTTP 400** (强制思考模型) ⇒ 不能当关思考档
#     deepseek-v4-pro 双档可用但同 primary 家族 ⇒ 不用
#   成本: T2 ~$0.011/次 × ~1 次/日 ≈ $0.01/日 (可忽略)。归因: 每行落
#   challenger_model / _challenger_tier / _challenger_self_debate ⇒ 模型时代可切分。
#   回滚: 删本两行 + 恢复 llm_synth.py.bak-challengerchain-20260918。
CHALLENGER_FALLBACK_MODEL = _read_env("CHALLENGER_FALLBACK_MODEL") or "kimi-k2.6"
CHALLENGER_FALLBACK_MODEL_2 = _read_env("CHALLENGER_FALLBACK_MODEL_2") or "glm-5.2"
# 2026-09-01 (PE 审阅·执行批): DA 分析师 system 前缀缓存开关 — DashScope 显式前缀缓存,
#   与网关 app/llm/model_call.py 同格式 (cache_control=ephemeral, 网关侧已实弹验证:
#   创建 3719tok → 第2发 cached=3719 命中 99.4%)。仅改传输消息格式, 不改 prompt 内容,
#   PROMPT_HASH/基线切分不受影响。收益: 同一 DA 轮内 7± 候选共享静态 system 前缀,
#   省输入 token + 降首 token 延迟。挑战者 (deepseek-v4-pro-0813) 不启用 — 数组格式
#   在该模型上未验证, 保持字节级原样。
#   回滚: .env.us 加 DA_PROMPT_CACHE=0 (或进程环境), 即恢复纯字符串 system。
DA_PROMPT_CACHE = (_read_env("DA_PROMPT_CACHE") or "1") != "0"
# 2026-11-17 (DEB-20261117 第2轮, 用户裁「确保不要限制模型自身的能力, 充分发挥信息
#   整理和有效推理」): 信息输入全量开关. 呈现层原丢弃大部分已采集数据:
#   60日K线只渲染近5日 / 新闻10条只给8条标题 / 社区30帖只给5帖×120字 /
#   内部人10笔只给5笔 / 研报只给5条 / Finnhub摘要采集端截200字(源最长1879字).
#   =1(默认): K线全60日 / 新闻全量(采集20) / 社区30帖×800字 / 内部人全量 /
#   研报10条 / Finnhub新闻12条×800字摘要. 零新增API调用(同源放宽截断),
#   输入增量实测见 DEB §R2. 回滚: .env.us 加 DA_INPUT_FULL=0 → 逐字节原截断行为.
DA_INPUT_FULL = (_read_env("DA_INPUT_FULL") or "1") != "0"
# 2026-11-27 (RFC-218 §8 P0 资金分布正确消费, 用户裁「按照建议合理优化落地」):
#   资金分布 code 错配修复独立开关. 病灶: Futu provider get_capital_distribution.py
#   返回 {"code": <ticker字符串>, capital_in_*...}, 而 llm_synth/deep_analyzer 两条
#   消费路径误以成功码 `code==0` 判定 → 35/35 份 11-25 有效 payload 正式块被丢.
#   =1: 以「八字段存在」判定有效分布 payload, 正式「## 资金面」块恢复渲染;
#   =0(默认): 逐字节保留旧 `code==0` 门 (当前生产行为不变, 影子先行/单变量就绪).
#   这是正式输入正确性修复、收益假设相邻 → 激活须按 RFC-218 §10.4 单变量 A/B
#   (n≥120 且 ≥20 独立 ET 日, 预注册 MDE), 不得当纯遥测直接上线.
#   回滚: .env.us 加 DA_CAPITAL_CODE_FIX=0 (或删除该行) → 旧渲染. 刻意不复用
#   DA_INPUT_FULL (RFC-218 §8 回滚约束: 独立开关, 不与其他输入变量捆绑).
DA_CAPITAL_CODE_FIX = (_read_env("DA_CAPITAL_CODE_FIX") or "0") != "0"
# 2026-11-27 (RFC-218 §24 短K样本不足显式 N/A, 呈现层正确性, 默认 OFF):
#   病灶: K线不足窗口时 MA5/10/20/60、chg5/20、量比被零填充 → prompt 出现
#   "MA60: 0.00 / +0.0% / 0.00x" 伪值, LLM 可能按真实值推断趋势/震荡.
#   =1: 样本不足指标渲染 "N/A(仅N根,需M)" + 实际根数标题 + 覆盖行 + 不得按0解读警示;
#   =0(默认): 逐字节旧零填充渲染 (当前生产行为不变). 计算逻辑两态完全一致.
#   正式输入变量 → 激活须按 RFC-218 §10.4 单变量 A/B, 不得当纯遥测直接上线.
#   回滚: .env.us 加 DA_SHORTK_NA=0 (或删除该行). 独立开关, 不与资金/DA_INPUT_FULL 捆绑.
DA_SHORTK_NA = (_read_env("DA_SHORTK_NA") or "0") != "0"
# 2026-11-27 (RFC-218 §26 健康空财报三态, 呈现层正确性, 默认 OFF):
#   病灶: next_earnings 为空时「## 财报日历」整段静默省略, 模型无法区分
#   「窗口内未发现事件(源健康)／源失败或降级／未提供」(11-25/11-27 归档 65/67
#   为健康空, 全部无栏目; 健康空=有效信息被当缺失丢弃).
#   =1: 空态渲染三态状态行 + 查询窗口(采集器声明值) + as-of(采集时点ET);
#       next_earnings 存在时两态均逐字节旧渲染. 计算/采集/覆盖分类不动.
#   =0(默认): 逐字节旧渲染 (当前生产行为不变).
#   正式输入变量 → 激活须按 RFC-218 §10.4 单变量 A/B, 不得当纯遥测直接上线.
#   回滚: .env.us 加 DA_EARNINGS_TRISTATE=0 (或删除该行). 独立开关,
#   不与资金/短K/DA_INPUT_FULL 捆绑.
DA_EARNINGS_TRISTATE = (_read_env("DA_EARNINGS_TRISTATE") or "0") != "0"
# 2026-11-27 (RFC-218 §27 来源状态可见性, 呈现层正确性, 默认 OFF):
#   病灶: 「## 数据源状态」仅 news/news_v2/research/sentiment 四 list 源;
#   dict 型源(资金分布/基本面/分析师/内部人/公司概况/大盘/行业)无 FAILED/EMPTY 区分,
#   资金分布"采集有数据但渲染门未通过→整段丢弃"完全不可见(审计判'完整'却无资金段).
#   =1: 扩面至 dict 型源 FAILED/EMPTY + 渲染丢弃(RENDER_DROPPED)具名披露;
#       资金丢弃判定复用 _render_capital_section 同源门; 不引入第二套覆盖计数,
#       与19维审计互补(审计=原始payload分类, 本段=呈现层可见性). 计算/采集/审计分类不动.
#   =0(默认): 逐字节旧4源渲染 (当前生产行为不变).
#   正式输入变量 → 激活须按 RFC-218 §10.4 单变量 A/B. 挑战者「数据源状态」白名单
#   缺口属独立批(§15.7 挑战者事实一致性), 本批不动白名单.
#   回滚: .env.us 加 DA_SOURCE_STATUS_FULL=0 (或删除该行). 独立开关,
#   不与资金/短K/财报三态/DA_INPUT_FULL 捆绑.
DA_SOURCE_STATUS_FULL = (_read_env("DA_SOURCE_STATUS_FULL") or "0") != "0"
# 2026-11-28 (RFC-218 §28 挑战者事实一致性, 呈现层正确性, 默认 OFF):
#   病灶: _challenger_data_view 的 _FULL 白名单含「资金面」却不含「数据源状态」→
#   「## 数据源状态」段被丢弃, 挑战者看不到源 FAILED/EMPTY/RENDER_DROPPED 状态,
#   与分析师信息不对称: 无法核验分析师弃权(SKIP)是否因缺材料, 无法据源失败反证
#   "没有催化剂"类论断. =1: 白名单补「数据源状态」, 挑战者与分析师同见该段(共享
#   同一 data_text, 同事件版本/同时点价格); 仅放行该段, 其余段/截断/回退逐字节不动.
#   =0(默认): 逐字节旧挑战者视图 (当前生产行为不变).
#   正式输入变量 → 激活须按 RFC-218 §10.4 单变量 A/B. 与 §27 源状态扩面正交独立
#   (§27 改分析师可见内容, 本批改挑战者可见性), 不与资金/短K/财报三态/源状态/DA_INPUT_FULL 捆绑.
#   回滚: .env.us 加 DA_CHALLENGER_FACT_CONSISTENCY=0 (或删除该行).
DA_CHALLENGER_FACT_CONSISTENCY = (_read_env("DA_CHALLENGER_FACT_CONSISTENCY") or "0") != "0"
# 2026-09-09 (消耗优化 F3, 用户批准): DA user prompt 契约段前移 — 稳定契约 (~6 成
#   user token, 跨候选逐字节相同) 成为共享前缀并挂第二个 cache_control 断点
#   (llm_synth._call_llm user_tail)。模型可见段落集合不变, 仅顺序变化; 文本差异仅
#   契约内 照抄"上方"→"数据中" 一处位置中性化。依赖 DA_PROMPT_CACHE=1 才有缓存收益;
#   PROMPT_HASH 按生效模板计 (重排前后基线可切分)。9/8 实测缓存命中仅 1677 tok
#   (system 前缀), 重排后预计 ~5.5-6k tok 契约前缀可命中, 估省 $0.10-0.15/日。
#   回滚: .env.us 加 DA_USER_CACHE_REORDER=0 → v1 数据在前原序。
DA_USER_CACHE_REORDER = (_read_env("DA_USER_CACHE_REORDER") or "1") != "0"
# 2026-09-01 (DEB-20260901b 用户裁"直接切生产, 修尺子提升质量"): DA 分析师思考模式。
#   qwen3.7-max 系推理模型, 生产原硬编码 enable_thinking=False (v0.70 投票场景
#   empty_response 教训的过度泛化)。思考预算防截断: 推理 token 计入输出预算,
#   max_tokens 配套 3000→6000 (见 llm_synth synthesize 调用点)。
#   回滚: .env.us 加 DA_THINKING_ENABLED=0 → 恢复关思考+3000 上限 (逐字节原行为)。
# 2026-09-14 (用户裁"都开启 enable_thinking, 确保正常的思考不被中断, 效果优先"):
#   预算 2048 → 8192。**2048 是错的, 不是保守** — 生产实测 48/48 行 reasoning_tokens
#   **恰好=2048** (撞顶), 即思考 100% 被腰斩; 且因尺子自己压住读数, 自然长度当时
#   根本不可观测。抬预算后跨 8 个真实标的同构回放 (raw checkpoint 落盘的 _user_prompt
#   原文 + 本文件 SYSTEM_PROMPT, 逐字节同源) 实录:
#     reasoning min 3646 / p50 4902 / max 5898, 0/8 撞顶；正文 1266-1921 tok;
#     延迟 57.1-80.9s (timeout 240s, 余量 ~3x)。
#   ⇒ 旧 2048 只够自然思考的 ~35%。8192 对实测 max 留 28% 余量。
#   ⚠️ 本值与调用点 max_tokens **必须联动** (推理计入输出预算): max_tokens 由
#     llm_synth 按 `budget + 8000` 推导, 只改这里不用改调用点。但预算若抬到
#     ~12000 以上, 推导出的 max_tokens 会顶到 qwen 输出上限 → 须同时下调常数。
#   回滚: .env.us 加 DA_THINKING_BUDGET=2048 (或本行默认值改回)。
# 2026-11-17 (DEB-20261117-da-analyst-qwen4max, 随主模型 qwen4-max 切换): 8192 → 16384.
#   实弹 (AMD 2026-11-16 生产同构): budget=8192 时 reasoning_tokens **恰好=8192**
#   (撞顶, 同 9/14 前的 2048 病灶 — 思考被腰斩); budget=16384 时 reasoning=14547
#   自然收尾 (0 撞顶), finish=stop, 契约 23 键全在. 沿用 9/14 用户裁"确保正常的
#   思考不被中断, 效果优先". max_tokens 联动推导 = 16384+8000 = 24384, qwen4-max
#   实弹接受且产出 20349 tok (上方"~12000 顶 qwen 输出上限"警告系 qwen3.7-max
#   口径, qwen4-max 已实测 ≥24384 可用). 代价: 分析师延迟 ~280s→~400s/候选,
#   由 llm_synth timeout 600 + pipeline workers 8 承接 (见各自注释).
#   回滚: .env.us 加 DA_THINKING_BUDGET=8192 (或本行默认值改回).
#   [本节已被 2026-11-17 第2轮取代 — 保留原文供回滚对照, 现行值见下方赋值行]
# 2026-11-17 (DEB-20261117 第2轮, 用户裁「确保不要限制模型自身的能力」):
#   16384 → 0 (= 不传 thinking_budget, 思考无上限, 模型自然收尾).
#   实弹 (AMD 生产同构, 无预算帽 + max_tokens=131072): reasoning=15173 自然收尾,
#   378.1s, finish=stop, 契约 23 键 ✓. 此前 16384 档 e2e run2 仍撞顶 (reasoning
#   恰好=16384) ⇒ 任何固定帽都可能腰斩思考; 自然长度实测分布 9986/14547/15173/
#   ≥16384, 帽只省很少延迟却截断推理. 输出预算配套 DA_UNCAPPED_MAX_TOKENS=131072
#   (实弹接受, 思考+正文共用, 正文不再有固定 8000 上限挤压).
#   回滚: .env.us 加 DA_THINKING_BUDGET=16384 (或 8192) → 恢复有限预算档.
DA_THINKING_ENABLED = (_read_env("DA_THINKING_ENABLED") or "1") != "0"
DA_THINKING_BUDGET = int(_read_env("DA_THINKING_BUDGET") or "0")
# 2026-11-17 (DEB-20261117 第2轮): 无预算帽档的输出总预算 (思考+正文).
#   qwen4-max 实弹接受 max_tokens=131072 (trivial 调用 finish=stop).
#   回滚: 本行改小 (如 24384) 或 DA_THINKING_BUDGET>0 走 budget+8000 推导.
DA_UNCAPPED_MAX_TOKENS = int(_read_env("DA_UNCAPPED_MAX_TOKENS") or "131072")
# 2026-11-17 (DEB-20261117 第2轮): 分析师思考档 timeout (原 llm_synth 硬编码 240,
#   第1轮改 600). 无帽思考典型 ~380-500s, 900 留 ~1.8x 余量; timeout 只是上限
#   不改变典型延迟. 回滚: .env.us 加 DA_ANALYST_TIMEOUT=600.
DA_ANALYST_TIMEOUT = int(_read_env("DA_ANALYST_TIMEOUT") or "900")
# 2026-09-21 temp0 落地 (施工单 /opt/ftseek/deferred_20260914/DA-TEMP0-DEFERRED-PLAN.md;
#   2026-09-14 用户授权, 因蒸馏影子对照臂=生产而推迟, 9/17 影子收口后障碍消除, 9/21 用户批准执行):
#   死配置 → 单一旋钮。llm_synth 三处调用点温度字面量 (0.2 契约修补 / 0.3 分析师 /
#   0.4 挑战者链, 原施工单第4处冷路径已被 9/18 挑战者链重构合并) 全部收口到本键,
#   _call_llm 缺省值同源。运行时回滚: .env.us 写 DA_LLM_TEMPERATURE=0.3, 无需改代码。
#   代码回滚: config.py.bak-temp0-20260921 / llm_synth.py.bak-temp0-20260921。
LLM_TEMPERATURE = float(_read_env("DA_LLM_TEMPERATURE") or "0.0")
LLM_MAX_TOKENS = 3000
LLM_TIMEOUT = 60

# ── 数据时效性 ────────────────────────────────────
DEFAULT_KLINE_DAYS = 60
DEFAULT_ANOMALY_DAYS = 7
DEFAULT_NEWS_SIZE = 10
DEFAULT_SENTIMENT_SIZE = 30
