#!/usr/bin/env python3
"""
DataCollector — 增量数据采集层
================================
只采集 FTSeek 现有 Provider 不覆盖的数据源。
FTSeek 已有: snapshot/kline/capital_flow/fundamental/news(RSS)/sentiment(Reddit/HN)
本模块增量: 3维异动 + 富途社区情绪 + 富途新闻/研报 + 全市场涨跌榜

设计原则 (Ponytail):
- 不重复 FTSeek 已有的采集逻辑
- 每个方法独立可调用，返回纯 dict/list
- 失败返回 {"_error": "..."}，不抛异常
"""
import subprocess
import json
import math
import os
import re
import sys
import time
import threading
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional

# 从 config 取所有路径/密钥，不硬编码
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import config

PYTHON = config.PYTHON
FUTUAPI_SCRIPTS = config.FUTUAPI_SCRIPTS
ANOMALY_SCRIPTS = config.ANOMALY_SCRIPTS
NEWS_BASE = config.NEWS_BASE
OPEND_HOST = config.OPEND_HOST
OPEND_PORT = config.OPEND_PORT
FINNHUB_BASE = config.FINNHUB_BASE

# ── 复用仓内单一真源 (2026-09-14, 用户裁「全部处理」P0-2) ────────────────────
#   用途: VIX 走 US.VIXY 代理时复用 app/data/vix_source.vixy_to_vix 的 0.85 校准,
#   不在本 skill 复制第二份系数 (同系数此前仓内 4 处复制, 任一漂移即口径分裂)。
#   append **不是** insert(0): FTSeek 仓根有 `config/` **包**, 而本 skill 用同名
#   `config.py` 模块 —— 插到最前会让后续 `import config` 解析到仓库包, 静默换掉
#   DA 自己的配置 (同 pipeline.py:149 注释)。实测 import 耗时 ~0.08s, 无副作用。
_FTSEEK_REPO = os.environ.get("FTSEEK_REPO", "/opt/ftseek/FTSeek-US")
if _FTSEEK_REPO not in sys.path:
    sys.path.append(_FTSEEK_REPO)

# ── OpenD 连接风暴治理 (2026-08-14, 8/13 盘中 35/35 快照超时实锤) ──────────
# 根因: collect_all 每维一个子进程连 OpenD (单标的最多 ~26 个), 5 标的并发 →
#   瞬时上百次握手; 盘中 live 服务已占 ~20 连接轮询 → OpenD 握手排队 →
#   全部卡死在子进程 timeout (15 并发对照实验 0/15 成功)。
# 修复: 全部 OpenD 子进程统一走 _opend_subprocess_run 信号量限流 (源头限流)。
#   DA_OPEND_MAX_CONC 可调 (默认 4: 实测单调 3s 稳定, 15 并发全灭)。
#   注意: _curl_json (Finnhub/新闻 HTTP) 不走 OpenD, 不限流。
_OPEND_MAX_CONC = int(os.environ.get("DA_OPEND_MAX_CONC", "4"))
_OPEND_SEM = threading.Semaphore(_OPEND_MAX_CONC)


def _opend_subprocess_run(cmd, timeout):
    """OpenD 子进程统一收口 — 信号量限并发连接, 防连接风暴 (见上方注释)."""
    with _OPEND_SEM:
        return subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)


def _run_futu_script(script_name: str, *args: str, timeout: int = 30) -> dict:
    script_path = os.path.join(FUTUAPI_SCRIPTS, script_name)
    if not os.path.exists(script_path):
        return {"_error": f"script not found: {script_path}"}
    cmd = [PYTHON, script_path] + list(args) + ["--json"]
    try:
        result = _opend_subprocess_run(cmd, timeout=timeout)
        stdout = result.stdout
        first, last = stdout.find('{'), stdout.rfind('}')
        if first >= 0 and last > first:
            try:
                return json.loads(stdout[first:last + 1])
            except json.JSONDecodeError:
                pass
        return {"_error": "no JSON", "_raw": stdout[:300]}
    except subprocess.TimeoutExpired:
        return {"_error": f"timeout {timeout}s"}
    except Exception as e:
        return {"_error": str(e)}


def _run_anomaly_script(anomaly_type: str, symbol: str, time_range: int = 7) -> dict:
    script_path = ANOMALY_SCRIPTS.get(anomaly_type)
    if not script_path or not os.path.exists(script_path):
        return {"_error": f"not found: {anomaly_type}"}
    cmd = [PYTHON, script_path, symbol, "--time-range", str(time_range), "--json"]
    try:
        result = _opend_subprocess_run(cmd, timeout=30)
        stdout = result.stdout
        first, last = stdout.find('{'), stdout.rfind('}')
        if first >= 0 and last > first:
            try:
                return json.loads(stdout[first:last + 1])
            except json.JSONDecodeError:
                pass
        return {"_error": "no JSON"}
    except Exception as e:
        return {"_error": str(e)}


def _curl_json(url: str, params: Dict[str, str], timeout: int = 15) -> dict:
    cmd = ["curl", "-sG", url, "-H", "User-Agent: deep-stock-analysis/0.2"]
    for k, v in params.items():
        cmd.extend(["--data-urlencode", f"{k}={v}"])
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return json.loads(result.stdout)
    except Exception as e:
        return {"_error": str(e)}


class SourceResult(list):
    def __init__(self, items=(), status: str = "ok", error: Optional[str] = None):
        super().__init__(items)
        self.source_status = status
        self.source_error = error


def _source_result(items, status: str, error: Optional[str] = None) -> SourceResult:
    return SourceResult(items, status=status, error=error)


def _source_status(value):
    if isinstance(value, dict):
        return "failed" if "_error" in value else "unknown"
    if not isinstance(value, list):
        return "failed"
    return getattr(value, "source_status", "ok" if value else "empty")


def _attach_source_status(result: dict) -> None:
    keys = ("news", "news_v2", "research", "sentiment")
    result["_source_status"] = {key: _source_status(result.get(key)) for key in keys}
    # 2026-10-23: additive effective-quality view. _quality counts a executed
    # collector task as ok even when the source itself failed; do not silently
    # call 100% coverage when sentiment/news failed. Keep _quality untouched
    # (it drives prompt/gates); expose the source-failure delta for audits.
    q = result.get("_quality") or {}
    failed = [k for k, v in result["_source_status"].items() if v == "failed"]
    result["_quality_effective"] = {
        "total": q.get("total", 0),
        "ok": max(0, int(q.get("ok", 0) or 0) - len(failed)),
        "failed": int(q.get("failed", 0) or 0) + len(failed),
        "source_failed": failed,
    }


# ── FTSeek 没有的增量数据源 ──────────────────────

def collect_technical_anomaly(symbol: str, time_range: int = 7) -> dict:
    """技术面异动: K线形态/MACD/RSI/KDJ/CCI等"""
    return _run_anomaly_script("technical", symbol, time_range)


def collect_capital_anomaly(symbol: str, time_range: int = 7) -> dict:
    """资金面异动: 资金分布/经纪商/流向/卖空"""
    return _run_anomaly_script("capital", symbol, time_range)


def collect_derivatives_anomaly(symbol: str, time_range: int = 7) -> dict:
    """衍生品异动: 期权大单/IV/量价/情绪"""
    return _run_anomaly_script("derivatives", symbol, time_range)


def collect_news(symbol: str, size: int = 10, lang: str = "zh-CN") -> List[dict]:
    """富途新闻 (FTSeek 用 RSS/finnhub, 这里是富途原生新闻源)"""
    keyword = symbol.split(".")[-1] if "." in symbol else symbol
    r = _curl_json(f"{NEWS_BASE}/news_search", {
        "keyword": keyword, "size": str(size),
        "news_type": "1", "lang": lang, "sort_type": "2",
    })
    if r.get("code") == 0:
        data = r.get("data", [])
        if isinstance(data, list):
            return _source_result(data, "ok" if data else "empty")
        return _source_result([], "failed", "invalid response")
    return _source_result([], "failed", "non-zero response")


def collect_research_reports(symbol: str, size: int = 5, lang: str = "zh-CN") -> List[dict]:
    """富途研报"""
    keyword = symbol.split(".")[-1] if "." in symbol else symbol
    r = _curl_json(f"{NEWS_BASE}/news_search", {
        "keyword": keyword, "size": str(size),
        "news_type": "3", "lang": lang, "sort_type": "2",
    })
    if r.get("code") == 0:
        data = r.get("data", [])
        if isinstance(data, list):
            return _source_result(data, "ok" if data else "empty")
        return _source_result([], "failed", "invalid response")
    return _source_result([], "failed", "non-zero response")


def collect_community_sentiment(symbol: str, size: int = 30) -> List[dict]:
    """富途社区帖子 (FTSeek 用 Reddit/HN, 这里是富途社区)"""
    keyword = symbol.split(".")[-1] if "." in symbol else symbol
    r = _curl_json(f"{NEWS_BASE}/stock_feed", {"keyword": keyword, "size": str(size)})
    if r.get("code") == 0:
        data = r.get("data", [])
        if isinstance(data, list):
            return _source_result(data, "ok" if data else "empty")
        return _source_result([], "failed", "invalid response")
    return _source_result([], "failed", "non-zero response")


# ── P1 新闻层升级 (2026-08-14): Finnhub company-news 带摘要事实流 ──
# 背景: 原 collect_news 只喂富途中文标题(实测CRM仅3条无正文), 而 Finnhub 近7天
#   有74条带summary(最长1879字)。本函数做信噪比过滤后注入, 补新闻维度数据洞。
# 实测口径 (CRM 74条): 模板垃圾仅3条, 标题含ticker约1/3 → 相关性过滤有效。
# 回滚: DA_NEWS_V2=0 (零采集成本, 显示段自然为空)。
_NEWS_V2_TEMPLATE_JUNK = re.compile(
    r"Stay informed|making waves|Discover which|top movers within", re.I)


def collect_finnhub_news(symbol: str, days: int = 7, top_n: int = 6) -> List[dict]:
    """Finnhub company-news: 7天窗 + 相关性过滤 + 去重, 返回带摘要的新闻列表。

    返回字段: time(ISO)/title/summary(DA_INPUT_FULL=1 截800字, 否则200字)/source/url/low_relevance(bool)
    失败或开关关闭返回带 source_status 的空 list (不阻塞主链路)。
    """
    if os.environ.get("DA_NEWS_V2", "1") == "0":
        return _source_result([], "disabled")
    bare = symbol.split(".")[-1] if "." in symbol else symbol
    to_ = datetime.now().strftime("%Y-%m-%d")
    from_ = (datetime.now() - timedelta(days=days)).strftime("%Y-%m-%d")
    data = _finnhub_get("company-news", {"symbol": bare, "from": from_, "to": to_})
    if isinstance(data, dict) and "_error" in data:
        return _source_result([], "failed", "finnhub request failed")
    if not isinstance(data, list) or not data:
        return _source_result([], "failed" if not isinstance(data, list) else "empty")
    # 1) 时间倒序 + 标题前40字去重
    seen, uniq = set(), []
    for n in sorted(data, key=lambda x: -(x.get("datetime") or 0)):
        k = (n.get("headline") or "")[:40]
        if k and k not in seen:
            seen.add(k)
            uniq.append(n)
    # 2) 模板垃圾过滤 + ticker 相关性过滤
    pat = re.compile(rf"\b{re.escape(bare)}\b", re.I)
    relevant = [n for n in uniq
                if not _NEWS_V2_TEMPLATE_JUNK.search(n.get("headline", ""))
                and pat.search(n.get("headline", ""))]
    low_rel = False
    if not relevant:  # ticker 少见于标题时如实降级, 取最新N条并标注
        relevant, low_rel = uniq[:top_n], True
    # 3) 组装输出
    out = []
    for n in relevant[:top_n]:
        ts = n.get("datetime") or 0
        out.append({
            "time": datetime.utcfromtimestamp(ts).strftime("%m-%d") if ts else "",
            "publish_time": (datetime.utcfromtimestamp(ts).isoformat() + "Z") if ts else "",
            "title": (n.get("headline") or "")[:150],
            # [2026-11-17 DEB-20261117 R2] 摘要 200→800 字 (源最长1879字,
            #   200字截断丢掉事实细节). 回滚: DA_INPUT_FULL=0.
            "summary": (n.get("summary") or "")[:800 if getattr(config, "DA_INPUT_FULL", True) else 200],
            "source": n.get("source", ""),
            "url": n.get("url", ""),
            "low_relevance": low_rel,
        })
    return _source_result(out, "ok" if out else "empty")


# ── 全市场扫描 (FTSeek screener 只从 watchlist 筛选, 这里是全市场) ──────────────
# 根因修复: 原代码不传 --min-price/--min-market-cap, 扫到仙股(LIMN $0.14, CWD $1.23)
# KO示例对标的是$84的可口可乐——正经大盘股。加过滤: 最低$5 + 最低市值5亿

def collect_top_gainers(market: str = "US", limit: int = 10) -> List[dict]:
    r = _run_futu_script("get_stock_filter.py", "--market", market,
                         "--sort", "change_rate", "--limit", str(limit),
                         "--min-price", "5", "--min-market-cap", "500")
    return r.get("data", []) if "_error" not in r else []


def collect_top_losers(market: str = "US", limit: int = 10) -> List[dict]:
    r = _run_futu_script("get_stock_filter.py", "--market", market,
                         "--sort", "change_rate", "--asc", "--limit", str(limit),
                         "--min-price", "5", "--min-market-cap", "500")
    return r.get("data", []) if "_error" not in r else []


def collect_top_volume(market: str = "US", limit: int = 10) -> List[dict]:
    r = _run_futu_script("get_stock_filter.py", "--market", market,
                         "--sort", "volume", "--limit", str(limit),
                         "--min-price", "5", "--min-market-cap", "500")
    return r.get("data", []) if "_error" not in r else []


# ── 快照 (FTSeek 有 FundamentalProvider, 但 market_scanner 快速评分需要轻量快照) ───

def session_price_fields(snapshot: Dict[str, Any]) -> Dict[str, Any]:
    """Return session-aware price/change without turning missing quotes into zero."""
    def positive(value):
        try:
            number = float(value)
            return number if math.isfinite(number) and number > 0 else None
        except (TypeError, ValueError):
            return None

    def finite(value):
        try:
            number = float(value)
            return number if math.isfinite(number) else None
        except (TypeError, ValueError):
            return None

    session = str(snapshot.get("session") or "regular")
    if session == "premarket":
        price = positive(snapshot.get("pre_price"))
        reported_change = finite(snapshot.get("effective_chg_pct"))
        if reported_change is None:
            reported_change = finite(snapshot.get("pre_change_rate"))
    elif session == "afterhours":
        price = positive(snapshot.get("after_price"))
        reported_change = finite(snapshot.get("effective_chg_pct"))
        if reported_change is None:
            reported_change = finite(snapshot.get("after_change_rate"))
    else:
        price = positive(snapshot.get("effective_price")) or positive(snapshot.get("last_price"))
        reported_change = finite(snapshot.get("effective_chg_pct"))

    prev_close = positive(snapshot.get("prev_close"))
    if prev_close is None:
        prev_close = positive(snapshot.get("prev_close_price"))
    if price is not None and reported_change is None and prev_close is not None:
        reported_change = (price - prev_close) / prev_close * 100.0
    return {
        "price": price,
        "change_pct": round(reported_change, 2) if price is not None and reported_change is not None else None,
        "session": session,
        "price_as_of": str(snapshot.get("update_time") or "") or None,
    }

def collect_snapshot(symbol: str) -> dict:
    """轻量快照 — 供 market_scanner 快速评分用。
    FTSeek 的 FundamentalProvider 更完整(多源降级), 但需要初始化 Provider 链。
    这里直接调 OpenD, 秒级返回, 适合扫描场景。

    2026-08-11 (LIF 盘前-20%盲区实锤): 补盘前/盘后字段 + effective_price。
    根因: 原实现只取 last_price/prev_close — 盘前时段 last_price=昨收,
    盘前真实异动 (pre_price/pre_change_rate) 完全不可见 → DA 06:22 ET 扫描
    看到 LIF "涨跌幅+2.2%" (昨收口径), 实际盘前 -19.5%, 指令建立在失效 thesis 上。
    effective_price = 按时段取当前真实价格 (盘前→pre_price, 盘后→after_price,
    盘中/收盘→last_price), 并给 effective_chg_pct (vs prev_close)。
    """
    # 从config读OpenD地址，不硬编码
    host = OPEND_HOST
    port = OPEND_PORT
    # 用subprocess参数传递symbol，不f-string注入（防代码注入）
    code = """
import json, sys
from datetime import datetime, timedelta, timezone
from futu import OpenQuoteContext, RET_OK
symbol = sys.argv[1]
host = sys.argv[2]
port = int(sys.argv[3])
q = OpenQuoteContext(host, port)
try:
    ret, data = q.get_market_snapshot([symbol])
    if ret == RET_OK and len(data) > 0:
        row = data.iloc[0]
        fields = {
            'code': str(row.get('code','')),
            'name': str(row.get('name','')),
            'last_price': float(row.get('last_price',0) or 0),
            'prev_close': float(row.get('prev_close_price',0) or 0),
            'prev_close_price': float(row.get('prev_close_price',0) or 0),
            'volume': float(row.get('volume',0) or 0),
            'turnover_rate': float(row.get('turnover_rate',0) or 0),
            'pe_ttm_ratio': float(row.get('pe_ttm_ratio',0) or 0),
            'pe_ratio': float(row.get('pe_ratio',0) or 0),
            'pb_ratio': float(row.get('pb_ratio',0) or 0),
            'total_market_val': float(row.get('total_market_val',0) or 0),
            'highest52weeks_price': float(row.get('highest52weeks_price',0) or 0),
            'lowest52weeks_price': float(row.get('lowest52weeks_price',0) or 0),
            'bid_ask_ratio': float(row.get('bid_ask_ratio',0) or 0),
            'volume_ratio': float(row.get('volume_ratio',0) or 0),
            'amplitude': float(row.get('amplitude',0) or 0),
            # 2026-08-11: 盘前/盘后真实价格与涨跌幅 (LIF 盲区修复)
            'pre_price': float(row.get('pre_price',0) or 0),
            'pre_change_rate': float(row.get('pre_change_rate',0) or 0),
            'pre_volume': float(row.get('pre_volume',0) or 0),
            'after_price': float(row.get('after_price',0) or 0),
            'after_change_rate': float(row.get('after_change_rate',0) or 0),
            'overnight_change_rate': float(row.get('overnight_change_rate',0) or 0),
            'bid_price': float(row.get('bid_price',0) or 0),
            'ask_price': float(row.get('ask_price',0) or 0),
            'update_time': str(row.get('update_time','')),
        }
        # 时段判定 (ET): 盘前 04:00-09:30 / 盘后 16:00-20:00。
        # 夏令时 EDT=UTC-4 / 冬令时 EST=UTC-5, 用 zoneinfo 精确解析。
        try:
            from zoneinfo import ZoneInfo
            _now_et = datetime.now(ZoneInfo('America/New_York'))
            _hm = _now_et.hour * 100 + _now_et.minute
        except Exception:
            # fallback: 服务器 CST(UTC+8) 换算 — EDT 差 12h / EST 差 13h (3-11月为夏令时)
            _now_local = datetime.now(timezone(timedelta(hours=8)))
            _dst = 3 <= _now_local.month <= 10  # 近似夏令时窗
            _hm = ((_now_local.hour + (12 if _dst else 13)) % 24) * 100 + _now_local.minute
        _session = 'premarket' if 400 <= _hm < 930 else ('afterhours' if 1600 <= _hm < 2000 else 'regular')
        fields['session'] = _session
        # effective_price: 该时段的市场真实成交价 (盘前 last_price=昨收, 非现价!)
        _eff = fields['last_price']
        if _session == 'premarket' and fields['pre_price'] > 0:
            _eff = fields['pre_price']
        elif _session == 'afterhours' and fields['after_price'] > 0:
            _eff = fields['after_price']
        # 兜底: 正股价为 0 但有扩展时段价 (数据源部分缺失) → 用扩展价, 不给 0
        if _eff <= 0:
            _eff = fields['pre_price'] or fields['after_price'] or fields['bid_price'] or fields['last_price']
        fields['effective_price'] = _eff
        _pc = fields['prev_close_price']
        # 2026-10-23: keep the pre-derivation value for audit/replay. The >1%
        # branch below must not erase the source truth; reconcile_prev_close
        # reads this field when it runs a second time.
        fields['prev_close_raw_source'] = _pc
        # [prev_close 口径修复 2026-08-29] 盘前时段 prev_close_price 概率性返回
        #   两天前收盘 (13天抽样 16/26=62% stale, 日K交叉核验实锤; 例: RBRK 返回
        #   8/26 收盘 96.13, 真昨收 8/27=107.02)。零成本交叉校验:
        #   pre_change_rate 是对真昨收计算的 → true_prev = pre_price/(1+rate/100),
        #   与 prev_close_price 偏离 >1% 即采信推导值 (ESTC 实测: 推导出 83.74
        #   = 真实 8/27 收盘 ✓)。同步重算 effective_chg_pct, 防盘前涨跌幅虚高
        #   (ESTC 曾显示 +24.7% 实为 +18.0%)。回滚: 删除本段即恢复旧行为。
        if fields['session'] == 'premarket' and fields['pre_price'] > 0 and fields['pre_change_rate'] != 0:
            _derived_pc = fields['pre_price'] / (1 + fields['pre_change_rate'] / 100.0)
            if _derived_pc > 0 and abs(_derived_pc - _pc) / _derived_pc > 0.01:
                _pc = _derived_pc
                fields['prev_close'] = round(_derived_pc, 4)
                fields['prev_close_price'] = round(_derived_pc, 4)
        fields['effective_chg_pct'] = round((_eff - _pc) / _pc * 100, 2) if (_eff > 0 and _pc > 0) else None
        print(json.dumps(fields, default=str))
    else:
        print(json.dumps({"_error": "empty"}))
except Exception as e:
    print(json.dumps({"_error": str(e)[:200]}))
finally:
    q.close()
"""
    try:
        result = _opend_subprocess_run(
            [PYTHON, "-c", code, symbol, host, port],
            timeout=15
        )
        for line in result.stdout.split('\n'):
            if line.startswith('{'):
                return json.loads(line)
        return {"_error": "no JSON"}
    except Exception as e:
        return {"_error": str(e)}


def collect_kline(symbol: str, ktype: str = "1d", num: int = 60) -> List[dict]:
    """K线 — 供 market_scanner 和 deep_analyzer 技术面计算用"""
    r = _run_futu_script("get_kline.py", symbol, "--ktype", ktype, "--num", str(num))
    return r.get("data", []) if "_error" not in r else []


def collect_snapshot_batch(symbols: List[str], timeout: int = 30, chunk_size: int = 30) -> List[dict]:
    """批量快照 — 单连接拉多标的 (含盘前/盘后/隔夜字段), 2026-08-11 新增。

    用途: premarket_movers 渠道。逐标的 collect_snapshot 每只一次连接 (~300ms),
    100+ 只池子太慢; get_market_snapshot 单调用支持批量, 秒级。
    ⚠️ 分批: 实测单次 >~130 只返回空 (API 隐性上限), 按 chunk_size 分批合并。
    只返回盘前/隔夜真实异动字段, 非交易时段 pre_price=0 的行由调用方过滤。
    """
    syms = [s for s in symbols if s and isinstance(s, str)]
    if not syms:
        return []
    host = OPEND_HOST
    port = OPEND_PORT
    code = """
import json, sys
from futu import OpenQuoteContext, RET_OK
symbols = sys.argv[1].split(',')
host = sys.argv[2]
port = int(sys.argv[3])
q = OpenQuoteContext(host, port)
try:
    ret, data = q.get_market_snapshot(symbols)
    if ret == RET_OK and data is not None and len(data) > 0:
        out = []
        for _, row in data.iterrows():
            out.append({
                'code': str(row.get('code','')),
                'name': str(row.get('name','')),
                'last_price': float(row.get('last_price',0) or 0),
                'prev_close_price': float(row.get('prev_close_price',0) or 0),
                'pre_price': float(row.get('pre_price',0) or 0),
                'pre_change_rate': float(row.get('pre_change_rate',0) or 0),
                'pre_volume': float(row.get('pre_volume',0) or 0),
                'after_price': float(row.get('after_price',0) or 0),
                'after_change_rate': float(row.get('after_change_rate',0) or 0),
                'overnight_change_rate': float(row.get('overnight_change_rate',0) or 0),
                'update_time': str(row.get('update_time','')),
                'total_market_val': float(row.get('total_market_val',0) or 0),
                'volume': float(row.get('volume',0) or 0),
            })
        print(json.dumps(out, default=str))
    else:
        print(json.dumps({"_error": "empty"}))
except Exception as e:
    print(json.dumps({"_error": str(e)[:200]}))
finally:
    q.close()
"""
    all_rows: List[dict] = []
    _queue: List[List[str]] = [syms[i:i + chunk_size] for i in range(0, len(syms), chunk_size)]
    _depth = 0
    while _queue and _depth < 50:
        _depth += 1
        chunk = _queue.pop(0)
        try:
            result = _opend_subprocess_run(
                [PYTHON, "-c", code, ",".join(chunk), host, str(port)],
                timeout=timeout
            )
            _ok = False
            for line in result.stdout.split('\n'):
                line = line.strip()
                if line.startswith('['):
                    all_rows.extend(json.loads(line))
                    _ok = True
                    break
            if not _ok and len(chunk) > 2:
                # 2026-08-11 实锤: OpenD 批量快照含任一无效代码 (OTC/退市/未知)
                #   → 整批 RET=-1 全灭. 二分重试隔离毒代码 (单只失败自然丢弃)。
                _half = len(chunk) // 2
                _queue.insert(0, chunk[:_half])
                _queue.insert(1, chunk[_half:])
        except Exception:
            continue
    return all_rows


def collect_premarket_rank_codes(market: str = "US", per_dir_limit: int = 50) -> List[dict]:
    """全市场盘前榜扩池 — 2026-08-12 (DEB-20260812 主张C 消费方接线)。

    根因: 原 collect_premarket_movers 池子=量榜+财报榜, 榜外盘前异动不可见
    (LIF 型标的只有命中财报榜才可见, 纯消息驱动盘前异动仍是盲区)。
    富途 get_us_pre_market_rank 直接给全市场按盘前涨跌幅排名的榜,
    双向 (领涨+领跌) 各取 per_dir_limit 只扩入候选池。

    零行为变更: 只扩供给 — 返回仅含 code/name, 后续走既有
    collect_snapshot_batch + |涨跌幅|/量阈值过滤, 门禁不变。
    """
    if market != "US":
        return []
    out = []
    for direction in ("descend", "ascend"):
        r = _run_futu_script("get_us_premarket_rank.py",
                             "--dir", direction, "--limit", str(per_dir_limit))
        if "_error" in r:
            continue
        for item in r.get("data", []):
            code = item.get("code", "")
            if code:
                out.append({"code": code, "name": item.get("name", "")})
    return out


def collect_premarket_movers(market: str = "US", pool_limit: int = 100,
                             min_abs_chg: float = 4.0, min_pre_volume: float = 500) -> List[dict]:
    """盘前/隔夜异动渠道 — 2026-08-11 (LIF 盲区修复) 新增。

    设计: get_stock_filter 的排序字段无 pre_change_rate → 无法直接按盘前涨跌选股,
    改为"活跃股池 + 批量快照 + 阈值过滤":
      1. 池子 = 量榜 top + 财报超预期榜 (盘前暴跌/暴涨 90% 是财报驱动, LIF 实锤:
         不在量榜/涨跌榜, 但在 earnings_surprise 榜) + 全市场盘前榜 (2026-08-12 扩池,
         覆盖榜外消息驱动异动)。
         ⚠️ 实测 get_stock_filter 的 change_rate 在盘前时段恒为 0 (不反映盘前涨跌),
         故涨跌榜无效, 不纳入。
      2. collect_snapshot_batch 单连接批量拉盘前/隔夜字段 (分批+毒码二分隔离)
      3. 过滤: |pre_change_rate| ≥ min_abs_chg 且 pre_volume ≥ min_pre_volume
         (pre_price=0 或无量 → 非异动/数据缺失, 跳过)
    输出按 |涨跌幅| 降序, 每项带 premarket_chg_pct / premarket_price, 供 scanner 消费。
    """
    pool = collect_top_volume(market, pool_limit)
    # 财报榜补漏: 盘前大波动多为财报驱动 (LIF 盘前-19.5%=指引miss, 仅在财报榜)
    try:
        pool += collect_earnings_surprise(market, pool_limit)
    except Exception:
        pass
    # 全市场盘前榜扩池 (2026-08-12): 覆盖量榜/财报榜之外的盘前异动
    try:
        pool += collect_premarket_rank_codes(market, 50)
    except Exception:
        pass
    codes, _seen = [], set()
    for p in pool:
        c = p.get("code", "")
        if c and c not in _seen:
            codes.append(c)
            _seen.add(c)
    if not codes:
        return []
    snaps = collect_snapshot_batch(codes)
    if isinstance(snaps, dict):  # {"_error": ...}
        return []
    movers = []
    for s in snaps:
        pre_chg = s.get("pre_change_rate", 0) or 0
        pre_px = s.get("pre_price", 0) or 0
        pre_vol = s.get("pre_volume", 0) or 0
        if pre_px <= 0 or abs(pre_chg) < min_abs_chg or pre_vol < min_pre_volume:
            continue
        movers.append({
            "code": s.get("code", ""),
            "name": s.get("name", ""),
            "price": pre_px,               # 盘前价即当前真实价 (quality_gate 价格过滤用)
            "last_price": s.get("last_price", 0),
            "prev_close": s.get("prev_close_price", 0),
            "market_val": s.get("total_market_val", 0),
            "premarket_chg_pct": round(pre_chg, 2),
            "premarket_price": pre_px,
            "premarket_volume": pre_vol,
            "overnight_chg_pct": s.get("overnight_change_rate", 0) or 0,
            "_source": "premarket_movers",
        })
    movers.sort(key=lambda x: abs(x["premarket_chg_pct"]), reverse=True)
    return movers


def collect_capital_flow(symbol: str) -> dict:
    """资金流向 — 供 deep_analyzer 资金面分析用。
    FTSeek 有 capital_flow factor 但在 app/factors/ 里需初始化链,
    这里直接调 OpenD 脚本, 秒级返回。
    """
    r = _run_futu_script("get_capital_flow.py", symbol, "--json")
    return r if "_error" not in r else {"_error": r.get("_error", "no data")}


def collect_capital_distribution(symbol: str) -> dict:
    """资金分布 (大单/中单/小单) — 供 deep_analyzer 资金面分析用。"""
    r = _run_futu_script("get_capital_distribution.py", symbol, "--json")
    return r if "_error" not in r else {"_error": r.get("_error", "no data")}


# ── Finnhub 基本面+分析师+内部人 (FTSeek有Provider但需初始化链, 这里直接调API) ───

FINNHUB_KEY = config.FINNHUB_KEY

FINNHUB_BASE = "https://finnhub.io/api/v1"
_FINNHUB_MAX_CONC = int(os.environ.get("DA_FINNHUB_MAX_CONC", "4"))
_FINNHUB_SEM = threading.Semaphore(_FINNHUB_MAX_CONC)


def _finnhub_get(endpoint: str, params: dict = None) -> dict:
    """Finnhub HTTP GET with bounded concurrency and retry/backoff.

    2026-10-23: 429/5xx and transient network errors were silently converted
    into a missing data dimension; 5 analysis workers x 6 collector threads
    could burst far above the API limit. Retry only transient statuses, cap
    concurrent requests, and keep the final error textual for source status.
    """
    if not FINNHUB_KEY:
        return {"_error": "no finnhub key"}
    query = f"token={FINNHUB_KEY}"
    if params:
        for k, v in params.items():
            query += f"&{k}={v}"
    url = f"{FINNHUB_BASE}/{endpoint}?{query}"
    import random
    import urllib.error
    import urllib.request
    attempts = max(1, int(os.environ.get("DA_FINNHUB_RETRY_ATTEMPTS", "3")))
    last_error = "request failed"
    for attempt in range(attempts):
        try:
            with _FINNHUB_SEM:
                req = urllib.request.Request(url)
                with urllib.request.urlopen(req, timeout=10) as resp:
                    return json.loads(resp.read())
        except urllib.error.HTTPError as exc:
            last_error = f"HTTP {exc.code}"
            if exc.code not in (429, 500, 502, 503, 504) or attempt >= attempts - 1:
                return {"_error": last_error}
        except Exception as exc:
            last_error = str(exc)
            if attempt >= attempts - 1:
                return {"_error": last_error}
        time.sleep(min(4.0, 0.5 * (2 ** attempt)) + random.uniform(0, 0.3))
    return {"_error": last_error}


def collect_fundamentals(symbol: str) -> dict:
    """Finnhub 基本面指标: 营收增长/ROE/利润率/PE/PB等 (133字段)"""
    bare = symbol.split(".")[-1] if "." in symbol else symbol
    data = _finnhub_get("stock/metric", {"symbol": bare, "metric": "all"})
    if "_error" in data:
        return data
    m = data.get("metric", {})
    return {
        "revenue_growth_yoy": m.get("revenueGrowthTTMYoy"),
        "revenue_growth_5y": m.get("revenueGrowth5Y"),
        "eps_growth_5y": m.get("epsGrowth5Y"),
        "roe_ttm": m.get("roeTTM"),
        "roa_ttm": m.get("roaTTM"),
        "net_profit_margin_ttm": m.get("netProfitMarginTTM"),
        "gross_margin_ttm": m.get("grossMarginTTM"),
        "operating_margin_ttm": m.get("operatingMarginTTM"),
        "pe_normalized": m.get("peNormalizedAnnual"),
        "pb_annual": m.get("pbAnnual"),
        "ps_annual": m.get("psAnnual"),
        "revenue_per_share_ttm": m.get("revenuePerShareTTM"),
        "book_value_per_share": m.get("bookValuePerShareAnnual"),
        "debt_to_equity": m.get("totalDebt/totalEquityAnnual"),
        "dividend_yield": m.get("dividendYieldIndicatedAnnual"),
        "payout_ratio": m.get("payoutRatioTTM"),
        "beta": m.get("beta"),
        "_source": "finnhub/stock/metric",
    }


def collect_analyst_consensus(symbol: str) -> dict:
    """Finnhub 分析师评级: strongBuy/buy/hold/sell/strongSell (按月)"""
    bare = symbol.split(".")[-1] if "." in symbol else symbol
    data = _finnhub_get("stock/recommendation", {"symbol": bare})
    if "_error" in data:
        return data
    if isinstance(data, list) and data:
        latest = data[0]
        total = sum(latest.get(k, 0) for k in ["strongBuy", "buy", "hold", "sell", "strongSell"])
        return {
            "period": latest.get("period"),
            "strong_buy": latest.get("strongBuy", 0),
            "buy": latest.get("buy", 0),
            "hold": latest.get("hold", 0),
            "sell": latest.get("sell", 0),
            "strong_sell": latest.get("strongSell", 0),
            "total_analysts": total,
            "buy_pct": round((latest.get("strongBuy",0) + latest.get("buy",0)) / max(total,1) * 100, 1),
            "all_months": data[:4],
            "_source": "finnhub/stock/recommendation",
        }
    return {"_error": "empty"}


def collect_insider_transactions(symbol: str) -> dict:
    """Finnhub 内部人交易: 最近3个月的买入/卖出"""
    bare = symbol.split(".")[-1] if "." in symbol else symbol
    data = _finnhub_get("stock/insider-transactions", {"symbol": bare})
    if "_error" in data:
        return data
    transactions = data.get("data", [])
    # 最近的交易 (按日期倒序)
    recent = transactions[:20]
    # 统计净买入
    buy_count = sum(1 for t in recent if t.get("transactionType", "").upper() in ("B", "BUY"))
    sell_count = sum(1 for t in recent if t.get("transactionType", "").upper() in ("S", "SELL"))
    total_value = sum(t.get("value", 0) or 0 for t in recent)
    
    # 列出最近5笔
    recent_list = []
    for t in recent[:10]:
        recent_list.append({
            "date": t.get("transactionDate"),
            "name": (t.get("name", "") or "")[:20],
            "type": t.get("transactionType"),
            "shares": t.get("shareCount"),
            "price": t.get("transactionPrice"),
            "value": t.get("value"),
        })
    
    return {
        "total_transactions": len(transactions),
        "recent_buy_count": buy_count,
        "recent_sell_count": sell_count,
        "total_recent_value": total_value,
        "recent_transactions": recent_list,
        "_source": "finnhub/insider-transactions",
    }


def collect_insider_sentiment(symbol: str) -> dict:
    """Finnhub 内部人情绪: MSPR (Monthly Share Purchase Ratio)"""
    bare = symbol.split(".")[-1] if "." in symbol else symbol
    data = _finnhub_get("stock/insider-sentiment", {"symbol": bare})
    if "_error" in data:
        return data
    records = data.get("data", [])
    # MSPR > 0 = 净买入, < 0 = 净卖出
    recent = records[-6:] if len(records) >= 6 else records  # 最近6个月
    avg_mspr = sum(r.get("mspr", 0) or 0 for r in recent) / max(len(recent), 1) if recent else 0
    return {
        "recent_months": recent,
        "avg_mspr_6m": round(avg_mspr, 2),
        "signal": "净买入" if avg_mspr > 0 else ("净卖出" if avg_mspr < 0 else "中性"),
        "_source": "finnhub/insider-sentiment",
    }


def collect_company_profile(symbol: str) -> dict:
    """Finnhub 公司概况: 行业/市值/流通股"""
    bare = symbol.split(".")[-1] if "." in symbol else symbol
    data = _finnhub_get("stock/profile2", {"symbol": bare})
    if "_error" in data:
        return data
    return {
        "name": data.get("name"),
        "industry": data.get("finnhubIndustry"),
        "country": data.get("country"),
        "exchange": data.get("exchange"),
        "market_cap": data.get("marketCapitalization"),
        "share_outstanding": data.get("shareOutstanding"),
        "_source": "finnhub/profile2",
    }


_INTERNAL_EARNINGS_CACHE: Dict[str, Any] = {
    "ts": 0.0, "rows": None, "error": None,
}
_INTERNAL_EARNINGS_LOCK = threading.Lock()


def _internal_earnings_rows() -> Optional[List[dict]]:
    """FTSeek 内部财报日历 (富途主源/AV 备源) — 带 1h 缓存与并发锁.

    2026-10-21: DA 的 Finnhub calendar/earnings 对 LITE/NBIS/ARM/UNH/CLF
    等标的返回空/仅过期记录 (10/20 evidence_gaps 8/8 提到财报日期缺失),
    而仓内 EarningsCalendar 刚在 10/20 修过缓存与断流告警。这里只做**回退**,
    Finnhub 有未来日期时仍优先用 Finnhub。
    失败返回 None (不缓存空结果, 防断流被当成"无财报")。
    """
    now = time.time()
    with _INTERNAL_EARNINGS_LOCK:
        cached = _INTERNAL_EARNINGS_CACHE
        if cached["rows"] is not None and now - float(cached["ts"] or 0) < 3600:
            return cached["rows"]
        if cached["rows"] is None and cached["error"] and now - float(cached["ts"] or 0) < 300:
            return None
        try:
            from app.data.earnings_calendar import EarningsCalendar
            rows, source_error = EarningsCalendar().get_earnings_calendar_with_status(
                horizon="3month")
            if not rows and source_error:
                _INTERNAL_EARNINGS_CACHE.update(
                    {"ts": now, "rows": None, "error": str(source_error)})
                return None
            rows = rows or []
            _INTERNAL_EARNINGS_CACHE.update(
                {"ts": now, "rows": rows, "error": source_error})
            return rows
        except Exception as exc:
            _INTERNAL_EARNINGS_CACHE.update(
                {"ts": now, "rows": None, "error": str(exc)})
            return None


def _internal_earnings_fallback(bare: str) -> Optional[dict]:
    """把仓内财报日历映射成 DA 既有 earnings_calendar 契约; 无数据返回 None."""
    rows = _internal_earnings_rows()
    if rows is None:
        return None
    try:
        from zoneinfo import ZoneInfo
        today_str = datetime.now(ZoneInfo("America/New_York")).strftime("%Y-%m-%d")
    except Exception:
        today_str = datetime.now().strftime("%Y-%m-%d")
    hits = []
    for row in rows:
        if not isinstance(row, dict):
            continue
        sym = str(row.get("symbol") or "").upper().removeprefix("US.")
        if sym != bare.upper():
            continue
        report_date = str(row.get("reportDate") or "")
        if report_date and report_date >= today_str:
            hits.append(row)
    hits.sort(key=lambda row: str(row.get("reportDate") or ""))
    if not hits:
        # 日历本身健康 (有全市场数据) 但该标的未来窗口无财报 — 这是有效信息,
        # 不是"源不可用"; lookahead_days 让 _has_meaningful_data 不误判降级.
        return {
            "next_earnings": None,
            "all_upcoming": [],
            "_source": "ftseek/earnings_calendar",
            "_quality": "ok",
            "lookahead_days": 7,
            "_note": "internal calendar healthy; no earnings in lookahead window",
        }
    upcoming = [{
        "date": row.get("reportDate"),
        "epsEstimate": row.get("estimate"),
        "revenueEstimate": None,
        "hour": row.get("timeOfTheDay"),
    } for row in hits[:3]]
    return {
        "next_earnings": upcoming[0],
        "all_upcoming": upcoming,
        "_source": f"ftseek/{hits[0].get('source') or 'earnings_calendar'}",
    }


def collect_earnings_calendar(symbol: str) -> dict:
    """Finnhub 财报日历: 下次财报日期+预期 (空/降级时回退仓内富途日历)."""
    bare = symbol.split(".")[-1] if "." in symbol else symbol
    data = _finnhub_get("calendar/earnings", {"symbol": bare})
    if "_error" in data:
        fallback = _internal_earnings_fallback(bare)
        return fallback if fallback is not None else data
    cal = data.get("earningsCalendar", [])
    # 找未来的财报 — 用ET时区（Finnhub返回的date是ET交易日）
    from datetime import timezone, timedelta
    _now = datetime.now()
    _offset = timedelta(hours=-4) if 3 <= _now.month <= 11 else timedelta(hours=-5)
    today_str = datetime.now(timezone(_offset)).strftime("%Y-%m-%d")
    future = [e for e in cal if e.get("date", "") >= today_str]
    next_earnings = future[0] if future else None
    if not next_earnings and cal:
        # 没有未来财报日期 — 不用过期的cal[-1]，
        # 标记降级让LLM知道财报日历不可用; 优先用仓内日历补
        fallback = _internal_earnings_fallback(bare)
        if fallback is not None:
            return fallback
        return {
            "next_earnings": None,
            "all_upcoming": [],
            "_source": "finnhub/calendar/earnings",
            "_quality": "degraded",
            "_degraded_reason": "无未来财报日期(API仅返回已过期记录)",
        }
    if not next_earnings:
        fallback = _internal_earnings_fallback(bare)
        if fallback is not None:
            return fallback
    return {
        "next_earnings": next_earnings,
        "all_upcoming": future[:3],
        "_source": "finnhub/calendar/earnings",
    }


# ── 多渠道市场扫描 (v0.23新增: 扩展渠道源) ──────────


def collect_earnings_surprise(market: str = "US", limit: int = 30) -> List[dict]:
    """Finnhub 财报超预期: 今日+昨日有财报的标的, 筛选actual vs estimate差异大的.

    返回格式同其他collect函数: [{code, name, change_rate, ...}]
    Finnhub /calendar/earnings 返回 {earningsCalendar: [{date, epsActual, epsEstimate, symbol, ...}]}
    """
    from datetime import datetime, timezone, timedelta
    _now = datetime.now()
    _offset = timedelta(hours=-4) if 3 <= _now.month <= 11 else timedelta(hours=-5)
    et_today = datetime.now(timezone(_offset))
    today_str = et_today.strftime("%Y-%m-%d")
    yesterday_str = (et_today - timedelta(days=1)).strftime("%Y-%m-%d")

    data = _finnhub_get("calendar/earnings", {"from": yesterday_str, "to": today_str})
    if "_error" in data or not isinstance(data, dict):
        return []

    cal = data.get("earningsCalendar", [])
    surprises = []
    for e in cal:
        sym = e.get("symbol", "")
        if not sym:
            continue
        actual = e.get("epsActual")
        estimate = e.get("epsEstimate")
        if actual is not None and estimate is not None:
            surprise_pct = ((actual - estimate) / max(abs(estimate), 0.01)) * 100 if estimate != 0 else 0
        else:
            surprise_pct = 0
        surprises.append({
            "code": f"US.{sym}" if market == "US" else sym,
            "name": sym,
            "eps_actual": actual,
            "eps_estimate": estimate,
            "surprise_pct": round(surprise_pct, 1),
            "_source": "earnings_surprise",
        })

    # 按surprise绝对值排序, 取top
    surprises.sort(key=lambda x: abs(x.get("surprise_pct", 0)), reverse=True)
    return surprises[:limit]


def collect_insider_movers(market: str = "US", limit: int = 20) -> List[dict]:
    """Finnhub 内部人异动: 近7天有内部人交易(买入)的标的.

    Finnhub /stock/insider-transactions 需要按symbol查,
    但 /calendar/gradings 或其他全市场接口有限.
    最短路径: 用 insider-sentiment 全市场接口(如果有)或用news关键词.
    实际: Finnhub免费版无全市场insider API, 用community_sentiment的post_count作为热度代理.
    """
    # Finnhub免费版无全市场insider API, 返回空但标注
    # 如果后续有付费API可在此扩展
    return []


def collect_after_hours_movers(market: str = "US", limit: int = 10) -> List[dict]:
    """富途夜盘异动: 用get_stock_filter的after_hours排序.

    富途get_stock_filter支持after_hours排序(如果有).
    最短路径: 复用get_stock_filter但传不同sort参数.
    """
    # 尝试用after_hours_change排序, 如果不支持就返回空
    r = _run_futu_script("get_stock_filter.py", "--market", market,
                         "--sort", "change_rate", "--limit", str(limit),
                         "--min-price", "5", "--min-market-cap", "500")
    if "_error" not in r:
        data = r.get("data", [])
        # 标注来源为after_hours
        for d in data:
            d["_source"] = "after_hours"
        return data
    return []


# ── 市场大盘+行业关联 (v0.39新增) ────────────────

# 2026-08-14 (连接风暴治理): market_context (SPY/QQQ/VIX) 对所有标的完全相同,
#   原每只标的重复算一遍 (35只=105个OpenD子进程白扇出) → 缓存10分钟复用。
#   industry_peers 按行业键缓存30分钟 (同行业标的共享peer列表)。
#   锁保护: collect_all 的6线程池并发读写。
_MC_CACHE = {"ts": 0.0, "val": None}
_MC_CACHE_TTL = float(os.environ.get("DA_MC_CACHE_TTL", "600"))
_MC_LOCK = threading.Lock()

_IP_CACHE: Dict[str, tuple] = {}  # industry -> (ts, val)
_IP_CACHE_TTL = float(os.environ.get("DA_IP_CACHE_TTL", "1800"))
_IP_LOCK = threading.Lock()


def classify_market_trend(spy_context: Dict[str, Any], qqq_context: Dict[str, Any]) -> dict:
    """SPY/QQQ 双指数行情趋势, 盘前与日线分口径。"""
    def premarket_change(context: Dict[str, Any]) -> Optional[float]:
        snapshot = context.get("snapshot") if isinstance(context, dict) else None
        if not isinstance(snapshot, dict) or "_error" in snapshot:
            return None
        try:
            return float(snapshot.get("pre_chg_pct"))
        except (TypeError, ValueError):
            return None

    spy_premarket_change = premarket_change(spy_context)
    qqq_premarket_change = premarket_change(qqq_context)
    if spy_premarket_change is not None and qqq_premarket_change is not None:
        if spy_premarket_change < 0 and qqq_premarket_change < 0:
            premarket_trend = "DOWN"
        elif spy_premarket_change > 0 and qqq_premarket_change > 0:
            premarket_trend = "UP"
        else:
            premarket_trend = "MIXED"
    else:
        premarket_trend = "UNKNOWN"

    spy_daily_trend = spy_context.get("trend") if isinstance(spy_context, dict) else None
    qqq_daily_trend = qqq_context.get("trend") if isinstance(qqq_context, dict) else None
    if spy_daily_trend == qqq_daily_trend and spy_daily_trend in ("UP", "DOWN"):
        daily_trend = spy_daily_trend
    elif spy_daily_trend and qqq_daily_trend:
        daily_trend = "MIXED"
    else:
        daily_trend = "UNKNOWN"

    return {
        "premarket": {
            "trend": premarket_trend,
            "spy_chg_pct": spy_premarket_change,
            "qqq_chg_pct": qqq_premarket_change,
        },
        "daily": {
            "trend": daily_trend,
            "spy_trend": spy_daily_trend,
            "qqq_trend": qqq_daily_trend,
        },
    }


def classify_industry_trend(today_change: Optional[float], five_day_change: Optional[float],
                            peer_count: int, today_peer_count: Optional[int] = None,
                            five_day_peer_count: Optional[int] = None) -> dict:
    """同业peer均值趋势: 当日与5日分口径, 零peer时如实UNKNOWN。"""
    def direction(change: Optional[float], sample_count: int) -> str:
        if sample_count <= 0 or change is None:
            return "UNKNOWN"
        if change > 0:
            return "UP"
        if change < 0:
            return "DOWN"
        return "FLAT"

    if peer_count <= 0:
        return {"today": "UNKNOWN", "five_day": "UNKNOWN", "combined": "UNKNOWN"}

    today_trend = direction(today_change, peer_count if today_peer_count is None else today_peer_count)
    five_day_trend = direction(five_day_change, peer_count if five_day_peer_count is None else five_day_peer_count)
    if "UNKNOWN" in (today_trend, five_day_trend):
        combined_trend = "UNKNOWN"
    elif today_trend == five_day_trend:
        combined_trend = today_trend
    else:
        combined_trend = "MIXED"
    return {
        "today": today_trend,
        "five_day": five_day_trend,
        "combined": combined_trend,
    }


def collect_market_context() -> dict:
    """大盘趋势: SPY/QQQ日K线 + VIX.

    让LLM判断个股技术面时能看到大盘环境:
    - SPY趋势向上 + 个股做多 = 顺风
    - SPY趋势向下 + 个股做多 = 逆风, 降低confidence
    - VIX > 25 = 高波动, 降低所有做多信号
    """
    import concurrent.futures

    with _MC_LOCK:
        if _MC_CACHE["val"] is not None and (time.time() - _MC_CACHE["ts"]) < _MC_CACHE_TTL:
            return dict(_MC_CACHE["val"])  # 浅拷贝够用: 下游只读

    result = {"_source": "market_context_v041"}  # v041: 增代码化大盘趋势 (盘前/日线双口径)
    
    def _get_index_kline(symbol):
        klines = collect_kline(symbol, "1d", 60)
        if not klines:
            return {"_error": f"no kline for {symbol}"}
        closes = [k.get("close", 0) for k in klines]
        if len(closes) < 20:
            return {"_error": "insufficient data"}
        ma5 = sum(closes[-5:]) / 5
        ma20 = sum(closes[-20:]) / 20
        ma50 = sum(closes[-50:]) / 50 if len(closes) >= 50 else ma20
        current = closes[-1]
        # 2026-09-24 (DEB-20260924 F1 方案B): 本函数的日K取自 collect_kline(sym,"1d",60)
        #   —— 该调用**无 start/end**, 走 get_kline.py 的 realtime 分支 (get_cur_kline),
        #   盘前今日日K尚不存在 ⇒ 最后一根 bar = **昨日** bar ⇒ current 恒等于昨收,
        #   而 prompt 那边它被当"当前大盘"渲染 ⇒ 模型看到"大盘持平/在涨"。
        #   同日盘中该值随今日形成中的 bar 变化 (实测 ET 10:25 已≠prev_close) ⇒ 病灶只在盘前,
        #   而 DA 恰恰只跑盘前。修法: 补 snapshot 盘前腿 + 显式基准日 (同 9/14 VIX 代理值
        #   标注先例: 口径可疑的值必须自带标签, 不能只给数字)。
        _snap: Dict[str, Any] = {}
        try:
            _s = collect_snapshot(symbol)
            if isinstance(_s, dict) and "_error" not in _s:
                _snap = {
                    "prev_close": _s.get("prev_close"),
                    "pre_price": _s.get("pre_price"),
                    "pre_chg_pct": _s.get("pre_change_rate"),
                    "session": _s.get("session"),
                    "snapshot_time": _s.get("update_time"),
                }
            else:
                _snap = {"_error": "snapshot unavailable"}
        except Exception as _e:  # 快照失败不得拖垮 market_context (盘前腿是增强项)
            _snap = {"_error": f"snapshot failed: {type(_e).__name__}"}
        _last_bar = klines[-1] if isinstance(klines[-1], dict) else {}
        _asof = str(_last_bar.get("time") or _last_bar.get("date") or _last_bar.get("timestamp") or "")[:10]
        chg_5d = ((closes[-1] - closes[-6]) / closes[-6] * 100) if len(closes) >= 6 else 0
        chg_20d = ((closes[-1] - closes[-21]) / closes[-21] * 100) if len(closes) >= 21 else 0
        above_ma20 = current > ma20
        above_ma50 = current > ma50
        # 简单趋势判定
        if above_ma20 and above_ma50 and chg_5d > 0:
            trend = "UP"
        elif not above_ma20 and not above_ma50 and chg_5d < 0:
            trend = "DOWN"
        else:
            trend = "MIXED"
        return {
            "current": round(current, 2),
            "ma5": round(ma5, 2),
            "ma20": round(ma20, 2),
            "ma50": round(ma50, 2),
            "chg_5d_pct": round(chg_5d, 2),
            "chg_20d_pct": round(chg_20d, 2),
            "above_ma20": above_ma20,
            "above_ma50": above_ma50,
            "trend": trend,
            "current_asof": _asof or "unknown",   # 日K最后一根的日期 = current 的基准日
            "snapshot": _snap,                     # 盘前腿 (prev_close/pre_price/pre_chg_pct/session)
        }
    
    def _get_vix():
        """VIX — 盘前唯一有效来源是 US.VIXY 代理 (×0.85 contango 校准)。

        病根 (2026-09-14 盘前数据有效性审计, 用户裁「全部处理」P0-2):
          DA 06:22 ET 跑在盘前, 而 **VIX 现货 (CBOE 现金指数) 无盘前交易**, 只能取
          代理; 原实现直查 `US.VIX` 快照 —— 而**富途不供指数快照**, 实测
          US.VIX/IXIC/DJI/SPX 全返 `{"_error": "empty"}`
          (docs/debates/DEB-20260818-futu-capability-audit.md:89,144) ⇒ VIX 自
          2026-08-11 起**结构性恒缺失**, 只是该缺失被 19 维覆盖审计掩盖
          (market_context 只要有 spy/qqq 就算 ok, 见 llm_synth._classify_data_sources)。
          而 prompt 里 VIX>25 是"降低所有做多信号"的依据 ⇒ 模型无据可依却仍可能要
          求引用 VIX 数值。

        修法: 改走 US.VIXY (短期期货 ETF, **有盘前成交**) 实时报价, 经仓内单一真源
          `app/data/vix_source.vixy_to_vix` 换算 (0.85 系数不再在本 skill 复制一份,
          防口径漂移 —— 同一系数此前在仓内 4 处复制)。导入失败时如实返回 _error
          (宁可让覆盖审计报缺失, 也不在本 skill 里再写一份字面量系数)。
        时点语义 (2026-11-09 更正, RFC-190 §1A 实测): **盘前 `last_price` 读到的是
          上一交易日收盘**, 不是实时盘前价 —— 23/23 个交易日 (2026-10-07..11-06) 的
          `vixy_price` 取值集合全部等于前一交易日 VIXY 收盘。盘前真实价在 `pre_price`,
          要改读它须先证明盘前成交质量并重标阈值 (RFC-190 选项 C, 未裁)。
        chg_pct 用 VIXY 自身 last/prev_close 现算 —— VIX 与 VIXY 只差常数比例,
          涨跌幅等价, 无需另取数据。
        """
        _vixy = None
        try:
            from app.data.vix_source import vixy_to_vix
        except Exception as _imp_err:   # pragma: no cover - 部署路径异常时
            return {"_error": f"vix_source unavailable ({_imp_err}); "
                              f"拒绝在本 skill 内复制 0.85 系数"}
        try:
            r = collect_snapshot("US.VIXY")
            if "_error" not in r:
                _vixy = float(r.get("last_price", 0) or 0)
                _pc = float(r.get("prev_close", 0) or r.get("prev_close_price", 0) or 0)
                _vix = vixy_to_vix(_vixy)
                if _vix is None:
                    return {"_error": "VIXY quote invalid (price<=0)"}
                return {
                    "current": _vix,
                    "chg_pct": round((_vixy - _pc) / _pc * 100, 2) if (_vixy > 0 and _pc > 0) else 0,
                    # 口径自述: 让 prompt 层能如实标注"代理值"而非假装是现货 VIX
                    "proxy": "US.VIXY",
                    "proxy_factor": 0.85,
                    "vixy_price": round(_vixy, 2),
                    # 2026-11-09 (RFC-190 §1A): 原标签"盘前/盘中实时代理"与实测相反 ——
                    #   盘前 last_price = 上一交易日收盘, 只差一个 0.85 系数。标签是
                    #   prompt 层判断"这是不是今日波动率"的唯一依据, 必须如实。
                    "caliber": "VIXY×0.85 代理 · 盘前读到上一交易日收盘 (非实时)",
                    "as_of_basis": "prev_close",
                }
        except Exception:
            pass
        return {"_error": "VIX unavailable (US.VIXY proxy failed)"}
    
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as ex:
        futs = {
            ex.submit(_get_index_kline, "US.SPY"): "spy",
            ex.submit(_get_index_kline, "US.QQQ"): "qqq",
            ex.submit(_get_vix): "vix",
        }
        for f in concurrent.futures.as_completed(futs):
            key = futs[f]
            try:
                result[key] = f.result()
            except Exception as e:
                result[key] = {"_error": str(e)}

    result["market_trend"] = classify_market_trend(
        result.get("spy") or {}, result.get("qqq") or {})

    # 缓存写入: 仅当核心 SPY/QQQ 至少一个成功才缓存 (全失败不缓存, 下只重试)
    if isinstance(result.get("spy"), dict) and "_error" not in result["spy"] or \
       isinstance(result.get("qqq"), dict) and "_error" not in result["qqq"]:
        with _MC_LOCK:
            _MC_CACHE["ts"] = time.time()
            _MC_CACHE["val"] = dict(result)
    return result


def collect_industry_peers(symbol: str) -> dict:
    """同行业peer对比: 同行业top 5股票的近期表现.
    
    让LLM判断个股时能看到行业整体走势:
    - 个股涨+行业涨 = 板块顺风
    - 个股涨+行业跌 = 个股alpha (可能持续,也可能是滞后补涨)
    - 个股跌+行业涨 = 个股beta不足 (可能继续跑输)
    """
    bare = symbol.split(".")[-1] if "." in symbol else symbol
    
    # 1. 获取公司行业
    profile = collect_company_profile(symbol)
    if "_error" in profile:
        return {"_error": "profile unavailable", "_detail": str(profile.get("_error"))}
    
    industry = profile.get("industry", "")
    if not industry:
        return {"_error": "no industry info"}

    # 行业级缓存: 结果纯行业聚合(peer列表+行业均值), 同行业标的共享 —
    #   消灭 5 标的 × 8 peers × (snapshot+kline) 的重复 OpenD 扇出 (连接风暴主源)
    _ck = str(industry).lower()
    with _IP_LOCK:
        _hit = _IP_CACHE.get(_ck)
        if _hit and (time.time() - _hit[0]) < _IP_CACHE_TTL:
            return dict(_hit[1])
    
    # 2. 获取同行业peer (Finnhub peers API)
    peers_data = _finnhub_get("stock/peers", {"symbol": bare})
    if "_error" in peers_data:
        return {"_error": "peers API failed", "_detail": str(peers_data.get("_error"))}
    
    # Finnhub返回的是symbol列表
    peer_symbols = peers_data if isinstance(peers_data, list) else peers_data.get("peers", [])
    if not peer_symbols:
        return {"_error": "no peers found", "industry": industry}
    
    # 3. 取top 5 peer的近期表现(用snapshot)
    import concurrent.futures
    
    peers_info = []
    
    def _get_peer_snapshot(peer_sym):
        """获取peer的快照+5日涨跌"""
        us_sym = f"US.{peer_sym}" if not peer_sym.startswith("US.") else peer_sym
        snap = collect_snapshot(us_sym)
        snapshot_failed = "_error" in snap
        if snapshot_failed:
            snap = {}
        # 5日收益 = 5个收益间隔，必须至少6个有效收盘；不足不得伪装成0。
        klines = collect_kline(us_sym, "1d", 6)
        closes = []
        for kline in klines:
            try:
                close = float(kline.get("close"))
                if math.isfinite(close) and close > 0:
                    closes.append(close)
            except (TypeError, ValueError):
                continue
        chg_5d = None
        if len(closes) >= 6:
            first_close, last_close = closes[-6], closes[-1]
            chg_5d = round((last_close - first_close) / first_close * 100, 2)
        price_info = session_price_fields(snap)
        if snapshot_failed:
            price_info["session"] = None
        pe = snap.get("pe_ttm_ratio") or snap.get("pe_ratio") or None
        market_cap = snap.get("total_market_val") or None
        return {
            "symbol": peer_sym,
            "price": price_info["price"],
            "chg_pct": price_info["change_pct"],
            "session": price_info["session"],
            "price_as_of": price_info["price_as_of"],
            "snapshot_status": "unavailable" if snapshot_failed else "ok",
            "chg_5d_pct": chg_5d,
            "pe": pe,
            "market_cap": market_cap,
        }
    
    with concurrent.futures.ThreadPoolExecutor(max_workers=5) as ex:
        futs = {ex.submit(_get_peer_snapshot, s): s for s in peer_symbols[:8]}
        for f in concurrent.futures.as_completed(futs):
            try:
                info = f.result()
                if info:
                    peers_info.append(info)
            except Exception:
                pass
    
    return _ip_done(industry, peers_info)


def _ip_done(industry: str, peers_info: List[dict]) -> dict:
    """industry_peers 收尾: 排序+均值+缓存写入 (仅成功结果入缓存)."""
    peers_info.sort(
        key=lambda item: (item.get("chg_5d_pct") is not None, item.get("chg_5d_pct") or 0.0),
        reverse=True,
    )
    valid_5d = [item["chg_5d_pct"] for item in peers_info if item.get("chg_5d_pct") is not None]
    valid_today = [item["chg_pct"] for item in peers_info if item.get("chg_pct") is not None]
    avg_5d = round(sum(valid_5d) / len(valid_5d), 2) if valid_5d else None
    avg_chg = round(sum(valid_today) / len(valid_today), 2) if valid_today else None
    result = {
        "industry": industry,
        "peer_count": len(peers_info),
        "peers": peers_info[:5],  # top 5
        "industry_avg_chg_5d_pct": avg_5d,
        "industry_avg_chg_today_pct": avg_chg,
        "industry_chg_5d_sample_count": len(valid_5d),
        "industry_chg_today_sample_count": len(valid_today),
        "industry_trend": classify_industry_trend(
            avg_chg, avg_5d, len(peers_info), len(valid_today), len(valid_5d)),
        "change_caliber": "session-aware effective price vs previous close; 5d=five close-to-close intervals",
        "caliber_version": "session_effective_v1",
        "_source": "industry_peers_v039",
    }
    if any(item.get("price") is not None or item.get("chg_5d_pct") is not None for item in peers_info):
        with _IP_LOCK:
            _IP_CACHE[str(industry).lower()] = (time.time(), dict(result))
    return result


# ── 批量采集 (供 deep_analyzer 用) ────────────────

def collect_all(symbol: str, kline_days: int = 60, anomaly_days: int = 7) -> dict:
    """全量采集 = 轻量快照 + K线 + 增量数据(异动/新闻/情绪)。
    轻量快照和K线是 deep_analyzer 技术面计算需要的;
    FTSeek 的 FundamentalProvider 更完整但需要完整初始化链, 不适合在 skill 里调。
    """
    import concurrent.futures, time

    result = {"symbol": symbol, "_timestamp": time.time()}

    tasks = {
        "snapshot": lambda: collect_snapshot(symbol),
        "kline": lambda: collect_kline(symbol, "1d", kline_days),
        "capital_flow": lambda: collect_capital_flow(symbol),
        "capital_distribution": lambda: collect_capital_distribution(symbol),
        "tech_anomaly": lambda: collect_technical_anomaly(symbol, anomaly_days),
        "cap_anomaly": lambda: collect_capital_anomaly(symbol, anomaly_days),
        "deriv_anomaly": lambda: collect_derivatives_anomaly(symbol, anomaly_days),
        # [2026-11-17 DEB-20261117 R2] DA_INPUT_FULL: 采集量放宽 (同一API调用,
        #   零新增请求): 新闻 10→20 / 研报 5→10 / Finnhub 6→12 条. 回滚: DA_INPUT_FULL=0.
        "news": lambda: collect_news(symbol, size=20 if getattr(config, "DA_INPUT_FULL", True) else 10),
        # P1 (2026-08-14): Finnhub 带摘要新闻流, 独立维度不覆盖富途中文标题源
        "news_v2": lambda: collect_finnhub_news(symbol, top_n=12 if getattr(config, "DA_INPUT_FULL", True) else 6),
        "research": lambda: collect_research_reports(symbol, size=10 if getattr(config, "DA_INPUT_FULL", True) else 5),
        "sentiment": lambda: collect_community_sentiment(symbol),
        "fundamentals": lambda: collect_fundamentals(symbol),
        "analyst_consensus": lambda: collect_analyst_consensus(symbol),
        "insider_transactions": lambda: collect_insider_transactions(symbol),
        "insider_sentiment": lambda: collect_insider_sentiment(symbol),
        "company_profile": lambda: collect_company_profile(symbol),
        "earnings_calendar": lambda: collect_earnings_calendar(symbol),
        # v0.39新增: 大盘关联 + 行业peer对比
        "market_context": lambda: collect_market_context(),
        "industry_peers": lambda: collect_industry_peers(symbol),
    }

    with concurrent.futures.ThreadPoolExecutor(max_workers=6) as executor:
        futures = {executor.submit(fn): key for key, fn in tasks.items()}
        for future in concurrent.futures.as_completed(futures):
            key = futures[future]
            try:
                result[key] = future.result()
            except Exception as e:
                result[key] = {"_error": str(e)}

    total = len(tasks)
    ok = sum(1 for k in tasks
             if isinstance(result.get(k), (dict, list))
             and not (isinstance(result.get(k), dict) and "_error" in result[k]))
    result["_quality"] = {"total": total, "ok": ok, "failed": total - ok}
    _attach_source_status(result)

    return result


def main():
    import argparse
    parser = argparse.ArgumentParser(description="DataCollector — 增量数据采集")
    parser.add_argument("symbol", help="股票代码")
    parser.add_argument("--mode", choices=["all", "anomaly", "news", "sentiment", "scan"],
                        default="all")
    args = parser.parse_args()

    if args.mode == "all":
        print(json.dumps(collect_all(args.symbol), ensure_ascii=False, default=str))
    elif args.mode == "anomaly":
        r = {
            "technical": collect_technical_anomaly(args.symbol),
            "capital": collect_capital_anomaly(args.symbol),
            "derivatives": collect_derivatives_anomaly(args.symbol),
        }
        print(json.dumps(r, ensure_ascii=False, default=str))
    elif args.mode == "news":
        print(json.dumps(collect_news(args.symbol), ensure_ascii=False, default=str))
    elif args.mode == "sentiment":
        print(json.dumps(collect_community_sentiment(args.symbol), ensure_ascii=False, default=str))
    elif args.mode == "scan":
        r = {
            "gainers": collect_top_gainers(),
            "losers": collect_top_losers(),
            "volume": collect_top_volume(),
        }
        print(json.dumps(r, ensure_ascii=False, default=str))


if __name__ == "__main__":
    main()
