#!/usr/bin/env python3
"""前序回吐率统计 (shadow信号, 2026-08-14)

动机: 归因框架里唯一"纯K线可算、零新闻依赖、零LLM"的要素。
定义: 标的历史上每次大涨日(close-to-close > +SPIKE_PCT)后,
      3/5/10个交易日的表现 — 守得住涨幅还是回吐。

输出指标 (每标的):
  spike_count        大涨日样本数
  hold_3d/5d/10d     大涨后第k日收盘仍高于大涨日收盘的概率 (守成率)
  avg_fwd_3d/5d/10d  大涨后k日累计收益均值(%)
  momentum_bias      avg_fwd_5d 符号 → 续涨倾向(+)/回吐倾向(-)

纪律: 只算、不下结论。IC验证攒够样本(≥30个spike事件)后另行裁决。
回滚: 删本文件 + 移除 pipeline 调用即可, 无schema依赖。
"""
import json
import os
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

PYTHON = "/opt/ftseek/FTSeek-US/venv/bin/python3.11"
GET_KLINE = "/root/.hermes/skills/futuapi/scripts/quote/get_kline.py"
WATCHLIST_JSON = Path("/opt/ftseek/FTSeek-US/config/watchlist_us.json")
OUT_PATH = Path(__file__).parent / "pullback_shadow.json"

SPIKE_PCT = 5.0      # 大涨日阈值: close-to-close > +5%
WINDOWS = (3, 5, 10)
NUM_KLINES = 260     # ~1年交易日


def fetch_klines(symbol: str) -> list:
    try:
        r = subprocess.run(
            [PYTHON, GET_KLINE, symbol, "--ktype", "1d",
             "--num", str(NUM_KLINES), "--json"],
            capture_output=True, text=True, timeout=30)
        raw = r.stdout
        i, j = raw.find("{"), raw.rfind("}")
        if i < 0 or j <= i:
            return []
        d = json.loads(raw[i:j + 1])
        return d.get("data", []) or []
    except Exception:
        return []


def compute_pullback(closes: list) -> dict:
    """closes: 按时间升序的收盘价列表"""
    spikes = []
    for t in range(1, len(closes)):
        chg = (closes[t] / closes[t - 1] - 1) * 100
        if chg > SPIKE_PCT:
            spikes.append((t, chg))
    if not spikes:
        return {"spike_count": 0}

    stats = {}
    for k in WINDOWS:
        holds, fwd = 0, []
        for t, chg in spikes:
            if t + k < len(closes):
                r_k = (closes[t + k] / closes[t] - 1) * 100
                fwd.append(r_k)
                if r_k >= 0:
                    holds += 1
        n = len(fwd)
        stats[f"n_{k}d"] = n
        if n:
            stats[f"hold_{k}d"] = round(holds / n * 100, 1)
            stats[f"avg_fwd_{k}d"] = round(sum(fwd) / n, 2)
    out = {"spike_count": len(spikes)}
    out.update(stats)
    bias = out.get("avg_fwd_5d")
    if bias is not None:
        out["momentum_bias"] = "续涨倾向" if bias > 0 else "回吐倾向"
    return out


def load_watchlist() -> list:
    try:
        data = json.loads(WATCHLIST_JSON.read_text())
        if isinstance(data, dict):
            data = data.get("watchlist") or data.get("symbols") or list(data.values())[0]
        return [s for s in data if isinstance(s, str)]
    except Exception:
        pass
    # fallback: 生产同款来源 (watchlist_manager), 与 DA cron Step 1 一致
    try:
        r = subprocess.run(
            [PYTHON, "-c",
             "from app.utils.watchlist_manager import get_stock_codes; "
             "print(','.join(get_stock_codes()))"],
            capture_output=True, text=True, timeout=30,
            cwd="/opt/ftseek/FTSeek-US")
        return [s.strip() for s in r.stdout.strip().split(",") if s.strip()]
    except Exception as e:
        print(f"watchlist加载失败: {e}", file=sys.stderr)
        return []


def main():
    raw = sys.argv[1:] if len(sys.argv) > 1 else load_watchlist()
    # 兼容 cron 传入的单个逗号分隔字符串
    symbols = []
    for s in raw:
        symbols.extend(x.strip() for x in s.split(",") if x.strip())
    if not symbols:
        print("无标的", file=sys.stderr)
        sys.exit(1)
    results = {}
    # 2026-10-23: 原来逐只 260 日 K 线串行，44 只约 2 分钟且挂在 DA 关键路径上。
    # 4 路并行取数（各自独立子进程/连接），输出仍按输入顺序打印与落盘。
    _workers = max(1, min(4, int(os.environ.get("PULLBACK_MAX_WORKERS", "4")),
                          len(symbols)))

    def _one(sym):
        klines = fetch_klines(sym)
        if len(klines) < 30:
            return sym, {"spike_count": 0, "_error": f"kline仅{len(klines)}根"}
        closes = [row["close"] for row in klines]
        return sym, compute_pullback(closes)

    with ThreadPoolExecutor(max_workers=_workers,
                            thread_name_prefix="pullback") as ex:
        for sym, stats in ex.map(_one, symbols):
            results[sym] = stats
            s = results[sym]
            print(f"{sym}: spikes={s['spike_count']} "
                  f"hold5d={s.get('hold_5d', 'N/A')}% "
                  f"avg_fwd5d={s.get('avg_fwd_5d', 'N/A')}% "
                  f"{s.get('momentum_bias', '')}")
    # 合并写入 (非覆盖): 保留未刷新标的(如扫描器历史候选)的既有统计
    try:
        merged = json.loads(OUT_PATH.read_text()) if OUT_PATH.exists() else {}
    except Exception:
        merged = {}
    merged.update(results)
    # 2026-08-26 审计修复: write_text 非原子写, 进程中断会留下截断 JSON;
    # 改为先写同目录 tmp 文件再 os.replace() 原子替换。
    _tmp_path = OUT_PATH.with_name(OUT_PATH.name + ".tmp")
    _tmp_path.write_text(json.dumps(merged, ensure_ascii=False, indent=2))
    os.replace(_tmp_path, OUT_PATH)
    print(f"\n落盘: {OUT_PATH} (刷新{len(results)}只, 合并后共{len(merged)}只)")


if __name__ == "__main__":
    main()
