#!/usr/bin/env python3
"""prev_close 与上一已完成日 K 线核对 (record-only, 2026-10-23).

背景: 快照 prev_close 概率性返回两天前收盘; 8/29 的 pre_price/(1+rate)
推导只在偏差 >1% 时覆盖, 10/22 实测 8/28 份偏差 0.24%-0.93% 漏过
(TSCO 32.91 vs 真昨收 32.69). 本模块只做纯计算, 不取数、不写库.

**尚未接入 data_collector.collect_all**: 目标文件当前含另一会话的未提交
WIP (财报日历回退等). 为避免把他人 WIP 随本改动一起送进下一 DA 进程,
本批只交付独立模块 + 测试. 接线时在 collect_all 末尾加:

    from prev_close_reconcile import reconcile_prev_close
    if isinstance(result.get("snapshot"), dict) and isinstance(result.get("kline"), list):
        result["snapshot"] = reconcile_prev_close(result["snapshot"], result["kline"])

默认 shadow 只加 provenance; apply 才改 prev_close/effective_chg_pct.

DA_PREV_CLOSE_BAR_RECONCILE: shadow (默认) | apply | off
守卫: 仅 premarket/regular; 日K早于今日且距今日<=4自然日; 偏差 0.05%-5%;
pre_change_rate 可推导且与日K偏差 <=0.5%. 任一不满足只记 conflict/stale_bar,
绝不覆盖.
"""
from __future__ import annotations

import os
from datetime import date, datetime
from typing import Any, Dict, List, Optional


def reconcile_prev_close(
    snapshot: Dict[str, Any],
    kline: List[Dict[str, Any]],
    today: Optional[date] = None,
    mode: Optional[str] = None,
) -> Dict[str, Any]:
    mode = str(mode or os.environ.get("DA_PREV_CLOSE_BAR_RECONCILE", "shadow")).lower()
    if mode not in ("off", "shadow", "apply") or mode == "off":
        return snapshot
    if not isinstance(snapshot, dict) or "_error" in snapshot:
        return snapshot
    session = str(snapshot.get("session") or "").lower()
    if session not in ("premarket", "regular"):
        return snapshot

    if today is None:
        try:
            from zoneinfo import ZoneInfo
            today = datetime.now(ZoneInfo("America/New_York")).date()
        except Exception:
            today = datetime.utcnow().date()

    bars = []
    for bar in kline or []:
        if not isinstance(bar, dict):
            continue
        bd = str(bar.get("time") or bar.get("date") or "")[:10]
        try:
            d = date.fromisoformat(bd)
            c = float(bar.get("close") or 0)
        except (TypeError, ValueError):
            continue
        if d < today and c > 0:
            bars.append((d, c))
    if not bars:
        return snapshot

    bar_date, bar_close = max(bars, key=lambda x: x[0])
    # Prefer the pre-correction source value. collect_snapshot may already
    # replace prev_close_price when its >1% derivation fires; keeping
    # prev_close_raw_source lets a second reconcile pass stay idempotent and
    # lets audits recover the original value.
    raw = snapshot.get("prev_close_raw")
    if raw in (None, ""):
        raw = snapshot.get("prev_close_raw_source")
    if raw in (None, ""):
        raw = snapshot.get("prev_close_price")
    if raw in (None, ""):
        raw = snapshot.get("prev_close")
    try:
        raw_f = float(raw)
    except (TypeError, ValueError):
        return snapshot
    if raw_f <= 0:
        return snapshot
    snapshot.setdefault("prev_close_raw_source", round(raw_f, 4))

    delta_pct = (raw_f - bar_close) / bar_close * 100.0
    gap_days = (today - bar_date).days
    pre = snapshot.get("pre_price")
    rate = snapshot.get("pre_change_rate")
    implied = None
    implied_vs_bar = None
    try:
        pre_f = float(pre)
        rate_f = float(rate)
        if pre_f > 0 and abs(rate_f) > 1e-12:
            implied = pre_f / (1.0 + rate_f / 100.0)
            implied_vs_bar = (implied - bar_close) / bar_close * 100.0
    except (TypeError, ValueError):
        pass

    if abs(delta_pct) <= 0.05:
        status = "ok"
    elif gap_days > 4:
        status = "stale_bar"
    elif abs(delta_pct) > 5.0:
        status = "conflict"
    elif implied_vs_bar is None or abs(implied_vs_bar) > 0.5:
        # 无 pre_change_rate 可交叉验证时不覆盖; 宁可保留原值并留 conflict.
        status = "conflict"
    else:
        status = "would_apply" if mode == "shadow" else "applied"

    snapshot["prev_close_raw"] = round(raw_f, 4)
    snapshot["prev_close_bar_close"] = round(bar_close, 4)
    snapshot["prev_close_bar_date"] = bar_date.isoformat()
    snapshot["prev_close_delta_pct"] = round(delta_pct, 4)
    snapshot["prev_close_reconcile"] = {
        "mode": mode,
        "status": status,
        "implied_prev_close": round(implied, 4) if implied is not None else None,
        "implied_vs_bar_pct": round(implied_vs_bar, 4) if implied_vs_bar is not None else None,
    }
    if status == "applied":
        snapshot["prev_close"] = round(bar_close, 4)
        snapshot["prev_close_price"] = round(bar_close, 4)
        snapshot["prev_close_effective"] = round(bar_close, 4)
        try:
            if float(pre) > 0:
                snapshot["effective_chg_pct"] = round(
                    (float(pre) - bar_close) / bar_close * 100.0, 2)
        except (TypeError, ValueError):
            pass
        snapshot["prev_close_reconcile"]["applied_close"] = round(bar_close, 4)
    return snapshot
