#!/usr/bin/env python3
"""
DeepAnalyzer — 单股深度分析引擎
================================
输入：DataCollector 采集的全量数据
输出：结构化分析报告（KO示例格式）

分析维度：
1. 基本面快照（PE/PB/EPS/市值/利润率/ROE）
2. 技术面（趋势/位置/量价/支撑阻力）
3. 资金面（大单流向/资金分布/主力行为）
4. 异动信号（技术/资金/衍生品三维）
5. 新闻催化（最新事件+方向判断）
6. 社区情绪（多空比+拥挤度）
7. 板块归属（所属板块+轮动位置）
8. 风险日历（财报日+宏观事件）

每个维度独立打分，最终合成综合评级。
"""

import json
import os
import sys
import time
from datetime import datetime, timedelta, timezone
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field, asdict

try:  # [RFC-117/v0.88] MA trend 单一真源在 FTSeek 仓 (app.playbook.momentum)。
    # 跨仓硬依赖必须 fail-open: 仓路径变动/文件改名时降级到本地同口径副本,
    # 绝不让 import 炸掉整条 DA 盘前链 (与下方 anomaly_parse 同款纪律)。
    # 仓内测试 test_da_uses_repo_classifier_from_skill_cwd 钉住"共享真源在线"
    # (module+__file__ 双断言) — 一旦走到降级臂, 该测试转红报警。
    sys.path.append("/opt/ftseek/FTSeek-US")
    from app.playbook.momentum import classify_ma_trend
except Exception:  # pragma: no cover — 降级臂, 口径与 app.playbook.momentum 逐字一致
    def classify_ma_trend(closes):  # type: ignore
        if len(closes) < 20:
            return "no_data", None

        def _ma(data, period):
            if len(data) < period:
                return None
            return round(sum(data[-period:]) / period, 2)

        ma5, ma10, ma20 = _ma(closes, 5), _ma(closes, 10), _ma(closes, 20)
        close = round(closes[-1], 2)
        detail = {"ma5": ma5, "ma10": ma10, "ma20": ma20, "close": close,
                  "bars_used": len(closes)}
        trend = "震荡"
        if ma5 and ma10 and ma20:
            if ma5 > ma10 > ma20 and close > ma5:
                trend = "多头排列"
            elif ma5 < ma10 < ma20 and close < ma5:
                trend = "空头排列"
            elif ma5 > ma10:
                trend = "短期偏多"
            elif ma5 < ma10:
                trend = "短期偏空"
        return trend, detail

try:  # v0.87: 异动 payload 解析单一真源 (中立模块, 无循环 import)
    from anomaly_parse import parse_anomaly_payload
except Exception:  # pragma: no cover — 降级到保守解析, 绝不谎报 has_anomaly
    def parse_anomaly_payload(payload):  # type: ignore
        d = payload.get("data") if isinstance(payload, dict) else None
        d = d if isinstance(d, dict) else (payload if isinstance(payload, dict) else {})
        c = (d.get("content") or "").strip() if isinstance(d, dict) else ""
        if d.get("err_code") == -12301 or (d.get("err_code") not in (0, 1) and not c):
            return {"status": "error", "count": 0, "items": [], "omitted": 0,
                    "time_range": str(d.get("time_range") or ""), "detail": f"err_code={d.get('err_code')}"}
        return {"status": "ok" if c else "empty", "count": (1 if c else 0),
                "items": ([c] if c else []), "omitted": 0,
                "time_range": str(d.get("time_range") or ""), "detail": None}


@dataclass
class AnalysisResult:
    """单股深度分析结果"""
    symbol: str
    name: str = ""
    timestamp: float = field(default_factory=time.time)

    # 各维度数据
    snapshot: Dict = field(default_factory=dict)
    technical: Dict = field(default_factory=dict)
    capital: Dict = field(default_factory=dict)
    anomalies: Dict = field(default_factory=dict)
    news: List[Dict] = field(default_factory=list)
    sentiment: Dict = field(default_factory=dict)
    plates: List[Dict] = field(default_factory=list)

    # 分析结论
    conclusion: str = ""
    rating: str = ""  # 强烈看多/看多/持有/观望/看空/强烈看空
    confidence: str = ""  # 高/中高/中/中低/低
    score: float = 0.0  # 综合评分 0-10

    # 核心理由（每条标注强度）
    bull_reasons: List[Dict] = field(default_factory=list)  # [{"text": "...", "strength": "强/中/弱"}]
    bear_reasons: List[Dict] = field(default_factory=list)
    constraints: List[Dict] = field(default_factory=list)  # 强制约

    # 交易计划
    action: str = ""  # 做多/做空/持有/观望
    entry_plan: str = ""
    stop_loss: str = ""
    target: str = ""
    key_levels: Dict = field(default_factory=dict)  # {"support": [...], "resistance": [...], "current": ...}

    # 风险
    risks: List[str] = field(default_factory=list)

    # 数据质量
    data_quality: Dict = field(default_factory=dict)

    # LLM原始输出 (供adapter提取entry/SL/TP)
    _llm_output: Dict = field(default_factory=dict)


class DeepAnalyzer:
    """单股深度分析引擎

    synth_module: 可注入的合成模块，必须有 synthesize(collected_data) -> dict 方法。
                  默认 None → 尝试 import llm_synth，失败则用规则降级。
                  传 'rule' → 强制规则模式，不调LLM。
    """

    def __init__(self, collected_data: Dict, synth_module=None):
        self.data = collected_data
        self.symbol = collected_data.get("symbol", "")
        self.result = AnalysisResult(symbol=self.symbol)
        self._synth_module = synth_module

    def analyze(self) -> Dict:
        """执行完整分析，返回 dict"""
        self._analyze_snapshot()
        self._analyze_technical()
        self._analyze_capital()
        self._analyze_anomalies()
        self._analyze_news()
        self._analyze_sentiment()
        self._analyze_plates()
        self._synthesize()
        self._compute_data_quality()
        return asdict(self.result)

    # ── 基本面快照 ─────────────────────────────────

    def _analyze_snapshot(self):
        snap = self.data.get("snapshot", {})
        if "_error" in snap:
            self.result.snapshot = {"_error": snap["_error"]}
            return

        self.result.name = snap.get("name", "")
        price = snap.get("last_price", 0)
        prev_close = snap.get("prev_close", 0)
        change = ((price - prev_close) / prev_close * 100) if prev_close else 0

        self.result.snapshot = {
            "price": price,
            "change_pct": round(change, 2),
            "volume": snap.get("volume", 0),
            "turnover": snap.get("turnover", 0),
            "turnover_rate": snap.get("turnover_rate", 0),
            "pe_ratio": snap.get("pe_ratio") or snap.get("pe_ttm_ratio", 0),
            "pe_ttm": snap.get("pe_ttm_ratio", 0),
            "pb_ratio": snap.get("pb_ratio", 0),
            "eps": snap.get("earning_per_share", 0),
            "market_cap": snap.get("total_market_val", 0),
            "net_profit": snap.get("net_profit", 0),
            "net_asset": snap.get("net_asset", 0),
            "dividend_yield": snap.get("dividend_ratio_ttm", 0),
            "high_52w": snap.get("highest52weeks_price", 0),
            "low_52w": snap.get("lowest52weeks_price", 0),
            "high_history": snap.get("highest_history_price", 0),
            "amplitude": snap.get("amplitude", 0),
            "bid_ask_ratio": snap.get("bid_ask_ratio", 0),
            "volume_ratio": snap.get("volume_ratio", 0),
            "pre_change": snap.get("pre_change_rate", 0),
            "after_change": snap.get("after_change_rate", 0),
            # 2026-08-11 (LIF 盲区修复): 时段真实价 — 盘前 last_price=昨收, 必须用 effective_price
            "effective_price": snap.get("effective_price", 0),
            "effective_chg_pct": snap.get("effective_chg_pct", 0),
            "session": snap.get("session", ""),
            "pre_price": snap.get("pre_price", 0),
            "pre_volume": snap.get("pre_volume", 0),
        }

        # 2026-08-11: 盘前时段 price/change_pct 修正为 effective 口径 —
        #   下游 LLM prompt/anchor_dev 全部消费 snapshot["price"], 盘前不改口径
        #   就是"用昨收当现价"的 LIF 盲区。
        if self.result.snapshot["session"] == "premarket" and self.result.snapshot["effective_price"] > 0:
            self.result.snapshot["price"] = self.result.snapshot["effective_price"]
            self.result.snapshot["change_pct"] = self.result.snapshot["effective_chg_pct"]

        # 52周位置
        high52 = self.result.snapshot["high_52w"]
        low52 = self.result.snapshot["low_52w"]
        if high52 and low52 and high52 > low52:
            pos = (price - low52) / (high52 - low52) * 100
            self.result.snapshot["position_52w_pct"] = round(pos, 1)

    # ── 技术面分析 ─────────────────────────────────

    def _analyze_technical(self):
        klines = self.data.get("kline", [])
        if not klines:
            self.result.technical = {"_error": "no kline data"}
            return

        # 计算 MA
        closes = [k.get("close", 0) for k in klines]
        volumes = [k.get("volume", 0) for k in klines]

        def ma(data, period):
            if len(data) < period:
                return None
            return round(sum(data[-period:]) / period, 2)

        ma5 = ma(closes, 5)
        ma10 = ma(closes, 10)
        ma20 = ma(closes, 20)
        ma50 = ma(closes, 50) if len(closes) >= 50 else None
        ma60 = ma(closes, 60)

        last = klines[-1] if klines else {}
        prev = klines[-2] if len(klines) >= 2 else {}
        price = last.get("close", 0)
        prev_close = prev.get("close", 0)

        # 趋势判断 — 与 UE 直写闸共用 FTSeek 仓内同一纯函数
        trend, _trend_detail = classify_ma_trend(closes)
        if trend == "no_data":
            trend = "震荡"

        # 量价关系
        avg_vol_5 = sum(volumes[-5:]) / 5 if len(volumes) >= 5 else 0
        avg_vol_20 = sum(volumes[-20:]) / 20 if len(volumes) >= 20 else 0
        vol_ratio = (volumes[-1] / avg_vol_20) if avg_vol_20 else 0

        # RSI (14)
        rsi = self._calc_rsi(closes, 14)

        # 支撑阻力位
        recent_highs = [k.get("high", 0) for k in klines[-20:]]
        recent_lows = [k.get("low", 0) for k in klines[-20:]]
        resistance = max(recent_highs) if recent_highs else 0
        support = min(recent_lows) if recent_lows else 0

        # 距52周高低
        high52 = self.result.snapshot.get("high_52w", 0)
        low52 = self.result.snapshot.get("low_52w", 0)
        dist_high = ((price - high52) / high52 * 100) if high52 else 0
        dist_low = ((price - low52) / low52 * 100) if low52 else 0

        self.result.technical = {
            "trend": trend,
            "price": price,
            "ma5": ma5, "ma10": ma10, "ma20": ma20, "ma50": ma50, "ma60": ma60,
            "rsi14": round(rsi, 1) if rsi else None,
            "volume": volumes[-1] if volumes else 0,
            "vol_ratio_5d": round(avg_vol_5 / avg_vol_20, 2) if avg_vol_20 else 0,
            "vol_vs_20d": round(vol_ratio, 2),
            "support_20d": round(support, 2),
            "resistance_20d": round(resistance, 2),
            "dist_52w_high": round(dist_high, 1),
            "dist_52w_low": round(dist_low, 1),
            "recent_5d_change": round(((closes[-1] - closes[-6]) / closes[-6] * 100) if len(closes) >= 6 else 0, 2),
            "recent_20d_change": round(((closes[-1] - closes[-21]) / closes[-21] * 100) if len(closes) >= 21 else 0, 2),
        }

        # 关键位
        self.result.key_levels["current"] = price
        self.result.key_levels["support"] = [support]
        self.result.key_levels["resistance"] = [resistance]

    @staticmethod
    def _calc_rsi(closes: List[float], period: int = 14) -> float:
        if len(closes) < period + 1:
            return 50.0
        gains = []
        losses = []
        for i in range(period):
            idx = -(period - i)
            change = closes[idx] - closes[idx - 1]
            gains.append(max(0, change))
            losses.append(max(0, -change))
        avg_gain = sum(gains) / period if gains else 0
        avg_loss = sum(losses) / period if losses else 0
        if avg_loss == 0:
            return 100.0
        rs = avg_gain / avg_loss
        return 100 - (100 / (1 + rs))

    # ── 资金面分析 ─────────────────────────────────

    def _analyze_capital(self):
        dist = self.data.get("capital_distribution", {})
        flow_raw = self.data.get("capital_flow", {})

        # RFC-218 §8 P0: DA_CAPITAL_CODE_FIX 独立开关 — provider 实写 code=<ticker>,
        #   旧 `code==0` 门误丢有效分布. =0(默认)逐字节保留旧门; =1 以八字段存在判定.
        #   与 llm_synth._render_capital_section 同开关同口径 (规则降级路径对称修复).
        #   RFC-218 §19: flag-ON 有效性判定单一真源 = llm_synth._capital_dist_valid
        #   (八字段完整 ∧ 数值 ∧ 有限 ∧ 非 bool ∧ provider 缺值清单空), 消除原
        #   any(四 inflow 键) 把单字段补零成「假完整」的 §18.2-A 病灶。
        #   llm_synth 不 import deep_analyzer ⇒ 惰性导入无环 (与 :485 同纪律)。
        import config as _cfg_cap
        _cap_fix = getattr(_cfg_cap, "DA_CAPITAL_CODE_FIX", False)
        if _cap_fix:
            try:
                from llm_synth import _capital_dist_valid as _cdv
                _schema_ok = _cdv(dist)
            except Exception:
                _schema_ok = False
            _dist_valid = isinstance(dist, dict) and "_error" not in dist and _schema_ok
        else:
            _dist_valid = isinstance(dist, dict) and "_error" not in dist and dist.get("code") == 0
        # 优先用 capital_distribution（资金分布：大单/中单/小单，当日快照）
        if _dist_valid:
            in_super = dist.get("capital_in_super", 0) or 0
            out_super = dist.get("capital_out_super", 0) or 0
            in_big = dist.get("capital_in_big", 0) or 0
            out_big = dist.get("capital_out_big", 0) or 0
            net_main = (in_super + in_big) - (out_super + out_big)
            total_in = sum(dist.get(k, 0) or 0 for k in
                          ["capital_in_super", "capital_in_big", "capital_in_mid", "capital_in_small"])
            total_out = sum(dist.get(k, 0) or 0 for k in
                           ["capital_out_super", "capital_out_big", "capital_out_mid", "capital_out_small"])
            self.result.capital = {
                "net_main_flow": round(net_main, 0),
                "net_total_flow": round(total_in - total_out, 0),
                "super_in": in_super, "super_out": out_super,
                "big_in": in_big, "big_out": out_big,
                "main_flow_pct": round((net_main / (total_in + total_out) * 100), 2) if (total_in + total_out) else 0,
            }
        # 降级：用 capital_flow（分时资金流，返回 {code:0, data:[...]}）
        elif isinstance(flow_raw, dict) and "_error" not in flow_raw:
            flow_data = flow_raw.get("data", [])
            if isinstance(flow_data, list) and flow_data:
                recent = flow_data[-5:]  # 最近5条分时
                net_flows = [r.get("main_in_flow", 0) for r in recent if isinstance(r, dict)]
                self.result.capital = {
                    "recent_net_flows": net_flows,
                    "latest_flow": net_flows[-1] if net_flows else 0,
                }
            else:
                self.result.capital = {"_error": "capital_flow data empty"}
        else:
            self.result.capital = {"_error": "no capital data"}

    # ── 异动信号 ───────────────────────────────────

    def _analyze_anomalies(self):
        # [v0.87] schema 错配修复 (2026-09-26 实测 642 payload):
        #   provider 返回 {"data": {err_code, retMsg, time_range, content}}, data 是 DICT;
        #   旧代码当 LIST 用 → has_anomaly=bool(dict)恒True / count=0 / details=[] /
        #   content(真实异动文本)从不读取 = 474/642 (74%) 有效信号静默丢弃,
        #   且 err_code=1「无异常」被谎报成 has_anomaly=true (122 次假阳)。
        #   现走 parse_anomaly_payload 单一真源 (与 llm_synth 渲染段共用)。
        anomalies = {}
        for key, label in [("tech_anomaly", "technical"), ("cap_anomaly", "capital"), ("deriv_anomaly", "derivatives")]:
            data = self.data.get(key, {})
            if isinstance(data, dict) and "_error" not in data:
                parsed = parse_anomaly_payload(data)
                if parsed["status"] == "error":
                    anomalies[label] = {"_error": parsed.get("detail") or "provider error"}
                else:
                    anomalies[label] = {
                        "has_anomaly": parsed["status"] == "ok",
                        "count": parsed["count"],
                        "details": parsed["items"][:3],
                    }
            else:
                anomalies[label] = {"_error": data.get("_error", "unknown") if isinstance(data, dict) else "no data"}

        self.result.anomalies = anomalies

    # ── 新闻催化 ───────────────────────────────────

    def _analyze_news(self):
        news = self.data.get("news", [])
        research = self.data.get("research", [])

        items = []
        for n in news[:10]:
            items.append({
                "title": self._strip_html(n.get("title", "")),
                "time": n.get("publish_time", ""),
                "url": n.get("url", ""),
            })

        research_items = []
        for r in research[:5]:
            research_items.append({
                "title": self._strip_html(r.get("title", "")),
                "time": r.get("publish_time", ""),
                "url": r.get("url", ""),
            })

        self.result.news = items
        self.result.sentiment = {**self.result.sentiment, "research_reports": research_items}

    @staticmethod
    def _strip_html(text: str) -> str:
        import re, html
        text = re.sub(r'<[^>]+>', '', text)
        return html.unescape(text).strip()

    # ── 社区情绪 ───────────────────────────────────

    def _analyze_sentiment(self):
        posts = self.data.get("sentiment", [])
        if not posts:
            self.result.sentiment = {**self.result.sentiment, "post_count": 0}
            return

        # 简单分类（基于关键词）
        bull_keywords = ["涨", "多", "买", "bull", "long", "up", "看多", "加仓", "抄底", "突破", "利好"]
        bear_keywords = ["跌", "空", "卖", "bear", "short", "down", "看空", "减仓", "止损", "破位", "利空"]

        bull_count = 0
        bear_count = 0
        neutral_count = 0
        viewpoints = []

        for post in posts:
            text = self._strip_html(post.get("title", "") + " " + post.get("desc", ""))
            text_lower = text.lower()
            is_bull = any(k in text_lower for k in bull_keywords)
            is_bear = any(k in text_lower for k in bear_keywords)
            if is_bull and not is_bear:
                bull_count += 1
            elif is_bear and not is_bull:
                bear_count += 1
            else:
                neutral_count += 1
            if len(viewpoints) < 5 and len(text) > 10:
                viewpoints.append(text[:100])

        total = bull_count + bear_count + neutral_count
        bull_pct = round(bull_count / total * 100, 0) if total else 0
        bear_pct = round(bear_count / total * 100, 0) if total else 0
        neutral_pct = round(neutral_count / total * 100, 0) if total else 0

        # 拥挤度判断
        crowding = "正常"
        if bull_pct >= 85:
            crowding = "多头像拥挤（反向警示）"
        elif bear_pct >= 85:
            crowding = "空头像拥挤（反向警示）"

        existing = self.result.sentiment
        existing.update({
            "post_count": total,
            "bull_pct": bull_pct,
            "bear_pct": bear_pct,
            "neutral_pct": neutral_pct,
            "crowding": crowding,
            "viewpoints": viewpoints,
        })
        self.result.sentiment = existing

    # ── 板块归属 ───────────────────────────────────

    def _analyze_plates(self):
        # data_collector不采集owner_plates（富途F10接口不可用），
        # 改用company_profile的industry字段作为行业归属
        profile = self.data.get("company_profile", {})
        if isinstance(profile, dict) and "_error" not in profile:
            industry = profile.get("industry", "")
            exchange = profile.get("exchange", "")
            if industry:
                self.result.plates = [
                    {"code": "", "name": industry, "type": "industry"}
                ]
            if exchange:
                if not self.result.plates:
                    self.result.plates = []
                self.result.plates.append({"code": "", "name": exchange, "type": "exchange"})

    # ── 综合合成 ───────────────────────────────────

    def _synthesize(self):
        """合成阶段 — 优先用注入的LLM策略，失败降级到规则评分。
        模块隔离原则: llm_synth 故障不影响 analyzer 的其他维度分析。
        """
        synth = self._synth_module
        if synth is None:
            # 默认: 尝试加载 llm_synth
            try:
                import llm_synth
                synth = llm_synth
            except ImportError:
                synth = None

        if synth is not None and synth != 'rule':
            try:
                # 查询近期交易经验，注入LLM prompt作为方向先验
                trade_exp = self._get_trade_experience()
                result = synth.synthesize(self.data, trade_experience=trade_exp)
            except Exception as e:
                result = {"_error": str(e)}
            if result and "_error" not in result:
                self._apply_llm_result(result)
                return
            # LLM失败 → 降级
            self._rule_fallback(result or {"_error": "LLM returned None"})
        else:
            # 强制规则模式
            self._rule_synthesize()

    def _get_obsidian_history(self) -> str:
        """读Obsidian symbol page提取上次deep_analysis结果, 注入LLM prompt.

        闭环: 上次分析→Obsidian写→本次分析读回→LLM看到上次判断→自我纠正.
        提取: 上次日期/方向/评分/核心论据(前2条bull+前1条bear)/verdict.
        只读最近1次(最新的## section), 不堆历史.
        """
        try:
            import re
            vault_dir = "/opt/ftseek/FTSeek-US/obsidian_vault/symbols"
            # symbol: US.AAPL → US_AAPL.md
            bare = self.symbol.split(".")[-1] if "." in self.symbol else self.symbol
            page_path = f"{vault_dir}/US_{bare}.md"
            if not os.path.exists(page_path):
                return ""

            content = open(page_path, encoding="utf-8").read()

            # 找所有 ## 日期 section (格式: ## 2026-07-08 | ...), 取最后一个(最新)
            # 不匹配 "## 同行业" 等非日期section
            date_sections = re.split(r"^## (\d{4}-\d{2}-\d{2})", content, flags=re.MULTILINE)
            # date_sections: [before_first, date1, section1_content, date2, section2_content, ...]
            if len(date_sections) < 3:
                return ""  # 没有日期section

            # 取最后一个日期section
            last_date = date_sections[-2]
            latest = last_date + date_sections[-1]

            # 提取方向/评分 (section标题行: 日期 | 评级 | 信心 | 方向)
            header = latest.split("\n")[0] if "\n" in latest else latest[:100]
            # 提取verdict (在 > 引用块里, 第一行非空引用)
            verdict_lines = re.findall(r"^>\s*(.+?)(?:\n|$)", latest, re.MULTILINE)
            verdict_text = verdict_lines[0][:100] if verdict_lines else ""
            # 提取bull_case前2条 (格式: "  1. [HIGH][IC=...] text")
            bull_lines = re.findall(r"^\s*\d+\.\s+\[[^\]]+\].*?\]\s*(.+?)(?:\n|$)", latest, re.MULTILINE)
            bull_text = " ; ".join(bull_lines[:2]) if bull_lines else ""

            parts = [f"上次分析({last_date}): {header.strip()[:80]}"]
            if verdict_text:
                parts.append(f"verdict={verdict_text}")
            if bull_text:
                parts.append(f"核心论据={bull_text[:150]}")
            return " | ".join(parts)
        except Exception:
            return ""

    def _get_trade_experience(self) -> str:
        """获取交易经验文本，注入LLM prompt。

        优先使用strategy_memory（持久化pattern积累），
        回退到直接查trade_records（首次运行时memory为空）。
        """
        parts = []

        # ── 0. 上次分析回顾 (Obsidian symbol page读回) ──
        obsidian_hist = self._get_obsidian_history()
        if obsidian_hist:
            parts.append(obsidian_hist)

        # ── 0b. 最近结局三元组 (R1, DEB-20260816-no-trigger §9.2) ──
        # 聚合WR的两个失败模式(自增强循环/regime切换误判)已实证 → 补"最近N笔
        # 具体失败模式+场景"事实。回滚: DA_RECENT_OUTCOME_INJECT=0。
        if os.environ.get("DA_RECENT_OUTCOME_INJECT", "1") != "0":
            try:
                _ro_rows = fetch_recent_outcomes(self.symbol)
                _ro_text = format_recent_outcomes(_ro_rows, symbol=self.symbol)
                if _ro_text:
                    parts.append(_ro_text)
            except Exception:
                pass  # record-only注入失败不阻断分析 (fail-open)

        try:
            # ── 优先：从strategy_memory获取 ──
            import strategy_memory
            hint = strategy_memory.get_strategy_hint(symbol=self.symbol)
            text = strategy_memory.format_hint_for_prompt(hint, symbol=self.symbol)
            # 按行判断而非整段子串: 个股历史与全市场pattern/退出效果/教训被join在
            # 同一字符串, 原先的整段丢弃让无历史标的连全市场经验一起丢失
            # (DEB-20260830-llm-chain-utilization E1)。
            if text and [ln for ln in text.split("\n") if "无历史交易记录" not in ln]:
                parts.append(text)
        except Exception:
            pass

        if parts:
            return " | ".join(parts)

        # ── 回退：直接查trade_records（首次运行或memory损坏时）──
        try:
            import sqlite3
            import config as cfg

            db_path = cfg.FTSEEK_DB
            if not os.path.exists(db_path):
                return ""

            conn = sqlite3.connect(db_path, timeout=3)
            conn.row_factory = sqlite3.Row

            # 用ET时区计算cutoff，与trade_records.trade_date对齐
            _now = datetime.now()
            _offset = timedelta(hours=-4) if 3 <= _now.month <= 11 else timedelta(hours=-5)
            et_now = datetime.now(timezone(_offset))
            cutoff_7d = (et_now - timedelta(days=7)).strftime("%Y-%m-%d")
            cutoff_30d = (et_now - timedelta(days=30)).strftime("%Y-%m-%d")

            parts = []

            # 个股历史
            sym_rows = conn.execute("""
                SELECT direction, exit_reason, realized_pnl, holding_hours,
                       signal_strength, entry_price, exit_price, trade_date
                FROM trade_records
                WHERE symbol = ? AND realized_pnl IS NOT NULL
                  AND strategy_id NOT IN ('manual','manual_sync','reconciler','futu_sync','broker_reconcile')
                  AND source_type NOT IN ('SCALPING','ORB_ENGINE','PLAYBOOK_SHADOW','MAIN_PIPELINE')
                ORDER BY trade_date DESC LIMIT 5
            """, (self.symbol,)).fetchall()

            if sym_rows:
                sym_wins = sum(1 for r in sym_rows if r['realized_pnl'] > 0)
                sym_pnl = sum(r['realized_pnl'] for r in sym_rows)
                parts.append(f"本股{self.symbol}近期{len(sym_rows)}笔: "
                           f"{sym_wins}胜 PnL=${sym_pnl:.0f}")
            else:
                parts.append(f"本股{self.symbol}无历史交易记录")

            # 方向参考
            for r in conn.execute("""
                SELECT direction, COUNT(*) as cnt,
                       SUM(CASE WHEN realized_pnl > 0 THEN 1 ELSE 0 END) as wins,
                       ROUND(SUM(realized_pnl), 0) as pnl
                FROM trade_records
                WHERE trade_date >= ? AND realized_pnl IS NOT NULL
                  AND strategy_id NOT IN ('manual','manual_sync','reconciler','futu_sync','broker_reconcile')
                  AND source_type NOT IN ('SCALPING','ORB_ENGINE','PLAYBOOK_SHADOW','MAIN_PIPELINE')
                GROUP BY direction
            """, (cutoff_30d,)).fetchall():
                wr = r['wins'] / r['cnt'] * 100 if r['cnt'] else 0
                parts.append(f"30天{r['direction']}:{r['cnt']}笔 WR={wr:.0f}% PnL=${r['pnl']}")

            conn.close()
            return " | ".join(parts) if parts else ""

        except Exception:
            return ""

    def _apply_llm_result(self, result: dict):
        """映射LLM输出到 AnalysisResult"""
        self.result.rating = result.get("rating", "观望")
        self.result.confidence = result.get("confidence", "中")
        self.result.score = float(result.get("score", 5.0))
        self.result.conclusion = result.get("executive_summary", "")
        self.result.action = result.get("direction", "SKIP")

        strength_map = {"HIGH": "强", "MEDIUM": "中", "LOW": "弱"}
        self.result.bull_reasons = [
            {"text": r.get("thesis", ""), "strength": strength_map.get(r.get("strength", ""), "中")}
            for r in result.get("bull_case", [])
        ]
        self.result.bear_reasons = [
            {"text": r.get("thesis", ""), "strength": strength_map.get(r.get("strength", ""), "中")}
            for r in result.get("bear_case", [])
        ]
        self.result.constraints = [
            {"text": r.get("thesis", ""), "strength": strength_map.get(r.get("strength", ""), "中")}
            for r in result.get("constraints", [])
        ]

        plan = result.get("execution_plan", {})
        self.result.entry_plan = plan.get("entry_strategy", "")
        self.result.stop_loss = plan.get("stop_loss", "")
        self.result.target = plan.get("take_profit", "")

        kl = result.get("key_levels", {})
        if kl:
            self.result.key_levels = {
                "current": kl.get("current", 0),
                "support": kl.get("support", []),
                "resistance": kl.get("resistance", []),
            }

        self.result.risks = result.get("risks", [])
        self.result._llm_output = result

    def _rule_fallback(self, llm_result: dict):
        """LLM失败时的规则降级"""
        self.result.rating = "观望"
        self.result.confidence = "低"
        self.result.score = 5.0
        self.result.conclusion = f"LLM分析失败: {llm_result.get('_error','')}"
        self.result.action = "SKIP"
        self.result.risks = ["LLM不可用"]

    def _rule_synthesize(self):
        """纯规则评分（不调LLM）— 技术面+资金面+异动+估值维度"""
        score = 5.0
        bull, bear, cons, risks = [], [], [], []

        tech = self.result.technical
        if tech and "_error" not in tech:
            trend = tech.get("trend", "")
            if "多头" in trend:
                score += 1.0
                bull.append({"text": f"技术面{trend}", "strength": "中"})
            elif "空头" in trend:
                score -= 1.0
                bear.append({"text": f"技术面{trend}", "strength": "中"})
            elif "偏多" in trend:
                score += 0.5
                bull.append({"text": f"短期{trend}", "strength": "弱"})

            rsi = tech.get("rsi14")
            if rsi and rsi > 80:
                cons.append({"text": f"RSI {rsi}超买", "strength": "中"})
            elif rsi and rsi < 20:
                bull.append({"text": f"RSI {rsi}超卖", "strength": "弱"})

            vr = tech.get("vol_vs_20d", 0)
            if vr > 1.5:
                bull.append({"text": f"放量{vr}x", "strength": "中"})

            dh = tech.get("dist_52w_high", 0)
            if dh > -2:
                cons.append({"text": f"贴近52周高({dh}%)", "strength": "强制约"})
            elif dh < -20:
                bull.append({"text": f"距52周高{dh}%", "strength": "中"})

        cap = self.result.capital
        if cap and "_error" not in cap:
            nm = cap.get("net_main_flow", 0)
            if nm > 0:
                score += 0.5
                bull.append({"text": f"主力净流入{nm/1e8:.1f}亿", "strength": "中"})
            elif nm < 0:
                score -= 0.5
                bear.append({"text": f"主力净流出{abs(nm)/1e8:.1f}亿", "strength": "中"})

        snap = self.result.snapshot
        pe = snap.get("pe_ttm") or snap.get("pe_ratio", 0)
        if pe > 50:
            cons.append({"text": f"PE({pe})偏高", "strength": "中"})
        elif 0 < pe < 15:
            bull.append({"text": f"PE({pe})低估值", "strength": "弱"})

        self.result.score = round(max(0, min(10, score)), 1)
        self.result.rating = "看多" if score >= 6 else ("看空" if score <= 4 else "持有/观望")
        self.result.confidence = "中" if score >= 7 or score <= 3 else "中低"
        self.result.action = "BUY" if score >= 6 else ("SELL_SHORT" if score <= 4 else "SKIP")
        self.result.bull_reasons = bull
        self.result.bear_reasons = bear
        self.result.constraints = cons
        self.result.risks = risks or ["止损纪律"]
        self.result.conclusion = f"{self.result.name} {self.symbol} 规则评分{self.result.score}/10"


    def _compute_data_quality(self):
        q = self.data.get("_quality", {})
        qe = self.data.get("_quality_effective") or {}
        self.result.data_quality = {
            "total": q.get("total", 0),
            "ok": q.get("ok", 0),
            "failed": q.get("failed", 0),
            "coverage_pct": round(q.get("ok", 0) / max(q.get("total", 1), 1) * 100, 0),
            # Additive source-truth view: a collector can return a failed source
            # list and still be counted "ok" by _quality. Keep gate semantics
            # unchanged; this field makes the effective failure visible.
            "source_failed": list(qe.get("source_failed") or []),
            "effective_ok": qe.get("ok"),
            "effective_coverage_pct": (
                round(qe.get("ok", 0) / max(qe.get("total", 1), 1) * 100, 0)
                if qe else None),
        }


# ── R1: 最近结局三元组 (DEB-20260816-no-trigger §9.2, 2026-08-16) ─────
# 教训载体从聚合WR升级为"方向+exit_reason+当时regime"三元组。
# 只给事实不给结论, record-only (仅注入prompt, 不参与gate/仓位)。
# 回滚: DA_RECENT_OUTCOME_INJECT=0。

def fetch_recent_outcomes(symbol: str, db_path: str = "", limit: int = 4) -> List[Dict[str, Any]]:
    """查该股最近 N 笔已平仓成交的结局三元组 (新→旧)。

    Args:
        symbol: 标的代码 (US.XXX)
        db_path: ftseek_us.db 路径 (默认 config.FTSEEK_DB)
        limit: 最近笔数上限

    Returns:
        [{trade_date, direction, exit_reason, realized_pnl, market_regime}, ...]
    """
    import sqlite3 as _sq3
    import config as _cfg
    path = db_path or _cfg.FTSEEK_DB
    if not path or not os.path.exists(path):
        return []
    conn = _sq3.connect(path, timeout=3)
    conn.row_factory = _sq3.Row
    rows = conn.execute("""
        SELECT trade_date, direction, exit_reason, realized_pnl, market_regime
        FROM trade_records
        WHERE symbol = ? AND realized_pnl IS NOT NULL
          AND strategy_id NOT IN ('manual','manual_sync','reconciler','futu_sync','broker_reconcile')
          AND source_type NOT IN ('SCALPING','ORB_ENGINE','PLAYBOOK_SHADOW','MAIN_PIPELINE')
        ORDER BY trade_date DESC, exit_time DESC LIMIT ?
    """, (symbol, limit)).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def format_recent_outcomes(rows: List[Dict[str, Any]], symbol: str = "") -> str:
    """把最近结局三元组格式化为prompt文本。纯函数, 可单测。

    格式: 本股最近N笔结局(新→旧): 08-11 LONG DEAD_SIGNAL_EXIT -$29@risk_on; ...
    空列表返回 ""。字段缺失用 "?" 占位, 不静默丢笔。
    """
    if not rows:
        return ""
    items = []
    for r in rows:
        d = (r.get("trade_date") or "?")[-5:]  # MM-DD
        dirn = r.get("direction") or "?"
        er = r.get("exit_reason") or "?"
        pnl = r.get("realized_pnl")
        pnl_s = (f"${pnl:.0f}" if pnl >= 0 else f"-${abs(pnl):.0f}") \
            if isinstance(pnl, (int, float)) else "$?"
        reg = r.get("market_regime") or "?"
        items.append(f"{d} {dirn} {er} {pnl_s}@{reg}")
    tag = f"本股{symbol}" if symbol else "本股"
    return f"{tag}最近{len(rows)}笔结局(新→旧): " + "; ".join(items)


# ── CLI 入口 ──────────────────────────────────────

def main():
    import sys
    import data_collector

    symbol = sys.argv[1] if len(sys.argv) > 1 else "US.AAPL"
    print(f"采集 {symbol} 全量数据...", file=sys.stderr)
    data = data_collector.collect_all(symbol)
    print(f"数据采集完成: {data.get('_quality', {})}", file=sys.stderr)

    analyzer = DeepAnalyzer(data)
    result = analyzer.analyze()
    print(json.dumps(result, ensure_ascii=False, default=str, indent=2))


if __name__ == "__main__":
    main()
