import copy
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "scripts"))

import llm_synth
import pipeline
import recommendation_evidence
import pytest
from recommendation_evidence import (
    build_counter_evidence,
    build_event_references,
    build_price_alignment,
    build_recommendation_evidence,
    canonical_json,
)


def _collected():
    return {
        "symbol": "US.TEST",
        "_timestamp": 1793971491,
        "snapshot": {
            "session": "premarket",
            "last_price": 80.0,
            "prev_close": 80.0,
            "pre_price": 84.0,
            "effective_chg_pct": 5.0,
            "update_time": "2026-11-06 08:30:00",
        },
        "news": [{"news_id": "shared", "title": "real news", "publish_time": "1793971491"}],
        "news_v2": [{"news_id": "shared", "title": "real news", "publish_time": "1793971491"}],
        "market_context": {
            "vix": {"current": 18.04, "proxy": "US.VIXY", "as_of_basis": "prev_close"},
            "spy": {"current_asof": "2026-11-05", "snapshot": {"snapshot_time": "2026-11-06 08:30:00"}},
        },
        "industry_peers": {
            "peer_count": 1,
            "industry_avg_chg_today_pct": 99.0,
            "peers": [{"symbol": "US.PEER", "chg_pct": 99.0}],
        },
    }


def _analysis():
    return {
        "symbol": "US.TEST",
        "action": "BUY",
        "technical": {"trend": "空头排列"},
        "_llm_output": {
            "direction": "BUY",
            "execution_plan": {"confirmation": {"price_level": 84.5}, "invalidation": "close below 80"},
            "evidence_gaps": ["sector event timestamp missing"],
            "_debate": {
                "challenger_verdict": "PARTIAL_AGREE",
                "challenger_direction": "BUY",
                "challenged_claims": [{
                    "original_thesis": "breakout",
                    "weakness": "trend conflict",
                    "counter_evidence": "MA trend is bearish",
                }],
                "missed_risks": ["premarket move may reverse"],
            },
        },
    }


def test_event_references_are_stable_scoped_and_timestamped():
    first = build_event_references(_collected())
    second = build_event_references(_collected())
    assert first["status"] == "AVAILABLE"
    assert first["reference_count"] == 2
    assert len({item["story_id"] for item in first["references"]}) == 1
    assert len({item["evidence_id"] for item in first["references"]}) == 2
    assert all(item["published"]["status"] == "PARSED" for item in first["references"])
    assert all(item["semantic_role"] == "UNADJUDICATED" for item in first["references"])
    assert canonical_json(first) == canonical_json(second)


def test_failed_news_is_not_rendered_as_empty():
    collected = _collected()
    collected["news"] = {"_error": "HTTP 502"}
    collected["news_v2"] = {"_error": "timeout"}
    events = build_event_references(collected)
    assert events["status"] == "UNAVAILABLE"
    assert events["references"] == []


def test_single_failed_news_source_is_partial_not_empty():
    collected = _collected()
    collected["news"] = {"_error": "HTTP 502"}
    collected["news_v2"] = []
    empty_peer = build_event_references(collected)
    assert empty_peer["status"] == "PARTIAL"
    assert empty_peer["failed_sources"] == ["news"]
    collected["news_v2"] = [{"news_id": "other", "title": "available"}]
    available_peer = build_event_references(collected)
    assert available_peer["status"] == "PARTIAL"
    assert available_peer["reference_count"] == 1


def test_legacy_industry_change_does_not_create_relative_confirmation():
    price = build_price_alignment(_collected(), _analysis())
    assert price["effective_price"] == 84.0
    assert price["price_alignment"] == "ALIGNED"
    assert price["technical_trend_alignment"] == "OPPOSED"
    assert price["industry_average_change_pct"] is None
    assert price["relative_to_industry_pct"] is None
    assert price["relative_alignment"] == "UNKNOWN"
    assert price["planned_confirmation"] == {"price_level": 84.5}


def test_verified_industry_change_produces_relative_alignment():
    collected = _collected()
    collected["industry_peers"].update({
        "caliber_version": "session_effective_v1",
        "industry_avg_chg_today_pct": 2.0,
        "industry_chg_today_sample_count": 3,
    })
    price = build_price_alignment(collected, _analysis())
    assert price["relative_to_industry_pct"] == 3.0
    assert price["relative_alignment"] == "ALIGNED"
    assert price["industry_today_sample_count"] == 3


def test_counter_evidence_distinguishes_missing_from_none_reported():
    analysis = _analysis()
    counter = build_counter_evidence(analysis)
    assert counter["status"] == "AVAILABLE"
    assert len(counter["items"]) == 2
    analysis["_llm_output"]["_debate"] = {"missed_risks": ["无实质反证: 当前方向的数据支撑成立"]}
    none_reported = build_counter_evidence(analysis)
    assert none_reported["status"] == "NONE_REPORTED"
    assert none_reported["items"] == []
    analysis["_llm_output"].pop("_debate")
    assert build_counter_evidence(analysis)["status"] == "UNAVAILABLE"


def test_builder_does_not_mutate_input_or_change_production_prompt():
    collected = _collected()
    original = copy.deepcopy(collected)
    prompt_before = llm_synth._format_data_for_prompt(collected)
    evidence = build_recommendation_evidence(collected, _analysis())
    assert collected == original
    assert llm_synth._format_data_for_prompt(collected) == prompt_before
    assert evidence["market_timing"]["vix"]["as_of"] is None
    assert evidence["market_timing"]["vix"]["as_of_basis"] == "prev_close"
    json.dumps(evidence, ensure_ascii=False)


def test_claim_lineage_only_links_exact_source_text():
    analysis = _analysis()
    analysis["_llm_output"]["bull_case"] = [
        {"thesis": "real news", "evidence": "real news"},
        {"thesis": "unrelated claim", "evidence": "no matching source"},
    ]
    evidence = build_recommendation_evidence(_collected(), analysis)
    lineage = evidence["claim_lineage"]
    assert lineage["claim_count"] == 2
    assert lineage["linked_claim_count"] == 1
    assert lineage["unlinked_claim_count"] == 1
    assert lineage["claims"][0]["evidence_ids"]
    assert lineage["claims"][1]["link_status"] == "UNLINKED"


def test_pipeline_attachment_preserves_analysis_and_candidate_context():
    analysis = _analysis()
    candidate = {
        "ue_causal_chain": "event to supplier",
        "ue_event_meta": {"event_family": "news"},
        "ue_counter_evidence": "already priced in",
    }
    result = pipeline._attach_recommendation_evidence(analysis, _collected(), candidate)
    assert result is analysis
    assert result["action"] == "BUY"
    evidence = result["recommendation_evidence"]
    assert evidence["event_references"]["candidate_context"]["origin"] == "UE_CANDIDATE_HYPOTHESIS"
    assert evidence["counter_evidence"]["items"][-1]["source"] == "UE_CANDIDATE"


def test_pipeline_emits_evidence_to_bridge_and_raw_instruction():
    source = Path(pipeline.__file__).read_text(encoding="utf-8")
    emission = '"recommendation_evidence": a.get("recommendation_evidence") or {},'
    assert source.count(emission) == 2


def test_pipeline_evidence_failure_does_not_drop_candidate(monkeypatch):
    analysis = _analysis()

    def fail(*args, **kwargs):
        raise RuntimeError("broken evidence input")

    monkeypatch.setattr(recommendation_evidence, "build_recommendation_evidence", fail)
    result = pipeline._attach_recommendation_evidence(analysis, _collected())
    assert result is analysis
    assert result["action"] == "BUY"
    assert result["recommendation_evidence"]["status"] == "ERROR"


def test_current_render_view_matches_full_and_rollback_news(monkeypatch):
    collected = _collected()
    collected["news"] = [{"news_id": str(i), "title": f"unique story number {i}"} for i in range(12)]
    for full, count in ((True, 12), (False, 8)):
        monkeypatch.setattr(llm_synth.config, "DA_INPUT_FULL", full)
        events = build_event_references(collected)
        futu = [r for r in events["references"] if r["source"] == "FUTU"]
        assert sum(r["prompt_visible"] for r in futu) == count
        assert events["visibility_basis"] == "CURRENT_RENDER_VIEW_NOT_HISTORICAL_PROOF"
        prompt = llm_synth._format_data_for_prompt(collected)
        observed = build_event_references(collected, user_prompt=prompt)
        assert [r["prompt_visible"] for r in events["references"]] == [r["prompt_visible"] for r in observed["references"]]


def test_observed_prompt_overrides_current_flag_and_other_sections(monkeypatch):
    collected = _collected()
    collected["news"] = [{"news_id": str(i), "title": f"unique story number {i}"} for i in range(12)]
    monkeypatch.setattr(llm_synth.config, "DA_INPUT_FULL", False)
    prompt = llm_synth._format_data_for_prompt(collected)
    prompt += "\n## unrelated section\n  [now] unique story number 10\n"
    monkeypatch.setattr(llm_synth.config, "DA_INPUT_FULL", True)
    events = build_event_references(collected, user_prompt=prompt)
    assert events["visibility_basis"] == "OBSERVED_USER_PROMPT"
    assert sum(r["prompt_visible"] for r in events["references"] if r["source"] == "FUTU") == 8


def test_finnhub_duplicate_remains_visible_and_missing_section_is_not_visible():
    collected = _collected()
    prompt = llm_synth._format_data_for_prompt(collected)
    observed = build_event_references(collected, user_prompt=prompt)
    assert observed["prompt_visible_count"] == 2
    assert len({r["story_id"] for r in observed["references"]}) == 1
    absent = build_event_references(collected, user_prompt="")
    assert absent["prompt_visible_count"] == 0
    assert absent["visibility_basis"] == "OBSERVED_USER_PROMPT"


def test_builder_uses_actual_model_prompt_and_preserves_all_input(monkeypatch):
    collected = _collected()
    collected["news"] += [{"news_id": str(i), "title": f"unique story number {i}"} for i in range(12)]
    monkeypatch.setattr(llm_synth.config, "DA_INPUT_FULL", False)
    analysis = _analysis()
    analysis["_llm_output"]["_user_prompt"] = llm_synth._format_data_for_prompt(collected)
    original = copy.deepcopy((collected, analysis))
    monkeypatch.setattr(llm_synth.config, "DA_INPUT_FULL", True)
    card = build_recommendation_evidence(collected, analysis)
    assert (collected, analysis) == original
    assert card["event_references"]["visibility_basis"] == "OBSERVED_USER_PROMPT"
    assert card["event_references"]["prompt_visible_count"] == 9
    assert analysis["action"] == card["price_alignment"]["direction"] == "BUY"


def test_exact_finnhub_publisher_parentheses_and_non_substring_titles():
    collected = _collected()
    collected["news"] = [{"news_id": "long", "title": "the short headline"}, {"news_id": "short", "title": "short headline"}]
    collected["news_v2"] = [{"news_id": "other", "title": "real news", "source": "Publisher (Asia)"}]
    prompt = "## 最新新闻\n  [time] the short headline\n## Finnhub 新闻事实流\n  [date] (Publisher (Asia)) real news\n"
    events = build_event_references(collected, user_prompt=prompt)
    assert [r["prompt_visible"] for r in events["references"]] == [True, False, True]


def test_repeated_title_cannot_make_unrendered_story_visible(monkeypatch):
    collected = _collected()
    collected["news"] = [{"news_id": str(i), "title": "identical title", "publish_time": "1793971491"} for i in range(12)]
    for full, expected in ((False, 8), (True, 12)):
        monkeypatch.setattr(llm_synth.config, "DA_INPUT_FULL", full)
        prompt = llm_synth._format_data_for_prompt(collected)
        events = build_event_references(collected, user_prompt=prompt)
        futu = [r for r in events["references"] if r["source"] == "FUTU"]
        assert [r["prompt_visible"] for r in futu] == [True] * expected + [False] * (12 - expected)
        assert len({r["story_id"] for r in futu}) == 12


@pytest.mark.parametrize("value", [float("inf"), "inf", 1e100, "NaN"])
def test_unrepresentable_publish_time_is_unparsed_not_fatal(value):
    collected = _collected()
    collected["news"][0]["publish_time"] = value
    events = build_event_references(collected)
    assert events["references"][0]["published"]["status"] == "UNPARSED"
    assert events["references"][0]["published"]["utc"] is None


def test_bracketed_title_is_not_confused_with_timestamp_or_shorter_title():
    collected = _collected()
    collected["news"] = [{"news_id": "short", "title": "foo"}, {"news_id": "long", "title": "[Breaking] foo"}]
    prompt = "## 最新新闻\n  [time] [Breaking] foo\n"
    events = build_event_references(collected, user_prompt=prompt)
    assert [r["prompt_visible"] for r in events["references"] if r["source"] == "FUTU"] == [False, True]


def test_duplicate_story_rows_consume_rendered_occurrences_before_reference_dedup(monkeypatch):
    collected = _collected()
    collected["news"] = [{"news_id": "same" if i < 2 else str(i), "title": "identical title"} for i in range(9)]
    monkeypatch.setattr(llm_synth.config, "DA_INPUT_FULL", False)
    prompt = llm_synth._format_data_for_prompt(collected)
    events = build_event_references(collected, user_prompt=prompt)
    futu = [r for r in events["references"] if r["source"] == "FUTU"]
    assert len(futu) == 8
    assert [r["prompt_visible"] for r in futu] == [True] * 7 + [False]
