#!/usr/bin/env python3
"""DA Prompt 输入真实性: 研报日期/同稿去重/prev_close apply (2026-10-23)."""
import sys
from datetime import date, datetime, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "scripts"))

import llm_synth  # noqa: E402


def _epoch(y, m, d):
    return datetime(y, m, d, 12, tzinfo=timezone.utc).timestamp()


def _collected():
    return {
        "symbol": "US.TEST",
        "_timestamp": _epoch(2026, 10, 22),
        "snapshot": {
            "session": "premarket", "prev_close": 32.91, "prev_close_price": 32.91,
            "pre_price": 30.82, "pre_change_rate": -5.72,
            "last_price": 32.69, "effective_price": 30.82,
        },
        "kline": [
            {"time": "2026-10-20 00:00:00", "close": 32.91},
            {"time": "2026-10-21 00:00:00", "close": 32.69},
        ],
        "news": [
            {"news_id": "1", "title": "same story", "publish_time": str(_epoch(2026, 10, 22))},
        ],
        "news_v2": [],
        "research": [
            {"news_id": "1", "title": "same story", "publish_time": str(_epoch(2026, 10, 22))},
            {"news_id": "2", "title": "old report", "publish_time": str(_epoch(2026, 10, 10))},
        ],
        "sentiment": [],
        "capital_distribution": {}, "capital_flow": {},
        "tech_anomaly": {}, "cap_anomaly": {}, "deriv_anomaly": {},
        "fundamentals": {}, "analyst_consensus": {}, "insider_transactions": {},
        "insider_sentiment": {}, "company_profile": {}, "earnings_calendar": {},
        "market_context": {}, "industry_peers": {},
    }


def test_research_duplicate_is_not_rendered_as_independent():
    text = llm_synth._format_data_for_prompt(_collected())
    assert "去重1条与新闻同稿" in text
    # 研报段只剩 old report, 同稿标题只应出现在新闻段
    res = text.split("## 研报", 1)[1]
    assert "same story" not in res
    assert "old report" in res


def test_research_renders_publish_time_not_empty():
    text = llm_synth._format_data_for_prompt(_collected())
    res = text.split("## 研报", 1)[1]
    assert "10-10" in res
    assert "⚠️" in res and "天前" in res


def test_prev_close_apply_changes_snapshot_and_prompt(monkeypatch):
    monkeypatch.setenv("DA_PREV_CLOSE_BAR_RECONCILE", "apply")
    # 冻结 today: fixture 的 bar 日期是硬编码 2026-10-21, 而 reconcile 的 today 默认取
    # 真实 ET 当日 ⇒ 不冻结则 2026-10-26 起 gap_days>4 命中 stale_bar 闸, 本测试自腐变红
    # (实测红 25 天无人发现: 本载体无 CI, cron 不跑 skill 测试)。范式同
    # test_prev_close_reconcile.py 的显式 today=date(2026,10,22)。
    from functools import partial

    import prev_close_reconcile as _pc

    monkeypatch.setattr(
        llm_synth, "reconcile_prev_close",
        partial(_pc.reconcile_prev_close, today=date(2026, 10, 22)),
    )
    c = _collected()
    out = llm_synth._apply_prev_close_fix(c)
    assert out["snapshot"]["prev_close_price"] == 32.69
    assert out["snapshot"]["prev_close_raw"] == 32.91
    assert out["snapshot"]["effective_chg_pct"] == -5.72
    text = llm_synth._format_data_for_prompt(out)
    assert "昨日收盘价: $32.69" in text


def test_prev_close_off_leaves_snapshot_unchanged(monkeypatch):
    monkeypatch.setenv("DA_PREV_CLOSE_BAR_RECONCILE", "off")
    c = _collected()
    out = llm_synth._apply_prev_close_fix(c)
    assert out["snapshot"]["prev_close_price"] == 32.91
    assert "prev_close_raw" not in out["snapshot"]


def test_source_truth_rollback_restores_old_render(monkeypatch):
    monkeypatch.setenv("DA_SOURCE_TRUTH_FIX", "0")
    text = llm_synth._format_data_for_prompt(_collected())
    res = text.split("## 研报", 1)[1]
    assert "去重" not in res
    assert "发布时间未知" not in res
