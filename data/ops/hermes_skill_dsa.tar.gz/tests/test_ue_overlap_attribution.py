# -*- coding: utf-8 -*-
"""UE∩DA 重叠票归因回填契约测试 (2026-10-10).

病灶: 撞车的 UE 行被 `_select_eligible` 标 duplicate ⇒ 不进 `_ue_taken` ⇒
`_merge_ue_candidates` 的 `_seen` 跳过 ⇒ UE 的 21 个 `ue_*` 字段静默丢弃,
bridge candidates / raw_instruction 里 `ue_direction` 为空 ⇒ 下游与审计者
误判「UE→DA 注入断了」(已连续误导两个独立审计)。

修复 `_merge_ue_attribution_into_overlap` 的**红线是「纯归因, 零行为变更」**:
只回填 `ue_*` 字段, 不动 `_source` / `direction_hint` / `candidate_screening`
⇒ Stage3 的 prompt 注入 (门控 `_source=='ue_candidate'`) 不触发 ⇒ LLM 看到的
内容逐字不变。本文件把这个红线钉成断言, 而不只测"字段有值"。
"""
import ast
import re
import sys
from pathlib import Path

SCRIPTS = Path(__file__).resolve().parents[1] / "scripts"
SCRIPT = SCRIPTS / "pipeline.py"

sys.path.insert(0, str(SCRIPTS))
import pipeline as PL  # noqa: E402


def _ue_row(symbol, direction="SHORT", **extra):
    row = {
        "symbol": symbol,
        "ue_direction": direction,
        "ue_confidence": 0.55,
        "ue_causal_chain": "事实: X 收购频谱; 传导假设: 直接竞争 D2D 业务",
        "ue_evidence": "AST SpaceMobile Sinks 7% - 24/7 Wall St.",
        "ue_scanned_at": "2026-10-09T08:02:17.779683-04:00",
        "ue_batch_id": "UE:baf300c04e1d32d8781d9b59",
        "ue_counter_evidence": "披露具体内容未知, 或已充分定价",
        "ue_invalidation": "次日高开回落破前低",
        "ue_horizon_hours": 24,
        "ue_short_check": {"provided": True, "borrow_feasible": True},
    }
    row.update(extra)
    return row


def _da_row(symbol):
    """DA 池既有行 — 注意 `_source` 不是 ue_candidate, direction_hint 已定档。"""
    return {
        "symbol": symbol,
        "_source": "main_pool",
        "direction_hint": "LONG",
        "candidate_screening": {"status": "PASS", "stage": "da_main_pool",
                                "candidate_id": f"DA:x:{symbol}:LONG"},
    }


# ══════════════════════════════════════════════════════════════
# 1. 核心行为: 重叠票真的拿到 UE 归因
# ══════════════════════════════════════════════════════════════

def test_overlap_row_receives_ue_attribution():
    deep = [_da_row("US.ASTS")]
    n = PL._merge_ue_attribution_into_overlap(deep, [_ue_row("US.ASTS")])
    assert n == 1, f"应回填 1 行, 实得 {n}"
    row = deep[0]
    assert row["ue_direction"] == "SHORT"
    assert row["ue_causal_chain"], "因果链是 UE 的核心产出, 不得丢"
    assert row["ue_evidence"], "证据引用不得丢"
    assert row["ue_counter_evidence"], "反证不得丢 (prompt 要求正面回应)"
    assert row["ue_batch_id"] and row["ue_scanned_at"], "批次/时点不得丢 (审计溯源锚)"
    assert row["_ue_overlap"] is True, "必须可审计地区分 UE 独有注入 vs UE∩DA 重叠"
    assert row["ue_short_check"]["borrow_feasible"] is True, (
        "2026-10-21: ue_short_check 改为可持久化审计 (quality_shadow/health 消费)")
    # 刻意**不**回填的 7 键: 其唯一消费点在 prompt 注入分支 (门控 _source=='ue_candidate'),
    # 本修复不改 _source ⇒ 对重叠票永远够不着, 回填 = 纯死字段。见 _UE_ATTR_KEYS 注释。
    for _dead in ("ue_invalidation", "ue_horizon_hours", "ue_thesis"):
        assert _dead not in row, f"{_dead} 是死字段, 不该回填"


def test_non_overlap_row_untouched():
    """UE 挖的票不在 DA 池 ⇒ 不该凭空造行 (只回填, 不注入)。"""
    deep = [_da_row("US.NVDA")]
    n = PL._merge_ue_attribution_into_overlap(deep, [_ue_row("US.ASTS")])
    assert n == 0
    assert "ue_direction" not in deep[0]
    assert "_ue_overlap" not in deep[0]
    assert len(deep) == 1, "回填函数不得新增候选 (新增=改变交易人群=行为变更)"


def test_symbol_normalization_both_ways():
    """symbol 归一必须双向容错 (UE 侧裸 ASTS / DA 侧 US.ASTS) — 否则重叠判定=0 显示为「无重叠」。"""
    for ue_sym, da_sym in (("ASTS", "US.ASTS"), ("US.ASTS", "ASTS"), ("asts", "US.ASTS")):
        deep = [_da_row(da_sym)]
        n = PL._merge_ue_attribution_into_overlap(deep, [_ue_row(ue_sym)])
        assert n == 1, f"归一失败: ue={ue_sym!r} da={da_sym!r}"
        assert deep[0]["ue_direction"] == "SHORT"


# ══════════════════════════════════════════════════════════════
# 2. 红线: 零行为变更 (prompt / 筛选 / 归因统计都不许动)
# ══════════════════════════════════════════════════════════════

def test_does_not_change_source_so_prompt_unchanged():
    """`_source` 必须保持 DA ⇒ Stage3 prompt 注入不触发 ⇒ LLM 输入逐字不变。

    这是「纯归因」与「行为变更」的分界: 若改 _source='ue_candidate', 因果链会进
    prompt (pipeline.py 的 `if _cand.get("_source")=="ue_candidate" and ue_causal_chain`),
    那就改了 LLM 决策输入 ⇒ 属行为变更, 须影子先行。
    """
    deep = [_da_row("US.ASTS")]
    PL._merge_ue_attribution_into_overlap(deep, [_ue_row("US.ASTS")])
    assert deep[0]["_source"] == "main_pool", "_source 被改 ⇒ prompt 注入会触发 = 行为变更"
    # _ue_origin 由 _source 派生 (pipeline Stage3), 故也必须是 False
    assert deep[0].get("_source") != "ue_candidate"


def test_does_not_change_direction_hint_or_screening():
    """direction_hint 已在 _screen_da_candidates 定档并写进 candidate_id 与候选漏斗。

    事后改写 = 归因与漏斗两张皮 (漏斗里的 rank/去重结论会与实际 hint 不符)。
    """
    deep = [_da_row("US.ASTS")]
    before = dict(deep[0]["candidate_screening"])
    PL._merge_ue_attribution_into_overlap(deep, [_ue_row("US.ASTS", direction="SHORT")])
    assert deep[0]["direction_hint"] == "LONG", (
        "direction_hint 被 UE 方向覆盖 ⇒ 改变筛选排序语义 = 行为变更")
    assert deep[0]["candidate_screening"] == before, "candidate_screening 不得被改写"
    assert deep[0]["candidate_screening"]["candidate_id"].endswith(":LONG"), (
        "candidate_id 已含定档 hint, 改 hint 会造成 id 与字段不一致")


def test_ue_candidate_rows_not_overwritten():
    """UE 独有注入的行 (_source=='ue_candidate') 是权威来源, 不得被重叠回填覆盖。"""
    deep = [{"symbol": "US.HUM", "_source": "ue_candidate", "ue_direction": "LONG",
             "ue_confidence": 0.52, "ue_causal_chain": "原始 UE 因果链"}]
    n = PL._merge_ue_attribution_into_overlap(
        deep, [_ue_row("US.HUM", direction="SHORT", ue_confidence=0.99,
                       ue_causal_chain="另一批次的因果链")])
    assert n == 0
    assert deep[0]["ue_direction"] == "LONG", "权威 UE 行的方向被覆盖"
    assert deep[0]["ue_confidence"] == 0.52
    assert deep[0]["ue_causal_chain"] == "原始 UE 因果链"
    assert "_ue_overlap" not in deep[0]


def test_no_direction_rows_are_skipped():
    """UE 侧 SKIP/空方向 ⇒ 无归因价值, 不得回填 (否则 bridge 出现 ue_direction='SKIP')。"""
    for bad in ("SKIP", "", None, "HOLD"):
        deep = [_da_row("US.ASTS")]
        n = PL._merge_ue_attribution_into_overlap(
            deep, [_ue_row("US.ASTS", direction=bad)])
        assert n == 0, f"方向={bad!r} 不该回填"
        assert "ue_direction" not in deep[0]


def test_empty_and_falsy_fields_not_copied():
    """空值不覆盖 (None/''/{}/[] 视为无信息), 但 0 / False 是真值必须保留。

    只用白名单内的键测 (被排除的 8 键本就不回填, 用它们测等于什么都没测)。
    """
    deep = [_da_row("US.ASTS")]
    PL._merge_ue_attribution_into_overlap(
        deep, [_ue_row("US.ASTS",
                       ue_evidence="",                       # 空串 → 不写
                       ue_batch_id=None,                     # None → 不写
                       ue_confidence_calibration={},         # 空 dict → 不写
                       ue_move_basis="",                     # 空串 → 不写
                       ue_confidence=0,                      # 0 是真值 → 必须写
                       ue_transmission_confirmation_required=False)])  # False 是真值
    row = deep[0]
    for _k in ("ue_evidence", "ue_batch_id", "ue_confidence_calibration", "ue_move_basis"):
        assert _k not in row, f"空值 {_k} 不该写进去 (下游 .strip() 判非空会变假绿)"
    assert row.get("ue_confidence") == 0, "0 是真值 (置信度 0), 不得当空值丢"
    assert row.get("ue_transmission_confirmation_required") is False, (
        "False 是真值 (无需传导确认), 不得当空值丢")
    # 有值的键仍须到位 (证明不是整行被跳过)
    assert row["ue_direction"] == "SHORT" and row["ue_causal_chain"]


def test_first_batch_wins_on_duplicate_symbol():
    """同票多批次 ⇒ 取首条, 不额外排序 (排序会改既有语义)。"""
    deep = [_da_row("US.BA")]
    n = PL._merge_ue_attribution_into_overlap(deep, [
        _ue_row("US.BA", direction="SHORT", ue_batch_id="UE:first"),
        _ue_row("US.BA", direction="LONG", ue_batch_id="UE:second"),
    ])
    assert n == 1
    assert deep[0]["ue_batch_id"] == "UE:first", "应取首条 (与既有 UE 消费顺序一致)"
    assert deep[0]["ue_direction"] == "SHORT"


def test_returns_count_not_rows():
    deep = [_da_row("US.BA"), _da_row("US.NVDA"), _da_row("US.PENG")]
    n = PL._merge_ue_attribution_into_overlap(deep, [
        _ue_row("US.BA"), _ue_row("US.PENG", direction="LONG")])
    assert n == 2
    assert deep[1].get("ue_direction") is None, "NVDA 未被 UE 命中, 不该有归因"


# ══════════════════════════════════════════════════════════════
# 3. 白名单与生产端对齐 (防漂移)
# ══════════════════════════════════════════════════════════════

def test_attr_keys_all_reach_bridge():
    """可落地性判据: 白名单每个键都必须被 `_mount_ue_attribution` 挂到 analysis。

    analysis → bridge (Stage6b `_write_bridge_file`) 是唯一让 `ue_*` 离开 pipeline
    进 FTSeek 的通道。回填了却挂不上 = **死字段** (只增噪声与漂移面, 审计时还会
    让人误以为归因已完整)。实测 2026-10-10: 挂载集 13 真键 == bridge 文件
    (data/opportunity_scan_2026-10-09.json) 实际落盘的 13 个 ue_* 键, 双向零差。
    """
    src = SCRIPT.read_text(encoding="utf-8")
    fn = [n for n in ast.walk(ast.parse(src)) if isinstance(n, ast.FunctionDef)
          and n.name == "_mount_ue_attribution"]
    assert len(fn) == 1, "_mount_ue_attribution 必须存在且唯一"
    body = ast.get_source_segment(src, fn[0]) or ""
    # analysis 侧带前导下划线 (_ue_direction), candidate 侧不带 (ue_direction)
    mounted = {m[1:] for m in re.findall(r'analysis\["(_ue_[a-z_]+)"\]', body)}
    mounted.discard("ue_origin")     # 派生字段 (由 _source 算), 不在回填白名单里
    whitelist = set(PL._UE_ATTR_KEYS)
    dead = whitelist - mounted
    assert not dead, f"回填了却挂不到 analysis ⇒ 死字段: {sorted(dead)}"


def test_excluded_keys_are_prompt_branch_only():
    """被排除的 7 键: 任何读点都不得落在 prompt 注入分支**之外** (否则排除=漏归因)。

    这 7 键生产端有、bridge 消费面没有。排除它们的正当理由是: 消费点要么在
    `_source=='ue_candidate'` 门控内 (本修复不改 `_source` ⇒ 对重叠票永远够不着),
    要么**根本没有任何消费者** (生产端就地死亡)。实测 2026-10-10:
      · 5 键在 prompt 分支内被读 (horizon_hours/expected_move_pct/invalidation/
        self_tier/critique)
      · 2 键零读点 (`ue_thesis` @931、`ue_streak_days` @951 只有生产行, 全仓无消费)
        ⇒ 回填它们纯属往 DA 行灌没人读的字段
    2026-10-21: ue_short_check 移出排除集 — FTSeek quality_shadow/ue_da_chain_health
    新增了门控外消费点, 按本测试的红线同步扩白名单 (ue_event_meta 同理)。
    若哪天有人在门控外新增了消费点, 本断言会红, 提示需同步扩白名单。
    """
    src = SCRIPT.read_text(encoding="utf-8")
    excluded = {"ue_thesis", "ue_invalidation", "ue_horizon_hours", "ue_expected_move_pct",
                "ue_self_tier", "ue_critique", "ue_streak_days"}
    assert not (excluded & set(PL._UE_ATTR_KEYS)), (
        f"排除键又回到白名单了: {sorted(excluded & set(PL._UE_ATTR_KEYS))}")
    assert {"ue_short_check", "ue_event_meta", "ue_event_reaction"} <= set(PL._UE_ATTR_KEYS), (
        "有门控外消费点的字段必须在白名单内")
    # 定位 prompt 注入分支: 门控起点 → 分支尾锚点 (ue_candidate_context 赋值)
    gate = src.index('_cand.get("_source") == "ue_candidate" and _cand.get("ue_causal_chain")')
    tail = src.index('_data["ue_candidate_context"]', gate)
    read_in_branch, dead = set(), set()
    for k in sorted(excluded):
        hits = list(re.finditer(re.escape(f'_cand.get("{k}"'), src))
        if not hits:
            dead.add(k)          # 生产端就地死亡: 无消费者 ⇒ 排除更正当
            continue
        for m in hits:
            assert gate <= m.start() <= tail, (
                f"{k} 在 prompt 注入分支外被读 (偏移 {m.start()}, 分支 {gate}..{tail}) "
                f"⇒ 排除该键会漏归因, 须同步扩 _UE_ATTR_KEYS")
        read_in_branch.add(k)
    assert read_in_branch | dead == excluded, (
        f"未被分类的排除键: {sorted(excluded - read_in_branch - dead)}")
    # 钉住实测事实: 这两键全仓无消费者 (若将来有人接上, 本断言红 ⇒ 需重新评估白名单)
    assert dead == {"ue_thesis", "ue_streak_days"}, (
        f"零读点的排除键集合变了: {sorted(dead)}")


def test_whitelist_is_explicit_not_prefix_glob():
    """禁 `startswith("ue_")` 通配: 会把生产端将来新增的任何 ue_* 中间量自动回填。"""
    src = SCRIPT.read_text(encoding="utf-8")
    fn = [n for n in ast.walk(ast.parse(src)) if isinstance(n, ast.FunctionDef)
          and n.name == "_merge_ue_attribution_into_overlap"]
    assert len(fn) == 1
    body = ast.get_source_segment(src, fn[0]) or ""
    assert 'startswith("ue_"' not in body and "startswith('ue_'" not in body, (
        "回填用了前缀通配 ⇒ 生产端新增任何 ue_* 中间量都会被自动带进 DA 行")


# ══════════════════════════════════════════════════════════════
# 4. 接线 (防死代码) + prompt 门控未被削弱
# ══════════════════════════════════════════════════════════════

def test_wired_into_select_deep_candidates():
    """必须真被调用, 且**来源是 _ue_screened (全集) 而非 _ue_taken**。

    撞车行被标 duplicate ⇒ 不在 _ue_taken 里 ⇒ 传 _ue_taken 等于没修 (死门形态③)。
    """
    tree = ast.parse(SCRIPT.read_text(encoding="utf-8"))
    fn = [n for n in ast.walk(tree) if isinstance(n, ast.FunctionDef)
          and n.name == "_select_deep_candidates"]
    assert len(fn) == 1, "_select_deep_candidates 必须存在且唯一"
    calls = [n for n in ast.walk(fn[0]) if isinstance(n, ast.Call)
             and isinstance(n.func, ast.Name)
             and n.func.id == "_merge_ue_attribution_into_overlap"]
    assert calls, "回填函数未被调用 = 死代码"
    args = [a.id for a in calls[0].args if isinstance(a, ast.Name)]
    assert "_ue_screened" in args, (
        f"来源必须是 _ue_screened (全集); 实得 {args} — 传 _ue_taken 会漏掉全部撞车行")


def test_overlap_count_is_observable():
    """回填数必须进 filter stats (埋点), 否则无法验证生效 = 无法审计。"""
    src = SCRIPT.read_text(encoding="utf-8")
    assert "ue_overlap_attributed" in src, (
        "filter stats 缺 ue_overlap_attributed 字段 ⇒ 生效与否不可观测")


def test_prompt_injection_still_gated_on_ue_candidate_source():
    """Stage3 的 prompt 注入门控必须仍是 `_source=='ue_candidate' and ue_causal_chain`。

    若有人为了让重叠票也吃到因果链而放宽这个门控, 就改了 LLM 决策输入 = 行为变更,
    必须影子先行。本断言把这条红线钉住。
    """
    src = SCRIPT.read_text(encoding="utf-8")
    needle = '_cand.get("_source") == "ue_candidate" and _cand.get("ue_causal_chain")'
    assert needle in src, (
        "prompt 注入门控被改动 ⇒ 可能已让重叠票吃到 UE 因果链 = 未走影子的行为变更")


def test_overlap_rows_do_not_trigger_prompt_injection():
    """端到端等价验证: 回填后的 DA 行, 用生产同一条件判 prompt 是否注入 ⇒ 必须 False。"""
    deep = [_da_row("US.ASTS")]
    PL._merge_ue_attribution_into_overlap(deep, [_ue_row("US.ASTS")])
    cand = deep[0]
    # 逐字复刻 pipeline.py 的注入条件 (不是重写语义)
    injects = bool(cand.get("_source") == "ue_candidate" and cand.get("ue_causal_chain"))
    assert injects is False, (
        "重叠票触发了 prompt 注入 ⇒ LLM 输入变了 = 行为变更, 须影子先行")


# ══════════════════════════════════════════════════════════════
# 5. 缓存分支也挂归因 (死门形态③: 产物被丢弃)
# ══════════════════════════════════════════════════════════════

def test_mount_ue_attribution_wired_in_both_stage3_branches():
    """Stage3 的 checkpoint 缓存分支必须也调 `_mount_ue_attribution`。

    缓存里的 analysis 是**旧 LLM 产物**, 不含本轮 UE∩DA 重叠回填的 `ue_*`;
    命中缓存时 `analyses.append(cached)` + `continue` 会跳过非缓存分支的挂载
    ⇒ 同日重跑归因静默丢失, 表现为"有时有有时没有" (最难查的一类)。
    """
    src = SCRIPT.read_text(encoding="utf-8")
    assert "_mount_ue_attribution(_cached, candidate)" in src, (
        "缓存命中分支未重挂 UE 归因 ⇒ 同日重跑 (DA_RESUME_CACHE 默认开) 归因丢失")
    assert "_mount_ue_attribution(analysis, candidate)" in src, (
        "非缓存分支的挂载被删 ⇒ 首轮就没有归因")


def test_mount_is_not_inside_the_non_cache_branch_only():
    """结构化确认: 缓存分支的挂载语句在 `if i in _ck_cached_map:` 块**内部**。

    光有字符串存在不够 — 若写在块外, `continue` 之后永不执行 = 仍是死门。
    """
    src = SCRIPT.read_text(encoding="utf-8")
    i_cached = src.index("if i in _ck_cached_map:")
    i_continue = src.index("continue", i_cached)
    i_mount = src.index("_mount_ue_attribution(_cached, candidate)")
    assert i_cached < i_mount < i_continue, (
        f"挂载不在缓存分支内 (块 {i_cached}..{i_continue}, 挂载在 {i_mount})")


def test_mount_keeps_origin_false_for_overlap_rows():
    """`_ue_origin` 必须由 `_source` 派生 ⇒ 重叠票为 False, 不冒认 UE 独有。

    (冒认会污染 source_attribution 归因统计: UE 独有命中数被重叠票灌水)
    """
    cand = _da_row("US.ASTS")
    PL._merge_ue_attribution_into_overlap([cand], [_ue_row("US.ASTS")])
    analysis = {}
    PL._mount_ue_attribution(analysis, cand)
    assert analysis["_ue_origin"] is False
    assert analysis["_ue_direction"] == "SHORT"
    assert analysis["_ue_causal_chain"] == cand["ue_causal_chain"]
    assert analysis["_ue_confidence"] == 0.55
    # UE 独有票仍应被识别
    ue_only = {"symbol": "US.UAB", "_source": "ue_candidate", "ue_direction": "LONG",
               "ue_causal_chain": "x"}
    a2 = {}
    PL._mount_ue_attribution(a2, ue_only)
    assert a2["_ue_origin"] is True
