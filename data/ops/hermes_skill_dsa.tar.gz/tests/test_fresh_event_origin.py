# -*- coding: utf-8 -*-
"""RFC-136 fresh-event origin 契约测试 (skill v0.96)。

不只做字面量扫描: 实例化 Pipeline(ue_only=True), 隔离外部行情/LLM/DB,
驱动 Stage 6b, 断言 bridge 与 raw_instruction 双输出都写 ue_fresh_event。
"""
import json
import sys
from pathlib import Path
from types import SimpleNamespace


SCRIPTS = Path(__file__).resolve().parents[1] / "scripts"
FTSEEK_ROOT = Path("/opt/ftseek/FTSeek-US")
sys.path.insert(0, str(SCRIPTS))
sys.path.insert(0, str(FTSEEK_ROOT))

import adapter  # noqa: E402
import app.core.obsidian_writer as obsidian_writer  # noqa: E402
import app.playbook.db as playbook_db  # noqa: E402
import app.playbook.entry_band as entry_band  # noqa: E402
import app.playbook.market_regime as market_regime  # noqa: E402
import pipeline as PL  # noqa: E402


class FakeMarketRegimeGate:
    def assess(self):
        return SimpleNamespace(
            regime=SimpleNamespace(value="neutral"),
            vix=15.0,
            spy_ma20=500.0,
            spy_ma50=490.0,
        )


class FakePlaybookDB:
    saved = []

    def save_instruction(self, instruction):
        self.saved.append(instruction)


class FakeObsidianWriter:
    written = []

    def write_daily_premarket(self, payload):
        self.written.append(payload)


def _analysis():
    return {
        "symbol": "US.RARE",
        "action": "BUY",
        "sector": "Semiconductors",
        "score": 7.0,
        "conclusion": "Fresh-event thesis",
        "risks": ["event fade"],
        "_ue_origin": True,
        "_ue_direction": "LONG",
        "_ue_confidence": 0.55,
        "_llm_output": {},
    }


def _voting_result():
    return {
        "symbol": "US.RARE",
        "direction": "BUY",
        "confidence": 0.55,
        "score": 7.0,
        "thesis": "Fresh-event thesis",
        "conditions": ["news_positive"],
        "risks": ["event fade"],
        "entry_price": 100.0,
        "stop_loss": 95.0,
        "take_profit": 110.0,
        "position_suggestion": {"stop_loss_pct": 5.0, "take_profit_pct": 10.0},
        "entry_strategy": "breakout",
        "invalidation": "thesis break",
        "tripwires": [],
        "invalidation_triggers": [],
    }


def test_pipeline_ue_only_writes_fresh_event_origin(tmp_path, monkeypatch):
    FakePlaybookDB.saved.clear()
    FakeObsidianWriter.written.clear()
    monkeypatch.setattr(adapter, "to_voting_result", lambda analysis: _voting_result())
    monkeypatch.setattr(
        PL, "_derive_entry_semantics",
        lambda *args, **kwargs: (None, None, None))
    monkeypatch.setattr(market_regime, "MarketRegimeGate", FakeMarketRegimeGate)
    monkeypatch.setattr(playbook_db, "PlaybookDB", FakePlaybookDB)
    monkeypatch.setattr(
        entry_band, "compute_entry_band",
        lambda entry_price, is_short: (99.0, 101.0))
    monkeypatch.setattr(obsidian_writer, "get_obsidian_writer", FakeObsidianWriter)

    pipeline = PL.Pipeline(
        output_dir=str(tmp_path), db_write=True, ue_only=True)
    pipeline._write_bridge_file({}, [_analysis()])

    bridge_paths = list(tmp_path.glob("opportunity_scan_*.json"))
    assert len(bridge_paths) == 1
    bridge = json.loads(bridge_paths[0].read_text(encoding="utf-8"))
    assert bridge["candidates"][0]["origin"] == "ue_fresh_event"
    assert FakePlaybookDB.saved[0]["raw_instruction"]["origin"] == "ue_fresh_event"
