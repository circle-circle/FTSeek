#!/usr/bin/env python3
"""v5 P0 回归: list 源失败/空态分离, PE=0 不再伪装成亏损事实."""
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "scripts"))

import data_collector as dc  # noqa: E402
from llm_synth import (  # noqa: E402
    USER_PROMPT_TEMPLATE,
    _format_data_for_prompt,
    _fundamental_view,
)


def _base_collected():
    return {
        "symbol": "US.TEST",
        "snapshot": {"last_price": 100.0},
        "kline": [],
        "capital_flow": {},
        "capital_distribution": {},
        "news": [],
        "news_v2": [],
        "research": [],
        "sentiment": [],
        "fundamentals": {},
        "analyst_consensus": {},
        "insider_transactions": {},
        "insider_sentiment": {},
        "company_profile": {},
        "earnings_calendar": {},
        "market_context": {},
        "industry_peers": {},
    }


def test_futu_list_sources_preserve_status_without_breaking_list_api(monkeypatch):
    monkeypatch.setattr(
        dc, "_curl_json", lambda *args, **kwargs: {"code": 0, "data": [{"title": "ok"}]}
    )
    result = dc.collect_news("US.TEST")
    assert result == [{"title": "ok"}]
    assert result.source_status == "ok"
    assert json.loads(json.dumps(result)) == [{"title": "ok"}]


def test_futu_empty_and_failed_are_distinct(monkeypatch):
    monkeypatch.setattr(dc, "_curl_json", lambda *args, **kwargs: {"code": 0, "data": []})
    assert dc.collect_news("US.TEST").source_status == "empty"

    monkeypatch.setattr(dc, "_curl_json", lambda *args, **kwargs: {"_error": "HTTP 502"})
    result = dc.collect_news("US.TEST")
    assert result == []
    assert result.source_status == "failed"
    assert result.source_error == "non-zero response"


def test_finnhub_empty_failed_and_disabled_are_distinct(monkeypatch):
    monkeypatch.setattr(dc, "_finnhub_get", lambda *args, **kwargs: [])
    assert dc.collect_finnhub_news("US.TEST").source_status == "empty"

    monkeypatch.setattr(dc, "_finnhub_get", lambda *args, **kwargs: {"_error": "timeout"})
    assert dc.collect_finnhub_news("US.TEST").source_status == "failed"

    monkeypatch.setenv("DA_NEWS_V2", "0")
    assert dc.collect_finnhub_news("US.TEST").source_status == "disabled"


def test_prompt_renders_failed_not_as_no_news():
    collected = _base_collected()
    collected["news"] = {"_error": "HTTP 502"}
    collected["news_v2"] = dc._source_result([], "failed")
    collected["research"] = dc._source_result([], "empty")
    collected["sentiment"] = dc._source_result([], "disabled")

    prompt = _format_data_for_prompt(collected)

    assert "Futu新闻: FAILED(采集失败" in prompt
    assert "Finnhub新闻: FAILED(采集失败" in prompt
    assert "研报: EMPTY(源成功但无结果)" in prompt
    assert "社区情绪: DISABLED(配置关闭)" in prompt
    assert "HTTP 502" not in prompt


def test_pe_zero_and_missing_render_as_na_but_negative_pe_keeps_meaning():
    assert _fundamental_view({})["pe_ttm"] is None
    assert _fundamental_view({"pe_ttm_ratio": 0})["pe_ttm"] is None
    assert _fundamental_view({"pe_ttm_ratio": -12.5})["pe_ttm"] == -12.5
    assert _fundamental_view({})["market_cap"] is None

    prompt = _format_data_for_prompt({"snapshot": {"last_price": 100.0}})
    assert "PE(TTM): 数据未采集(N/A)" in prompt
    assert "总市值: 数据未采集(N/A)" in prompt


def test_prompt_contract_decouples_pe_zero_from_loss():
    assert "PE为负或0" not in USER_PROMPT_TEMPLATE
    assert "PE<0" in USER_PROMPT_TEMPLATE
    assert "PE=0或缺失只能写入evidence_gaps" in USER_PROMPT_TEMPLATE


def test_effective_quality_does_not_hide_failed_source():
    collected = _base_collected()
    collected["_quality"] = {"total": 19, "ok": 19, "failed": 0}
    collected["news"] = dc._source_result([], "ok")
    collected["news_v2"] = dc._source_result([], "ok")
    collected["research"] = dc._source_result([], "ok")
    collected["sentiment"] = dc._source_result([], "failed", "timeout")
    dc._attach_source_status(collected)
    assert collected["_source_status"]["sentiment"] == "failed"
    assert collected["_quality_effective"] == {
        "total": 19, "ok": 18, "failed": 1, "source_failed": ["sentiment"]}


def test_finnhub_news_keeps_full_publish_time(monkeypatch):
    monkeypatch.setattr(dc, "_finnhub_get", lambda *args, **kwargs: [{
        "headline": "TEST catalyst", "summary": "s",
        "datetime": 1792757011, "source": "wire", "url": "u",
    }])
    rows = dc.collect_finnhub_news("US.TEST")
    assert rows and rows[0]["publish_time"].endswith("Z")
    assert len(rows[0]["publish_time"]) >= 19
