#!/usr/bin/env python3
"""v5 P1: score_band 影子审计与挑战者盲评开关, 不改变生产行为."""
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "scripts"))

import data_collector as dc  # noqa: E402
import llm_synth  # noqa: E402


def _collected():
    return {
        "symbol": "US.TEST",
        "snapshot": {
            "effective_price": 100.0,
            "prev_close": 100.0,
        },
    }


def test_source_status_sidecar_survives_json(monkeypatch):
    collected = _collected()
    collected["news"] = dc._source_result([], "failed")
    collected["news_v2"] = dc._source_result([{"title": "ok"}], "ok")
    collected["research"] = []
    collected["sentiment"] = []
    dc._attach_source_status(collected)

    restored = json.loads(json.dumps(collected))

    assert restored["_source_status"] == {
        "news": "failed",
        "news_v2": "ok",
        "research": "empty",
        "sentiment": "empty",
    }
    prompt = llm_synth._format_data_for_prompt(restored)
    assert "Futu新闻: FAILED(采集失败" in prompt
    assert "Finnhub新闻" not in prompt


def test_score_band_audit_supports_high_without_enforcement(monkeypatch):
    monkeypatch.setattr(llm_synth, "_classify_data_sources", lambda _: (19, 19, [], []))
    result = {
        "direction": "BUY",
        "score_band": "HIGH",
        "bull_case": [{
            "thesis": "公司获得新合约",
            "source_type": "news",
            "evidence": "输入新闻",
            "claim_type": "product_catalyst",
        }],
    }

    audit = llm_synth._score_band_audit(result, _collected())

    assert audit["high_supported"] is True
    assert audit["should_downgrade"] is False
    assert result["score_band"] == "HIGH"


def test_score_band_audit_records_high_downgrade_and_claim_mismatch(monkeypatch):
    monkeypatch.setattr(llm_synth, "_classify_data_sources", lambda _: (19, 19, [], []))
    collected = _collected()
    collected["snapshot"]["effective_price"] = 103.0
    result = {
        "direction": "BUY",
        "score_band": "HIGH",
        "bull_case": [{
            "thesis": "营收增长",
            "source_type": "fundamental",
            "evidence": "营收同比增长",
            "claim_type": "technical_breakout",
        }],
    }

    audit = llm_synth._score_band_audit(result, collected)

    assert audit["criteria"]["not_priced_in"]["priced_in"] == "yes"
    assert audit["should_downgrade"] is True
    assert audit["suggested_band"] == "MEDIUM"
    assert audit["claim_type_recheck"]["mismatches"][0]["inferred"] == "earnings_beat"
    assert result["score_band"] == "HIGH"


def test_blind_direction_shadow_is_off_by_default(monkeypatch):
    calls = []

    def fake_call_llm(*args, **kwargs):
        calls.append((args, kwargs))
        return {"independent_direction": "BUY", "top_evidence": "x", "data_blind_spots": []}

    monkeypatch.setattr(llm_synth, "_call_llm", fake_call_llm)
    monkeypatch.delenv("DA_CHALLENGER_BLIND_SHADOW", raising=False)

    assert llm_synth._run_blind_direction_shadow("raw data") is None
    assert calls == []


def test_blind_direction_shadow_can_be_enabled(monkeypatch):
    captured = {}

    def fake_call_llm(system, user, **kwargs):
        captured["system"] = system
        captured["user"] = user
        captured["kwargs"] = kwargs
        return {
            "independent_direction": "skip",
            "top_evidence": "data gap",
            "data_blind_spots": ["news missing"],
            "confidence": "low",
        }

    monkeypatch.setattr(llm_synth, "_call_llm", fake_call_llm)
    monkeypatch.setenv("DA_CHALLENGER_BLIND_SHADOW", "1")

    shadow = llm_synth._run_blind_direction_shadow("raw data")

    assert shadow["direction"] == "SKIP"
    assert shadow["data_blind_spots"] == ["news missing"]
    assert "raw data" in captured["user"]
    assert "不参考任何已有分析结论" in captured["system"]
