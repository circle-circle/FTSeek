"""MarketScanner parallel scoring must preserve the serial output order."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "scripts"))

import market_scanner  # noqa: E402


def test_parallel_scoring_preserves_input_order(monkeypatch):
    scanner = market_scanner.MarketScanner("US", 10)
    candidates = [{"code": f"US.T{i}", "name": f"T{i}"} for i in range(12)]
    monkeypatch.setattr(scanner, "_collect_multi_channel",
                        lambda: {"candidates": candidates, "data_quality": {}})
    monkeypatch.setattr(scanner, "_quality_gate", lambda rows: rows)
    monkeypatch.setattr(scanner, "_four_signal_score",
                        lambda symbol, base: {"symbol": symbol, "score": 5.0})
    monkeypatch.setattr(scanner, "_collect_sector_data", lambda scored: {})
    monkeypatch.setattr(scanner, "_sector_narrative", lambda scored, rotation: "")
    monkeypatch.setattr(scanner, "_bucketing", lambda scored: {
        "bullish": [], "bearish": [], "watchlist": [], "avoid": []})

    result = scanner.scan(2)
    assert [row["symbol"] for row in result["all_scored"]] == [
        c["code"] for c in candidates]
