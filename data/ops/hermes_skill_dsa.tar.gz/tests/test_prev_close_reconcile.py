#!/usr/bin/env python3
"""prev_close 日K核对: 默认 shadow 不改输入, apply 才替换."""
import sys
from datetime import date
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "scripts"))

import prev_close_reconcile as pc  # noqa: E402


def _snap():
    return {
        "session": "premarket",
        "prev_close": 32.91,
        "prev_close_price": 32.91,
        "pre_price": 30.82,
        "pre_change_rate": -5.72,
        "effective_price": 30.82,
        "effective_chg_pct": -6.35,
    }


def _kline():
    return [
        {"time": "2026-10-20 00:00:00", "close": 32.91},
        {"time": "2026-10-21 00:00:00", "close": 32.69},
    ]


def test_shadow_records_would_apply_without_changing_model_input(monkeypatch):
    monkeypatch.setenv("DA_PREV_CLOSE_BAR_RECONCILE", "shadow")
    out = pc.reconcile_prev_close(_snap(), _kline(), today=date(2026, 10, 22))
    assert out["prev_close_price"] == 32.91
    assert out["effective_chg_pct"] == -6.35
    assert out["prev_close_raw"] == 32.91
    assert out["prev_close_bar_close"] == 32.69
    assert out["prev_close_delta_pct"] == 0.673
    assert out["prev_close_reconcile"]["status"] == "would_apply"


def test_apply_uses_completed_bar_and_recomputes_effective_change(monkeypatch):
    monkeypatch.setenv("DA_PREV_CLOSE_BAR_RECONCILE", "apply")
    out = pc.reconcile_prev_close(_snap(), _kline(), today=date(2026, 10, 22))
    assert out["prev_close_price"] == 32.69
    assert out["prev_close"] == 32.69
    assert out["effective_chg_pct"] == -5.72
    assert out["prev_close_reconcile"]["status"] == "applied"


def test_off_does_not_add_fields(monkeypatch):
    monkeypatch.setenv("DA_PREV_CLOSE_BAR_RECONCILE", "off")
    out = pc.reconcile_prev_close(_snap(), _kline(), today=date(2026, 10, 22))
    assert "prev_close_reconcile" not in out
    assert out["prev_close_price"] == 32.91


def test_conflict_on_implied_vs_bar_mismatch(monkeypatch):
    monkeypatch.setenv("DA_PREV_CLOSE_BAR_RECONCILE", "apply")
    snap = _snap()
    snap["pre_price"] = 40.0  # implied ~42.43, 与 32.69 明显冲突
    out = pc.reconcile_prev_close(snap, _kline(), today=date(2026, 10, 22))
    assert out["prev_close_price"] == 32.91
    assert out["prev_close_reconcile"]["status"] == "conflict"


def test_stale_bar_is_not_applied(monkeypatch):
    monkeypatch.setenv("DA_PREV_CLOSE_BAR_RECONCILE", "apply")
    out = pc.reconcile_prev_close(_snap(), _kline(), today=date(2026, 10, 30))
    assert out["prev_close_price"] == 32.91
    assert out["prev_close_reconcile"]["status"] == "stale_bar"


def test_missing_pre_change_rate_does_not_guess(monkeypatch):
    monkeypatch.setenv("DA_PREV_CLOSE_BAR_RECONCILE", "apply")
    snap = _snap()
    snap.pop("pre_change_rate")
    snap.pop("pre_price")
    out = pc.reconcile_prev_close(snap, _kline(), today=date(2026, 10, 22))
    assert out["prev_close_price"] == 32.91
    assert out["prev_close_reconcile"]["status"] == "conflict"


def test_apply_is_idempotent_and_keeps_source_truth(monkeypatch):
    monkeypatch.setenv("DA_PREV_CLOSE_BAR_RECONCILE", "apply")
    snap = _snap()
    snap["prev_close_raw_source"] = 32.91
    first = pc.reconcile_prev_close(dict(snap), _kline(), today=date(2026, 10, 22))
    assert first["prev_close_price"] == 32.69
    assert first["prev_close_raw"] == 32.91
    second = pc.reconcile_prev_close(dict(first), _kline(), today=date(2026, 10, 22))
    assert second["prev_close_price"] == 32.69
    assert second["prev_close_raw"] == 32.91
    assert second["prev_close_raw_source"] == 32.91
    assert second["prev_close_reconcile"]["status"] == "applied"
