"""Pullback refresh parallel path keeps one merged, atomic output."""
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "scripts"))

import pullback_stats as ps  # noqa: E402


def test_parallel_fetch_merges_all_symbols(tmp_path, monkeypatch):
    closes = [100 + i for i in range(40)]
    monkeypatch.setattr(ps, "fetch_klines", lambda sym: [
        {"close": float(c)} for c in closes])
    out = tmp_path / "pullback_shadow.json"
    out.write_text(json.dumps({"US.KEEP": {"spike_count": 1}}), encoding="utf-8")
    monkeypatch.setattr(ps, "OUT_PATH", out)
    monkeypatch.setattr(sys, "argv", ["pullback_stats.py", "US.AAA,US.BBB"])
    ps.main()
    data = json.loads(out.read_text(encoding="utf-8"))
    assert {"US.AAA", "US.BBB", "US.KEEP"} <= set(data)
    assert data["US.AAA"]["spike_count"] == 0
