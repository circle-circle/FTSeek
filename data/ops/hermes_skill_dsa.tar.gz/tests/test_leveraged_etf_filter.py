# -*- coding: utf-8 -*-
"""RFC-159: DA 杠杆/反向 ETF 前置过滤契约 (2026-10-22).

证据: 10/22 28 条 gate 中 8 条是 "2倍做空/做多 ... ETF", 全部缺 9 维数据 SKIP.
本过滤只认 name 含 ETF + 杠杆/反向关键词; SPY/QQQ 等宽基 ETF 与个股不误伤.
"""
import sys
from pathlib import Path

import pytest

SCRIPTS = Path(__file__).resolve().parents[1] / "scripts"
sys.path.insert(0, str(SCRIPTS))
import pipeline as PL  # noqa: E402


@pytest.mark.parametrize("name", [
    "2倍做空AAOI ETF-Tradr",
    "2倍做空AXTI ETF-Tradr",
    "2倍做多AXTI ETF-Tradr",
    "2倍做空BMNR ETF-Defiance",
    "2倍做多LITE ETF-Leverage Shares",
    "2倍做空MSTR ETF-Defiance",
    "2倍做多LRCX ETF-Corgi",
    "2倍做多LRCX ETF-Tradr",
    "Direxion Daily 3X Bull ETF",
])
def test_leveraged_etf_names_match(name):
    assert PL._is_leveraged_etf_name(name) is True


@pytest.mark.parametrize("name", [
    "SpaceX",
    "SPDR S&P 500 ETF Trust",
    "Invesco QQQ Trust",
    "Arm Holdings",
    "",
    None,
])
def test_non_leveraged_names_do_not_match(name):
    assert PL._is_leveraged_etf_name(name) is False


def _fake_atr(*_a, **_k):
    return {"ratio": 0.05, "atr": 1.0, "basis": "test", "source": "test",
            "adjustment": "test", "bars_used": 10, "reason": "ok",
            "bars_asof": "2026-10-21", "status": "PASS", "ratio_pct": 5.0,
            "denominator": "test"}


def _patch_screening(monkeypatch):
    monkeypatch.delenv("DA_CANDIDATE_SCREEN", raising=False)
    monkeypatch.setattr(PL, "_ftseek_screening_deps", lambda: {
        "evaluate_candidate": lambda facts, policy: {
            "status": "PASS", "reasons": [], "missing_fields": []},
        "fingerprint": lambda _x: "test-hash",
    })
    monkeypatch.setattr(PL, "_da_screening_thresholds", lambda: {
        "version": "test", "min_price": 5.0, "min_atr_ratio": 0.03,
        "config_source": "test",
    })
    monkeypatch.setattr(PL, "_fetch_screening_atr", _fake_atr)
    monkeypatch.setattr(PL, "_candidate_ref_price", lambda c: c.get("price"))
    monkeypatch.setattr(PL, "_da_skip_leveraged_etf", lambda: True)


def test_screening_rejects_leveraged_etf(monkeypatch):
    _patch_screening(monkeypatch)
    rows = PL._screen_da_candidates(
        [{"symbol": "US.AAOZ", "name": "2倍做空AAOI ETF-Tradr", "price": 10.0}],
        stage="test")
    assert len(rows) == 1
    screen = rows[0]["candidate_screening"]
    assert screen["status"] == "REJECT"
    assert "leveraged_etf" in screen["reasons"]


def test_screening_keeps_normal_symbol(monkeypatch):
    _patch_screening(monkeypatch)
    rows = PL._screen_da_candidates(
        [{"symbol": "US.SPCX", "name": "SpaceX", "price": 10.0}], stage="test")
    assert rows[0]["candidate_screening"]["status"] == "PASS"
    assert "leveraged_etf" not in rows[0]["candidate_screening"]["reasons"]


def test_config_switch_reads_yaml(tmp_path, monkeypatch):
    cfg = tmp_path / "cfg.yaml"
    cfg.write_text("universe_expansion:\n  da_skip_leveraged_etf: true\n",
                   encoding="utf-8")
    monkeypatch.setattr(PL, "_UE_CONFIG_PATH", str(cfg))
    monkeypatch.setattr(PL, "_DA_SKIP_LEVERAGED_ETF", None)
    assert PL._da_skip_leveraged_etf() is True

    cfg.write_text("universe_expansion:\n  da_skip_leveraged_etf: false\n",
                   encoding="utf-8")
    monkeypatch.setattr(PL, "_DA_SKIP_LEVERAGED_ETF", None)
    assert PL._da_skip_leveraged_etf() is False
