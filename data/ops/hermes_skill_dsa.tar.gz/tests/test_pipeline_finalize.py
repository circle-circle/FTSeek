"""Checkpoint finalize / decision_id fallback contract (2026-10-23)."""
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "scripts"))

import pipeline  # noqa: E402


def _write_ckpt(root: Path, date: str, symbol: str, payload: dict):
    folder = root / "da_checkpoint" / date
    folder.mkdir(parents=True, exist_ok=True)
    (folder / f"{symbol}.json").write_text(json.dumps(payload), encoding="utf-8")


def test_ensure_decision_id_preserves_existing():
    a = {"symbol": "US.ACI", "_ic_decision_id": "DA-20261023-US.ACI-abcd"}
    assert pipeline._ensure_decision_id(a, "2026-10-23") == "DA-20261023-US.ACI-abcd"
    assert a["_ic_decision_id"] == "DA-20261023-US.ACI-abcd"


def test_ensure_decision_id_falls_back_deterministically():
    a = {"symbol": "US.ACI", "_ic_decision_id": None}
    did = pipeline._ensure_decision_id(a, "2026-10-23")
    assert did == "DA-20261023-US.ACI-noic"
    assert a["_ic_decision_id"] == did
    assert pipeline._fallback_decision_id("2026-10-23", "US.ACI") == did


def test_load_checkpoint_analyses_skips_raw_and_error(tmp_path):
    _write_ckpt(tmp_path, "2026-10-23", "US.ACI",
                {"symbol": "US.ACI", "rating": "看多", "action": "BUY"})
    _write_ckpt(tmp_path, "2026-10-23", "US.BAD",
                {"symbol": "US.BAD", "rating": "错误"})
    raw = tmp_path / "da_checkpoint" / "2026-10-23" / "US.ACI.raw.json"
    raw.write_text("{}", encoding="utf-8")
    loaded = pipeline._load_checkpoint_analyses(str(tmp_path), "2026-10-23")
    assert [a["symbol"] for a in loaded] == ["US.ACI"]


def test_finalize_uses_normal_stage6_writers_with_fallback_id(tmp_path, monkeypatch):
    _write_ckpt(tmp_path, "2026-10-23", "US.ACI",
                {"symbol": "US.ACI", "rating": "看多", "action": "BUY",
                 "score": 7.0, "_signal_gate": {"decision": "PASS"}})
    calls = {}

    def fake_channels(self, scan_result, analyses, selected_symbols=None,
                      trade_date=None):
        calls["channels"] = ([a["symbol"] for a in analyses], trade_date)

    def fake_bridge(self, scan_result, analyses, trade_date=None):
        calls["bridge"] = ([a.get("_ic_decision_id") for a in analyses], trade_date)
        return {"candidates": 1, "db_written": 1}

    monkeypatch.setattr(pipeline.Pipeline, "_write_ftseek_data_channels",
                        fake_channels)
    monkeypatch.setattr(pipeline.Pipeline, "_write_bridge_file", fake_bridge)
    result = pipeline.finalize_from_checkpoint("2026-10-23", str(tmp_path))
    assert result["finalized"] is True
    assert result["bridge_candidates"] == 1
    assert calls["channels"] == (["US.ACI"], "2026-10-23")
    assert calls["bridge"] == (["DA-20261023-US.ACI-noic"], "2026-10-23")


def test_finalize_without_checkpoints_is_noop(tmp_path):
    result = pipeline.finalize_from_checkpoint("2026-10-23", str(tmp_path))
    assert result["finalized"] is False
    assert result["reason"] == "no_checkpoint_analyses"


def test_raw_checkpoint_merges_corrected_snapshot(tmp_path):
    first = {"snapshot": {"prev_close": 32.91, "prev_close_raw_source": 32.91},
             "kline": [{"close": 32.69}]}
    pipeline._ckpt_save_raw(str(tmp_path), "2026-10-23", "US.ACI", first)
    corrected = {"snapshot": {"prev_close": 32.69, "prev_close_raw": 32.91,
                              "prev_close_raw_source": 32.91,
                              "prev_close_reconcile": {"status": "applied"}},
                 "kline": [{"close": 32.69}]}
    pipeline._ckpt_save_raw(str(tmp_path), "2026-10-23", "US.ACI", corrected,
                            user_prompt="prompt-body")
    raw = json.loads((tmp_path / "da_checkpoint" / "2026-10-23" /
                      "US.ACI.raw.json").read_text(encoding="utf-8"))
    assert raw["collected"]["snapshot"]["prev_close"] == 32.69
    assert raw["collected"]["snapshot"]["prev_close_raw"] == 32.91
    assert raw["user_prompt"] == "prompt-body"
