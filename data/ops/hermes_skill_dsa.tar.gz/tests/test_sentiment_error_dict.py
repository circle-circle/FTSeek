#!/usr/bin/env python3
"""复现 + 回归测试: _format_data_for_prompt 收到 executor 异常写入的
{"_error": ...} dict 型 sentiment 时, L576 sentiment[:5] 抛 TypeError。

背景 (v5 五模型审查 + 人工取证):
- data_collector.py executor 异常路径: result["sentiment"] = {"_error": str(e)}
- llm_synth.py L563 `if sentiment:` 对非空 dict 为真 → L576 `sentiment[:5]` TypeError
- dict 型源(fundamentals 等)渲染端均有 "_error" not in 守卫, list 型源缺失

用法: python3 tests/test_sentiment_error_dict.py
修复前: 应抛 TypeError (测试证明 bug 存在)
修复后: 正常返回, 且 sentiment 段被视为缺失
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "scripts"))

from llm_synth import _format_data_for_prompt  # noqa: E402


def _base_collected():
    """最小可用 collected: 快照有现价避免触发 SKIP 分支."""
    return {
        "symbol": "US.TEST",
        "snapshot": {"last_price": 100.0},
        "kline": [],
        "capital_flow": {},
        "capital_distribution": {},
        "news": [],
        "news_v2": [],
        "research": [],
        "fundamentals": {},
        "analyst_consensus": {},
        "insider_transactions": {},
        "insider_sentiment": {},
        "company_profile": {},
        "earnings_calendar": {},
        "market_context": {},
        "industry_peers": {},
        "_quality": {"total": 3, "ok": 2, "failed": 1},
    }


def test_error_dict_sentiment_no_crash():
    """executor 异常 → sentiment 是 dict, 渲染端不得崩溃."""
    collected = _base_collected()
    collected["sentiment"] = {"_error": "Connection timeout"}
    out = _format_data_for_prompt(collected)
    assert isinstance(out, str), "应返回字符串"
    assert "Connection timeout" not in out, "错误内容不得泄漏进 prompt"
    assert "社区讨论" not in out, "失败的 sentiment 应视为缺失, 不渲染该段"
    print("PASS: error-dict sentiment 不崩溃、不泄漏、不渲染")


def test_empty_sentiment_ok():
    collected = _base_collected()
    collected["sentiment"] = []
    out = _format_data_for_prompt(collected)
    assert "社区讨论" not in out
    print("PASS: 空 list 正常")


def test_real_sentiment_renders():
    import time
    collected = _base_collected()
    now = time.time()
    collected["sentiment"] = [
        {"title": "看涨 TEST", "desc": "业绩超预期", "publish_time": now - 60},
        {"title": "讨论二", "desc": "机构增持", "publish_time": now - 300},
    ]
    out = _format_data_for_prompt(collected)
    assert "社区讨论" in out and "看涨 TEST" in out
    print("PASS: 真实 list 正常渲染")


def test_all_list_sources_error_dict():
    """kline/news/research 同样注入 {"_error":..} dict 时不得崩溃."""
    collected = _base_collected()
    for k in ("kline", "news", "research", "sentiment"):
        collected[k] = {"_error": "HTTP 502"}
    out = _format_data_for_prompt(collected)
    assert isinstance(out, str)
    assert "HTTP 502" not in out
    print("PASS: kline/news/research/sentiment 全部 error-dict 免疫")


if __name__ == "__main__":
    test_error_dict_sentiment_no_crash()
    test_empty_sentiment_ok()
    test_real_sentiment_renders()
    test_all_list_sources_error_dict()
    print("ALL PASS")
