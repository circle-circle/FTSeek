#!/usr/bin/env python3
"""记忆/复盘真值: 真实30日窗口、净额、退出日归属、不再假"全胜" (2026-10-23)."""
import sqlite3
import sys
from datetime import datetime, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "scripts"))

import config  # noqa: E402
import feedback_loop  # noqa: E402
import strategy_memory  # noqa: E402


def _today():
    return datetime.now(strategy_memory.ET_TZ).date()


def _make_trade_db(path: Path):
    conn = sqlite3.connect(path)
    conn.execute("""
        CREATE TABLE trade_records (
            id INTEGER PRIMARY KEY, trade_date TEXT, exit_time TEXT, symbol TEXT,
            direction TEXT, entry_price REAL, exit_price REAL, quantity REAL,
            realized_pnl REAL, pnl_net REAL, pnl_pct REAL, exit_reason TEXT,
            holding_hours REAL, signal_strength REAL, signal_confidence REAL,
            strategy_id TEXT, source_type TEXT, data_quality TEXT,
            entry_reason TEXT, factor_detail TEXT)
    """)
    d2 = (_today() - timedelta(days=2)).isoformat()
    d3 = (_today() - timedelta(days=3)).isoformat()
    d100 = (_today() - timedelta(days=100)).isoformat()
    rows = [
        # 旧时代: 不得进入 30 日窗口
        (d100, d100 + "T15:00:00", "US.A", "LONG", 100, 101, 1, 500, 480, 1,
         "SL_TRAIL_LOCK", 1, 75, .8, "playbook_sim", "PLAYBOOK_SIM", "clean", "", ""),
        # 窗口内净额 90 / 净额 40
        (d3, d3 + "T15:00:00", "US.A", "LONG", 100, 101, 1, 100, 90, 1,
         "SL_TRAIL_LOCK", 1, 75, .8, "playbook_sim", "PLAYBOOK_SIM", "clean", "", ""),
        (d2, d2 + "T15:00:00", "US.A", "LONG", 100, 101, 1, 50, 40, 1,
         "SL_TRAIL_LOCK", 1, 75, .8, "playbook_sim", "PLAYBOOK_SIM", "clean", "", ""),
        # 窗口内亏损 (同 pattern 两笔才进入 loss top3)
        (d2, d2 + "T15:00:00", "US.A", "SHORT", 100, 101, 1, -30, -35, -1,
         "SL_INITIAL", 1, 75, .8, "playbook_sim", "PLAYBOOK_SIM", "clean", "", ""),
        (d3, d3 + "T15:00:00", "US.A", "SHORT", 100, 101, 1, -20, -25, -1,
         "SL_INITIAL", 1, 75, .8, "playbook_sim", "PLAYBOOK_SIM", "clean", "", ""),
        # 坏质量行: 不得进入表现统计
        (d2, d2 + "T15:00:00", "US.A", "LONG", 100, 101, 1, 999, 999, 9,
         "SL_TRAIL_LOCK", 1, 75, .8, "playbook_sim", "PLAYBOOK_SIM", "suspect", "", ""),
    ]
    conn.executemany("""
        INSERT INTO trade_records
        (trade_date, exit_time, symbol, direction, entry_price, exit_price, quantity,
         realized_pnl, pnl_net, pnl_pct, exit_reason, holding_hours, signal_strength,
         signal_confidence, strategy_id, source_type, data_quality, entry_reason, factor_detail)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
    """, rows)
    conn.commit()
    conn.close()


def _patch_paths(monkeypatch, tmp_path):
    db = tmp_path / "ftseek.db"
    mem = tmp_path / "strategy_memory.db"
    _make_trade_db(db)
    monkeypatch.setattr(config, "FTSEEK_DB", str(db))
    monkeypatch.setattr(strategy_memory, "DB_PATH", str(mem))
    return db, mem


def test_memory_hint_uses_true_window_net_and_a10(monkeypatch, tmp_path):
    _patch_paths(monkeypatch, tmp_path)
    hint = strategy_memory.get_strategy_hint(symbol="US.A")
    win = {p["direction"]: p for p in hint["win_patterns"]}
    loss = {p["direction"]: p for p in hint["loss_patterns"]}
    assert win["LONG"]["trades"] == 2
    assert win["LONG"]["pnl"] == 130.0  # 90+40, 不含旧 480 / 坏质量 999
    assert loss["SHORT"]["pnl"] == -60.0
    assert hint["symbol_history"]["LONG"]["total_pnl"] == 130.0
    text = strategy_memory.format_hint_for_prompt(hint, symbol="US.A")
    assert "近30日净额" in text
    assert "480" not in text and "999" not in text


def test_daily_trades_are_selected_by_exit_date(monkeypatch, tmp_path):
    _patch_paths(monkeypatch, tmp_path)
    db = Path(config.FTSEEK_DB)
    conn = sqlite3.connect(db)
    conn.execute("DELETE FROM trade_records")
    rows = [
        # 前一日入场, 当日退出 -> 必须计入当日
        ("2026-10-21", "2026-10-22T10:00:00", "US.OVERNIGHT", "LONG", 10, 11, 1, 1, 1,
         0.1, "SL_TRAIL_LOCK", 1, 70, .8, "playbook_sim", "PLAYBOOK_SIM", "clean", "", ""),
        # 当日入场当日退出 -> 计入
        ("2026-10-22", "2026-10-22T11:00:00", "US.SAMEDAY", "LONG", 10, 11, 1, 1, 1,
         0.1, "SL_TRAIL_LOCK", 1, 70, .8, "playbook_sim", "PLAYBOOK_SIM", "clean", "", ""),
        # 当日入场未退出 -> 不计入
        ("2026-10-22", None, "US.OPEN", "LONG", 10, None, 1, 0, 0,
         0, "OPEN", 0, 70, .8, "playbook_sim", "PLAYBOOK_SIM", "clean", "", ""),
        # 下一日退出 -> 不计入
        ("2026-10-22", "2026-10-23T10:00:00", "US.TOMORROW", "LONG", 10, 11, 1, 1, 1,
         0.1, "SL_TRAIL_LOCK", 1, 70, .8, "playbook_sim", "PLAYBOOK_SIM", "clean", "", ""),
    ]
    conn.executemany("""
        INSERT INTO trade_records
        (trade_date, exit_time, symbol, direction, entry_price, exit_price, quantity,
         realized_pnl, pnl_net, pnl_pct, exit_reason, holding_hours, signal_strength,
         signal_confidence, strategy_id, source_type, data_quality, entry_reason, factor_detail)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
    """, rows)
    conn.commit()
    conn.close()
    got = {t["symbol"] for t in feedback_loop._get_today_trades("2026-10-22")}
    assert got == {"US.OVERNIGHT", "US.SAMEDAY"}


def test_lessons_do_not_claim_all_win_with_same_direction_loss():
    trades = [
        {"symbol": "A", "direction": "LONG", "realized_pnl": 20, "pnl_net": 18,
         "exit_reason": "SL_TRAIL_LOCK", "holding_hours": 1},
        {"symbol": "B", "direction": "LONG", "realized_pnl": 10, "pnl_net": 8,
         "exit_reason": "SL_BREAKEVEN", "holding_hours": 1},
        {"symbol": "C", "direction": "LONG", "realized_pnl": -200, "pnl_net": -205,
         "exit_reason": "SL_INITIAL", "holding_hours": 1},
    ]
    lessons = feedback_loop.extract_lessons(trades, "2026-10-22")
    text = "\n".join(l["content"] for l in lessons)
    assert "全胜" not in text
    assert "2胜1负" in text
    assert "净PnL=$-179" in text


def test_save_lessons_roundtrip_uses_add_lesson(monkeypatch, tmp_path):
    _patch_paths(monkeypatch, tmp_path)
    feedback_loop.save_lessons([{
        "date": "2026-10-22", "type": "loss_pattern",
        "content": "净亏$1", "evidence": "{}", "impact": "low",
    }])
    conn = sqlite3.connect(strategy_memory.DB_PATH)
    try:
        assert conn.execute("SELECT COUNT(*) FROM lesson_log WHERE date='2026-10-22'").fetchone()[0] == 1
    finally:
        conn.close()


def test_rebuild_uses_net_and_excludes_bad_quality(monkeypatch, tmp_path):
    _patch_paths(monkeypatch, tmp_path)
    stats = strategy_memory.rebuild_from_trade_records()
    assert stats["trades"] == 5  # 旧 1 + 窗口 4; 坏质量 1 行排除
    conn = sqlite3.connect(strategy_memory.DB_PATH)
    try:
        total = conn.execute("SELECT ROUND(SUM(total_pnl),2) FROM pattern_memory").fetchone()[0]
        assert total == 550.0  # 480+90+40-35-25, 不含坏质量 999
    finally:
        conn.close()


def test_pre_fix_lessons_are_not_injected(monkeypatch, tmp_path):
    _patch_paths(monkeypatch, tmp_path)
    today = _today()
    yesterday = (today - timedelta(days=1)).isoformat()
    monkeypatch.setattr(strategy_memory, "LESSON_TRUTH_START", today.isoformat())
    conn = sqlite3.connect(strategy_memory.DB_PATH)
    conn.execute("""CREATE TABLE IF NOT EXISTS lesson_log (
        id INTEGER PRIMARY KEY AUTOINCREMENT, date TEXT NOT NULL,
        lesson_type TEXT NOT NULL, content TEXT NOT NULL, evidence TEXT,
        impact TEXT, created_at TEXT NOT NULL)""")
    conn.execute("INSERT INTO lesson_log (date,lesson_type,content,impact,created_at) VALUES (?,?,?,?,?)",
                 (yesterday, "market_regime", "旧假 lesson", "high", "x"))
    conn.execute("INSERT INTO lesson_log (date,lesson_type,content,impact,created_at) VALUES (?,?,?,?,?)",
                 (today.isoformat(), "market_regime", "新净额 lesson", "high", "x"))
    conn.commit(); conn.close()
    hint = strategy_memory.get_strategy_hint()
    text = "\n".join(hint.get("recent_lessons") or [])
    assert "旧假 lesson" not in text
    assert "新净额 lesson" in text
