#!/usr/bin/env python3
"""DA 生料 VIX 口径标签契约 (RFC-190 §1A / DEB-20261106 §57.4)。

守的不变量:
  1. `data_collector._get_vix` 返回的 `caliber` **不得**再声称"实时代理"
     —— 实测 23/23 个交易日盘前 `last_price` = 上一交易日收盘;
  2. `llm_synth._format_data_for_prompt` 把该口径写进 prompt, 且明确"非今日实时"。
本用例只钉文本语义, 不碰任何数值/阈值 (A2 把现货真值喂模型仍属未裁的输入变更)。

跑全目录前加 `PROTOCOL_BUFFERS_PYTHON_IMPLEMENTATION=python` —— 否则
`test_fresh_event_origin.py` 在 collection 阶段就因 futu 的 pb2 与 protobuf 版本
不兼容而中断整批 (与本文件无关, 是环境老问题)。
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "scripts"))

import llm_synth  # noqa: E402


def _collected():
    return {
        "market_context": {
            "spy": {"current": 600.0, "trend": "UP", "chg_5d_pct": 1.0, "chg_20d_pct": 2.0},
            "qqq": {"current": 500.0, "trend": "UP", "chg_5d_pct": 1.0, "chg_20d_pct": 2.0},
            "vix": {
                "current": 18.04, "chg_pct": 0.0, "proxy": "US.VIXY",
                "proxy_factor": 0.85, "vixy_price": 21.22,
                "caliber": "VIXY×0.85 代理 · 盘前读到上一交易日收盘 (非实时)",
                "as_of_basis": "prev_close",
            },
        }
    }


def _vix_line(text):
    return next(ln for ln in text.splitlines() if ln.startswith("- VIX"))


def test_prompt_labels_vix_as_previous_close_not_realtime():
    line = _vix_line(llm_synth._format_data_for_prompt(_collected()))
    assert "18.04" in line
    assert "上一交易日收盘" in line
    assert "非今日实时" in line
    # 盘前 chg_pct 恒 0.0 (last==prev_close) ⇒ 不得打印"今日+0.0%"冒充"今日无波动"
    assert "今日涨跌不可得" in line
    assert "今日+0.0%" not in line
    # 旧标签 (会诱导模型把 T-1 收盘读成今日波动率) 不得复活
    assert "盘前/盘中实时代理" not in line


def test_prompt_keeps_change_pct_when_basis_is_live():
    c = _collected()
    c["market_context"]["vix"]["as_of_basis"] = "live"
    c["market_context"]["vix"]["chg_pct"] = 1.2
    line = _vix_line(llm_synth._format_data_for_prompt(c))
    assert "今日+1.2%" in line
    assert "涨跌不可得" not in line


def test_prompt_vix_label_absent_when_no_proxy_metadata():
    c = _collected()
    c["market_context"]["vix"].pop("proxy")
    line = _vix_line(llm_synth._format_data_for_prompt(c))
    assert "18.04" in line
    assert "上一交易日收盘" not in line  # 无代理元数据时不臆造口径


def test_collector_caliber_source_is_truthful():
    src = (Path(__file__).resolve().parent.parent / "scripts" / "data_collector.py").read_text(
        encoding="utf-8")
    # 先剔整行注释: 修法说明里会引用旧标签 (tombstone), 那是证据不是复活
    code = "\n".join(ln for ln in src.splitlines() if not ln.lstrip().startswith("#"))
    assert "盘前/盘中实时代理" not in code, "旧口径标签复活 ⇒ 模型会把 T-1 收盘当今日实时"
    assert "上一交易日收盘" in code
    assert '"as_of_basis": "prev_close"' in code