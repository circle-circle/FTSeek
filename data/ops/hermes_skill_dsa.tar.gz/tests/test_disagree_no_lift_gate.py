#!/usr/bin/env python3
"""B2 (2026-10-27): 明确反对 (DISAGREE) 不得按"弃权"抬升 decision_conf.

病灶: 挑战者 verdict=DISAGREE 却把 my_direction 填成 SKIP (Prompt 要求 DISAGREE 必给
反方向 ⇒ 输出自相矛盾), 但 signal_gate 的弃权分支只看 challenger_direction、不看 verdict,
一律按 score/10 抬到 0.6~0.8 ⇒ tier 良/优 ⇒ PASS ⇒ "明确反对"反而拿最高档。
实测 2026-10-27 US.META: DISAGREE+SKIP → decision_conf 0.80 / tier 优 / PASS。

本文件锁死:
  ① DISAGREE+SKIP 不再抬升 (conf 0.50 / tier 中 / WARN), 且 tier 不硬 BLOCK (供给不灭);
  ② 真弃权 (PARTIAL_AGREE+SKIP / AGREE+SKIP) 行为**不变** (抬升仍在);
  ③ 同向 AGREE / 真反向 三态不变;
  ④ 回滚开关 DA_GATE_DISAGREE_NO_LIFT=0 ⇒ 恢复旧行为;
  ⑤ llm_synth 文案: 明确反对不得标成"合法弃权", 但必须保留"弃权"二字
     (app/playbook/admission.py:240 与 app/review/daily_review.py:914 按子串分层).
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "scripts"))

import llm_synth  # noqa: E402
import signal_gate  # noqa: E402


def _analysis(verdict="DISAGREE", chall_dir="SKIP", direction="BUY",
              score=8.0, agreed=False, self_debate=False):
    return {
        "symbol": "US.TEST",
        "action": direction,
        "score": score,
        "_llm_output": {
            "direction": direction,
            "confidence": "高",
            "debate_outcome": "x",
            "_debate": {
                "challenger_direction": chall_dir,
                "challenger_verdict": verdict,
                "challenger_agreed": agreed,
                "challenger_fallback": False,
                "challenger_self_debate": self_debate,
                "challenger_score": 3.0,
            },
        },
        "_ftseek": {"voting_result": {
            "conditions": [], "entry_price": 100.0,
            "stop_loss": 95.0, "take_profit": 105.0,
        }},
    }


def _gate(monkeypatch, **kw):
    monkeypatch.setattr(signal_gate.strategy_memory, "get_strategy_hint",
                        lambda **_: {})
    return signal_gate.evaluate_signal(_analysis(**kw))


def test_disagree_with_skip_direction_is_not_lifted(monkeypatch):
    r = _gate(monkeypatch, verdict="DISAGREE", chall_dir="SKIP", score=8.0)
    assert r["decision_conf"] == 0.50, r["decision_conf"]
    assert r["tier"] == "中", r["tier"]
    assert r["decision"] == "WARN", r["decision"]
    # 降级不删除: 不得硬 BLOCK (供给不灭)
    assert r["decision"] != "BLOCK"


def test_disagree_suppression_is_recorded_in_reasons(monkeypatch):
    r = _gate(monkeypatch, verdict="DISAGREE", chall_dir="SKIP")
    assert any("弃权抬升抑制" in x for x in r["reasons"]), r["reasons"]


def test_true_abstain_still_lifted(monkeypatch):
    """PARTIAL_AGREE + 挑战者弃权 = 真弃权 ⇒ 抬升仍在 (本批不动此支)。"""
    r = _gate(monkeypatch, verdict="PARTIAL_AGREE", chall_dir="SKIP", score=8.0)
    assert r["decision_conf"] == 0.8, r["decision_conf"]
    assert r["tier"] == "优", r["tier"]
    assert r["decision"] == "PASS", r["decision"]
    assert not any("弃权抬升抑制" in x for x in r["reasons"])


def test_agree_same_direction_unchanged(monkeypatch):
    r = _gate(monkeypatch, verdict="AGREE", chall_dir="BUY", score=8.0, agreed=True)
    assert r["decision_conf"] == 0.70, r["decision_conf"]
    assert r["tier"] == "优", r["tier"]


def test_true_reverse_unchanged(monkeypatch):
    r = _gate(monkeypatch, verdict="DISAGREE", chall_dir="SELL_SHORT",
              direction="BUY", score=8.0)
    assert r["decision_conf"] == 0.35, r["decision_conf"]
    assert r["tier"] == "差", r["tier"]
    assert r["decision"] == "BLOCK", r["decision"]


def test_self_debate_disagree_keeps_lift(monkeypatch):
    """T4 同模型自辩的 DISAGREE 不是独立反对信号 ⇒ 不抑制抬升。"""
    r = _gate(monkeypatch, verdict="DISAGREE", chall_dir="SKIP",
              score=8.0, self_debate=True)
    assert r["decision_conf"] == 0.8, r["decision_conf"]


def test_rollback_switch_restores_legacy(monkeypatch):
    monkeypatch.setenv("DA_GATE_DISAGREE_NO_LIFT", "0")
    r = _gate(monkeypatch, verdict="DISAGREE", chall_dir="SKIP", score=8.0)
    assert r["decision_conf"] == 0.8, r["decision_conf"]
    assert r["tier"] == "优", r["tier"]
    assert not any("弃权抬升抑制" in x for x in r["reasons"])


def test_merge_labels_explicit_disagree_not_as_legal_abstain(monkeypatch):
    monkeypatch.setenv("DA_SCORE_BAND", "1")
    initial = {"direction": "BUY", "score": 8.0, "confidence": "中",
               "risks": [], "bull_case": [], "bear_case": []}
    challenge = {"my_direction": "SKIP", "my_score_band": "HIGH",
                 "agreed": False, "verdict": "DISAGREE",
                 "missed_risks": [], "challenged_claims": []}
    out = llm_synth._merge_debate_results(initial, challenge)
    oc = str(out.get("debate_outcome", ""))
    assert "明确反对" in oc, oc
    assert "合法弃权" not in oc, oc
    # 必须保留 "弃权" 二字: 下游 admission.py:240 / daily_review.py:914 按子串分层
    assert "弃权" in oc, oc
    # 不得含 "AGREE" 子串 (含 "DISAGREE" 也不行): signal_gate/adapter 有
    # `"AGREE" in debate_outcome` 判定, 命中会白捡 +0.20
    assert "AGREE" not in oc.upper(), oc


def test_merge_legal_abstain_text_unchanged(monkeypatch):
    monkeypatch.setenv("DA_SCORE_BAND", "1")
    initial = {"direction": "BUY", "score": 8.0, "confidence": "中",
               "risks": [], "bull_case": [], "bear_case": []}
    challenge = {"my_direction": "SKIP", "my_score_band": "HIGH",
                 "agreed": False, "verdict": "PARTIAL_AGREE",
                 "missed_risks": [], "challenged_claims": []}
    out = llm_synth._merge_debate_results(initial, challenge)
    oc = str(out.get("debate_outcome", ""))
    assert "合法弃权" in oc, oc
    assert "DISAGREE" not in oc, oc
