# -*- coding: utf-8 -*-
"""_write_bridge_file UE 元数据契约测试 (v0.90 后置防线).

v0.90 提交版曾读取未绑定的 ``candidate`` 变量, 导致每个 bridge/DB 候选都在
外层 except 中被跳过。UE 元数据在 Stage5 analysis 快照上已写成 ``_ue_*`` 字段,
Stage6b 只能消费 ``a`` (analysis), 不得回读已经离开作用域的扫描候选变量。
"""
import ast
from pathlib import Path


SCRIPT = Path(__file__).resolve().parents[1] / "scripts" / "pipeline.py"


def _write_bridge_function(source: str) -> ast.FunctionDef:
    tree = ast.parse(source)
    functions = [
        node for node in ast.walk(tree)
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
        and node.name == "_write_bridge_file"
    ]
    assert functions, "_write_bridge_file 必须存在"
    return functions[0]


def test_write_bridge_does_not_read_unbound_scan_candidate():
    source = SCRIPT.read_text(encoding="utf-8")
    function = _write_bridge_function(source)
    candidate_loads = [
        node.lineno for node in ast.walk(function)
        if isinstance(node, ast.Name) and node.id == "candidate"
        and isinstance(node.ctx, ast.Load)
    ]
    assert candidate_loads == [], (
        "_write_bridge_file 读取未绑定 candidate: "
        "会导致 DA bridge/DB 候选整批被外层 except 跳过"
    )


def test_ue_metadata_uses_analysis_snapshot_fields():
    source = SCRIPT.read_text(encoding="utf-8")
    expected = {
        '"ue_direction": str(a.get("_ue_direction") or "").upper(),',
        '"ue_confidence": a.get("_ue_confidence"),',
        '"ue_scanned_at": a.get("_ue_scanned_at", ""),',
    }
    stripped_lines = {line.strip() for line in source.splitlines()}
    assert expected.issubset(stripped_lines), (
        "bridge 文件与 DB raw_instruction 必须同源消费 analysis._ue_* 字段"
    )


def test_raw_instruction_preserves_original_direction():
    """SKIP 行 DB direction 被改写后, raw 仍保留 DA 原始 BUY/SHORT 方向."""
    source = SCRIPT.read_text(encoding="utf-8")
    assert '"direction": _inst_dir,' in source
    assert '"original_direction": _dir_long_short,' in source
