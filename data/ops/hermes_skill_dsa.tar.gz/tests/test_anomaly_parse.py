# -*- coding: utf-8 -*-
"""anomaly_parse (DA skill v0.87) — 异动 payload schema 错配修复的回归测试。

病根 (2026-09-26 实测 642 payload):
  futu 异动 provider 返回 {"data": {err_code, retMsg, time_range, content}},
  data 是 DICT (content 是中文异动文本), 旧代码当 LIST 用:
    has_anomaly = bool(dict) → 恒 True (err_code=1「无异常」也报 True, 122 次假阳)
    count = len(...) if isinstance(list) else 0 → 恒 0
    渲染 len(dict) = 4 → prompt 恒报「4条异动」
    content → 从不读取, 474/642 (74%) 有效异动文本被静默丢弃
"""
import os
import sys

import pytest

SKILL_SCRIPTS = "/root/.hermes/skills/deep-stock-analysis/scripts"
sys.path.insert(0, SKILL_SCRIPTS)

anomaly_parse = pytest.importorskip("anomaly_parse", reason="DA skill scripts 不可达")


def _payload(err_code, content, ret_msg="success", time_range="近7个自然日"):
    return {"data": {"err_code": err_code, "retMsg": ret_msg,
                     "time_range": time_range, "content": content}}


class TestParsePayload:
    def test_dict_payload_not_treated_as_list(self):
        """旧 bug 核心: dict 不再被 bool() 成 has_anomaly=True / count=0。"""
        p = anomaly_parse.parse_anomaly_payload(_payload(0, "[timestamp: 1790136000]\n收盘价跌破MA5。"))
        assert p["status"] == "ok"
        assert p["count"] == 1            # 真实条数, 不是 0
        assert "跌破MA5" in p["items"][0]  # content 真被读取

    def test_no_anomaly_reports_empty_not_true(self):
        """err_code=1「无异常」必须 empty, 不得谎报 has_anomaly (旧代码 122 次假阳)。"""
        p = anomaly_parse.parse_anomaly_payload(
            _payload(1, "", ret_msg="资金面异动无异常"))
        assert p["status"] == "empty"
        assert p["count"] == 0
        assert p["items"] == []

    def test_provider_error_distinct_from_empty(self):
        """err_code=-12301 = 采集失败, 必须与「无异动」严格区分 (缺数据不编数据)。"""
        p = anomaly_parse.parse_anomaly_payload(_payload(-12301, "", ret_msg=""))
        assert p["status"] == "error"
        assert "err_code" in (p["detail"] or "")

    def test_missing_payload_is_error(self):
        assert anomaly_parse.parse_anomaly_payload({})["status"] == "error"
        assert anomaly_parse.parse_anomaly_payload(None)["status"] == "error"

    def test_multiple_bracket_ts_items(self):
        """[timestamp:] 块逐条切分 (tech/cap 主格式, 实测 260/260 命中)。"""
        c = ("[timestamp: 1790136000]\n跌破MA5。\n"
             "[timestamp: 1790049600]\nMA10跌破MA20死叉。\n"
             "[timestamp: 1789963200]\nAR转入超卖。")
        p = anomaly_parse.parse_anomaly_payload(_payload(0, c))
        assert p["count"] == 3
        assert all("[ts " in it for it in p["items"])

    def test_deriv_date_prefixed_items(self):
        """期权大单 "9.24 03:40，…" 行首格式 (deriv 主格式)。"""
        c = ("期权大单异动：\n"
             "9.24 03:40，出现一笔卖出看涨期权交易，成交量为1079张。\n"
             "9.24 02:51，出现一笔卖出看涨期权交易，成交量为1405张。")
        p = anomaly_parse.parse_anomaly_payload(_payload(0, c))
        assert p["count"] == 2                       # 标题行不计入
        assert "卖出看涨" in p["items"][0]

    def test_mixed_format_single_pass(self):
        """deriv 实测混合格式: 标题 + 日期行 + bracket 块, 单遍都要切对。"""
        c = ("期权大单异动：\n9.24 03:40，卖出一笔看涨。\n"
             "[timestamp: 1790917200]\n看涨期权在160附近成交集中。")
        p = anomaly_parse.parse_anomaly_payload(_payload(0, c))
        assert p["count"] == 2

    def test_cap_budget_and_omitted_counted(self):
        """超出 MAX_ITEMS 显式标注条数, 不静默截断。"""
        c = "\n".join(f"[timestamp: {1790000000 + i * 86400}]\n异动描述{i}。" for i in range(20))
        p = anomaly_parse.parse_anomaly_payload(_payload(0, c))
        assert p["count"] == 20
        assert len(p["items"]) == anomaly_parse.MAX_ITEMS
        assert p["omitted"] == 20 - anomaly_parse.MAX_ITEMS

    def test_item_clip_length(self):
        c = "[timestamp: 1790136000]\n" + ("长" * 400)
        p = anomaly_parse.parse_anomaly_payload(_payload(0, c))
        assert len(p["items"][0]) <= anomaly_parse.MAX_ITEM_CHARS + 1

    def test_content_without_markers_kept(self):
        """切不出条目时整段保留 (不丢数据)。"""
        p = anomaly_parse.parse_anomaly_payload(_payload(0, "主力资金近5日持续净流入，减缓流入。"))
        assert p["count"] >= 1 and "主力资金" in p["items"][0]


class TestRenderSection:
    def test_render_shows_items_and_labels(self):
        collected = {
            "tech_anomaly": _payload(0, "[timestamp: 1790136000]\n跌破MA5、MA10和MA30。"),
            "cap_anomaly": _payload(1, "", ret_msg="资金面异动无异常"),
            "deriv_anomaly": {"_error": "boom"},
        }
        sec = anomaly_parse.render_anomaly_section(collected)
        assert "## 异动信号" in sec
        assert "技术面异动: 1条" in sec
        assert "跌破MA5" in sec                     # 真实文本进 prompt
        assert "资金面异动: 无异动" in sec            # 不谎报条数
        assert "衍生品异动: 采集失败" in sec          # 失败与无异常区分

    def test_render_never_reports_dict_key_count(self):
        """旧 bug: len(dict)=4 → 恒报「4条异动」。任何 payload 都不得出现该谎报。"""
        collected = {"tech_anomaly": _payload(1, "", ret_msg="技术面异动无异常"),
                     "cap_anomaly": _payload(1, "", ret_msg="资金面异动无异常"),
                     "deriv_anomaly": _payload(1, "", ret_msg="衍生品异动无异常")}
        sec = anomaly_parse.render_anomaly_section(collected)
        assert "4条异动" not in sec
        assert sec.count("无异动") == 3

    def test_render_missing_keys_degrades_honestly(self):
        sec = anomaly_parse.render_anomaly_section({})
        assert sec.count("采集失败") == 3
        assert "条异动" not in sec


class TestDeepAnalyzerWiring:
    def test_analyze_anomalies_uses_shared_parser(self):
        """deep_analyzer._analyze_anomalies 必须走同一真源 (双尺子=口径漂移)。"""
        deep_analyzer = pytest.importorskip("deep_analyzer")
        import inspect
        src = inspect.getsource(deep_analyzer.DeepAnalyzer._analyze_anomalies)
        assert "parse_anomaly_payload" in src, "未使用共享解析器 (尺子分叉)"
        assert 'data.get("data", [])' not in src, "旧的 list 错配逻辑仍在"

    def test_llm_synth_renders_via_shared_helper(self):
        llm_synth_src = open(os.path.join(SKILL_SCRIPTS, "llm_synth.py"), encoding="utf-8").read()
        assert "render_anomaly_section" in llm_synth_src
        assert 'len(adata)}条异动' not in llm_synth_src, "旧的 dict 键数谎报仍在"

    def test_end_to_end_orcl_20260924(self):
        """真实产物回归: 9/24 ORCL 包 (原报告 P2-9 的现场)。"""
        p = "/opt/ftseek/FTSeek-US/data/da_checkpoint/2026-09-24/US.ORCL.raw.json"
        if not os.path.exists(p):
            pytest.skip("ORCL checkpoint 不在 (10 天保留)")
        import json
        collected = json.load(open(p))["collected"]
        sec = anomaly_parse.render_anomaly_section(collected)
        assert "4条异动" not in sec
        assert "跌破MA5" in sec            # 9/23 技术破位 (与当日 BUY 冲突) 恢复
        assert "卖出看涨期权" in sec        # 事件当晚机构卖 call 恢复
        assert "资金面异动: 无异动" in sec   # err_code=1 如实报
