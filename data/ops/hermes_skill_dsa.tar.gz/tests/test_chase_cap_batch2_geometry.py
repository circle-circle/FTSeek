#!/usr/bin/env python3
"""chase_cap 第2批几何一致性 — 机检 + prompt 三处同步的钉 (2026-10-17, RFC-144).

病灶 (实测): 计划写两腿 (第1批低吸 + 第2批突破追入), 而 cap 落在第2批触发价内侧 ⇒
价格必须先越过 P2 才触发第2批, 越过 P2 即越过 cap ⇒ 该腿**结构上永不执行**。
实证: 10/16 US.CMC cap=66.50 vs 第2批 MA60 67.53 (该指令空转 25 轮);
      10/15 US.REAL cap=9.5 vs 9.60 (整日 0 成交, 终态 skip_reason=chase_cap_enforced)。

本文件钉四件事:
  1. 机检命中真实形态 (含"突破MA60(67.53)"均线括号形态 + 个位数价格 + SHORT 下破动词);
  2. 不误报自洽/单腿/"第2批是回踩腿"/止盈价 (宁漏不误);
  3. 机检**只报告不 repair** (零字段改动 — 改 cap = 改交易决策, 属门禁范畴);
  4. prompt 三处 (SYSTEM 几何条款 / 字段语义 / 挑战者核验项) 都已同步 — 防未来改 prompt 时漏掉一处,
     漏掉会让"教模型自洽"失效而机检单独存在 (模型不知道 = 违约率不会降)。

回滚: 删本文件即可 (纯测试, 零生产依赖)。
"""
import copy
import sys
from pathlib import Path

import pytest

_SKILL = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(_SKILL / "scripts"))

import llm_synth as m  # noqa: E402

_SRC = (_SKILL / "scripts" / "llm_synth.py").read_text(encoding="utf-8")


def _result(cap, entry, es, direction):
    return {
        "direction": direction,
        "execution_plan": {
            "chase_cap_price": cap,
            "entry_price": entry,
            "entry_strategy": es,
            "stop_loss": entry * 0.95 if direction == "BUY" else entry * 1.05,
            "take_profit": entry * 1.1 if direction == "BUY" else entry * 0.9,
        },
        "tripwires": [],
        "bull_case": [{"claim_type": "fundamental", "evidence": "x"},
                      {"claim_type": "technical", "evidence": "y"}],
        "bear_case": [],
    }


def _b2_violations(cap, entry, es, direction):
    v = m._validate_output_contract(_result(cap, entry, es, direction)).get("violations") or []
    return [x for x in v if "batch2" in x]


def test_cmc_shape_hits_ma_parenthesised_level():
    """实证 10/16 CMC: cap 66.50 < 第2批 '放量突破MA60(67.53)' → 命中。"""
    out = _b2_violations(66.50, 64.68,
                         "分2批建仓：第1批在回踩MA5(64.68)时限价低吸；"
                         "第2批在放量突破MA60(67.53)时右侧追入确认趋势", "BUY")
    assert len(out) == 1 and "67.53" in out[0] and "66.50" in out[0]


def test_real_shape_hits_single_digit_price():
    """实证 10/15 REAL: cap 9.5 < 第2批 突破$9.60 → 命中 (个位数价格必须支持)。"""
    out = _b2_violations(9.5, 9.3,
                         "第1批：突破$9.30(MA20上方)且15分钟成交量>30,000股时买入50%；"
                         "第2批：突破$9.60(MA5附近)且维持高位时买入50%", "BUY")
    assert len(out) == 1 and "9.60" in out[0]


def test_short_shape_hits_downward_verb():
    """SHORT 的第2批是'向下跌破' — 用 BUY 的动词表会漏报 (2026-10-17 实测漏一次)。"""
    out = _b2_violations(302.0, 298.0,
                         "第1批在$298限价做空；第2批：下破$295.5时加空", "SELL_SHORT")
    assert len(out) == 1 and "295.50" in out[0]


@pytest.mark.parametrize("cap,entry,es,direction,why", [
    (68.0, 64.68, "第1批回踩MA5(64.68)低吸；第2批在放量突破MA60(67.53)时追入", "BUY", "自洽: cap≥P2"),
    (66.5, 64.68, "第1批在回踩MA5(64.68)时限价低吸, 不加仓", "BUY", "单腿: 无第2批"),
    (66.5, 64.68, "第1批在突破67.53时追入；第2批：若冲高回落回踩MA5($64.02)企稳, 限价$64.05低吸", "BUY",
     "第2批是回踩腿, 不是向上触发"),
    (66.5, 64.68, "第1批回踩MA5(64.68)低吸；第2批在放量突破MA60(67.53)时追入, 上看 72.0", "BUY",
     "止盈价不得被当触发价 (本例只应报 67.53 那条)"),
])
def test_no_false_positive(cap, entry, es, direction, why):
    out = _b2_violations(cap, entry, es, direction)
    if why == "自洽: cap≥P2" or why.startswith("单腿") or why.startswith("第2批是回踩"):
        assert out == [], f"{why} 误报: {out}"
    else:  # 该例本身有真冲突(67.53), 但不得把 72.0 也列进来
        assert len(out) == 1 and "72" not in out[0]


def test_missing_cap_or_strategy_not_judged():
    """取不到 cap / entry_strategy → 不判 (宁漏不误)。"""
    for cap, es in ((None, "第2批突破 67.53 追入"), (66.5, None)):
        r = _result(cap, 64.68, es, "BUY")
        if es is None:
            r["execution_plan"].pop("entry_strategy", None)
        v = m._validate_output_contract(r).get("violations") or []
        assert not [x for x in v if "batch2" in x]


def test_record_only_no_field_mutation():
    """机检只报告不 repair: 调用前后 result 逐字不变 (改 cap = 改交易决策, 属门禁范畴)。"""
    r = _result(66.50, 64.68, "第1批回踩MA5(64.68)低吸；第2批在放量突破MA60(67.53)时追入", "BUY")
    before = copy.deepcopy(r)
    m._validate_output_contract(r)
    assert r == before


def test_prompt_no_longer_teaches_executable_second_leg():
    """2026-10-23 单批执行契约: 模型可见 Prompt 不再教第二腿; 机检保留作遗留兜底。"""
    assert "第2批" not in m.SYSTEM_PROMPT
    assert "第2批" not in m.effective_user_template()
    assert "第二腿" in m.SYSTEM_PROMPT and "不会执行" in m.SYSTEM_PROMPT
    assert "第二腿(2026-10-23)" in _SRC
    assert "cap=null 是正确输出" in _SRC, "null 语义澄清缺失 (自造帽的根因面)"
    # 机检本体与只报告纪律 (保留, 用于旧计划/人工输入兜底)
    assert "chase_cap_vs_batch2_conflict" in _SRC
    assert "direction == \"BUY\" and max(_lvl_b2) > _cap_ic" in _SRC
    assert "direction == \"SELL_SHORT\" and min(_lvl_b2) < _cap_ic" in _SRC