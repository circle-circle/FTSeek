#!/usr/bin/env python3
"""Prompt 只承诺当前执行能力: 单一首批/执行锚, 不承诺第二腿/限价单 (2026-10-23)."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "scripts"))

import llm_synth  # noqa: E402


def test_no_mandatory_two_batch_language():
    text = llm_synth.SYSTEM_PROMPT + llm_synth.effective_user_template()
    assert "至少2批" not in text
    assert "必须分批" not in text


def test_single_executable_first_batch_is_explicit():
    text = llm_synth.SYSTEM_PROMPT + llm_synth.effective_user_template()
    assert "只写1个可执行首批" in text
    assert "当前执行端只按单一首批/执行锚下单" in text
    assert "confirmation 是研究确认位, 不是限价单" in text
    assert "不写第二个可执行触发价" in text
    assert "第2批" not in text


def test_confirmation_is_research_not_order():
    text = llm_synth.effective_user_template()
    assert "不是订单" in text
    assert "限价单有效分钟数" not in text
    assert "执行端使用自己的确认窗" in text


def test_chase_cap_is_preserved():
    text = llm_synth.SYSTEM_PROMPT + llm_synth.effective_user_template()
    assert "chase_cap" in text
    assert "cap=null 是正确输出" in text


def test_prompt_hash_is_recomputed_from_current_text():
    assert llm_synth.PROMPT_HASH == llm_synth._prompt_fingerprint(
        llm_synth.SYSTEM_PROMPT, llm_synth.effective_user_template(),
        llm_synth._SAMPLING_TAG)
