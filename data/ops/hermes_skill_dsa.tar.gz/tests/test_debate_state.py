#!/usr/bin/env python3
"""挑战者裁决规范状态 + merge 回归 (2026-10-23)."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "scripts"))

import debate_state as ds  # noqa: E402


def test_partial_is_not_upgraded_by_agreed_boolean():
    r = ds.classify_debate("BUY", "BUY", "PARTIAL_AGREE", True)
    assert r["state"] == "PARTIAL_AGREE"
    assert r["priority"] == 6


def test_analyst_skip_wins_even_if_challenger_unavailable():
    assert ds.classify_debate("SKIP", None, None, False)["state"] == "ANALYST_SKIP"


def test_abstain_priority_over_raw_disagree():
    assert ds.classify_debate("BUY", "SKIP", "DISAGREE", True)["state"] == "ABSTAIN"


def test_unavailable_is_not_abstain():
    assert ds.classify_debate("BUY", None, None, False)["state"] == "UNAVAILABLE"


def test_mismatch_is_conflict():
    assert ds.classify_debate("BUY", "BUY", "DISAGREE", True)["state"] == "CONFLICT"
    assert ds.classify_debate("BUY", "SELL_SHORT", "AGREE", True)["state"] == "CONFLICT"
    assert ds.classify_debate("BUY", None, "AGREE", True)["state"] == "CONFLICT"


def test_merge_partial_keeps_canonical_not_agreed(monkeypatch):
    import llm_synth
    monkeypatch.setenv("DA_SCORE_BAND", "1")
    initial = {"direction": "BUY", "score": 8.0, "confidence": "中",
               "risks": [], "bull_case": [], "bear_case": []}
    challenge = {"my_direction": "BUY", "my_score_band": "HIGH",
                 "agreed": True, "verdict": "PARTIAL_AGREE",
                 "missed_risks": ["硬伤"], "challenged_claims": []}
    out = llm_synth._merge_debate_results(initial, challenge)
    assert out["_debate"]["challenger_verdict_state"] == "PARTIAL_AGREE"
    assert out["_debate"]["challenger_agreed"] is False
    assert out["_debate"]["challenger_agreed_raw"] is True
    assert out["confidence"] == "中"  # 不再因 agreed=true 提升
    assert "AGREE" not in str(out.get("debate_outcome", "")).upper()


def test_merge_agree_raises_confidence(monkeypatch):
    import llm_synth
    monkeypatch.setenv("DA_SCORE_BAND", "1")
    initial = {"direction": "BUY", "score": 8.0, "confidence": "中",
               "risks": [], "bull_case": [], "bear_case": []}
    challenge = {"my_direction": "BUY", "my_score_band": "HIGH",
                 "agreed": False, "verdict": "AGREE",
                 "missed_risks": [], "challenged_claims": []}
    out = llm_synth._merge_debate_results(initial, challenge)
    assert out["_debate"]["challenger_verdict_state"] == "AGREE"
    assert out["_debate"]["challenger_agreed"] is True
    assert out["confidence"] == "中高"


def test_debate_state_rollback_keeps_legacy_agreed(monkeypatch):
    import llm_synth
    monkeypatch.setenv("DA_SCORE_BAND", "1")
    monkeypatch.setenv("DA_DEBATE_STATE_FIX", "0")
    initial = {"direction": "BUY", "score": 8.0, "confidence": "中",
               "risks": [], "bull_case": [], "bear_case": []}
    challenge = {"my_direction": "BUY", "my_score_band": "HIGH",
                 "agreed": True, "verdict": "PARTIAL_AGREE",
                 "missed_risks": [], "challenged_claims": []}
    out = llm_synth._merge_debate_results(initial, challenge)
    assert out["_debate"]["challenger_verdict_state"] == "LEGACY"
    assert out["_debate"]["challenger_agreed"] is True
    assert out["confidence"] == "中高"
