import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "scripts"))

import data_collector as dc
import llm_synth as ls
import market_scanner as ms


def test_premarket_fundamental_uses_effective_price_and_timestamp():
    snapshot = {
        "session": "premarket",
        "last_price": 74.6204,
        "prev_close": 74.6204,
        "pre_price": 91.21,
        "pre_change_rate": 22.232,
        "effective_price": 91.21,
        "effective_chg_pct": 22.23,
        "update_time": "2026-11-06 08:32:05.322",
    }
    view = ls._fundamental_view(snapshot)
    assert view["effective_price"] == 91.21
    assert view["change_pct"] == 22.23
    assert view["price_as_of"] == "2026-11-06 08:32:05.322"
    prompt = ls._format_data_for_prompt({"snapshot": snapshot})
    assert "当前价格: $91.21" in prompt
    assert "涨跌幅(有效价 vs 昨收): +22.2%" in prompt


def test_missing_premarket_price_is_na_not_zero():
    snapshot = {
        "session": "premarket",
        "last_price": 100.0,
        "prev_close": 100.0,
        "pre_price": 0,
        "effective_price": 100.0,
        "effective_chg_pct": 0.0,
    }
    view = ls._fundamental_view(snapshot)
    assert view["effective_price"] is None
    assert view["change_pct"] is None
    prompt = ls._format_data_for_prompt({"snapshot": snapshot})
    assert "当前价格: 数据未采集(N/A)" in prompt
    assert "涨跌幅(有效价 vs 昨收): 数据未采集(N/A)" in prompt


def test_industry_collection_keeps_peers_and_requires_six_closes(monkeypatch):
    monkeypatch.setattr(dc, "_IP_CACHE", {})
    monkeypatch.setattr(dc, "collect_company_profile", lambda symbol: {"industry": "Software"})
    monkeypatch.setattr(dc, "_finnhub_get", lambda *args: ["AAA", "BBB"])
    kline_requests = []

    def snapshot(symbol):
        if symbol.endswith("BBB"):
            return {"_error": "timeout"}
        return {
            "session": "premarket",
            "last_price": 100.0,
            "prev_close": 100.0,
            "pre_price": 110.0,
            "effective_price": 110.0,
            "effective_chg_pct": 10.0,
            "update_time": "2026-11-09 08:30:00",
            "pe_ttm_ratio": 20.0,
            "total_market_val": 1_000_000_000,
        }

    def kline(symbol, ktype, num):
        kline_requests.append((symbol, num))
        count = 5 if symbol.endswith("BBB") else 6
        return [{"close": value} for value in [100, 101, 102, 103, 104, 110][:count]]

    monkeypatch.setattr(dc, "collect_snapshot", snapshot)
    monkeypatch.setattr(dc, "collect_kline", kline)
    result = dc.collect_industry_peers("US.TEST")

    assert result["peer_count"] == 2
    assert len(result["peers"]) == 2
    assert {symbol for symbol, _ in kline_requests} == {"US.AAA", "US.BBB"}
    assert all(num == 6 for _, num in kline_requests)
    assert result["industry_avg_chg_today_pct"] == 10.0
    assert result["industry_avg_chg_5d_pct"] == 10.0
    assert result["industry_chg_today_sample_count"] == 1
    assert result["industry_chg_5d_sample_count"] == 1
    unavailable = next(peer for peer in result["peers"] if peer["symbol"] == "BBB")
    assert unavailable["price"] is None
    assert unavailable["chg_pct"] is None
    assert unavailable["chg_5d_pct"] is None
    assert unavailable["session"] is None


def test_industry_aggregation_does_not_treat_missing_as_zero():
    peers = [
        {"symbol": "AAA", "chg_pct": None, "chg_5d_pct": None},
        {"symbol": "BBB", "chg_pct": -2.0, "chg_5d_pct": 4.0},
    ]
    result = dc._ip_done("Software", peers)
    assert result["peer_count"] == 2
    assert result["industry_avg_chg_today_pct"] == -2.0
    assert result["industry_avg_chg_5d_pct"] == 4.0
    assert result["industry_trend"] == {"today": "DOWN", "five_day": "UP", "combined": "MIXED"}
    empty = dc._ip_done("Software", [{"symbol": "CCC", "chg_pct": None, "chg_5d_pct": None}])
    assert empty["industry_avg_chg_today_pct"] is None
    assert empty["industry_trend"]["combined"] == "UNKNOWN"


def test_legacy_industry_values_are_not_rendered_as_verified():
    collected = {
        "industry_peers": {
            "industry": "Software",
            "peer_count": 1,
            "peers": [{"symbol": "AAA", "price": 100.0, "chg_pct": 0.0, "chg_5d_pct": 99.0, "pe": 20.0}],
            "industry_avg_chg_today_pct": 0.0,
            "industry_avg_chg_5d_pct": 99.0,
        }
    }
    prompt = ls._format_data_for_prompt(collected)
    industry = prompt.split("## 行业对比", 1)[1]
    assert "AAA" in industry
    assert "PE=20.0" in industry
    assert "99.0%" not in industry
    assert "旧版行业价格/涨跌缺少时点与6根日K证据" in industry
    assert "今日数据未采集(N/A) 5日数据未采集(N/A)" in industry


def test_scanner_missing_change_does_not_drop_candidate(monkeypatch):
    scanner = ms.MarketScanner("US", 10)
    monkeypatch.setattr(dc, "collect_snapshot", lambda symbol: {
        "session": "premarket",
        "last_price": 100.0,
        "prev_close_price": 0.0,
        "pre_price": 101.0,
        "effective_price": 101.0,
        "effective_chg_pct": None,
        "pre_change_rate": 0.0,
    })
    monkeypatch.setattr(dc, "collect_kline", lambda *args: [])
    row = scanner._four_signal_score("US.TEST", {"code": "US.TEST"})
    assert row["symbol"] == "US.TEST"
    assert row["change_pct"] is None

    buckets = scanner._bucketing([row])
    assert sum(len(items) for items in buckets.values()) == 1
    assert "1未知" in scanner._market_narrative([row])
    assert "N/A" in scanner._sector_narrative([row], {})


def test_failed_peer_collection_is_not_cached(monkeypatch):
    cache = {}
    monkeypatch.setattr(dc, "_IP_CACHE", cache)
    result = dc._ip_done("Software", [{
        "symbol": "AAA", "price": None, "chg_pct": None, "chg_5d_pct": None,
        "snapshot_status": "unavailable",
    }])
    assert result["peer_count"] == 1
    assert cache == {}
