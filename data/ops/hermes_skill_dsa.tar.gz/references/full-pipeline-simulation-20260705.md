# 3股全链路模拟验证 — 2026-07-05

## 背景

用户要求用MU/CVNA/MRVL三只股票模拟全链路交易，从筛选→评分→投票→过程→结果→记录详细说明每阶段。目的是真正了解当前真实的流程和逻辑，双方检测优化点。

用户偏好: "模型批量输出那说明结果是不可靠的，真正根据每只股不同的情况进行深度分析非常重要，可以开启thinking 时间可以不限制 充分思考给出有价值的推理 要质量先不关注成本"

## 执行环境

- 时间: 2026-07-05 22:54 ET (周日，美股休市，数据锚7/2收盘)
- 命令: `pipeline.py --mode analyze --symbol US.MU/CVNA/MRVL --synth llm`
- 三只并行执行，每只约15秒完成

## Stage 1: 市场扫描 (market_scanner)

scanner扫描87只候选（涨幅榜30+跌幅榜30+量榜30去重），用_quick_score打分排序。

| 股票 | 扫描排名 | 扫描评分 | 扫描信号 | 是否进Top |
|------|---------|---------|---------|----------|
| MU | 66/87 | ~5.0 | 观望列表外 | ❌ |
| CVNA | 38/87 | ~5.5 | 观望列表外 | ❌ |
| MRVL | 78/87 | **3.5** | **做空Top 3**: 空头排列+5日-12.8% | ✅(做空侧) |

实际Top 10做多: HOOD(6.9) > SPGI/IBM/SCHW/MSFT/BAC(6.5) > AJG/AAPL/MCO(6.4) > AZN(6.3)
实际Top 4做空: TRP(4.0) > F(3.5) > MRVL(3.5) > NOK(3.2)

**关键观察**: MRVL进了做空Top3（空头排列+5日-12.8%），但LLM后续却给出BUY方向——scanner和LLM方向冲突。

## Stage 2: 数据采集 (data_collector.collect_all)

每只股票采集16个数据源。pipeline输出 `[Pipeline] 数据质量: {'total': 16, 'ok': 16, 'failed': 0}`

| 股票 | 完整 | 降级 | 缺失 | 关键异常 |
|------|------|------|------|---------|
| MU | 16 | 0 | 0 | PE(TTM)=0/EPS=0矛盾；52周高低=0；市值=0 |
| CVNA | 15 | 1 | 0 | earnings_calendar空壳；PE(TTM)=0/EPS=0 |
| MRVL | 16 | 0 | 0 | PE(TTM)=0/EPS=0；52周高低=0 |

### 关键数据快照

| 指标 | MU | CVNA | MRVL |
|------|------|------|------|
| 价格 | $975.56 | $68.60 | $245.29 |
| 涨跌(7/2) | -5.49% | +1.08% | -9.84% |
| 成交量 | 61.8M | 8.4M | 38.6M |
| 换手率 | 5.69% | 1.19% | 4.42% |
| PE(动态) | 128.5 | 40.6 | 79.9 |
| PE(TTM) | 22.1 | 39.7 | 84.3 |
| PB | 10.9 | 13.2 | 11.8 |
| 市值 | $1.1T | N/A | $215B |
| 52周位置 | 75.7% | N/A | N/A |

## Stage 3: LLM深度分析 (deep_analyzer → llm_synth)

### MU（美光科技）— 方向: SKIP（观望）

| 维度 | 内容 |
|------|------|
| 评级 | 观望（中信心）｜评分 5/10 |
| 结论 | AI周期上行确认但PE 128.5x+MSPR-24.33+Burry做空构成估值与内部人背离风险，观望至$950支撑企稳 |
| 看多① | 营收YoY+166.98%，净利率55.91%，ROE 70.55%——AI驱动HBM需求爆发（HIGH，earnings_beat） |
| 看多② | DBS目标$1400/Cantor目标$2000，55位分析师92.7%维持买入（MEDIUM，product_catalyst） |
| 看多③ | volume_expansion IC=+0.297历史验证有效，换手率5.69%（MEDIUM，technical_breakout） |
| 看空① | 动态PE 128.5x远高于半导体中枢（HIGH，valuation_expensive） |
| 看空② | MSPR=-24.33，CEO Mehrotra 5/29连续4笔减持均价~$977（HIGH，insider_bearish） |
| 看空③ | Michael Burry公开做空+散户92.7%买入占比拥挤（MEDIUM，sentiment_crowded） |
| 约束① | 财报日2026-06-24距今-11天（已过期但系统标注异常） |
| 约束② | 历史LONG 0胜PnL=-$216，LONG+SL_ATR_STOP亏损-$5474 |
| 因果链 | AI算力需求激增→HBM供不应求→营收+167%→PE推升至128.5x→MSPR-24.33+Burry做空→估值与内部人背离→回调至$975等待财报验证 |
| 入场 | $950（MA60附近），第2批$1043（MA20回踩） |
| 止损 | $920 ｜ 目标 $1140 ｜ 盈亏比 6.33 |
| 溯源 | 24 verified / 26 unverified——星展银行$1400目标价被flagged（3次重复标记） |

### CVNA（Carvana）— 方向: BUY（看多）

| 维度 | 内容 |
|------|------|
| 评级 | 看多（中高信心）｜评分 7/10 |
| 结论 | 营收YoY+51.7%+ROE 51.6%验证规模效应拐点，但MSPR=-58.57净卖出+估值天花板，回调至$66-67分批试多 |
| 看多① | 营收+51.72%，净利率6.4%，ROE 51.6%——规模效应拐点（HIGH，earnings_beat） |
| 看多② | YieldMax CVNA期权收入ETF连续周派息$0.28-$0.29，做市商对冲Delta被迫买入正股（MEDIUM，product_catalyst） |
| 看多③ | 32位分析师68.8%买入，BTIG目标$97(+41.4%)（MEDIUM，sentiment_crowded） |
| 看空① | MSPR=-58.57深度净卖出，SEC文件减持合计$778万（HIGH，insider_bearish） |
| 看空② | PE 40.6x/PB 13.2x远超零售行业中枢(PE<20/PB<3)（HIGH，valuation_expensive） |
| 看空③ | 当前$68.6距目标均值仅+36%，Beta=3.47下行放大3.5倍（MEDIUM，valuation_expensive） |
| 约束① | 财报日历降级（空壳），无法预判业绩窗口 |
| 约束② | 30天LONG胜率42% PnL=-$3187 |
| 因果链 | 二手车在线渗透率提升→单位经济模型转正→ROE 51.6%吸引机构但内部人趁高位减持→ETF对冲买盘支撑但估值天花板限制→回调至$66-67最优入场点 |
| 入场 | $66.75（MA20），第2批$64-65（前低） |
| 止损 | $61.85 ｜ 目标 $88 ｜ 盈亏比 4.34 |
| conditions | news_positive, sentiment_bullish |

### MRVL（迈威尔科技）— 方向: BUY（看多）

| 维度 | 内容 |
|------|------|
| 评级 | 看多（中高信心）｜评分 7/10 |
| 结论 | 营收YoY+34%+瑞银目标$340确认AI互连独占性，但MSPR=-23.74+PE 79.9限制反弹，分批承接 |
| 看多① | 瑞银/斯迪富上调目标至$340/$350，数据中心高速互连为独有增长引擎（HIGH，product_catalyst） |
| 看多② | 营收+34.07%，净利率28.99%，毛利51.5%——AI定制芯片高毛利兑现（HIGH，earnings_beat） |
| 看多③ | 49位分析师85.7%买入(42人)，强烈看空=0（MEDIUM，sentiment_crowded） |
| 看空① | MSPR=-23.74，高管Durn/Murphy在$281-$298减持（HIGH，insider_bearish） |
| 看空② | PE 79.9x/PB 11.8x远超半导体中枢4-6倍（MEDIUM，valuation_expensive） |
| 看空③ | 7/2放量暴跌-12.8%击穿MA20($282)与MA10($281)，技术破位（MEDIUM，technical_breakdown） |
| 约束① | TTM EPS=0导致PE(TTM)失效，盈利波动风险被掩盖 |
| 约束② | Beta=2.23高波动，仓位需压缩至常规1/2 |
| 因果链 | 瑞银上调目标→确认AI互连独占性→营收+34%验证→当前$245较目标-25.7%有安全边际→但MSPR+PE限制反弹→需$237支撑确认 |
| 入场 | $237.2（7/2低点），第2批需站稳MA60($208.6)+量>4000万 |
| 止损 | $198 ｜ 目标 $282 ｜ 盈亏比 1.14 |
| conditions | news_positive, revenue_growth_high, sentiment_bullish |

## Stage 4: IC写入 (ic_writer.write_signal_snapshot)

三只信号成功写入signal_snapshots.db。

| 股票 | decision_id | direction | strength | claim_types | alpha_t1 |
|------|-------------|-----------|----------|-------------|----------|
| MU | DA-20260705225437-US.MU-da77 | NEUTRAL | 50 | earnings_beat, product_catalyst, technical_breakout, valuation_expensive, insider_bearish, sentiment_crowded | None |
| CVNA | DA-20260705225433-US.CVNA-da73 | LONG | 70 | earnings_beat, product_catalyst, sentiment_crowded, insider_bearish, valuation_expensive×2 | None |
| MRVL | DA-20260705225439-US.MRVL-da79 | LONG | 70 | product_catalyst, earnings_beat, sentiment_crowded, insider_bearish, valuation_expensive, technical_breakdown | None |

alpha_t1=None——需等7/6周一FTSeek backfill cron运行后回填SPY收盘价并计算alpha。

**DB验证**: `SELECT decision_id, symbol, direction, strength FROM signal_snapshots WHERE strategy_id='deep_analysis' ORDER BY created_at DESC LIMIT 3` 确认三条记录均存在。

## Stage 5: 信号门禁 (signal_gate.evaluate_signal)

| 股票 | 质量分 | 决策 | 仓位 | 推荐退出 | 盈亏比 | 关键问题 |
|------|--------|------|------|---------|--------|---------|
| MU | 55 | WARN | small | EOD_FORCE_CLOSE | 6.33 | insider_net_sell IC<0 (-10分) |
| CVNA | 60 | WARN | small | EOD_FORCE_CLOSE | 4.34 | 匹配亏钱pattern LONG+SL_ATR_STOP(-$5474) + insider_net_sell IC<0 |
| MRVL | 50 | WARN | small | EOD_FORCE_CLOSE | 1.14 | 匹配亏钱pattern + insider_net_sell IC<0 + 盈亏比极差 |

三只全部WARN，全部small仓位。没有一只PASS。

### 门禁7维评估详情（以MRVL为例）

1. ✅ 个股历史：MRVL无历史交易记录
2. ⚠️ pattern匹配：匹配到赚钱pattern LONG+ORB_TAKE_PROFIT(2笔100% WR，但confidence=very_low) + 亏钱pattern LONG+SL_ATR_STOP(12笔 -$5474, confidence=low)
3. ✅ 信号质量：LLM score=7, confidence=0.7
4. ❌ 盈亏比：1.14（极差）
5. ✅ conditions完整：3个conditions
6. ✅ 退出效果推荐：EOD_FORCE_CLOSE(WR=82%, 34笔)
7. ❌ 论据有效性：使用了insider_net_sell(IC=-0.30, -10分) + news_positive(IC>0, +5分)

## 12个优化点详细分析

### 优化点1 (P1): scanner-LLM方向冲突无人检测

**现象**: MRVL scanner做空Top3（空头排列+5日-12.8%），但LLM输出BUY。signal_gate没有检查scanner_direction和llm_direction的一致性。

**风险**: 7/2半导体血洗场景下，scanner看到技术面破位给出做空信号，但LLM看到基本面催化（瑞银上调目标价）就翻多。两个视角都有道理但方向完全相反——用户不知道有冲突。

**修复建议**: Gate加scanner_direction一致性检查维度。不一致时不BLOCK但标注"⚠️ scanner方向(做空)与LLM方向(做多)冲突"并额外降5分。

### 优化点2 (P2): PE(TTM)=0/EPS=0系统性异常

**现象**: 三只股票OpenD快照API返回的EPS字段都是0，导致PE(TTM)=0。LLM在data_quality_note里注意到并改用PE(动态)，但这是静默替代。

**修复建议**: data_collector对EPS=0加降级标记，上报"快照EPS异常(=0)，使用Finnhub pe_normalized替代"。

### 优化点3 (P2): 52周高低=0未上报降级

**现象**: 三只股票52周高低都是0，LLM用K线60日数据推导替代（如MU推导$1255/$103.23）。

**修复建议**: 应上报为降级而非静默替代。52周数据缺失影响position_52w_pct计算。

### 优化点4 (P1): MRVL方向冲突的技术面vs基本面分歧

**现象**: scanner看技术面（空头排列+5日-12.8%→做空），LLM看基本面（瑞银上调+营收+34%→做多）。

**分析**: 不是bug但需在Gate标注。两种视角都有合理性——半导体血洗时技术面正确，但如果有强催化可能是抄底机会。关键是让用户知道分歧存在。

### 优化点5 (P1): LLM盈亏比无下限约束

**现象**: MRVL盈亏比仅1.14（入场$237.2，止损$198，目标$282 → 风险$39.2/收益$44.8），但LLM仍给BUY+7分。

**修复建议**: llm_synth prompt加约束"盈亏比<1.5时不得输出BUY/SELL_SHORT，应降级为SKIP或调整入场/止损/目标价"。

### 优化点6 (P2): 过期财报日未清洗

**现象**: MU财报日2026-06-24，系统标注"距今-11天（已过期）"，但仍作为约束列出。

**修复建议**: data_collector清洗过期财报日期。如果next_earnings_date < today，标记为"已过期，需刷新"并尝试从Finnhub重新获取。

### 优化点7 (P1): LLM论据溯源率<50%

**现象**: MU 24/50 verified(48%)，CVNA 21/47 verified(45%)，MRVL 29/64 verified(45%)。超过一半的数字无法溯源到输入数据。被flagged的都是"星展银行目标价$1400"这类研报数字——LLM从新闻标题摘取数字当事实。

**分析**: 已有flagged_claims机制但LLM仍使用这些数字。当前flagged_claims只是标记不阻止。可考虑：flagged数字在prompt中标注"⚠️ 此数字来自新闻标题未经验证"。

### 优化点8 (P2): NEUTRAL方向的IC回填未确认

**现象**: MU direction=SKIP→adapter映射为NEUTRAL→ic_writer写入NEUTRAL。FTSeek backfill是否对NEUTRAL信号计算IC未确认。

**修复建议**: 查FTSeek backfill_forward_returns.py源码确认NEUTRAL处理逻辑。如果跳过NEUTRAL，则SKIP信号的IC永远不会被计算——可能需要改为计算绝对收益IC(不分方向)。

### 优化点9 (P2): claim_type重复不去重

**现象**: CVNA有6个claim_type但其中2个都是valuation_expensive（看空②和看空③）。ic_writer的_extract_claim_factors不做去重。

**影响**: 同一个claim_type出现多次会在中国共产党统计中双倍权重。应该去重或合并同类claim_type。

### 优化点10 (P1): pattern匹配非个股特定

**现象**: 三只从未交易过的股票（CVNA/MRVL无历史记录）都能匹配到LONG+ORB_TAKE_PROFIT和LONG+SL_ATR_STOP——这些是全市场通用的pattern，对个股没有参考价值。

**根因**: pattern_memory查询逻辑是direction+exit_reason+strength_bucket，没有按symbol过滤。

**修复建议**: 有个股历史时用个股pattern，无历史时明确标注"无个股特定pattern，使用全市场参考(置信度very_low)"并降低权重。当前Gate已经把very_low置信度的pattern加分从10降到5，但应该进一步：无个股历史时pattern匹配结果只提示不加分。

### 优化点11 (P2): 退出推荐未考虑个股波动率

**现象**: 三只都推荐EOD_FORCE_CLOSE——因为这是34笔WR=82%的最赚退出方式。但这个推荐是全市场通用的，没有考虑个股波动率。MRVL Beta=2.23+单日-12.8%，EOD_FORCE_CLOSE可能在高波动股票上不适用。

**修复建议**: 退出推荐加Beta过滤——Beta>2.0的高波动股，EOD_FORCE_CLOSE的"日内收盘前平仓"策略可能需要更紧的止损而非收盘前平仓。

### 优化点12 (P2): SKIP direction的pattern匹配分支不一致

**现象**: MU direction=SKIP→pattern_match=null（similar_win=null, similar_loss=null），而CVNA/MRVL direction=BUY→都有pattern匹配。

**分析**: 可能是SKIP→NEUTRAL映射后，pattern_memory查LONG/SHORT不匹配NEUTRAL。需确认signal_gate的pattern匹配逻辑对NEUTRAL的处理。

## 全链路数据流图（以MRVL为例）

```
Stage 1: market_scanner.scan()
  ├─ collect_top_volume/gainers/losers → 87候选
  ├─ _quick_score(MRVL) = 3.5  (空头排列+5日-12.8%+PE70高估-0.3)
  └─ 输出: 做空Top3

Stage 2: data_collector.collect_all("US.MRVL")
  ├─ OpenD: 快照/K线/资金流向/资金分布/异动 (6源)
  ├─ 富途HTTP: 新闻10/研报5/社区30 (3源)
  ├─ Finnhub: 基本面/分析师/内部人/MSPR/概况/财报 (6源)
  └─ 数据质量审计: 16/16 ok
      ⚠️ PE(TTM)=0, EPS=0, 52周高低=0, 市值=0

Stage 3: deep_analyzer.DeepAnalyzer(data).analyze()
  ├─ _get_trade_experience("US.MRVL") → 查trade_records
  │   └─ 30天LONG WR=42% PnL=-$3187 (注入LLM prompt)
  ├─ _load_claim_ic_for_prompt() → 读claim_ic_cache.json
  │   └─ "insider_net_sell IC=-0.30" (注入LLM prompt)
  ├─ llm_synth.synthesize(data, experience, claim_ic) → 调DashScope LLM
  │   └─ 输出JSON: direction=BUY, score=7, 6个claim_type标注论据
  ├─ _verify_sourced_numbers() → 29 verified/35 unverified
  └─ 输出: BUY, entry=$237.2, SL=$198, TP=$282

Stage 4: ic_writer.write_signal_snapshot(result)
  ├─ _get_et_trade_date() → 2026-07-02 (ET时区, 周日→前推到周四)
  ├─ _extract_claim_factors(result) → 6个factors (LLM标注claim_type)
  ├─ INSERT INTO signal_snapshots (decision_id=DA-...MRVL-da79)
  └─ FTSeek backfill cron将在7/6回填alpha_t1

Stage 5: signal_gate.evaluate_signal(result)
  ├─ 个股历史: MRVL无记录 → 0分
  ├─ pattern匹配: LONG+ORB_TAKE_PROFIT(+) + LONG+SL_ATR_STOP(-) → 0分
  ├─ 信号质量: score=7/confidence=0.7 → +15分
  ├─ 盈亏比: 1.14 → 0分 (差)
  ├─ conditions: 3个 → +5分
  ├─ 退出效果: EOD_FORCE_CLOSE推荐 → +5分
  ├─ 论据有效性: insider_net_sell IC<0(-10) + news_positive IC>0(+5) → -5分
  └─ 总分: 50 → WARN, small仓位
```

## 修复优先级排序

| 优先级 | 优化点 | 修复建议 | 影响面 |
|--------|--------|---------|--------|
| P1 | #1 scanner-LLM方向冲突 | Gate加scanner_direction一致性检查 | signal_gate.py |
| P1 | #5 盈亏比无下限 | LLM prompt加盈亏比>1.5约束 | llm_synth.py |
| P1 | #7 溯源率<50% | flagged数字在prompt标注"未经验证" | llm_synth.py |
| P1 | #10 pattern非个股特定 | 无个股历史时pattern只提示不加分 | signal_gate.py |
| P2 | #2 PE(TTM)=0 | data_collector加降级标记 | data_collector.py |
| P2 | #3 52周高低=0 | 上报为降级 | data_collector.py |
| P2 | #6 过期财报日 | data_collector清洗过期日期 | data_collector.py |
| P2 | #9 claim_type去重 | ic_writer加去重 | ic_writer.py |
| P2 | #11 退出推荐加Beta | signal_gate加Beta过滤 | signal_gate.py |
| P2 | #8 NEUTRAL IC | 确认FTSeek backfill行为 | 需查FTSeek源码 |
| P2 | #12 SKIP pattern分支 | 确认pattern匹配逻辑 | signal_gate.py |
