# FTSeek-US 交易表现分析方法论

> 2026-07-09 实盘查询验证。所有SQL基于真实数据库执行结果。

## 数据库路径（验证日期: 2026-07-09）

| DB路径 | 大小 | 用途 | 关键表 |
|--------|------|------|--------|
| `data/ftseek_us.db` | 8.2M | **主库**: 交易+持仓+信号+退出 | trade_records(403行), open_positions, signals, signal_lifecycle, failures, shadow_trades, order_tracking, performance_stats |
| `data/signal_snapshots.db` | 1.7M | IC+前向收益 | signal_snapshots, regime_history |
| `data/decisions.db` | 1.9M | 投票决策+模型票 | decisions, model_votes, trade_outcomes, capital_ledger |
| `data/rejections.db` | 980K | 信号拒绝记录 | rejections |
| `data/ftseek_us.db` (根目录) | 4K | **空壳!** 无表 | — |
| `data/ftseek.db` | 0 | 空文件 | — |
| `data/ftseek_us_live.db` | 0 | 空文件 | — |
| `data/signals.db` | 0 | 空文件 | — |
| `data/signal_snapshots.db` (根目录) | 0 | 空文件 | — |

**关键gotcha**: 根目录 `/opt/ftseek/FTSeek-US/ftseek_us.db` 是4KB空壳，无任何表。真实数据在 `data/ftseek_us.db`。首次查询必须 `.tables` 验证非空。

## 查询方法论（5步）

### Step 1: 定位活跃数据库
```bash
# 找所有非空DB
find /opt/ftseek/FTSeek-US/ -name "*.db" -size +1k -exec ls -lh {} \; 2>/dev/null | sort -k5 -h

# 验证主库有表
sqlite3 /opt/ftseek/FTSeek-US/data/ftseek_us.db ".tables"
```

### Step 2: 已平仓交易统计（trade_records表）
```sql
-- 最近30天汇总
SELECT 
  COUNT(*) as 总交易笔数,
  COUNT(CASE WHEN realized_pnl > 0 THEN 1 END) as 盈利笔数,
  COUNT(CASE WHEN realized_pnl < 0 THEN 1 END) as 亏损笔数,
  ROUND(100.0 * COUNT(CASE WHEN realized_pnl > 0 THEN 1 END) / COUNT(*), 1) as 胜率pct,
  ROUND(SUM(realized_pnl), 2) as 总盈亏,
  ROUND(AVG(realized_pnl), 2) as 平均每笔盈亏,
  ROUND(MAX(realized_pnl), 2) as 单笔最大盈利,
  ROUND(MIN(realized_pnl), 2) as 单笔最大亏损
FROM trade_records
WHERE trade_date >= date('now', '-30 days')
  AND realized_pnl IS NOT NULL;

-- 按来源分类
SELECT source_type, COUNT(*) as 笔数,
  COUNT(CASE WHEN realized_pnl > 0 THEN 1 END) as 盈利,
  ROUND(100.0 * COUNT(CASE WHEN realized_pnl > 0 THEN 1 END) / COUNT(*), 1) as 胜率pct,
  ROUND(SUM(realized_pnl), 2) as 总盈亏
FROM trade_records
WHERE trade_date >= date('now', '-30 days') AND realized_pnl IS NOT NULL
GROUP BY source_type ORDER BY 总盈亏 DESC;

-- 按退出原因分类（找亏损根因）
SELECT exit_reason, COUNT(*) as 笔数,
  ROUND(SUM(realized_pnl), 2) as 总盈亏,
  ROUND(AVG(realized_pnl), 2) as 平均盈亏
FROM trade_records
WHERE trade_date >= date('now', '-30 days') AND realized_pnl IS NOT NULL
GROUP BY exit_reason ORDER BY 总盈亏 ASC;

-- Top5盈利/亏损
SELECT trade_date, symbol, direction, ROUND(realized_pnl,2) as pnl, exit_reason, source_type
FROM trade_records
WHERE trade_date >= date('now', '-30 days') AND realized_pnl IS NOT NULL
ORDER BY realized_pnl DESC LIMIT 5;  -- DESC=盈利 ASC=亏损
```

### Step 3: 当前持仓（open_positions表）
```sql
SELECT symbol, direction, size, avg_entry_price, entry_time, owner_strategy, account_type
FROM open_positions WHERE size > 0 ORDER BY entry_time DESC;
```

### Step 4: 信号→交易执行率（跨库ATTACH + JOIN）
```sql
-- 在 ftseek_us.db 中执行，ATTACH signal_snapshots.db 和 decisions.db
ATTACH '/opt/ftseek/FTSeek-US/data/signal_snapshots.db' AS ss;
ATTACH '/opt/ftseek/FTSeek-US/data/decisions.db' AS dec;

-- 执行率 = 有trade_record的decision_id / 总decision数
SELECT 
  (SELECT COUNT(*) FROM dec.decisions WHERE created_at >= datetime('now', '-30 days')) as 决策总数,
  COUNT(DISTINCT t.decision_id) as 已执行信号数,
  ROUND(100.0 * COUNT(DISTINCT t.decision_id) / 
    (SELECT COUNT(*) FROM dec.decisions WHERE created_at >= datetime('now', '-30 days')), 1) as 执行率pct
FROM trade_records t
WHERE t.trade_date >= date('now', '-30 days')
  AND t.decision_id IN (SELECT decision_id FROM dec.decisions WHERE created_at >= datetime('now', '-30 days'));

-- 未执行信号按策略+方向分布（Gap分析）
SELECT s.strategy_id, s.direction, COUNT(*) as 未执行信号数,
  ROUND(AVG(s.confidence), 3) as 平均信心度, ROUND(AVG(s.strength), 1) as 平均强度
FROM ss.signal_snapshots s
LEFT JOIN trade_records t ON s.decision_id = t.decision_id
WHERE s.trade_date >= date('now', '-30 days') AND t.decision_id IS NULL
GROUP BY s.strategy_id, s.direction ORDER BY 未执行信号数 DESC;
```

### Step 5: 拒绝记录（rejections.db + failures表）
```sql
-- rejections.db
SELECT reason_category, COUNT(*) as 拒绝次数, ROUND(AVG(strength), 1) as 平均强度
FROM rejections WHERE timestamp >= datetime('now', '-30 days')
GROUP BY reason_category ORDER BY 拒绝次数 DESC;

-- ftseek_us.db failures表（注意: 列名是timestamp不是created_at）
SELECT failure_type, COUNT(*) as cnt
FROM failures WHERE timestamp >= datetime('now', '-30 days')
GROUP BY failure_type ORDER BY cnt DESC;
```

## 2026-07-09 查询结果快照

### 交易统计（最近30天: 2026-06-09 ~ 2026-07-08）
| 指标 | 值 |
|------|-----|
| 总交易笔数 | 80 |
| 胜率 | 40.0% (32胜45负3平) |
| 总盈亏 | -$1,435.37 |
| 平均每笔 | -$17.94 |
| 最大盈利 | +$807.20 (US.MSFT SHORT, FORCED_CLOSE_OKR_AUDIT) |
| 最大亏损 | -$975.59 (US.ORCL LONG, SL_ATR_STOP) |

### 按来源
| 来源 | 笔数 | 胜率 | 总盈亏 |
|------|------|------|--------|
| PLAYBOOK_SIM | 44 | 38.6% | -$956.21 |
| PLAYBOOK_SHADOW | 23 | 56.5% | +$242.31 |
| MAIN_PIPELINE | 8 | 12.5% | -$686.39 |
| ORB_ENGINE | 3 | 33.3% | -$35.08 |
| MANUAL | 2 | 0.0% | $0.00 |

### 退出原因亏损根因
- **SL_ATR_STOP**: 7笔 -$2,847 (平均-$407/笔) — 最大亏损来源
- **TIME_EXIT**: 16笔 -$1,215 (平均-$76/笔)
- **EOD_FORCE_CLOSE**: 14笔 +$1,786 (平均+$128/笔) — 最佳盈利来源

### 信号执行率
| 环节 | 数量 |
|------|------|
| decisions.db 决策总数 | 1,425 |
| signal_snapshots 信号快照 | 1,500 |
| 实际执行交易(有decision_id) | 70 |
| **执行率** | **4.7%** |
| rejections.db 拒绝记录 | 2 |
| failures 表 | 1 (exec_rejected) |

### 关键发现: 信号→交易Gap在静默过滤层
- 95.3%的信号未转化为交易，但rejections.db只有2条拒绝
- Gap不在显式rejection层，在portfolio/仓位管理/风控的静默过滤
- PLAYBOOK_SIM产生44笔交易有自己的decision_id体系，不完全走decisions.db链路
- NEUTRAL方向决策115条（不生成交易，正常过滤）

## trade_records 表关键字段
```
trade_date, symbol, direction, entry_time, exit_time, entry_price, exit_price,
quantity, realized_pnl, pnl_pct, exit_reason, holding_hours,
signal_strength, signal_confidence, source_type, trade_mode,
owner_strategy, decision_id, strategy_id, market_regime, mode
```

**source_type 枚举**: MAIN_PIPELINE, PLAYBOOK_SIM, PLAYBOOK_SHADOW, ORB_ENGINE, MANUAL
**trade_mode 枚举**: simulate, live
**account_type (open_positions)**: sim, real, simulate

## 注意事项
1. `failures` 表用 `timestamp` 列，不是 `created_at` — 查 `created_at` 会报错
2. 根目录的 `ftseek_us.db`/`ftseek.db`/`ftseek_us_live.db`/`signals.db`/`signal_snapshots.db` 全是空文件(0字节或4KB空壳)，真实数据在 `data/` 子目录
3. `trade_records.db` 仍是空表(已废弃) — 查交易记录必须用 `data/ftseek_us.db`
4. ATTACH跨库查询时，主库的表不需要前缀，ATTACH的库用别名前缀(如 `ss.signal_snapshots`)
