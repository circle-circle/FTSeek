# 规划-执行解耦架构审计 (2026-07-09)

## 架构概览

```
规划层 (skill)                          执行层 (FTSeek)
─────────────────                       ─────────────────
deep_analysis pipeline                  scheduler_core
  18维数据采集                             _try_load_bridge()
  2模型辩论(qwen→deepseek)                → BridgeVotingAdapter
  bridge JSON + instruction直写DB         → run_playbook_generate (跳过)
  ↓                                      → auto_execute (30min)
opportunity_scan_YYYYMMDD.json           → re-price → _submit_order
playbook_instructions表                   → 退出监控 (drawdown+EOD)
```

## 关键断点与修复

### P0-1: bridge候选永远不生成instruction (已修复)
**根因**: `run_playbook_generate`幂等检查(DB已有instruction就跳过). VotingCoordinator在ET 04:17先跑→生成DEC-格式instruction→幂等→bridge在ET 09:00生成→但instruction不会重新生成.
**修复**: `_write_bridge_file()`同时调`PlaybookDB.save_instruction()`直写instruction到DB. UPSERT by date+symbol.

### P0-2: 辩论结果未写入bridge (已修复)
**根因**: `_debate`/`debate_outcome`在`llm_synth.synthesize()`返回的result dict中, 经过`deep_analyzer._apply_llm_result()`存到`self.result._llm_output`, `asdict()`后变成`a["_llm_output"]["_debate"]`. 直接`a.get("_debate")`=None.
**修复**: `a.get("_llm_output", {}).get("_debate", {})`.

### P0-3: NullVotingAdapter的SKIP覆盖bridge的BUY (已修复)
**根因**: NullVotingAdapter.vote()返回None→pipeline SKIP→save_instruction的UPSERT会覆盖bridge已写的BUY/SELL_SHORT为SKIP.
**修复**: `run_playbook_generate()`开头加type check, NullVotingAdapter时直接return None.

## 消费链路验证 (12点)

| # | 检查点 | 状态 | 说明 |
|---|---|---|---|
| 1 | 路径一致性 | ✅ | skill和FTSeek都用ET日期(timezone(_et_offset)+strftime) |
| 2 | confidence门禁 | ✅ | min_confidence=0.7, bridge=0.7刚好过 |
| 3 | re-price | ✅ | bridge的entry/SL/TP被实时bid/ask覆盖 |
| 4 | 排序优先 | ✅ | DA-开头排前面(pipeline.py:2152) |
| 5 | pool幂等 | ✅ | 已存在不重复追加 |
| 6 | pool容量 | ❌(P2) | 不检查max_pool_size, 但实际不超50 |
| 7 | 2模型超时 | ✅ | cron无硬超时, deepseek fallback到qwen |
| 8 | 退出规则 | ✅ | conditions→factor_exit_rules匹配 |
| 9 | 辩论写入 | ✅ | _llm_output._debate提取后写入bridge |
| 10 | instruction直写DB | ✅ | PlaybookDB.save_instruction UPSERT |
| 11 | NullVotingAdapter防覆盖 | ✅ | type check跳过generate |
| 12 | 全链路 | ✅ | bridge→instruction→auto_execute验证通过 |

## 价格来源澄清 (v0.42新增)

**bridge里的entry_price = LLM建议的"期望回调入场价"**, 不是实时现价:
- PSX: LLM说"回调至MA5($178.98)附近建仓" → entry_price=$178.98, 实际现价$187.81 (+4.9%)
- TTE: LLM说"在$76.60-$77.00区间首批建仓" → entry_price=$76.80, 实际$78.87 (+2.7%)
- VLO: LLM说"回调至MA20($256)附近建仓" → entry_price=$271.30, 实际$282.88 (+4.3%)
- MPC: LLM说"回调至MA10($261.62)分2批" → entry_price=$265.00, 实际$280.68 (+5.9%)

**实际执行价 = auto_execute触发时的实时bid/ask** (re-price覆盖):
- entry = 实时ask(BUY)或bid(SHORT)
- SL = entry × (1 - sl_pct%), sl_pct由ATR分桶决定(2-5%)
- TP = entry × (1 + sl_pct×tp_mult), rr_ratio=999时TP=0(无止盈)

**推送修复**: 钉钉推送同时显示现价(Finnhub实时)和LLM建议价, 标注"实际以re-price为准"。

## cron推送修复

bridge cron(`13dde1f65703`)飞书delivery报`99992402 field validation failed`. 原因: Hermes飞书adapter消息体格式限制.
修复: cron prompt第4步加`DingTalkNotifier.send_text()`直接发钉钉, 绕过Hermes飞书adapter. cron prompt内嵌Python代码: 读bridge文件→获取Finnhub实时价→格式化消息→发钉钉. FTSeek自己的`FeishuNotifier`发送正常(测试通过).

## 退出参数收紧 (v0.41)

| 参数 | 旧值 | 新值 | 原理 |
|---|---|---|---|
| default breakeven | 1.5% | 1.0% | 更早保本, 减少SL出血 |
| default drawdown | 0.8% | 0.5% | 更紧锁利, 减少giveback(85%→预期60-70%) |
| 趋势类 drawdown | 0.6-0.7% | 0.5-0.6% | 同步收紧 |
| 基本面类 drawdown | 0.6% | 0.5% | 同步收紧 |

不碰: rr_ratio=999(无TP, MFE太低)、SL参数(等MFE/MAE数据)、EOD(唯一稳定盈利源).

## 日cap提升 (v0.42)

`daily_notional_cap_pct`: 0.40→0.60. equity~$157K → 日cap从$63K→$94K. 10笔不再因预算提前耗尽被跳过. 单仓max_position_pct不变(4%≈$6,300/仓).
