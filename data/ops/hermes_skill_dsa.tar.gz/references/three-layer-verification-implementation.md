# 三层验证体系 — 落地实现 (v0.15)

## 问题

用户核心问题："瓶颈不是信息不够，而是现有信息有没有用，如何能够泛化和涌现并能验证确认是否有用"

旧的IC只验证"BUY方向对不对"——不验证"为什么BUY的推理对不对"。如果NVDA输出BUY因为"GB300催化"，T+1涨了1%——但涨是因为GB300还是因为大盘反弹？不知道。

## 三层验证体系

### 第一层：Alpha IC（剥离大盘beta）

**实现**: `alpha_backfill.py` — 给 signal_snapshots.db 加11列

| 新增列 | 用途 |
|--------|------|
| spy_close_t0/t1/t5/t20 | SPY在信号日及T+1/5/20的收盘价 |
| spy_ret_t1/t5/t20 | SPY收益率（不带方向） |
| alpha_t1/t5/t20 | 个股fwd_ret - SPY_ret = 超额收益 |
| market_context_json | 板块/宏观上下文快照（Phase 3预留） |

**核心逻辑**:
- `fwd_ret_t1`已经按方向调整过（LONG=正涨, SHORT=正跌）
- `spy_ret_t1`不带方向（大盘涨跌）
- `alpha_t1 = fwd_ret_t1 - spy_ret_t1` = 信号方向收益 - 大盘收益 = 超额收益

**数据源**: 复用FTSeek的`scripts.backfill_forward_returns.get_daily_closes()`拉SPY日K（只读import，不碰运行时代码）

**验证结果**: 916条voting_llm历史信号全部回填成功
- NVDA: fwd=-1.39%, spy=-0.13%, alpha=-1.26% → NVDA比大盘多跌1.26% ✅
- NFLX: fwd=+4.66%, spy=-0.13%, alpha=+4.80% → 大盘跌时NFLX涨4.66% ✅

### 第二层：论据级IC（验证哪个论点真有预测力）

**实现**: `ic_writer._extract_claim_factors()` + `_classify_claim()`

factors_json从旧格式`["news","fundamental"]`升级为：
```json
[
  {"thesis": "GB300性能碾压前代20倍", "source_type": "news", "claim_type": "product_catalyst", "strength": "HIGH", "side": "bull"},
  {"thesis": "MSPR -77.39高管净卖出", "source_type": "sentiment", "claim_type": "insider_bearish", "strength": "HIGH", "side": "bear"}
]
```

**11种claim_type分类**（泛化到全市场任何股票）:
- `product_catalyst`: 产品/合约/IPO/管理层变动
- `earnings_beat`: 营收/EPS/利润率超预期
- `valuation_cheap` / `valuation_expensive`: PE/PB低于/高于行业中枢
- `insider_bearish` / `insider_bullish`: MSPR净卖出/买入
- `technical_breakout` / `technical_breakdown`: 突破/破位
- `sentiment_crowded`: 散户一边倒
- `macro_tailwind` / `macro_headwind`: 降息顺风/加息逆风

**分类逻辑**: `_classify_claim(thesis, source_type, evidence)` — 按关键词优先级匹配

**IC计算**: T+N后按claim_type分组，计算Spearman IC(strength vs alpha)
- IC > 0.05: 该论据有预测力
- IC ≈ 0: 该论据是噪声
- IC < 0: 该论据反向（信号方向错误）

**首跑结果** (96条voting_llm样本):

| claim_type | n | IC_T1 | IC_T5 | 解读 |
|------------|---|-------|-------|------|
| volume_expansion | 23 | +0.30 | +0.04 | ✅ 最强短线预测因子 |
| news_positive | 23 | +0.17 | +0.13 | ✅ 新闻正面有效 |
| pe_below_industry | 40 | -0.43 | +0.21 | ❌ 低PE短线是价值陷阱 |
| insider_net_sell | 33 | -0.30 | +0.55 | ❌ 内部人卖出未定价 |
| rsi_oversold | 17 | -0.07 | -0.40 | ❌ 超卖反弹是假突破 |
| macd_golden_cross | 26 | -0.16 | +0.55 | ❌ 金叉短线反向 |

**关键发现**:
- 整体Alpha IC: T+1=-0.07（短线反向） T+5=+0.30（周级有效）
- voting_llm信号短线噪声大但周级有预测力
- 低PE和内部人卖出是最差的短线论据——市场不把这当回事

### 第三层：情境IC（预留）

`market_context_json`列已建好，等market_context.py实现后：
- 注入"半导体BEARISH"时记录context
- T+5后对比：有context vs 无context的alpha IC差多少
- 验证"市场上下文注入到底有没有用"

## 文件变更

| 文件 | 变更 |
|------|------|
| `alpha_backfill.py` | **新建** — 加DB列+拉SPY+计算alpha+claim IC统计 |
| `ic_writer.py` | `_extract_claim_factors()` + `_classify_claim()` 新增; `get_ic_summary()` 升级含alpha+claim_type |
| `adapter.py` | `to_ic_snapshot()` factors同步升级为结构化claim |

## Cron

- **alpha-backfill** (job_id: 6af0648e3eb3)
- Schedule: `30 6 * * 2-6` (CST 06:30 = ET 18:30 前日)
- 在FTSeek signal-ic-backfill (06:00) 之后接力运行
- deliver: local (静默运行，有显著发现才推送)

## 验证命令

```bash
# 加DB列（一次性）
cd ~/.hermes/skills/deep-stock-analysis/scripts
/opt/ftseek/FTSeek-US/venv/bin/python3.11 alpha_backfill.py --add-columns

# 回填alpha
/opt/ftseek/FTSeek-US/venv/bin/python3.11 alpha_backfill.py --backfill

# 论据级IC统计
/opt/ftseek/FTSeek-US/venv/bin/python3.11 alpha_backfill.py --claim-ic

# get_ic_summary（含alpha+claim_type）
/opt/ftseek/FTSeek-US/venv/bin/python3.11 -c "
import sys; sys.path.insert(0, '.')
from ic_writer import get_ic_summary
import json; print(json.dumps(get_ic_summary('voting_llm'), indent=2, default=str))
"
```

## 泛化能力来源

1. **Alpha IC**用SPY做基准，任何股票都能算alpha，不依赖Deepulse覆盖
2. **论据级IC**用claim_type分类，这些类别对任何股票都适用
3. **情境IC**用板块ETF强弱（11个SPDR覆盖全市场），不依赖Deepulse的3个domain
