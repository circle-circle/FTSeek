# Plan→Execute Gap: First-Principles Analysis (2026-07-11)

Three-dimensional fracture between strategy generation and execution, with DB evidence and design pattern for zone-based triggers.

## The Three Fractures

### 1. Price: Single Point vs Zone

**LLM output**: "分2批建仓：第1批在$204-205区间挂限价单" (a zone)
**DB stores**: `entry_price=204` (a single point)
**Execution reads**: only the single point, with ±5% chase zone / ±3% knife floor

**Result**: Price at $204.5 → LLM says "in zone, enter" → execution's touch zone may not trigger. Worse: LLM says "回调至$612" but price drops to $613 and bounces → never triggers.

**DB evidence** (executed trades, 7/6-7/10):
- 90% of executed trades had gap < 0.1% (re-price works when triggered)
- But 60-80% of instructions NEVER trigger — core cause is single-point entry + no zone

### 2. Trend: Generation Time ≠ Trigger Time

**4:00 ET generation**: "NVDA突破MA20, BUY" (trend confirmed at generation)
**9:35 ET execution check**: NVDA already fell back below MA20 (breakout failed)
**Current protection**: Only 8% gap filter checks price deviation, not trend validity

**Need**: Simple direction consistency check — if BUY and current price < entry × 0.95, trend likely reversed.

### 3. Range: Plans Never Expire

**LLM output**: "若7/14前未回调至$615以下则取消" (invalidation date)
**Execution**: Never checks dates. Plan can sit for days/weeks.
**Result**: Stale signals trigger at wrong time, buying assets that lost their original catalyst.

## DB Evidence Summary

### Trigger Rate by Source (7/1-7/11)
```
deep_analysis: 16 total, 4 triggered (25%), 5 executed (31%)
voting_llm:    82 total, 22 triggered (27%), 36 executed (44%)
```

### Deep_analysis Confidence Distribution
```
conf 25-35: 8 candidates (2-model debate, lowered confidence)
conf 60-70: 4 candidates (single model)
conf 70+:    4 candidates (single model)
```

**Critical finding**: Deep_analysis candidates (conf=25-35) bypass the confidence gate entirely because:
- Skill writes directly to DB via `PlaybookDB.save_instruction()`
- `_build_instructions_from_votes()` confidence gate (line 1151, `confidence < _min_conf_for_dir`) never runs for bridge candidates
- Config `buy_min_confidence: 85` → 0/13 deep_analysis BUY candidates would pass if they went through the gate
- This is BY DESIGN (bridge candidates are pre-filtered by signal_gate BLOCK/WARN), but means confidence only affects sort order and position sizing

### Not-Triggered Analysis (7/8-7/10)
```
7/10: 5/8 not triggered (META, COIN, BE, WDFC, RIVN)
7/9:  4/6 not triggered (MPC, VLO, TTE, PSX)
7/8:  8/10 not triggered (ASML, ANET, TTE, NFLX, BA, AVGO, ARM, UNH)
```

### Entry Strategy Text — Stored But Never Parsed
LLM produces rich `entry_strategy` text stored in `raw_instruction_json`:
```
"分2批建仓：第1批在$204.00-205.00区间(MA20=$201.95上方+7/8日放量阳线实体中段)
挂限价单，仓位40%；第2批在$201.95-202.07区间(MA20与MA5共振支撑)挂限价单，
仓位30%；若直接突破$211..."
```

**Execution side (`_check_intraday_trigger`)**: Does NOT parse this text. Only checks `entry_price` single point with ±5%/±3% zones. The entire LLM entry plan is discarded.

## Design Pattern: Zone + Type + Validity

### Solution: Structured Fields in raw_instruction_json (Zero DB Schema Change)

Instead of parsing text, have LLM output structured fields:

```json
{
  "entry_price": 204.00,           // backward compatible
  "entry_zone_low": 203.00,        // zone lower bound
  "entry_zone_high": 205.00,       // zone upper bound
  "entry_type": "limit",            // "limit" (wait for pullback) | "breakout" (chase)
  "valid_days": 3                   // plan auto-expires after N days
}
```

### Trigger Logic by Type

**limit (等待回调)**:
- BUY: price enters [zone_low, zone_high] → trigger
- SHORT: price enters [zone_low, zone_high] → trigger
- Price below zone_low → don't trigger (catching falling knife)

**breakout (追突破)**:
- BUY: price >= zone_high → trigger (breakout up)
- SHORT: price <= zone_low → trigger (breakdown)
- Price in zone but not breaking → don't trigger

### Backward Compatibility
- No `entry_zone_low` → zone_low = zone_high = entry_price → falls back to original ±5%/±3% logic
- No `entry_type` → defaults to "limit"
- No `valid_days` → defaults to 0 (never expires, original behavior)

### Direction Consistency Check (Trend Fracture Fix)

After trigger, before SL check:
```python
# BUY but price dropped >5% from entry → trend reversed, don't enter
if not is_short and current_price < entry_price * 0.95:
    return False  # direction reversal
# SHORT but price rose >5% from entry → trend reversed
if is_short and current_price > entry_price * 1.05:
    return False  # direction reversal
```

5% threshold aligns with existing `_chase_zone`, no new parameter. Breakout triggers are unaffected (breakout condition itself ensures direction).

### Invalidation (Range Fracture Fix)

In `auto_execute` loop, before trigger check:
```python
if valid_days > 0:
    expiry = created_at + timedelta(days=valid_days)
    if now > expiry:
        mark as "expired" → SKIP
```

## Key Design Decisions (Ponytail + Karpathy)

### What NOT to do (YAGNI)
- **Don't parse entry_strategy text** — fragile, LLM output format varies
- **Don't implement batch entry (batch 1/2)** — requires position management refactor
- **Don't add volume/RSI conditions** — daily vol_ratio has zero predictive power (verified 7/10)
- **Don't add complex trend indicators (MA20/RSI)** — simple price direction is sufficient
- **Don't add DB columns** — encode to existing `raw_instruction_json` JSON column

### Assumptions (Explicit)
1. LLM can reliably output `entry_zone_low/high` numeric values (same as outputting `entry_price`)
2. "limit" and "breakout" cover all entry types (verified: all 7/8-7/10 entry_strategies fit one of these)
3. Daily-level invalidation is sufficient (LLM invalidation is always date-level)
4. 5% direction threshold matches existing `_chase_zone` (no new parameter)

## Audit SQL Templates

```sql
-- Trigger rate by source
SELECT
    CASE WHEN decision_id LIKE 'DA-%' THEN 'deep_analysis' ELSE 'voting_llm' END as source,
    COUNT(*) as total,
    SUM(CASE WHEN triggered = 1 THEN 1 ELSE 0 END) as triggered,
    SUM(CASE WHEN executed = 1 THEN 1 ELSE 0 END) as executed
FROM playbook_instructions
WHERE direction != 'SKIP' AND date >= '2026-07-01'
GROUP BY source;

-- Non-triggered instructions with entry strategy
SELECT date, symbol, direction, entry_price, stop_loss, confidence,
       json_extract(raw_instruction_json, '$.entry_strategy') as entry_strategy
FROM playbook_instructions
WHERE triggered = 0 AND direction != 'SKIP'
ORDER BY date DESC LIMIT 20;

-- Gap between planned and actual execution price
SELECT date, symbol, direction, entry_price, execution_price,
       ROUND((execution_price - entry_price) / entry_price * 100, 2) as gap_pct
FROM playbook_instructions
WHERE executed = 1 AND execution_price > 0
ORDER BY date DESC LIMIT 30;
```
