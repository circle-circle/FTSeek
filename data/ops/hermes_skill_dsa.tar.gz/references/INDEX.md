# DA skill 参考文档索引 (references/INDEX.md)

> **用途**: 路由 `references/` 下全部 68 份文档 + 本批新增 3 份（三段披露第 3 段：按需读取，不进 SKILL.md 正文）。
> **生成**: 2026-09-06 文档形态收敛批。描述取各文件首个标题；可达性状态按**当前** SKILL.md / 归档文件实测标注。
> **本批修的病灶**: ①此前 66 份中 12 份**从未被任何入口引用**（孤儿 = 写了没人能发现）；②Pitfalls 迁移后有 7 份的指针
>   随 ✅ 条目进了归档（仍可达，但不再从 SKILL.md 正文直达）—— 两类都在本索引里显式标注，避免后来人误判为死文件而清理。
> **维护纪律**: 新增 references 必须在本索引补一行（否则等同孤儿）；改名/删除必须同步本索引与 SKILL.md 指针。

**可达性标注**：`[SKILL 引用]` 正文有指针 · `[归档内引用]` 指针在 `pitfalls-closed-archive.md` 内 · `[孤儿→本批接入]` 此前无任何入口。

---

## 链路与桥接 (bridge / 直写 DB / 执行一致性 / 双开仓守卫)

- `bridge-deadfile-python311-20260710.md` (2KB) `[孤儿→本批接入]` — Bridge JSON 死文件冲突 + Python 3.11 切换 (2026-07-10)
- `bridge-link-audit-methodology.md` (10KB) `[SKILL 引用]` — Bridge Link Audit Methodology (2026-07-09, updated v0.31)
- `bridge-not-pushed-cron-skip-20260710.md` (3KB) `[归档内引用]` — Bridge 未推送根因 — 2026-07-10
- `bridge-priority-exit-rules-audit-20260709.md` (6KB) `[归档内引用]` — Bridge Priority + Exit Rules Audit (2026-07-09)
- `da-to-executor-consistency-audit-20260712.md` (15KB) `[归档内引用]` — DA脑→执行脑 一致性全链路审计 (2026-07-12)
- `guardrail-bypass-and-double-trade-20260710.md` (7KB) `[孤儿→本批接入]` — 7/10 全链路审计: guardrail 空过 + 双重 trade_record + None穿透
- `plan-execute-decoupling-audit-20260709.md` (5KB) `[SKILL 引用]` — 规划-执行解耦架构审计 (2026-07-09)
- `plan-execute-gap-first-principles-20260711.md` (7KB) `[SKILL 引用]` — Plan→Execute Gap: First-Principles Analysis (2026-07-11)
- `plan-execute-separation-20260708.md` (6KB) `[SKILL 引用]` — 规划-执行分离架构分析
- `position-size-gap-and-fallback-20260709.md` (3KB) `[孤儿→本批接入]` — Position Size Gap: bridge直写DB绕过compute_instruction_values
- `signal-gate-wiring-20260710.md` (2KB) `[孤儿→本批接入]` — Signal Gate Wiring — P0 Fix (2026-07-10)
- `sl-tp-reprice-kill-chain-20260711.md` (6KB) `[SKILL 引用]` — SL/TP Re-price Kill Chain Analysis (2026-07-11)
- `strategy-emergence-and-market-context-bridge.md` (7KB) `[SKILL 引用]` — 策略涌现分析 + 市场上下文桥接层设计
- `trigger-and-save-trade-fix-20260709.md` (5KB) `[归档内引用]` — Trigger Zone Fix + factor_detail List Type Bug — 2026-07-09
- `trigger-logic-gap-analysis-20260709.md` (7KB) `[归档内引用]` — Trigger Logic Gap Analysis — 2026-07-09

## DA 管线与吞吐 (扫描 / 候选 / 时序 / 指令质量 / 能力边界)

- `capability-boundary-cross-asset-reasoning-20260714.md` (8KB) `[SKILL 引用]` — 能力边界：跨资产/宏观事件驱动推理缺口
- `da-cron-verification-20260713.md` (3KB) `[SKILL 引用]` — DA 18:00 Cron 扫描状态验证方法 (2026-07-13)
- `da-instruction-quality-audit-20260714.md` (3KB) `[孤儿→本批接入]` — DA指令质量回溯审计 — 修正版 (2026-07-20)
- `da-throughput-and-silent-bug-20260714.md` (3KB) `[SKILL 引用]` — DA吞吐量瓶颈 + 盘中诊断SILENT Bug (2026-07-14)
- `da-timing-and-premarket-verify-20260811.md` (2KB) `[归档内引用]` — DA 生成时间与盘前数据覆盖 (2026-08-11, v0.65)
- `deep-analysis-replace-voting-20260708.md` (7KB) `[SKILL 引用]` — deep_analysis 架构gap + 替代voting_llm三阶段方案 — 2026-07-08
- `market-scanner-gap-analysis-20260708.md` (5KB) `[SKILL 引用]` — 市场扫描差距分析：参考报告 vs FTSeek现有管线
- `market-scanner-v023-implementation-20260708.md` (4KB) `[SKILL 引用]` — v0.23 多渠道扫描实施记录
- `skill-chain-audit-and-warn-fix-20260710.md` (3KB) `[孤儿→本批接入]` — Skill→Execution Chain Audit + WARN Fix Evolution (2026-07-10)
- `voting-removal-migration-20260709.md` (15KB) `[SKILL 引用]` — voting_llm 移除/迁移分析 (2026-07-09)
- `voting-replacement-and-2-model-debate-20260709.md` (7KB) `[SKILL 引用]` — Voting Replacement & 2-Model Debate + Bridge Direct-Write DB (v0.39-v0.40)

## 数据源与真实性 (采集矩阵 / 校验 / 多DB地图 / 幻觉)

- `data-flow-audit-methodology.md` (3KB) `[SKILL 引用]` — 数据流审计方法论 (v0.19)
- `data-source-matrix.md` (4KB) `[孤儿→本批接入]` — Data Source Matrix — 完整数据源可用性矩阵
- `hallucination-detection-and-conf-bypass-20260711.md` (6KB) `[SKILL 引用]` — LLM Hallucination Detection & Confidence Gate Bypass (2026-07-11)
- `hallucination-detection-infrastructure-20260711.md` (3KB) `[SKILL 引用]` — LLM 幻觉检测基础设施 (2026-07-11 辩论实证)
- `m1-data-infrastructure-20260709.md` (3KB) `[孤儿→本批接入]` — M1 Data Infrastructure — 2026-07-09 (deep-stock-analysis v0.36)
- `stale-data-after-parameter-change-20260709.md` (3KB) `[SKILL 引用]` — 参数变更后旧数据失效 — 2026-07-09 (v0.38)

## 退出与风控 (SL/TP / EOD / trailing / 回撤 / 冻结后补丁)

- `eod-performance-review-methodology-20260714.md` (4KB) `[SKILL 引用]` — EOD 盘后复盘验证方法论
- `exit-rule-three-layer-architecture-20260709.md` (6KB) `[SKILL 引用]` — Exit Rule Three-Layer Architecture (2026-07-09)
- `ftseek-exit-rules-20260705.md` (7KB) `[SKILL 引用]` — FTSeek退出规则全景 (2026-07-05)
- `playbook-vs-exit-monitor-architecture.md` (2KB) `[孤儿→本批接入]` — Playbook退出架构 vs ExitMonitor — 确认实际退出决策路径
- `post-freeze-exit-policy-patch.md` (7KB) `[孤儿→本批接入]` — 7/24冻结期后执行：分桶×分方向 SL/TP 代码消费

## 置信度与评分 (confidence / IC / 双脑冲突)

- `confidence-first-principles-20260710.md` (7KB) `[SKILL 引用]` — confidence 第一性原理分析 (2026-07-10)
- `dual-brain-ic-conflict-20260710.md` (5KB) `[归档内引用]` — 双脑IC冲突根因与修复 — 2026-07-10
- `ic-direction-strength-inversion-20260708.md` (9KB) `[SKILL 引用]` — IC分方向拆解 + Strength倒挂 + 4h生死线 + 退出调优 — 2026-07-08

## 复盘与记忆 (feedback / strategy_memory / pattern / 自进化闭环)

- `code-review-checklist.md` (4KB) `[SKILL 引用]` — Code Review Checklist — deep-stock-analysis
- `llm-prompt-ko-pattern.md` (5KB) `[SKILL 引用]` — LLM Prompt KO Pattern — 从KO示例反推的prompt设计模式
- `self-evolving-loop-architecture.md` (3KB) `[SKILL 引用]` — 自我进化交易闭环架构
- `single-trade-full-chain-review-20260714.md` (7KB) `[SKILL 引用]` — 单笔交易全链路复盘方法论

## 方法论与工程纪律 (审计法 / review 清单 / 原则 / 陈旧数据)

- `breakdown-buy-skip-20260722.md` (1KB) `[孤儿→本批接入]` — 破位硬买拦截 (2026-07-22, 用户B授权)
- `cross-module-audit-20260705.md` (8KB) `[孤儿→本批接入]` — 跨模块数据流审计 — 2026-07-05
- `cross-module-audit-methodology.md` (5KB) `[SKILL 引用]` — 跨模块数据流审计方法论
- `ftseek-integration.md` (6KB) `[孤儿→本批接入]` — FTSeek Integration — 分工边界与集成路径
- `ftseek-interface-contract.md` (7KB) `[SKILL 引用]` — FTSeek Interface Contract (2026-07-05)
- `full-pipeline-simulation-20260705.md` (17KB) `[SKILL 引用]` — 3股全链路模拟验证 — 2026-07-05
- `honest-quality-audit-v0.11.md` (4KB) `[SKILL 引用]` — v0.11 诚实质量审计 — 7项修复
- `pre-launch-verification-20260705.md` (4KB) `[SKILL 引用]` — 上线前验证方法论（v0.10）
- `pre-market-verification-20260708.md` (5KB) `[SKILL 引用]` — 盘前全链路验证（代码改动后，服务运行中）
- `quant-architect-audit-v0.16.md` (5KB) `[SKILL 引用]` — 量化架构师审计：12隐患 + 修复决策 (v0.16→v0.17)
- `three-agent-debate-and-first-principles-20260709.md` (4KB) `[SKILL 引用]` — 三方辩论 + 第一性原理复盘 (2026-07-09)
- `three-layer-verification-architecture.md` (5KB) `[SKILL 引用]` — 三层验证体系 + 架构辩论结论
- `three-layer-verification-implementation.md` (5KB) `[SKILL 引用]` — 三层验证体系 — 落地实现 (v0.15)
- `timezone-audit-methodology.md` (5KB) `[SKILL 引用]` — 时区审计方法论
- `v011-v012-fix-batch.md` (4KB) `[归档内引用]` — v0.11-v0.12 修复批次详情

## 其他 (未归类)

- `CHANGELOG.md` (20KB) `[SKILL 引用]` — DA skill 版本史 (CHANGELOG)
- `horizon-selector-trend-scoring-20260708.md` (4KB) `[SKILL 引用]` — HorizonSelector 趋势强度评分 — 数据驱动设计
- `ko-example-quality-bar.md` (6KB) `[SKILL 引用]` — KO示例质量标准 — 深度分析反推模式
- `okr-gap-analysis.md` (4KB) `[SKILL 引用]` — OKR 对齐差距分析
- `pitfalls-closed-archive.md` (93KB) `[SKILL 引用]` — DA skill 已闭环陷阱归档 (Pitfalls ✅ closed archive)
- `strategy-emergence-from-trade-data.md` (4KB) `[SKILL 引用]` — Strategy Emergence from Trade Data
- `trade-experience-injection.md` (7KB) `[SKILL 引用]` — 交易经验注入：个股复盘+赢亏pattern归因 (v0.8)
- `trade-performance-analysis-20260709.md` (7KB) `[SKILL 引用]` — FTSeek-US 交易表现分析方法论
- `volatility-bucket-sl-tp-analysis-20260705.md` (9KB) `[SKILL 引用]` — 波动率桶×方向 SL/TP 数据推导 (2026-07-05)

---

## 本批新增（形态收敛产物，非历史文档）

- `CHANGELOG.md` — **版本史单一真源**：从 frontmatter `description` 逐字迁出 16 个版本条目，新增 v0.75 与 v0.74.2 补记，
  含 `version:` 两次漏更事故留痕与「`skill_version` 只写 bridge JSON、不写 DB 指令行」的遗留缺口登记。
- `pitfalls-closed-archive.md` — 58 条 ✅ 已闭环陷阱（v0.4–v0.52 时代，60,526 字符）逐字归档：原编号不重排、带目录与原行号回溯、
  迁移块经 sha1 逐字节校验。仍在生效的原则以 5 条摘要留在 SKILL.md 正文。
- `INDEX.md` — 本文件。

## 跨 skill 指针（不在本目录，勿当孤儿清理）

- SKILL.md 正文有一处指向**别的 skill**：`quantitative-trading/ftseek-playbook-shadow-system/references/drawdown-stoploss-and-position-sizing-20260709.md`
  （绝对路径 `/root/.hermes/skills/quantitative-trading/ftseek-playbook-shadow-system/references/`，2026-09-06 实测存在）。
  本目录内无同名文件 —— 曾据「本目录找不到」误判为悬空指针，口径已更正，勿据此删改。
