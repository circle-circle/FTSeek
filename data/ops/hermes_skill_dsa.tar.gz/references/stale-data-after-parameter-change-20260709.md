# 参数变更后旧数据失效 — 2026-07-09 (v0.38)

## 用户纠正

> "原来历史的数据是历史参数参数的 不能用于新修改后的链路和策略 要通过新的管线表现再来做调整和决策"

## 背景

v0.37 落地了 6 项 P0 修复 + M1 数据基础设施：
- 回撤止损 (0.6-0.8%) 替代步进 trailing
- 仓位 max_position_pct 8%→4%, risk_pct 1.0%→0.5%
- SL 分桶收紧 (low floor 2.0%, high/extreme ceil 5.0%)
- 盘中 gap>2% 过滤
- daily_notional_cap DB 持久化
- feedback_loop 全样本 override

然后用旧数据（旧步进 trailing/旧仓位/旧 SL 下产生的 12 笔交易）推导出 3 条建议：
1. HIGH_VOL regime 过滤 (HIGH_VOL 两方向都亏)
2. TRAILING_STOP 参数调优 (84 笔 51%WR 但 -$224)
3. DAY_TRADE_TP 优先 (13 笔 100%WR)

## 用户指出全部作废

这些数据的分布反映的是**旧参数的行为**，不是新管线的。用旧数据指导新参数 = 循环错误。

## 验证时序

```
pipeline.py patch:  2026-07-09 13:49 CST
服务重启:           2026-07-09 13:56 CST
7/9 已有 4 笔交易:  CST 09:10-11:55 (全部在 patch 之前)
patch 后新管线交易: 0 笔
```

12 笔交易全部是旧管线下产生的。MFE/MAE 全部为 0（采集代码虽然在 pipeline.py 里，但那 4 笔 7/9 交易在重启前完成，没跑到新代码）。

## 时间线验证命令

```bash
# 1. 检查代码 mtime
stat -c '%y' /opt/ftseek/FTSeek-US/app/playbook/pipeline.py

# 2. 检查服务重启时间
systemctl show ftseek-us --property=ActiveEnterTimestamp

# 3. 检查交易创建时间
sqlite3 /opt/ftseek/FTSeek-US/data/ftseek_us.db \
  "SELECT created_at FROM trade_records WHERE source_type='PLAYBOOK_SIM' ORDER BY created_at DESC LIMIT 10;"

# 4. 判断: 如果 trade created_at < patch mtime → 数据无效
```

## 方法论原则

1. **参数变更后旧数据立即失效** — 旧 trailing/旧 SL/旧仓位下产生的数据不能反映新管线行为
2. **用旧数据推荐新参数改动是方法论错误** — 即使数据"看起来有道理"（HIGH_VOL 确实两方向都亏）
3. **时间线验证是前置条件** — 做任何基于交易数据的参数建议前，先验证数据来源是否在新管线下产生
4. **等干净样本** — 积累 20-30 笔新管线下交易后，再用新数据做参数决策
5. **停止加管道，先测水** — 62 个 pitfall 说明管道已足够精致，问题是信号质量 (47%≈随机)，不是基础设施。先用 MFE/MAE 测出信号问题在哪，再决定改什么

## 新管线下需要等待的数据

等积累 20-30 笔新管线下干净交易后，用新数据回答：

1. **MFE 中位数** → 信号方向有没有预测力
2. **MAE 分布** → SL 分桶 (2-5%) 是否合理
3. **回撤止损触发频率和效果** → 0.6-0.8% 参数是否需要调
4. **daily_notional_cap 实际利用率** → 仓位是否太小/太大
5. **bridge 信号 vs voting 信号** → 哪个方向准

在此之前不做任何参数调整。新管线需要干净的样本才能评估。

## 相关 Pitfall

- deep-stock-analysis SKILL.md Pitfall #63: 完整方法论记录
- three-agent-debate-and-first-principles-20260709.md: 辩论原始数据（注意其中"立即可做"的建议已作废）
