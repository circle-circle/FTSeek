# Bridge Priority + Exit Rules Audit (2026-07-09)

## Bridge Priority Sorting Fix

### Problem
auto_execute (pipeline.py:2099) sorts instructions by confidence descending:
```python
instructions.sort(key=lambda x: x.get("confidence", 0) or 0, reverse=True)
```

Bridge candidates have confidence=70 (adapter.py:174: `confidence = score / 10.0`, score=7.0).
VotingCoordinator candidates have confidence=88-100 (LLM consensus).

Result: bridge candidates sorted last → budget consumed by non-bridge instructions first.

### 7/8 Real Data
| ID | symbol | source | conf | triggered | executed |
|---|---|---|---|---|---|
| 499 | ORCL | VotingCoord | 90 | 1 | 1 |
| 503 | GOOGL | VotingCoord | 90 | 1 | 1 |
| 505 | LLY | VotingCoord | 90 | 1 | 1 |
| 509 | AMZN | VotingCoord | 90 | 1 | 1 |
| ... | ... | VotingCoord | 90 | 1 | 1 |
| 539 | TTE | bridge(DA-) | 70 | 0 | 0 |
| 540 | ANET | bridge(DA-) | 70 | 0 | 0 |
| 541 | ASML | bridge(DA-) | 70 | 0 | 0 |

13 non-bridge instructions (conf=90) executed first → consumed $44K budget.
3 bridge instructions (conf=70) → budget exhausted → never executed.

### Fix (pipeline.py:2099-2108)
```python
instructions.sort(key=lambda x: (
    1 if (x.get("decision_id", "") or "").startswith("DA-") else 0,
    x.get("confidence", 0) or 0
), reverse=True)
```

Bridge candidates (decision_id starts with "DA-") sorted first, then by confidence.

### Double Insurance
When bridge file exists before pre-market scan (cronjob generates at ET 03:00):
1. scheduler uses BridgeVotingAdapter
2. Non-bridge candidates: vote() returns None → SKIP (pipeline.py:626-630)
3. Only bridge candidates generate instructions
4. No competition

Sort priority is the fallback insurance: if bridge loading fails → VotingCoordinator runs → both bridge and non-bridge instructions exist → bridge still gets budget first.

---

## Budget Mechanism

### Configuration
- `capital_safety.get_available_budget_for_auto()` = $57,040 (based on current_equity=$98,844)
- `daily_notional_cap = equity × daily_notional_cap_pct` (default 0.20 = $19,768)
- `max_daily_positions` = 5 (code default, not in config)
- `min_confidence` = 65 (code default)

### auto_execute Flow (pipeline.py:1970+)
1. Check `auto_execute` config (true)
2. Check trading day
3. Check market regime (NO_TRADE → skip)
4. Get today's instructions
5. **Sort by (bridge_first, confidence)** ← v0.32 fix
6. For each instruction:
   a. Skip if executed or SKIP direction
   b. Check broker existing position (skip if held)
   c. Check _check_intraday_trigger (price crosses entry ±1%)
   d. Re-price at trigger (real-time bid/ask)
   e. Confidence ≥ min_confidence (65)?
   f. **Buying power limit**: `_max_deploy + _new_notional > _bp_limit` → skip
   g. **Daily notional cap**: `_today_opened_notional + _new_notional > _daily_notional_cap` → skip
   h. **Max daily positions**: `_today_opened_count >= _max_daily_positions` → skip
   i. Execute via service.execute_instruction()

### 7/8 Log Evidence
```
15:24 ET: TTE  re-price: $79.04→$78.81  跳过—购买力上限 (已用$44,083 + 新$28,138 > 限$45,293)
15:24 ET: ANET re-price: $178.15→$178.81 跳过—购买力上限 (已用$44,083 + 新$11,936 > 限$45,293)
15:24 ET: ASML re-price: $1765→$1767    跳过—购买力上限 (已用$44,083 + 新$12,359 > 限$45,293)
15:55 ET: TTE  跳过—购买力上限 (已用$31,672 + 新$28,056 > 限$54,767)
15:55 ET: ANET 跳过—单日notional上限 (已用$18,969 + 新$11,980 > 限$19,776)
15:55 ET: ASML 跳过—单日notional上限 (已用$18,969 + 新=$12,371 > 限$19,776)
```

Budget recovered between 15:24 and 15:55 ($44K→$31K used, limit $45K→$54K) but daily notional cap ($19,776) still blocked.

---

## Exit Rules Audit

### ATR Stop Loss (playbook_horizon.yaml)
```yaml
vol_buckets:
  low:    { atr_pct_max: 0.015, sl_multiplier: 1.2, sl_floor_pct: 1.5, sl_ceil_pct: 2.5, tp_multiplier: 2.0, short_widen_pct: 0.2 }
  medium: { atr_pct_max: 0.035, sl_multiplier: 1.5, sl_floor_pct: 2.5, sl_ceil_pct: 4.5, tp_multiplier: 1.8, short_widen_pct: 0.3 }
  high:   { atr_pct_max: 0.08,  sl_multiplier: 1.5, sl_floor_pct: 3.5, sl_ceil_pct: 8.0, tp_multiplier: 1.5, short_widen_pct: 0.5 }
  extreme:{ atr_pct_max: 999.0, sl_multiplier: 1.2, sl_floor_pct: 3.5, sl_ceil_pct: 6.0, tp_multiplier: 1.5, short_widen_pct: 0.8 }
```

Formula: `sl_pct = max(sl_floor, min(sl_ceil, atr_pct × 100 × sl_multiplier))`
SHORT: `sl_pct += short_widen_pct`

### SL_ATR_STOP 7 Trades (all losses, -$2,847 total)
6/7 trades on 6/24 crash day (LONG positions in a down market).
6/7 held ≤0.1h (6 minutes) — stopped out at open.
SL distance: 2.0-3.3%.

**Root cause: direction error (LONG on crash day), not SL too tight.**
SL was already widened on 7/8 (0.7→1.5×ATR).

### EOD_FORCE_CLOSE 14 Trades (86% WR, +$1,786 total)
Best exit method. Avg hold 7-18h. Most profitable: TSM SHORT +$375 (6.7%), TSLA SHORT +$328 (5.8%).

### rr_ratio = 999 (no TP for short horizon)
```yaml
short_horizon:
  rr_ratio: 999  # 移除TP, 让EOD捕获利润(100%WR avg+$203)
```
Rationale: TP=3% never triggered and would truncate SHORT EOD avg=5.66%.
Risk: intraday peaks not captured if price retreats by close.

### Exit Priority
`SL_FIXED_PCT > PRE_CLOSE_EXIT > TIME_EXIT (intraday) + EOD_FORCE_CLOSE/MAX_HOLD_T5 (post-market)`

### factor_exit_rules (per-condition, 32 rules)
- **Trend/momentum** (above_ma20, macd_golden_cross, etc.): trailing=true, time_exit=6h, max_hold=3d
- **Fundamental** (roe_high, revenue_growth_high): trailing=true, time_exit=999h, max_hold=5d
- **Volatility/reversal** (volume_expansion, rsi_oversold): trailing=false, time_exit=0.5h, max_hold=1d
- **Bearish** (below_ma20, insider_net_sell): trailing=false, time_exit=0.5-1h, max_hold=1d

### Conclusion
Exit parameters are reasonable. The biggest improvement lever is signal quality (deep_analysis replacing VotingCoordinator), not SL/TP tuning.
