# 盘前全链路验证（代码改动后，服务运行中）

> 来源：2026-07-08 session，用户问"还有不到1小时开盘了，请完整的全链路检查"
> 场景：在运行中的FTSeek服务上改了代码，需要在开盘前确认不会破坏交易
> 与 pre-launch-verification 的区别：那个是"系统能不能启动"，这个是"改动安全吗"

## 核心问题：运行进程加载的是旧代码还是新代码？

```bash
# 文件修改时间
stat -c "%Y %y" app/core/obsidian_writer.py
# → 1783513630 2026-07-08 20:27:10

# 服务进程启动时间
ps -p <PID> -o lstart=
# → Wed Jul  8 19:51:03 2026

# 结论：mtime(20:27) > process_start(19:51) → 运行进程加载的是旧代码
```

**关键判断**：
- mtime > process_start → 运行进程有旧代码，新代码下次重启才生效
- mtime < process_start → 运行进程已加载新代码
- **不需要紧急重启**：如果改动是加法（新方法不被运行代码调用），旧代码运行不受影响

## 7项验证清单

### 1. 服务状态
```bash
systemctl status ftseek-us.service | head -5
# → Active: active (running)
journalctl -u ftseek-us.service --no-pager -n 30
# → 无异常，position_sync每5min轮询，news_v2采集正常
```

### 2. 语法检查（所有改动文件）
```bash
venv/bin/python3.11 -m py_compile app/core/obsidian_writer.py && echo OK
venv/bin/python3.11 -m py_compile scripts/backfill_symbol_pages.py && echo OK
venv/bin/python3.11 -m py_compile ~/.hermes/skills/deep-stock-analysis/scripts/pipeline.py && echo OK
```

### 3. 改动是否触碰交易路径
```bash
# grep改动模块在交易代码中的引用
grep -rn "obsidian_writer" app/ --include="*.py" | grep -v __pycache__
# → 只在 order_executor.py:5340 (平仓) 和 daily_review.py:1260 (盘后) 被调
# → 新增的 write_symbol_analysis 不在这两个调用点 → 不影响交易

# grep 新方法名在 app/ 中的引用
grep -rn "write_symbol_analysis" app/ --include="*.py"
# → 只在 obsidian_writer.py 定义，无 app/ 调用 → 安全

# grep deep_analysis pipeline 是否被 FTSeek 运行时调用
grep -rn "deep_stock_analysis\|deep-stock-analysis" app/ --include="*.py"
# → 空 = 不在FTSeek运行进程内，是外部skill脚本
```

### 4. app上下文导入测试（模拟order_executor的import路径）
```python
from app.core.obsidian_writer import get_obsidian_writer
ow = get_obsidian_writer()
# 测试现有方法不变
ow.write_trade({...})  # → OK
ow.write_daily_postmarket({...})  # → OK
# 测试新方法存在
assert hasattr(ow, 'write_symbol_analysis')
```

### 5. Broker连接
```python
from futu import OpenQuoteContext
qctx = OpenQuoteContext(host='127.0.0.1', port=11111)
ret, data = qctx.get_market_snapshot(['US.AAPL'])
# → AAPL last_price=310.66 → OpenD正常
```

### 6. 主交易管线配置
```bash
grep -n "_skip_execution_in_trading" app/pipeline/signal_pipeline.py
# → _skip_execution_in_trading = True (scan_loop禁用)

grep -A5 "playbook:" config/unified_config.yaml
# → auto_execute: true, direction_mode: llm_vote
```

### 7. deep_analysis端到端跑通
```bash
cd ~/.hermes/skills/deep-stock-analysis/scripts
venv/bin/python3.11 pipeline.py --mode analyze --symbol US.JPM --synth rule
# → symbol page追加成功, 无error
```

## 判断矩阵：是否需要重启服务

| 改动类型 | 例子 | 需要重启？ |
|----------|------|-----------|
| 新增方法，不被运行代码调用 | write_symbol_analysis | ❌ 不需要 |
| 修改现有方法签名 | write_trade参数变了 | ✅ 必须重启 |
| 修改交易路径上的代码 | order_executor改动 | ✅ 必须重启 |
| 修改配置文件(yaml) | exit_policy.yaml | ❌ HotReloader重载 |
| 修改Python代码(交易路径) | pipeline.py | ✅ 必须重启 |
| 新增独立脚本 | backfill_symbol_pages.py | ❌ 不影响运行时 |

## 关键教训

1. **mtime vs process_start是第一判断**：先确认运行进程是旧代码还是新代码，再决定后续动作
2. **grep import路径是安全判据**：改动模块在app/中哪些地方被import → 那些调用点是否调了新方法
3. **best-effort模式=安全隔离**：新代码在try/except中，失败只log不阻塞 → 即使新代码有bug也不影响交易
4. **skill脚本≠运行时代码**：~/.hermes/skills/下的脚本不在FTSeek Python进程内，改了不影响服务
5. **不完美时诚实列gap**：用户问"完整和完美了吗"→列具体gap→gap分"值得修"和"不该修"→修完再验证
6. **用户说"可以重启"时立即执行**：盘前未开盘时用户允许重启=最佳窗口。systemctl restart → 确认active → tail logs看盘前巡检通过 → 确认无error/traceback。重启后检查: pre-market audit通过+Signal IC正常+Futu连接+新闻采集正常。
