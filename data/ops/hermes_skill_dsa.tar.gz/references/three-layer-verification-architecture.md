# 三层验证体系 + 架构辩论结论

> 核心问题：如何验证"现有信息有没有用"——不只是IC方向对不对，是论据有没有预测力，市场上下文有没有增益。

## 背景

用户问："收集了充足的信息，如何在这些信息中找到或涌现可以收益的策略和执行规则？"

当前IC只验证"BUY方向对不对"——如果NVDA输出BUY，T+1=-1.39%，标为信号错了。但其中-1.26%是SPY大盘拖累，个股alpha只亏了-0.13%。**不剥离大盘的IC会误杀好信号。**

## 第一层：Alpha IC（剥离大盘beta）

### 数据验证

NVDA vs SPY 日收益对比（2026-07）：

| 日期 | NVDA | SPY | Alpha |
|------|------|-----|-------|
| 6/29 | +1.27% | +1.65% | -0.38% |
| 6/30 | +2.63% | +0.78% | +1.85% |
| 7/1 | -1.25% | -0.14% | -1.12% |
| 7/2 | -1.39% | -0.13% | -1.26% |

7/2 NVDA跌-1.39%看起来信号错了，但-1.26%是大盘拖累，个股alpha只亏了-0.13%。

### 实现
ic_writer写入时同时记录SPY的T+1收益，回填时计算`alpha = 个股T1 - SPY T1`。只在signal_snapshots.db加一列，不碰FTSeek运行代码。

### 泛化
SPY做基准对任何股票都适用，不依赖Deepulse覆盖范围。

## 第二层：论据级IC（验证哪个论点真有预测力）

### 问题
当前factors_json存的是`["news","fundamental","sentiment"]`——只知道用了什么类型的来源，不知道具体论点。

### 方案
改为存论点的**可验证断言**：

```json
factors_json = [
  {"thesis": "GB300性能碾压前代20倍", "source": "news", "claim_type": "product_catalyst"},
  {"thesis": "MSPR -77.39高管净卖出", "source": "sentiment", "claim_type": "insider_bearish"},
  {"thesis": "动态PE 39.8低于半导体中枢45.2", "source": "fundamental", "claim_type": "valuation_cheap"}
]
```

T+1/T+5后回溯：信号方向对了时，哪个claim_type出现频率最高？信号方向错时，哪个claim_type在误导？

积累30条后能回答："product_catalyst类论据T+1预测准确率65%，insider_bearish类T+5准确率40%——内部人减持是短期噪声不是长期信号"。

### claim_type分类（泛化到任何股票）
- `product_catalyst` — 产品发布/技术突破/合约变更
- `insider_bearish` — 内部人减持/MSPR负
- `insider_bullish` — 内部人增持/MSPR正
- `valuation_cheap` — PE/PB低于行业中枢
- `valuation_expensive` — PE/PB高于行业中枢
- `technical_breakdown` — 技术破位/空头排列
- `technical_breakout` — 技术突破/多头排列
- `macro_headwind` — 板块弱势/宏观逆风
- `macro_tailwind` — 板块强势/宏观顺风

## 第三层：情境IC（验证"盘感"对不对）

当market_context注入"半导体BEARISH"时，记录这个context。T+5后看：
- 有板块上下文 vs 没有板块上下文的信号，alpha IC差多少？
- 板块弱势+个股BUY的信号 vs 板块强势+个股BUY的信号，胜率差多少？

这验证"市场上下文注入到底有没有用"——不是假设它有用，是用数据证明。

## 架构辩论结论

### 三视角辩论

| 视角 | 结论 | 核心论据 |
|------|------|----------|
| 务实派 | market_context 6/10(有用但不紧急) | 系统从未验证过，先看IC正不正 |
| 务实派 | context_memory 3/10(过度设计) | 362笔样本太稀疏 |
| 创新派 | market_context方向对但不够 | 还缺板块ETF→个股映射+事件提取+资金切换 |
| 创新派 | context_memory需1000+笔 | 特征向量匹配找不到有意义的邻居 |
| 风险派 | 数据时效性假设不成立 | premarket_scan_cache可能不是当天的 |
| 风险派 | LLM注意力分散 | 2000+tokens prompt关键信号被淹没 |
| 风险派 | 最优先:先验证IC | 6条样本0回填，空中楼阁 |

### 最终结论

| 提案 | 决定 | 理由 |
|------|------|------|
| market_context.py Step1(板块强弱映射) | ✅ 值得做 | 11个SPDR ETF覆盖全市场，泛化 |
| market_context.py Step3(宏观上下文) | ✅ 值得做 | VIX+经济事件从daily_battle_plan读 |
| market_context.py Step2(资金切换) | ⏸ 暂缓 | YAGNI，先验证基础有效 |
| context_memory.py(特征向量匹配) | ❌ 不做 | 362笔样本不足，需1000+笔 |

### 前置条件
**等下周二backfill跑完后看deep_analysis的IC。IC>0→market_context值得做。IC<0→先修prompt和数据质量。**

## 关键数据

| 指标 | 值 | 含义 |
|------|-----|------|
| voting_llm IC样本 | 535条t1回填 | FTSeek已有系统的验证基线 |
| voting_llm LONG T1 | +0.0131 | LONG信号有正预测力 |
| voting_llm SHORT T1 | -0.0021 | SHORT信号预测力为负 |
| deep_analysis IC | 6条0回填 | 从未验证过 |
| Deepulse覆盖 | 23只(4%与scanner重叠) | 不能依赖它做泛化 |
| FTSeek板块ETF | 11个SPDR(全市场) | 泛化基础 |

## 泛化能力来源

三层验证天然泛化：
1. **Alpha IC** — SPY做基准，任何股票都能算alpha
2. **论据级IC** — claim_type分类对任何股票都适用
3. **情境IC** — 11个SPDR板块ETF覆盖全市场，不依赖Deepulse的3个domain
