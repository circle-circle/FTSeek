# 市场扫描差距分析：参考报告 vs FTSeek现有管线

> 来源：2026-07-08 session，用户提供了一份高质量机会扫描报告，要求对比FTSeek现有管线提炼能力
> 核心原则：不是简单模仿报告格式，是从中蒸馏出可落地的优化能力

## 参考报告特征（用户提供的标杆）

### 数据广度
- 6个渠道合并：市场异动(movers) + 夜盘(after_hours) + 做空(short_interest) + 热度(heat) + 超预期(earnings_surprise) + 策略筛选
- 252个去重名 → 质量闸 → 137个过闸
- 质量闸过滤：<$5的45个(仙股) + 杠杆/反向ETF 12个 + <$2B的5个 + >30天陈旧PEAD 19个

### 评分体系
- 四信号0-10：catalyst(利好/利空/结构) + momentum(偏多/偏空) + sentiment(偏多/偏空/分歧) + value(低/中/高)
- 多渠道命中加成(每多一渠道+0.5, 封顶10)
- 看法7档自洽
- featured override：综合分被均值口径拉低时(NET momentum=8但value=1拉低到5.3)，手动override到featured
- value trap检测：半导体深回撤机械value分8-10但override到4-5（板块de-rating非市场错杀）

### 市况叙事
- 完整板块轮动叙事："资金从AI/半导体momentum切向能源/价值"
- 具体涨跌幅：能源+0.35%, 工业-3.41%, 房地产+2.60%
- 个股标注：OXY+5.9, COP+4.7, INTC-9.7
- 三条主线分解：①半导体de-rating ②能源/价值轮动 ③软件分化+高beta回落

### 操作分桶
- 做多桶分两类：质地/突破型(NET/OXY/COP) + 战术超跌反弹型(RIVN, 投机·仓位小·止损紧)
- 做空桶分两类：趋势空(INTC) + 回避(falling-knife: AMD/MU/LRCX追空晚, 轧空风险)
- 观望桶：方向打架/事件前(WULF beta4.26破位, SOUND高短仓逼空vs下跌趋势)
- 每桶附粗触发位(SMA10支撑/前高阻力)

## FTSeek现有管线对比

### market_scanner.py（deep_analysis skill）
- 渠道：只有3个（涨幅榜+跌幅榜+量榜, 各10个, 去重后约20-30候选）
- 评分：纯技术（MA排列±1 + 5日动量±0.5 + 量比±0.5 + 52周位置±0.3 + PE区间±0.3~0.5）
- 无catalyst分类, 无sentiment, 无value trap检测, 无featured override
- 市况叙事：4要素（方向定调+极值标注+资金切换+量能）但无板块级映射
- 操作分桶：3桶（score>=6做多 / <=4做空 / 中间观望）无策略子类

### PlaybookScreener（FTSeek运行时）
- 候选来源：27只静态watchlist + factor_engine动态池(MOVER_POOL+dragonhead quote扫描)
- 不做跨渠道榜单发现, 只在已有池子内做quote涨跌幅检测
- 质量门槛：流动性/财报/数据新鲜度过滤
- 不做板块轮动叙事, 不做操作分桶

### premarket_scanner.py（FTSeek运行时）
- 板块轮动：11个SPDR板块ETF涨跌排名(strongest/weakest)
- plan_validator用strongest/weakest做方向一致检查(LONG不在最弱, SHORT不在最强)
- 但无个股→板块归属映射, 无"资金切换叙事", 只是机械ETF排名

## 5个差距（按ROI排序）

### P0: 扩展渠道源 — 加做空榜+夜盘榜+超预期榜
**差距**：只扫涨幅/跌幅/量三个榜, 漏掉夜盘异动(WULF -8.9%)、做空挤压(SOUN高短仓)、财报超预期
**数据源**：Finnhub免费API有earnings calendar + insider sentiment; 富途API有做空数据
**改动量**：加3个collect函数, 在_merge_candidates合并, 候选池从30扩大到100+
**不动运行时**：只改deep_analysis skill的data_collector.py + market_scanner.py

### P1: 板块轮动叙事 + 个股→板块映射
**差距**：FTSeek已有11个SPDR ETF涨跌排名但缺叙事和个股映射
**最短路径**：_quick_score加sector字段(从company_profile.industry读), _market_narrative按sector分组统计
**已有基础**：plan_validator已有strongest/weakest检查, 加个股sector归属就能做硬过滤

### P1: 四信号评分替代纯技术评分
**差距**：当前_quick_score是单维度(技术面), 参考报告是四维度(catalyst+momentum+sentiment+value)
**改动**：
  - catalyst分类：从news标题关键词推断(产品/财报/估值/内部人/技术突破)
  - sentiment：从社区情绪bull/bear_pct
  - value trap检测：PE低但板块de-rating时降分
**不需要完美**：关键是从单维度变多维度

### P2: featured override + value trap检测
**差距**：NET案例——综合分被"近高位→value低"拉低但momentum=8方向确定性最高
**改动**：当某信号(momentum)≥8且方向确定时, 即使综合分不够也单列为featured
**value trap**：板块de-rating时PE低不等于便宜, 需要板块regime override

### P2: 操作分桶细化
**差距**：扫描层就把做多分"质地/突破型"和"战术超跌反弹型", 做空分"趋势空"和"回避(falling-knife)"
**falling-knife检测**：当日跌>5%且5日跌>15%且板块de-rating → 标记回避不追空
**对FTSeek价值**：避免在半导体de-rating时追空被轧

## 实现约束

- **不在FTSeek运行时管线做改动**：7/24冻结期, scan_loop/playbook代码不碰
- **改动集中在deep_analysis skill脚本**：market_scanner.py/data_collector.py, 外部脚本不影响交易进程
- **不新建模块/新DB表**：扩展现有函数, 加collect_xxx, 改_quick_score, 改_market_narrative
- **用户设计哲学**：最短路径——一个缓存文件+几个读取点, 复杂度是敌人
