# OKR 对齐差距分析

> 2026-07-05 会话产出。核心发现：**分析输出达到KO级≠能提升胜率和盈利OKR**。
> 用真实交易数据验证deep_analysis对OKR的实际影响。

## 真实交易基线（2026-07-05 查 trade_records）

### 全量统计
- 总笔数: 383 | 胜: 140 | 负: 243 | 胜率: 36.6%
- 总P&L: $7487 | 均P&L: $19.55 | Profit Factor: 1.12
- 近30天: 60笔 胜率43.3% P&L=+$492（极薄）

### 按方向
| 方向 | 笔数 | 胜率 | P&L | 问题 |
|------|------|------|-----|------|
| LONG | 165 | **27.9%** | **-$5992** | 系统性亏损 |
| SHORT | 205 | 44.9% | +$25936 | 唯一盈利来源 |
| SHORT_PROXY_OPTION | 13 | 15.4% | -$12457 | 期权做空巨亏 |

### 按策略
| 策略 | 笔数 | 胜率 | P&L |
|------|------|------|-----|
| voting_llm | 182 | 42.3% | **-$13371** ← 最大亏损源 |
| scalping | 129 | 20.9% | -$1638 |
| playbook_sim | 19 | 52.6% | -$955 |
| playbook_shadow | 23 | 56.5% | +$242 |

### LONG方向退出原因诊断
| 退出原因 | 笔数 | 胜率 | P&L |
|----------|------|------|-----|
| TRAILING_STOP | 44 | 43.2% | -$1150 |
| sl_hit | 53 | 7.5% | -$995 |
| PRE_CLOSE_EXIT | 20 | 30.0% | -$1151 |
| SL_ATR_STOP | 6 | 0% | -$2737 |
| FLASH_EXIT | 4 | 0% | -$1144 |
| DAY_TRADE_TP | 2 | 100% | +$2315 ← 唯一盈利 |

### LONG持仓时间 vs P&L
| 持仓 | 笔数 | 胜率 | P&L |
|------|------|------|-----|
| 0-2h | 49 | 28.6% | -$6305 ← 短时间大亏 |
| 2-6h | 41 | 48.8% | -$756 |
| 6-12h | 6 | 83.3% | +$394 ← 最优窗口 |
| 12-24h | 6 | 50.0% | +$2436 |
| 24h+ | 63 | 6.3% | -$1760 ← 长持仓必亏 |

## IC数据
- deep_analysis: 5样本 0回填 → 远未达graduation gate(30样本+IC(T+3)>0.05)
- voting_llm: 579样本 535回填 → IC=+0.21 (信号方向正确，但交易亏损→问题在执行/退出)
  - LONG: avg_t1=+1.3% (信号方向对) → 但交易胜率27.9% (执行/退出有问题)
  - SHORT: avg_t1=-0.2% (信号方向弱) → 但交易P&L=+$25936 (退出好)

## 三层差距

### A层：选股——方向先验缺失（deep_analysis能修）
deep_analysis输出BUY信号时不知道LONG方向胜率只有27.9%。LLM看到NVDA基本面强就输出BUY——但市场环境不利多头。

**修复方案**：在pipeline analyze阶段，先查trade_records获取LONG/SHORT近30天胜率。如果LONG胜率<35%，在LLM prompt中注入方向偏置：
```
【方向先验】当前LONG方向近30天胜率仅27.9%，SHORT胜率44.9%。
BUY信号需要score≥8且confidence≥0.8才输出，否则倾向SKIP。
优先寻找做空机会。
```

### B层：退出——不能碰（冻结期7/24）
LONG亏损核心在退出策略：TRAILING_STOP启动太早、0-2h被止损、24h+长持仓必亏。
退出系统7/24前不能碰（Ponytail铁律：never simplify away safety）。

### C层：IC积累——需要时间
deep_analysis只有5条IC样本。graduation gate要求30样本+IC(T+3)>0.05。
cron每天产出4只→约7-8天可积累30样本。在此之前信号无法进入实盘。

## 诊断SQL模板

```sql
-- 全量统计
SELECT COUNT(*) as cnt,
       SUM(CASE WHEN realized_pnl > 0 THEN 1 ELSE 0 END) as wins,
       ROUND(SUM(realized_pnl), 2) as total_pnl,
       ROUND(AVG(realized_pnl), 2) as avg_pnl
FROM trade_records WHERE realized_pnl IS NOT NULL;

-- Profit Factor
SELECT
  (SELECT SUM(realized_pnl) FROM trade_records WHERE realized_pnl > 0) as gross_profit,
  ABS((SELECT SUM(realized_pnl) FROM trade_records WHERE realized_pnl < 0)) as gross_loss;

-- 方向×退出原因
SELECT exit_reason, direction, COUNT(*) as cnt,
       SUM(CASE WHEN realized_pnl > 0 THEN 1 ELSE 0 END) as wins,
       ROUND(SUM(realized_pnl), 2) as pnl
FROM trade_records WHERE realized_pnl IS NOT NULL
GROUP BY exit_reason, direction ORDER BY pnl;

-- IC查询
SELECT strategy_id, COUNT(*) as cnt,
       SUM(CASE WHEN fwd_ret_t1 IS NOT NULL THEN 1 ELSE 0 END) as t1,
       AVG(fwd_ret_t1) as avg_t1
FROM signal_snapshots GROUP BY strategy_id;
```
