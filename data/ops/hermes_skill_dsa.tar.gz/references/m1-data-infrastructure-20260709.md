# M1 Data Infrastructure — 2026-07-09 (deep-stock-analysis v0.36)

## Context

After the first-principles 3-way debate (bull/bear/architect), the consensus was: "accumulating data first" is wrong when the data being accumulated is unanalyzable. Three data infrastructure fixes were landed to make future trades carry full attribution context.

See also: `ftseek-troubleshooting-playbook/references/m1-data-infrastructure-20260709.md` for FTSeek-side implementation details.

## What Was Fixed

### M1-1: MFE/MAE Collection
- `trade_records` got `mfe_pct` + `mae_pct` + `entry_vix` + `entry_session` columns
- `monitor_playbook_sim_exits` now updates MFE/MAE in metadata every 60s cycle (alongside peak_price)
- `_close_trade_record` extracts MFE/MAE from metadata to independent columns at close time
- **Impact**: Can now distinguish "good signal + bad execution" from "bad signal"

### M1-2: decision_id Full-Chain Propagation
- `trade_attribution.decision_id` was 0/214 non-empty — INSERT never wrote it
- `attribution_scheduler.py` now queries `trade_records.decision_id` before INSERT
- **Impact**: Can JOIN trade_attribution → signal_snapshots for signal-to-trade attribution

### M1-3: Factor Snapshot Persistence (f1-f5)
- `trade_records.f1_trend` through `f5_lifecycle` were 0 for ALL rows
- `playbook_service.py` now extracts binary 0/1 factor flags from conditions_json
- `factor_detail` now stores the raw conditions_json string
- **Impact**: Factor-level P&L attribution becomes possible

## Feedback Loop Now Works End-to-End

```
Signal → decision_id + f1-f5 + conditions in metadata
Monitor → peak_price + MFE/MAE updated every 60s
Close → MFE/MAE extracted to independent columns
Post-close → attribution writes decision_id → feedback_loop generates override
```

## Key Pitfall (general pattern)

When you add a column to a table via ALTER TABLE, you MUST also update the INSERT statements that create new rows in that table. The column existing in schema but not being written to is a **silent failure** — queries return NULL/default without error. This pattern was found in:
- `trade_attribution.decision_id`: column existed, INSERT never wrote it
- `trade_records.f1-f5`: columns existed (added by trade_store.py), no INSERT/UPDATE ever wrote them
- `trade_records.mfe_pct/mae_pct`: newly added, both monitor (metadata) and close (independent column) write paths implemented

## Timeline

From 2026-07-10 onward, every new trade carries full attribution context. 4 weeks later (~100 trades), first meaningful attribution analysis is possible. This is the prerequisite for data-driven exit parameter optimization — without MFE/MAE, you cannot know whether to fix the signal or fix the execution.
