# HorizonSelector 趋势强度评分 — 数据驱动设计

> 日期: 2026-07-08
> 关联: PROPOSAL-plan-execute-separation.md, config/playbook_horizon.yaml

## 数据基础

### T1/T3/T5 胜率对比 (playbook_instructions, 94条有T3数据)

| 方向 | n | T1 WR | T3 WR | T5 WR | adj_t1 | adj_t3 | adj_t5 |
|------|---|-------|-------|-------|--------|--------|--------|
| BUY | 51 | 39% | **55%** | 43% | -0.005 | +0.005 | +0.005 |
| SELL_SHORT | 43 | 40% | **60%** | 44% | -0.004 | +0.004 | +0.012 |

**关键发现**: T3(3天)胜率最优. 1天太短(噪音), 5天太长(均值回归), **3天是最佳持有期**.

### 持仓时间 vs PnL

| 持仓时间 | n | 平均PnL | 胜率 |
|----------|---|---------|------|
| <2h | 30 | **-$82.90** | 43% |
| 2-6h | 13 | +$22.16 | 38% |
| **6-12h** | **10** | **+$131.29** | **70%** |
| 12h+ | 3 | -$274.12 | 0% |

**6-12小时是利润甜区. <2h被扫损是亏损主因(30笔亏$2487).**

### 退出原因 vs T5收益

| 退出原因 | n | avg_pnl | avg_t5 | 诊断 |
|----------|---|---------|--------|------|
| EOD_FORCE_CLOSE | 14 | +$128 | +0.022 | ✅赚钱 |
| TIME_EXIT | 15 | -$62 | +0.017 | ❌错误时机平仓(T5正=本该持有) |
| SL_ATR_STOP | 8 | -$356 | -0.009 | 止损太窄 |

## 改动详情

### 1. horizon_selector.py `_fallback_score()` 重写

**趋势强度评分 (trend_strength) 0-6分**:
- 4a: momentum (price vs MA20): |偏离|>3% → +2, >1.5% → +1
- 4b: 均线排列: MA20>MA50 同向 → +1 (BUY), MA20<MA50 → +1 (SHORT)
- 4c: MACD: 金叉→+1 (BUY), 死叉→+1 (SHORT)
- 4d: volume_ratio >1.3: +1
- 4e: trend_5d 方向一致: +1

**高波动一票否决**: VIX>22 或 ATR%>4% → long_score封顶+0.5 (即使趋势再强也走日内)

**评分→horizon映射**:
- TS≥4 且 VIX<20 → long +2.0 (强趋势+低波动=波段)
- TS≥3 → long +1.5
- TS≥2 → long +0.5
- 高波动时以上全部降为 long +0.5 max

### 2. `_extract_features()` 新增字段
- `ma20`, `ma50` (均线排列)
- `trend_5d` (5日趋势方向: up/down/flat)
- `rsi` fallback (兼容SymbolContext的`rsi`字段名, 非只有`rsi_14`)

### 3. playbook_horizon.yaml 配置

| 参数 | 旧值 | 新值 | 理由 |
|------|------|------|------|
| horizon_selector.enabled | false | **true** | 启用趋势分类 |
| long_horizon.rr_ratio | 999 | **2.0** | 波段需要止盈目标 |
| long_horizon.max_hold_days | 5 | **3** | T3 WR最优, T5回落 |

### 4. 验证结果 (7/7真实数据)

| 标的 | 方向 | TS | horizon | 理由 |
|------|------|----|---------|------|
| SNDK | SHORT | 4 | **short** | ATR=13.3%高波动→一票否决 |
| LLY | BUY | 5 | **long** ✅ | 金叉+放量+均线多头+低波动 |
| BA | BUY | 4 | **long** ✅ | 金叉+均线多头+趋势确认 |
| AMZN | BUY | 0 | **short** | 弱趋势, MA20<MA50 |
| PLTR | SHORT | 3 | **long** | 死叉+均线空头+5日下跌 |
| 高波动测试 | BUY | 6 | **short** | VIX=25一票否决 |

## 验证SQL模板

```sql
-- T1/T3/T5 胜率对比
SELECT direction,
       COUNT(*) as n,
       SUM(CASE WHEN (direction='BUY' AND fwd_return_t1>0) OR (direction='SELL_SHORT' AND fwd_return_t1<0) THEN 1 ELSE 0 END) as t1c,
       SUM(CASE WHEN (direction='BUY' AND fwd_return_t3>0) OR (direction='SELL_SHORT' AND fwd_return_t3<0) THEN 1 ELSE 0 END) as t3c,
       SUM(CASE WHEN (direction='BUY' AND fwd_return_t5>0) OR (direction='SELL_SHORT' AND fwd_return_t5<0) THEN 1 ELSE 0 END) as t5c
FROM playbook_instructions
WHERE direction IN ('BUY','SELL_SHORT') AND fwd_return_t3 IS NOT NULL
GROUP BY direction;

-- 持仓时间 vs PnL
SELECT 
    CASE WHEN holding_period_hours < 2 THEN '1_<2h'
         WHEN holding_period_hours < 6 THEN '2_2-6h'
         WHEN holding_period_hours < 12 THEN '3_6-12h'
         ELSE '4_12h+'
    END as bucket,
    COUNT(*), AVG(pnl), SUM(CASE WHEN pnl > 0 THEN 1 ELSE 0 END)
FROM playbook_instructions
WHERE direction IN ('BUY','SELL_SHORT') AND pnl IS NOT NULL
GROUP BY bucket ORDER BY bucket;
```

## 不做的事 (Ponytail判断)
- **T5/过夜波段**: 12h+全亏(avg -$274, 0%WR), T5胜率回落到43-44%. 数据不支持.
- **完整波段(5天)**: T5胜率< T3, 且missed交易T5 WR(62-67%)可能有survivor bias.
- **双轨退出架构**: 不需要新模块, HorizonSelector已在pipeline内, 退出引擎已按horizon读不同配置.
