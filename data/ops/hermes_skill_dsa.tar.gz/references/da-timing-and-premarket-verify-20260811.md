# DA 生成时间与盘前数据覆盖 (2026-08-11, v0.65)

## 时间裁决

- 美股财报 80% 在 06:00–08:30 ET 发布; 原 18:00 CST (06:00 ET) 启动只吃到 2h 盘前数据 → LIF 类财报驱动异动全错过 (LIF 案例: 财报后盘前 -20%, DA 仍按昨收 $64.61 生成 BUY 指令).
- 2026-08-11 用户批准延后: DA cron `e0d574cc1a3c` schedule 从 `0 18 * * 1-5` 改为 **`0 19 * * 1-5`** (19:00 CST = 07:00 ET).
  - 实跑耗时 ~24-29min → ~19:30 CST 就绪, 距开盘 (21:30 CST) 有 2h 缓冲.
  - 不碰 20:00 CST 盘前综合预检 (其 Step 4 读当日指令做 GO/NO-GO, 19:30 就绪后仍可见).
  - 回滚: schedule 改回 `0 18 * * 1-5`.
- 20:00 CST (08:00 ET) 进一步延后**暂缓**: 与 20:00 预检冲突且缓冲只剩 1h; 待验证数据 (趋势几点确立) 再裁.

## 盘后验证闭环 (B类收益攒样)

- cron `2a0eb17a475e` "盘前趋势验证" — no_agent script, 04:40 CST 周二-六 (美股收盘后).
- script: ~/.hermes/scripts/premarket_trend_verify.py (支持 `python3 premarket_trend_verify.py YYYY-MM-DD` 回填).
- 数据源: data/opportunity_scan_{date}.json 的 `premarket_movers` 块 (v0.64 起落盘, |盘前涨跌|≥4%) + playbook_instructions + Futu 日K.
- 产出: data/premarket_trend_outcomes.jsonl (按 date 幂等, 重跑先删当日行) + 飞书报告.
- 报告内容: ①盘前异动延续率+顺势影子收益(开盘→收盘) ②DA指令影子结局(band触及→悲观口径SL/TP/close) ③作废指令的机会成本核查 ④累计统计.
- 决策门槛: n≥30 后评估延续率与影子收益是否支持转实盘信号.

## 技术陷阱

1. bridge 文件 v0.64 起含 `premarket_movers` 块 — DA 决策时点的真实信息集, 验证脚本唯一数据源; v0.64 前的历史文件无此块, 回填时该段显示"无记录" (正常).
2. Futu K线子进程: request_history_kline 断连日志打 stdout 且可能在 JSON **之后** → 解析必须逐行倒序找可解析 JSON, 不能取最后一行 (2026-08-11 实测踩坑).
3. 批量快照分批: 单次 >~130 只返回空; 含任一无效代码(OTC)整批失败 → chunk=30+二分重试 (见 v0.64 pitfalls).
