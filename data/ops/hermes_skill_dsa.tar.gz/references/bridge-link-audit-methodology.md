# Bridge Link Audit Methodology (2026-07-09, updated v0.31)

Reusable 6-point audit for verifying the deep_analysis → FTSeek bridge link end-to-end.
Each point has a concrete verification command and expected output.

## Complete 6-Point Execution Chain

```
① deep_analysis pipeline → bridge JSON file          (skill pipeline.py)
② FTSeek scheduler startup → _try_load_bridge()      (scheduler_core.py L256-260)
③ Bridge candidates → daily_active_pool injection     (pipeline.py _try_load_bridge, v0.30 fix)
④ Pipeline iterates pool → BridgeVotingAdapter.vote() → playbook_instructions (pipeline.py L617)
⑤ _check_intraday_trigger → triggered=1              (pipeline.py L2291-2386)
⑥ auto_execute → execute_instruction → order         (pipeline.py L1970-2288)
```

**Each link must be verified independently.** File generation ≠ execution success.

## Audit Checklist

### 1. Bridge File Generation

```bash
ls -la /opt/ftseek/FTSeek-US/data/opportunity_scan_*.json
```

Read the latest file's structure (first ~100 lines). Expected format:
```json
{
  "trade_date": "YYYY-MM-DD",
  "generated_at": "ISO-8601 with ET offset",
  "market_condition": "...",
  "candidate_count": N,
  "candidates": [
    {symbol, direction("LONG"/"SHORT"), confidence, score, thesis, conditions,
     risks, entry_price, stop_loss, take_profit, position_suggestion,
     entry_strategy, invalidation, strategy_id="deep_analysis",
     decision_id="DA-...", strategy_type, position_size_hint}
  ]
}
```

**Pitfall**: File name uses ET date (`datetime.now(_et_tz).strftime("%Y-%m-%d")`).
At 18:38 ET on 7/8, "today" is still 2026-07-08, not 2026-07-09.

### 2. Runtime Bridge Read Code

```bash
grep -n "BridgeVotingAdapter\|_try_load_bridge\|opportunity_scan" \
  /opt/ftseek/FTSeek-US/app/playbook/pipeline.py \
  /opt/ftseek/FTSeek-US/app/core/scheduler_core.py
```

- `app/playbook/pipeline.py` L296-389: `BridgeVotingAdapter` class + `_try_load_bridge()`
- `app/core/scheduler_core.py` L243-262: bridge override of `voting_coordinator`

### 3. Pool Injection (v0.30 fix — critical)

```bash
# Verify bridge candidates are in pool
/opt/ftseek/FTSeek-US/venv/bin/python3.11 -c "
import json
with open('/opt/ftseek/FTSeek-US/data/daily_active_pool.json') as f:
    pool = json.load(f)
bridge = [e for e in pool['entries'] if e.get('metadata',{}).get('bridge')]
print(f'pool: {len(pool[\"entries\"])} entries, bridge: {len(bridge)}')
for e in bridge: print(f'  {e[\"code\"]} source={e[\"source\"]}')
"
```

**Root cause fixed**: `BridgeVotingAdapter.vote(symbol)` is passive — only fires when
pipeline iterates pool symbols. Bridge candidates not in pool → vote() never called.
**Fix**: `_try_load_bridge()` now injects bridge candidates into pool at load time
(source=SCAN, metadata={bridge:true, strategy_id:deep_analysis}). Idempotent.

### 4. Instruction Generation

```bash
sqlite3 data/ftseek_us.db "SELECT id, symbol, direction, triggered, executed, \
  entry_price, stop_loss, take_profit, decision_id, created_at \
  FROM playbook_instructions WHERE decision_id LIKE 'DA-%' ORDER BY id DESC LIMIT 10;"
```

**Column gotcha**: `playbook_instructions` uses `triggered` and `executed` (not `status`).
If triggered=0 and executed=0 and skip_reason is NULL → instruction was created but
never triggered (not rejected — silently skipped).

**entry_price mismatch**: Bridge file's entry_price comes from
`adapter.to_voting_result()` → `plan.get("entry_price") or kl.get("current")`.
But instruction's entry_price comes from
`instruction_generator.py:298` → `tech.ask or price` (real-time bid/ask).
These can differ by 2-7%. The trigger check uses instruction's entry_price ±1%.

### 5. Trigger Check

```bash
# Check if auto_execute ran and what it logged for bridge candidates
grep -E "TTE|ANET|ASML|未触发|方向穿越触发|盘中触发|跳过.*购买力|跳过.*notional" \
  /opt/ftseek/FTSeek-US/logs/ftseek_us.log | tail -30
```

Trigger logic (`_check_intraday_trigger`, pipeline.py L2291):
- BUY: `current_price <= entry_price × 1.01` (price pulled back to entry zone)
- SHORT: `current_price >= entry_price × 0.99` (price bounced to entry zone)
- Post-trigger SL check: if price already past stop_loss → don't enter

**auto_execute runs every 30min during market hours** (scheduler heartbeat, 30min interval).
Instructions created at 14:28 ET will be checked at 15:24 ET and 15:55 ET.

### 6. Budget / Execution (the real blocker)

```bash
# Check capital_state
sqlite3 data/ftseek_us.db "SELECT current_equity, buying_power, cash, \
  market_value, is_locked, water_level FROM capital_state ORDER BY rowid DESC LIMIT 1;"

# Check auto_execute log for budget rejection
grep "跳过.*购买力\|跳过.*notional" /opt/ftseek/FTSeek-US/logs/ftseek_us.log | tail -10
```

**2026-07-09 log evidence (the ACTUAL root cause)**:
```
15:24 ET — first auto_execute:
  US.TTE  跳过 — 购买力上限 (已用=$44,083 + 新=$28,138 > 限=$45,293)
  US.ANET 跳过 — 购买力上限 (已用=$44,083 + 新=$11,936 > 限=$45,293)
  US.ASML 跳过 — 购买力上限 (已用=$44,083 + 新=$12,359 > 限=$45,293)

15:55 ET — second auto_execute:
  US.TTE  跳过 — 购买力上限 (已用=$31,672 + 新=$28,056 > 限=$54,767)
  US.ANET 跳过 — 单日notional上限 (已用=$18,969 + 新=$11,980 > 限=$19,776)
  US.ASML 跳过 — 单日notional上限 (已用=$18,969 + 新=$12,371 > 限=$19,776)
```

**Root cause = TIMING, not budget**: VotingCoordinator runs盘前 (04:23 ET),
generates 11 instructions, opens positions consuming $44K of $45K budget.
Bridge file generated at 13:19 ET (盘中). Bridge instructions created at 14:28 ET.
By the time auto_execute checks at 15:24 ET, budget is exhausted by VotingCoordinator's
positions. Bridge candidates triggered successfully but were rejected at execution.

## DB Location Gotcha

The root `/opt/ftseek/FTSeek-US/ftseek_us.db` is an EMPTY placeholder (4096 bytes, 0 tables).
The real production DB is at `/opt/ftseek/FTSeek-US/data/ftseek_us.db` (8.2MB, 42+ tables).
Always query `data/ftseek_us.db`.

**Key column names** (common mistakes):
- `open_positions`: uses `size` (not `qty` or `quantity`), no `status` column, `avg_entry_price` (not `entry_price`)
- `playbook_instructions`: uses `executed` and `triggered` (not `status`)
- `trade_records`: no `status` column, uses `realized_pnl` (not `pnl`)
- `capital_state`: no `strategy_id` column
- `failures` table: column is `timestamp` not `created_at`

## 2026-07-09 Full Audit Results

| # | Chain Link | Status | Detail |
|---|-----------|--------|--------|
| ① | Bridge file generation | ✅ | `opportunity_scan_2026-07-08.json` (5496B, 3 candidates: TTE/ANET/ASML) |
| ② | Runtime bridge load | ✅ | Log: `[scheduler] bridge文件加载成功, voting_coordinator → BridgeVotingAdapter` |
| ③ | Pool injection | ✅ | Pool 30→33→37 entries, TTE/ANET/ASML added (source=SCAN, bridge=true) |
| ④ | Instruction generation | ✅ | IDs 539/540/541 created at 14:28 ET, triggered=0, executed=0, skip_reason=NULL |
| ⑤ | Trigger check | ✅ | Price crossed entry±1% → triggered successfully at 15:24 ET |
| ⑥ | Budget/execution | ❌ | **Budget exhausted by VotingCoordinator's盘前 positions** — bridge candidates rejected |

### Root Cause: Timing Gap

```
04:23 ET  VotingCoordinator盘前投票 → 11 instructions → positions opened ($44K used)
13:19 ET  Bridge file generated (盘中, too late for盘前)
14:28 ET  Bridge instructions created (from BridgeVotingAdapter.vote())
15:24 ET  auto_execute: bridge candidates trigger but budget exhausted → "跳过—购买力上限"
15:55 ET  auto_execute retry: budget still exhausted + daily notional cap hit
```

**Fix**: Two cron jobs set up (2026-07-09, schedule changed 2026-07-12):
1. **`deep-analysis-bridge-generation`** (cron `0 4 * * 2-6` = CST 04:00 = **ET 16:00 prev day**, Mon-Sat):
   ⚠️ **实际生成于 ET 16:00 (收盘后), 非盘前**。handoff.md 说 "ET 09:00" 是错的。
   bridge 文件用 `datetime.now(ET)` 生成日期, 在 CST 04:00 时 ET 还是前一天
   → 文件名 = `opportunity_scan_{ET_yesterday}.json`
   → scheduler 在 ET 04:23 盘前查 `opportunity_scan_{ET_today}.json` → **找不到**
   → scheduler fallback 到 TechnicalFallbackAdapter
   → BridgeVotingAdapter 路径是死代码 (见 da-to-executor-consistency-audit-20260712.md [8])
   DA 信号实际通过 DB 直写路径执行 (skill pipeline.py:457 save_instruction)
2. **`ftseek-eod-feedback-loop`** (CST 05:30 = ET 16:30, Mon-Fri):
   Runs `feedback_loop.py` for盘后复盘 + pattern extraction.

With cron #1 (⚠️ 实际状态, 2026-07-12 验证):
```
ET 16:00  deep_analysis cron generates bridge file (收盘后!)
ET 04:23  FTSeek盘前: scheduler 查今日 bridge → 不存在 → TechnicalFallbackAdapter
          (bridge 文件名为 ET_yesterday, scheduler 查 ET_today, 不匹配)
09:30 ET  Market open: DA 信号通过 DB 直写路径执行 (不经 BridgeVotingAdapter)
16:30 ET  feedback_loop复盘
```
⚠️ BridgeVotingAdapter 路径是死代码。DA 信号实际通过 DB 直写路径执行。
详见 da-to-executor-consistency-audit-20260712.md [7]-[8]。

## Quick Verification (post-fix, next trading day)

```bash
# 1. Bridge file exists for today (ET date)
ls -la /opt/ftseek/FTSeek-US/data/opportunity_scan_$(date -u -d "-4 hours" +%Y-%m-%d).json

# 2. FTSeek log shows bridge loaded
grep "bridge文件加载成功\|bridge候选注入pool" /opt/ftseek/FTSeek-US/logs/ftseek_us.log | tail -5

# 3. Pool contains bridge candidates
/opt/ftseek/FTSeek-US/venv/bin/python3.11 -c "
import json; p=json.load(open('/opt/ftseek/FTSeek-US/data/daily_active_pool.json'))
print([e['code'] for e in p['entries'] if e.get('metadata',{}).get('bridge')])"

# 4. Instructions generated for bridge candidates
sqlite3 /opt/ftseek/FTSeek-US/data/ftseek_us.db \
  "SELECT symbol, triggered, executed FROM playbook_instructions WHERE decision_id LIKE 'DA-%' ORDER BY id DESC LIMIT 5;"

# 5. Trade records show deep_analysis execution (the ultimate proof)
sqlite3 /opt/ftseek/FTSeek-US/data/ftseek_us.db \
  "SELECT symbol, direction, realized_pnl, exit_reason FROM trade_records WHERE strategy_id LIKE '%deep%' ORDER BY rowid DESC LIMIT 5;"
```
