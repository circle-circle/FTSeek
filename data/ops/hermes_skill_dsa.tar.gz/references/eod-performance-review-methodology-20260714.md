# EOD 盘后复盘验证方法论

> 2026-07-14 实盘验证。cron 生成的 EOD 报告必须 DB 验证后再评价。

## 核心原则

cron 报告是 LLM 合成的 → 可能遗漏/误报。评价前必须从 `data/ftseek_us.db` 拉原始数据交叉验证。用户质疑数据真实性是最高价值信号。

## 验证流程 (4步)

### Step 1: 单日交易明细
```sql
SELECT symbol, direction, entry_price, exit_price, quantity, realized_pnl, pnl_pct,
       exit_reason, holding_hours, signal_strength, source_type, market_regime,
       mfe_pct, mae_pct, entry_vix, entry_session, signal_confidence, final_strength
FROM trade_records
WHERE trade_date = 'YYYY-MM-DD'
ORDER BY entry_time;
```

### Step 2: 汇总统计 (验证报告数字)
```sql
-- 胜率/盈亏/方向拆分
SELECT
  COUNT(*) as 总笔数,
  COUNT(CASE WHEN realized_pnl > 0 THEN 1 END) as 盈利笔数,
  ROUND(100.0 * COUNT(CASE WHEN realized_pnl > 0 THEN 1 END) / COUNT(*), 0) as 胜率pct,
  ROUND(SUM(realized_pnl), 2) as 总盈亏
FROM trade_records WHERE trade_date = 'YYYY-MM-DD';

-- 方向拆分
SELECT direction, COUNT(*) as 笔数, ROUND(SUM(realized_pnl), 2) as 盈亏
FROM trade_records WHERE trade_date = 'YYYY-MM-DD'
GROUP BY direction;

-- 退出原因拆分
SELECT exit_reason, COUNT(*) as 笔数, ROUND(SUM(realized_pnl), 2) as 盈亏
FROM trade_records WHERE trade_date = 'YYYY-MM-DD'
GROUP BY exit_reason ORDER BY 盈亏 ASC;
```

### Step 3: 7日上下文 (防止单日误判)
```sql
SELECT trade_date,
  COUNT(*) as 笔数,
  ROUND(100.0 * COUNT(CASE WHEN realized_pnl > 0 THEN 1 END) / COUNT(*), 0) as 胜率pct,
  ROUND(SUM(realized_pnl), 2) as 盈亏,
  COUNT(CASE WHEN direction='LONG' THEN 1 END) as LONG,
  COUNT(CASE WHEN direction='SHORT' THEN 1 END) as SHORT
FROM trade_records
WHERE trade_date >= date('YYYY-MM-DD', '-7 days')
GROUP BY trade_date ORDER BY trade_date;
```

### Step 4: 资金状态
```sql
SELECT current_equity, peak_equity, drawdown_pct, max_drawdown_pct, water_level, is_locked
FROM capital_state ORDER BY id DESC LIMIT 1;
```

## 评价维度 (5项)

| 维度 | 检查点 | 信号 |
|------|--------|------|
| **退出策略** | SL_TRAIL_LOCK vs TRAILING_STOP_BY_MAIN vs TIME_EXIT 的盈亏分布 | 退出是 alpha 来源 |
| **入场质量** | confidence 高的信号是否表现好? 高 conf 亏钱 = 入场无预测力 | conf≠风险 |
| **MFE/MAE 数据完整性** | TRAILING_STOP_BY_MAIN 退出是否有 MFE=MAE=0 | 数据流断裂 |
| **开仓集中度** | 所有交易是否在 N 分钟内同时入场? | 集中入场=集中亏损风险 |
| **7日趋势** | 单日结果在 7 日上下文中是反弹还是趋势? | 防单日误判 |

## 2026-07-14 复盘结果

### 概览
- 9 笔交易, 56% WR, +$30.10
- LONG 7 笔 +$6.40, SHORT 2 笔 +$23.70
- equity $98,782, drawdown -2.45%, water_level=green

### 关键发现

**1. MFE/MAE=0 数据断裂 (recurring)**
- CVE LONG (-$63.77) 和 EOG LONG (-$68.89) 退出原因=`TRAILING_STOP_BY_MAIN`, MFE=MAE=0
- 与 7/12 发现的 "mfe 只填 winners" 同类问题 — `TRAILING_STOP_BY_MAIN` 路径未记录价格高低点
- 影响: 无法评估 "如果追踪止损能多挽回多少"
- 根因猜测: position tracking 在该退出路径下未更新 high/low watermark

**2. 高 confidence ≠ 低风险 (recurring, 更多实证)**
- EOG conf=0.92 (全日最高) → -$68.89 (全日最大亏损)
- ORCL conf=0.88 → +$28.50 (第二高, 做对了)
- 7/10 的 conf audit 已发现此问题, 7/14 再次确认

**3. 开仓集中度风险 (新发现)**
- 9 笔中 8 笔在 9:38-9:42 ET (4分钟) 内入场
- 这是 Playbook SIM 的标准行为 (盘前信号 → 开盘批量执行)
- 风险: 7/8 的 -94.31 日 (12 笔 WR 17%) 就是集中入场+方向错的典型案例
- 可检查项: 限制前5分钟最多开仓数, 或分批入场

**4. 退出策略验证**
- SL_TRAIL_LOCK: 4 笔全胜 (NVDA +$101.92, MSFT +$9.41, META +$0.76, ORCL +$28.50)
- TRAILING_STOP_BY_MAIN: 2 笔全亏 (CVE -$63.77, EOG -$68.89) — 与 SL_TRAIL_LOCK 形成对比
- TIME_EXIT: 2 笔小亏 (COIN -$4.80, LLY -$3.20)
- PRE_CLOSE_EXIT: 1 笔胜 (AMZN +$30.16)

**5. 7日上下文**
- 7 日累计 -$53.33, 37 笔交易, 均胜率 33%
- 7/14 是反弹日 (+$30.10) 但未覆盖 7/8 的 -$94.31 坑
