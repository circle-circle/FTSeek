# 时区审计方法论

## 核心教训

**修复一处时区bug后，必须`grep -n "datetime.now()" *.py`扫描所有模块的同模式调用。不能只修当前文件就结束。**

这个教训适用于所有系统性pattern——时区、字段名、错误处理、兜底值——修一处后主动grep同类，不要等用户指出。

## 背景

美股项目的服务器在CST(UTC+8)，但所有交易数据(trade_date/信号时刻/日K日期)用ET(UTC-4 DST/UTC-5 EST)。CST比ET快12-13小时，导致：
- trade_date错位（CST 7/5 11:23 = ET 7/4 23:23）
- backfill找不到日K线（写入周日trade_date，FTSeek找不到该日K线）
- IC永远不回填（非交易日trade_date→backfill跳过）
- 复盘查错日期（CST日期查ET日期的trade_records→空数据）

## 时区bug历史

| 版本 | 发现位置 | 根因 |
|------|---------|------|
| v0.4 | ic_writer _get_et_trade_date() | datetime.now()返回CST |
| v0.10 | 盘前扫描cron | 0 9 * * 1-5 = CST 9:00 = ET 21:00前一天 |
| v0.12 | feedback_loop _get_et_today() | datetime.now()返回CST |
| v0.16 | deep_analyzer回退SQL cutoff | datetime.now()返回CST |
| v0.17 | feedback_loop run_daily + run_backfill | datetime.now()返回CST |
| **v0.18** | **data_collector财报日历** | **datetime.now()返回CST** |
| **v0.18** | **llm_synth财报距今天数** | **datetime.now()返回CST** |
| **v0.18** | **strategy_memory rolling window cutoff** | **datetime.now()返回CST** |
| **v0.18** | **strategy_memory lesson cutoff** | **datetime.now()返回CST** |

## v0.18补修的4处漏网

### 1. data_collector.py:386 — 财报日历查询
```python
# 修复前
today_str = datetime.now().strftime("%Y-%m-%d")  # CST日期

# 修复后
_now = datetime.now()
_offset = timedelta(hours=-4) if 3 <= _now.month <= 11 else timedelta(hours=-5)
today_str = datetime.now(timezone(_offset)).strftime("%Y-%m-%d")  # ET日期
```
影响: Finnhub返回的earningsCalendar日期是ET交易日，用CST日期比对会漏掉/多算财报。

### 2. llm_synth.py:289 — prompt里财报距今天数
```python
# 修复前
today = datetime.now().strftime("%Y-%m-%d")

# 修复后
_now = datetime.now()
_offset = timedelta(hours=-4) if 3 <= _now.month <= 11 else timedelta(hours=-5)
today = datetime.now(timezone(_offset)).strftime("%Y-%m-%d")
```
影响: LLM prompt里"距财报X天"算错，可能误导LLM判断"财报前3日不开仓"。

### 3. strategy_memory.py:229 — 30天rolling window cutoff
```python
# 修复前
cutoff_30d = (datetime.now() - timedelta(days=30)).strftime("%Y-%m-%d")

# 修复后
_now = datetime.now()
_offset = timedelta(hours=-4) if 3 <= _now.month <= 11 else timedelta(hours=-5)
et_now = datetime.now(timezone(_offset))
cutoff_30d = (et_now - timedelta(days=30)).strftime("%Y-%m-%d")
```
影响: pattern_memory.last_trade_date是ET日期，用CST的cutoff比对会多算12小时的交易，边界case漏pattern。

### 4. strategy_memory.py:289 — 7天lesson cutoff
```python
# 修复前
cutoff = (datetime.now() - timedelta(days=7)).strftime("%Y-%m-%d")

# 修复后
cutoff = (et_now - timedelta(days=7)).strftime("%Y-%m-%d")
```
影响: lesson_log.date是ET日期，同上问题。

## ET时区标准代码片段

所有需要生成日期的地方用这个pattern:

```python
from datetime import datetime, timezone, timedelta

_now = datetime.now()
_offset = timedelta(hours=-4) if 3 <= _now.month <= 11 else timedelta(hours=-5)
et_now = datetime.now(timezone(_offset))
et_date_str = et_now.strftime("%Y-%m-%d")
```

简化DST判断: 3-11月用EDT(UTC-4)，12-2月用EST(UTC-5)。不依赖pytz。

## 审计命令

修复时区bug后跑这个命令扫漏网:

```bash
cd ~/.hermes/skills/deep-stock-analysis/scripts
grep -n "datetime.now()" *.py | grep -v "timezone\|_ET_TZ\|et_now\|# \|import\|def \|__pycache__"
```

排除已修复的（含timezone/_ET_TZ/et_now）和注释/import。剩下的就是潜在漏网。

**注意**: `datetime.now().isoformat()`用于时间戳（不是日期比对）的可以保留CST——不影响数据正确性，只是时间戳显示。只有用于**日期比对**的才必须用ET。

## 系统性pattern修复原则

这个方法论不限于时区，适用于所有系统性bug pattern:

1. **字段名不匹配**: 修一处后`grep -n "old_field_name" *.py`扫全模块
2. **兜底值非法**: 修一处后`grep -n "\"default\"" *.py`扫全模块
3. **错误处理吞异常**: 修一处后`grep -n "except.*pass" *.py`扫全模块
4. **时区**: 修一处后`grep -n "datetime.now()" *.py`扫全模块

原则: **系统性bug不会只出现一次——如果在一个模块发现了，其他模块大概率也有。修完必须主动grep，不要等用户指出。**
