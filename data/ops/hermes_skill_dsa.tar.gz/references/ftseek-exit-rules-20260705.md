# FTSeek退出规则全景 (2026-07-05)

deep_analysis信号进入FTSeek执行后，退出由FTSeek的exit_policy.yaml v3.0规则引擎决定。
deep_analysis输出的entry/SL/TP和conditions只是参考，真正退出触发由4条规则执行。

## 当前启用的4条退出规则 (exit_policy.yaml v3.0)

| 规则 | 优先级 | 触发条件 | 执行动作 |
|------|--------|---------|---------|
| ① atr_stop | 硬止损 | entry ± ATR×桶mult | 平仓，max_loss% 1.5-4% |
| ② pre_close_exit | P=2 | 收盘前8分钟 | 盈利≥2ATR全平 / 亏损平 / 微利减半 |
| ③ pre_close adaptive | P=2 | 同上细化 | 盈利100%平 / 保本50%平 / 亏损不强制 |
| ④ earnings_guard | P=4 | 财报前2天+后1天 | 减仓50% |

## 规则①：ATR动态止损（波动率桶自适应）

```
SL = entry ± ATR × multiplier,  且不超过 max_loss%

波动率桶判定: ATR% = ATR / entry_price
┌──────────┬───────────┬──────────┬────────────┐
│ 桶       │ ATR%范围  │ mult     │ max_loss%  │
├──────────┼───────────┼──────────┼────────────┤
│ low      │ <1.5%     │ 1.5×     │ 1.5%       │ ← 低波动SL收紧
│ medium   │ 1.5-3.5%  │ 2.0×     │ 2.0%       │ ← 标准
│ high     │ 3.5-8%    │ 2.5×     │ 3.0%       │ ← 高波动SL放宽防噪声
│ extreme  │ ≥8%       │ 3.0×     │ 4.0%       │ ← 极端波动SL最宽
└──────────┴───────────┴──────────┴────────────┘
滞回区间: 桶切换需超过边界±0.2%, 防止频繁切换
```

## 规则②：盘末退出（收盘前8分钟分层）

```
距收盘≤8分钟时:
  盈利≥2ATR     → 全平（落袋为安）
  微利0~0.5ATR  → 减半仓（保留一半跑隔夜）
  亏损仓         → 全平（loss_flat=true，不持亏过夜）
  隔夜亏损>3%   → 次日止损
```

## 规则④：财报保护

```
财报前2天 + 后1天 → 减仓50%
```

## 禁用的规则（全部因回测EV为负或形同虚设）

| 规则 | 禁用原因 | 历史数据 |
|------|---------|---------|
| breakeven | 2% SL下ratchet意义有限 | — |
| chandelier_trail | 92笔46.7%WR接近零EV | -$34 |
| scale_out | 4笔触发形同虚设 | 50%锁利反而少赚 |
| time_exit | 亏损仓应交给硬止损 | 14笔42.9%WR -$1016 |
| technical_breach | 33笔-$3106误触发多 | 30.3%WR |
| progressive_trailing | 死代码(current_sl写17次读0次) | — |
| day_trade_mode | Phase B.3删除 | — |
| flash_exit | 6笔全亏0%WR纯噪音 | — |

## 退出规则优先级与互斥

```
优先级 (数字越小越优先):
  ① pre_close         P=2   ← 盘末最高优先级
  ② circuit_breaker   P=3   ← 组合熔断(日亏≥3%)
  ③ earnings_guard    P=4   ← 财报保护
  ④ scale_out         P=5   ← (已禁用)
  ⑤ trailing_stop     P=7   ← (已禁用)
  ⑥ time_decay        P=8   ← (dormant)

互斥规则:
  pre_close触发 → 跳过 trailing_stop, time_exit
  time_exit触发 → 跳过 trailing_stop

SHORT方向特殊: trailing_stop优先级从40→30
  但trailing_stop已禁用, 此规则当前不生效

最小持仓时间: 45分钟 (仅硬止损豁免)
  硬止损集合: STOP_LOSS/ATR_LOSS_1X/FLASH_EXIT/QUICK_EXIT/PRE_CLOSE/SL_HIT/HARD_STOP/ATR_STOP
  数据依据: 0min持仓163笔亏-$15413; 5-6h持仓75%WR +$5187
```

## 真实交易退出分布（374笔已平仓）

| 退出原因 | 笔数 | 胜率 | PnL | 平均持仓 | 评价 |
|---------|------|------|-----|---------|------|
| sl_hit | 115 | 16.5% | -$2,023 | 0.0h | 硬止损主力，触发即亏 |
| TRAILING_STOP | 85 | 50.6% | -$3,802 | 2.5h | 50%WR但PnL负→已禁用 |
| STRUCTURE_EXIT | 33 | 30.3% | -$3,106 | 0.5h | 误触发多→已禁用 |
| PRE_CLOSE_EXIT | 33 | 42.4% | +$7,511 | 4.1h | **唯一正PnL主力退出** |
| TIME_EXIT | 14 | 42.9% | -$1,016 | 4.4h | 已禁用 |
| EOD_FORCE_CLOSE | 14 | 85.7% | +$1,786 | 12.2h | **高WR+正PnL** |
| DAY_TRADE_TP | 13 | **100%** | +$13,101 | 4.3h | **最赚钱退出(已禁用)** |
| SL_ATR_STOP | 7 | 0% | -$2,847 | 0.1h | ATR硬止损全亏 |
| FLASH_EXIT | 7 | 0% | -$1,756 | 0.3h | 已禁用 |
| SCALE_OUT | 4 | 100% | +$429 | 7.9h | 已禁用(样本太少) |

## 方向×退出 交叉矩阵（核心发现）

| 方向 | 最赚退出 | 最亏退出 | 关键差异 |
|------|---------|---------|---------|
| LONG | DAY_TRADE_TP 2笔100% +$2,315 | SL_ATR_STOP 6笔0% -$2,737 | LONG+硬止损全亏 |
| LONG | EOD_FORCE_CLOSE 5笔100% +$470 | TRAILING_STOP 44笔43% -$1,150 | LONG+trailing净亏 |
| SHORT | DAY_TRADE_TP 11笔100% +$10,786 | BREAKEVEN_STOP 2笔0% -$6,125 | SHORT+breakeven灾难 |
| SHORT | PRE_CLOSE_EXIT 13笔62% +$8,662 | STRUCTURE_EXIT 33笔30% -$3,106 | SHORT+structure误杀 |

## deep_analysis与FTSeek退出系统的关系

```
deep_analysis输出 (adapter.py)
    │
    ├─ voting_result → FTSeek._submit_order() → 开仓
    │   └─ conditions: ["news_positive", "revenue_growth_high", ...]
    │      (27个合法枚举, 用于退出规则匹配)
    │
    ├─ exit_meta → FTSeek._check_playbook_exit_rules()
    │   └─ cohort: "A", stop_loss: $198, peak_price: $237
    │      conditions: ["news_positive", "revenue_growth_high", "sentiment_bullish"]
    │
    └─ 开仓后 → FTSeek退出系统接管
        │
        ├─ ExitRuleDispatcher.evaluate() 按优先级检查
        │   ├─ pre_close (P=2): 收盘前8min分层退出
        │   ├─ circuit_breaker (P=3): 日亏≥3%熔断
        │   ├─ earnings_guard (P=4): 财报前2天减仓50%
        │   └─ atr_stop (硬止损): entry±ATR×桶mult, max 2%
        │
        └─ position_exit_monitor.scan_positions() 每60秒扫描
            └─ ExitRuleRegistry.check_all_rules()
                ├─ pre_close (优先级10)
                ├─ trailing_stop (优先级40, 但已禁用)
                └─ scale_out (优先级60, 但已禁用)
```

**关键点**：deep_analysis输出的conditions和exit_meta进入FTSeek后，实际退出由FTSeek的4条规则决定。
- deep_analysis建议的止损价如果比ATR计算的更紧，会用ATR的
- deep_analysis建议的止盈价如果碰到收盘前8分钟盈利≥2ATR，会提前平掉
- deep_analysis的conditions用于FTSeek的`_get_factor_exit_config`匹配退出规则配置

## 关键源码位置

| 文件 | 职责 |
|------|------|
| `app/risk/exit_policy.yaml` | 退出策略SSOT配置(4条规则+禁用规则) |
| `app/risk/exit_rule_dispatcher.py` | 统一退出调度器(优先级+互斥) |
| `app/risk/exit_rules/exit_rule_registry.py` | 退出规则注册表(渐进式替代scan_positions) |
| `app/risk/exit_rules/trailing_stop.py` | ATR动态止损+Chandelier追踪(已禁用但代码保留) |
| `app/risk/exit_rules/pre_close.py` | 盘末分层强制退出 |
| `app/risk/exit_rules/scale_out.py` | 分批止盈(已禁用) |
| `app/risk/exit_rules/exit_reason_enum.py` | 所有退出原因枚举(30+种) |
| `app/risk/position_exit_monitor.py` | 退出监控主入口(每60秒扫描) |
| `app/playbook/condition_taxonomy.py` | 27个合法condition枚举+方向约束 |
