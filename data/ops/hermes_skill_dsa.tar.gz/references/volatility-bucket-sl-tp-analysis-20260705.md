# 波动率桶×方向 SL/TP 数据推导 (2026-07-05)

## 背景

用户问: "已经不同标的股做分层和分桶的策略，其SL和TP在这种设置中是否也需要考虑不同的阈值，如何更优雅高效实现？"

当前exit_policy.yaml的波动率桶只分了SL（atr_stop的vol_bucket_multipliers），TP是统一的2ATR（pre_close_exit.close_profit_atr）。**SL做了波动率适配，TP没有。**

## 当前配置

```yaml
# SL: 已分桶（4桶×2参数）
vol_bucket_multipliers:
  low:     {atr_pct<1.5%,  mult=1.5×, max_loss=1.5%}
  medium:  {1.5-3.5%,      mult=2.0×, max_loss=2.0%}
  high:    {3.5-8%,        mult=2.5×, max_loss=3.0%}
  extreme: {≥8%,           mult=3.0×, max_loss=4.0%}

# TP: 不分桶，统一2ATR（仅盘末8分钟触发）
pre_close_exit:
  close_profit_atr: 2.0
```

消费链路: `ExitPolicyGuardian._select_vol_bucket(atr_pct, vol_buckets, param_key)` → 按atr_pct选桶 → 返回atr_multiplier或max_loss_pct → `atr_stop_engine.compute_stop_lines()`使用。

## 数据切片（374笔真实交易）

### 按桶×方向 盈亏价格变动中位数

用 `ABS(exit_price - entry_price) / entry_price * 100` 作为价格变动%代理ATR%。

| 桶 | 方向 | 盈利中位数变动 | 亏损中位数变动 | 盈亏比 | 样本(盈/亏) |
|-----|------|-------------|-------------|-------|-----------|
| low(<1.5%) | LONG | 0.26% | 0.24% | 1.06 | 35/94 |
| low | SHORT | 0.29% | 0.31% | 0.92 | 58/99 |
| medium(1.5-3.5%) | LONG | 2.12% | 2.25% | 0.94 | 5/11 |
| medium | SHORT | 1.88% | 2.26% | 0.83 | 18/7 |
| high(3.5-8%) | LONG | **6.17%** | 4.27% | **1.44** | 5/7 |
| high | SHORT | 5.93% | 7.47% | 0.79 | 13/3 |
| extreme | — | 数据不足 | 数据不足 | — | — |

### 核心发现

1. **low桶**: 价格变动<0.3%，2ATR止盈可能永远不触发（ATR%<1.5%时2ATR≈3%价格变动，但盈利中位数只有0.26%）
2. **high桶LONG**: 盈亏比1.44是唯一正期望的——但当前TP=2ATR可能在盈利6%前就被pre_close的2ATR阈值触发平掉
3. **所有桶的SHORT盈亏比<1**——SHORT方向需要更紧的TP（快止盈）和更宽的SL
4. **low桶SL=1.5%远超实际亏损中位数0.24%**——止损位放太宽，等到1.5%亏损时已经太晚了

### 当前桶配置的SL/TP不匹配

| 桶 | 当前max_loss | 亏损中位数 | 当前TP(2ATR) | 盈利中位数 | 问题 |
|-----|------------|----------|-------------|----------|------|
| low | 1.5% | 0.24% | ~3% | 0.26% | SL太宽(1.5% vs 0.24%)，TP太远(3% vs 0.26%) |
| medium | 2.0% | 2.25% | ~4% | 2.12% | SL略宽，TP太远 |
| high | 3.0% | 4.27% | ~6% | 6.17% | SL合理，TP合理 |
| extreme | 4.0% | 数据不足 | ~8%+ | 数据不足 | 样本太少 |

## 数据推导的分桶×方向 SL/TP阈值

推导原则: SL = 亏损中位数×1.2（给50%的亏损仓位反转空间），TP = 盈利中位数×1.5（让盈利继续跑一点）

| 桶 | 方向 | SL建议 | TP建议 | 盈亏比 | 当前SL | 当前TP | 调整方向 |
|-----|------|-------|-------|-------|--------|--------|---------|
| low | LONG | 0.3% | 0.4% | 1.3 | 1.5% | ~3% | SL收紧5倍, TP收紧8倍 |
| low | SHORT | 0.4% | 0.4% | 1.0 | 1.5% | ~3% | SL收紧4倍, TP收紧8倍 |
| medium | LONG | 2.7% | 3.2% | 1.2 | 2.0% | ~4% | SL放宽, TP略收 |
| medium | SHORT | 2.7% | 2.8% | 1.0 | 2.0% | ~4% | SL放宽, TP收 |
| high | LONG | 5.1% | 9.3% | 1.8 | 3.0% | ~6% | SL放宽, TP放宽 |
| high | SHORT | 9.0% | 8.9% | 1.0 | 3.0% | ~6% | SL放宽3倍, TP放宽 |
| extreme | LONG | 维持 | 维持 | — | 4.0% | ~8% | 样本不足 |
| extreme | SHORT | 维持 | 维持 | — | 4.0% | ~8% | 样本不足 |

## 优雅高效实现方案

### 方案设计原则
1. 复用已有`_select_vol_bucket`（桶选择+滞回逻辑），只扩展返回值
2. yaml配置扩展，direction_override是optional的，不配走原逻辑（向后兼容）
3. 最小代码改动：加2个方法+1个检查点

### Step 1: yaml配置扩展（改1个文件，冻结期内可执行）

```yaml
atr_stop:
  vol_bucket_multipliers:
    low:
      atr_pct_max: 0.015
      atr_multiplier: 1.5
      max_loss_pct: 1.5
      # 新增: 分方向SL覆盖
      direction_override:
        LONG:  {max_loss_pct: 0.3}
        SHORT: {max_loss_pct: 0.4}
      # 新增: 分桶TP配置
      take_profit_pct: 0.4
    medium:
      atr_pct_max: 0.035
      atr_multiplier: 2.0
      max_loss_pct: 2.0
      direction_override:
        LONG:  {max_loss_pct: 2.7}
        SHORT: {max_loss_pct: 2.7}
      take_profit_pct: 3.0
    high:
      atr_pct_max: 0.08
      atr_multiplier: 2.5
      max_loss_pct: 5.0  # 从3.0→5.0
      direction_override:
        LONG:  {max_loss_pct: 5.1, take_profit_pct: 9.0}
        SHORT: {max_loss_pct: 9.0, take_profit_pct: 8.9}
    extreme:
      atr_pct_max: 999.0
      atr_multiplier: 3.0
      max_loss_pct: 4.0
      # extreme样本不足, 维持现状
```

### Step 2: ExitPolicyGuardian加2个方法（7/24后改代码，约20行）

```python
def get_max_loss_pct(self, atr_pct=0, direction=''):
    """按桶×方向获取max_loss_pct"""
    bucket_cfg = self._select_vol_bucket_cfg(atr_pct)
    if direction and bucket_cfg.get('direction_override', {}).get(direction):
        return float(bucket_cfg['direction_override'][direction]['max_loss_pct'])
    return float(bucket_cfg.get('max_loss_pct', 2.0))

def get_take_profit_pct(self, atr_pct=0, direction=''):
    """按桶×方向获取盘中TP阈值(新增)"""
    bucket_cfg = self._select_vol_bucket_cfg(atr_pct)
    if direction and bucket_cfg.get('direction_override', {}).get(direction):
        override = bucket_cfg['direction_override'][direction]
        if 'take_profit_pct' in override:
            return float(override['take_profit_pct'])
    return float(bucket_cfg.get('take_profit_pct', 0))  # 0=不启用盘中TP
```

### Step 3: pre_close_exit加盘中TP检查（7/24后改代码，约15行）

在`pre_close.py`的`check_pre_close_exit`开头加:

```python
# 盘中TP: 盈利达桶配置阈值 → 部分止盈(50%)
tp_pct = guardian.get_take_profit_pct(atr_pct, direction)
if tp_pct > 0 and profit_pct >= tp_pct:
    return {
        "reason": "INTRADAY_TP",
        "reason_cn": f"盘中止盈(盈利{profit_pct:.2f}%≥{tp_pct}%)",
        "exit_price": current_price,
        "close_ratio": 0.5,  # 平50%
    }
```

### 改动量汇总

| 文件 | 改动 | 行数 | 冻结期内可改？ |
|------|------|------|-------------|
| exit_policy.yaml | 加direction_override+take_profit_pct | ~20行yaml | ✅配置文件 |
| exit_policy_guardian.py | 加get_take_profit_pct+改get_max_loss_pct | ~20行 | ❌FTSeek代码(7/24后) |
| pre_close.py | 加盘中TP检查 | ~15行 | ❌FTSeek代码(7/24后) |

## 关键风险提醒

1. **low桶样本量大(129笔LONG+157笔SHORT)但high桶样本少(5+13笔)**——high桶的阈值建议置信度低
2. **"亏损中位数×1.2"是假设**——实际最优SL需要回测验证，当前数据只能推导方向不能推导精确值
3. **盘中TP是复活DAY_TRADE_TP的思路**——但DAY_TRADE_TP的100%WR可能来自幸存者偏差(只13笔)
4. **7/24冻结期内只能改yaml**——direction_override和take_profit_pct加进去不会被消费，但为7/24后一键启用做好准备

## 退出策略5条建议（基于374笔真实数据）

| 优先级 | 建议 | 改动量 | 预期收益 |
|--------|------|--------|---------|
| P0 | loss_flat改false | 1行yaml | 亏损仓均亏$500→$27, 预估省$9,000 |
| P1 | 恢复1.5%盘中止盈 | 加几行yaml | 复活100%WR的DAY_TRADE_TP |
| P2 | LONG/SHORT方向差异化pre_close窗口 | yaml配置 | LONG给更多时间, SHORT快止盈 |
| P2 | LONG max_loss_pct 1.5% | 1行yaml | 减少LONG硬止损亏损金额 |
| P2 | deep_analysis止损位作为ATR上限 | 需7/24后改代码 | 让分析止损位不被覆盖 |

### 亏损仓退出方式对比（核心数据支撑）

| 退出方式 | 笔数 | 均亏 | 持仓时间 | 结论 |
|---------|------|------|---------|------|
| sl_hit（硬止损） | 96 | **-$27** | 0.0h | 最快, 亏最少 |
| STRUCTURE_EXIT | 23 | -$168 | 0.5h | 中等亏损 |
| SL_ATR_STOP | 7 | -$407 | 0.1h | ATR止损更宽 |
| TRAILING_STOP | 42 | -$428 | 2.3h | 追踪止损变亏损 |
| **PRE_CLOSE_EXIT** | 19 | **-$500** | 2.8h | **盘末退亏损仓, 亏最多!** |

**结论**: 亏损仓等盘末退(PRE_CLOSE_EXIT均亏$500) 比硬止损(sl_hit均亏$27) 亏18倍! → pre_close的loss_flat=true是错误策略。

### 持仓时间×方向 盈亏矩阵

| 方向 | 最优时段 | 最差时段 | 关键差异 |
|------|---------|---------|---------|
| LONG | 6-12h(83%WR+$394) 12-24h(50%WR+$2436) | 0-0.5h(29%WR-$3586) | LONG需要时间发展 |
| SHORT | 0.5-2h(49%WR+$18849) 6-12h(80%WR+$8162) | 24h+(32%WR-$6012) | SHORT利润来自快速下跌 |

## 关键源码位置

| 文件 | 职责 |
|------|------|
| `app/risk/exit_policy_guardian.py:195-279` | `get_atr_multiplier()` + `_select_vol_bucket()` + `get_max_loss_pct()` |
| `app/risk/atr_stop_engine.py:267-287` | `compute_stop_lines()` 硬止损+ATR止损计算 |
| `app/risk/exit_rules/trailing_stop.py:22-200` | ATR动态止损+Chandelier追踪+Regime自适应 |
| `app/risk/exit_rules/pre_close.py:25-229` | 盘末分层退出(盈利全平/亏损平/微利减半) |
| `app/risk/exit_rule_dispatcher.py:57-486` | 统一退出调度器(优先级+互斥) |
