# 上线前验证方法论（v0.10）

> 来源：2026-07-05 session，用户问"下周一是否可以运行和验证这套系统了？"
> 教训：不能凭记忆回答"能跑"——必须系统验证每个依赖层，这次验证发现了cron时区bug。

## 12项验证清单

### Layer 1: 运行时环境

```python
# 1. Python venv存在
venv_py = "/opt/ftseek/FTSeek-US/venv/bin/python3.11"
os.path.exists(venv_py)  # → True

# 2. futu-api版本正确
subprocess.run([venv_py, "-c", "import futu; print(futu.__version__)"])
# → 10.05.6508

# 3. OpenD进程运行中
subprocess.run(["pgrep", "-af", "OpenD"])
# → PID 967/1127
```

### Layer 2: 代码完整性

```python
# 4. 全部模块文件存在（11个）
expected = ["config.py","data_collector.py","market_scanner.py","llm_synth.py",
            "deep_analyzer.py","adapter.py","ic_writer.py","pipeline.py",
            "strategy_memory.py","signal_gate.py","feedback_loop.py"]
for f in expected:
    assert (skill_dir / f).exists()

# 5. 全部模块可导入（无import错误）
code = """
import sys; sys.path.insert(0, scripts_dir)
for mod in ['config','data_collector','market_scanner','llm_synth',
            'deep_analyzer','adapter','ic_writer','strategy_memory',
            'signal_gate','feedback_loop']:
    __import__(mod)
"""
# → 10/10 OK
```

### Layer 3: 密钥+API可达性

```python
# 6. 密钥从.env.us正确加载
from config import DASHSCOPE_KEY, FINNHUB_KEY
bool(DASHSCOPE_KEY)  # → True (sk-2b206...)
bool(FINNHUB_KEY)    # → True (d604po9r...)

# 7. Finnhub API可达
r = requests.get(f'https://finnhub.io/api/v1/quote?symbol=AAPL&token={FINNHUB_KEY}')
r.status_code  # → 200
r.json()['c']  # → 308.63 (AAPL实时价格)

# 8. DashScope API可达
r = requests.post('https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions',
                  json={'model':'qwen3.7-max','messages':[{'role':'user','content':'say hi'}],'max_tokens':10},
                  headers={'Authorization': f'Bearer {DASHSCOPE_KEY}'})
r.status_code  # → 200
r.json()['choices'][0]['message']['content']  # → "Hi! 👋"
```

### Layer 4: 链路可执行

```bash
# 9. 单股深度分析完整跑通
cd ~/.hermes/skills/deep-stock-analysis/scripts
/opt/ftseek/FTSeek-US/venv/bin/python3.11 pipeline.py --mode analyze --symbol US.NVDA
# → 14/14数据源 → LLM产出 → IC写入 → Signal Gate PASS score=70

# 10. 市场扫描可运行
/opt/ftseek/FTSeek-US/venv/bin/python3.11 pipeline.py --mode scan --limit 5 --top 2
# → 15只候选 → 2做多+1做空+2观望

# 11. 盘后复盘可运行（周日无交易应返回"无交易记录"）
python3.11 -c "import feedback_loop; print(feedback_loop.run_daily())"
# → "📊 2026-07-05 复盘\n无交易记录"
```

### Layer 5: 数据库+Cron

```python
# 12. 数据库健康
# strategy_memory.db: pattern_memory=64, symbol_memory=92, lesson_log=148
# signal_snapshots.db: signal_snapshots=971
# ftseek_us.db: trade_records=383

# 13. Cron时区验证（关键！）
# CST=UTC+8, ET=UTC-4(夏令时), 差12小时
# 盘前扫描: 0 18 * * 1-5 → CST 18:00 = ET 6:00 → 开盘前3.5h ✅
# 盘后复盘: 0 5 * * 2-6 → CST 5:00 = ET 17:00 → 收盘后1h ✅
# FTSeek盘前预检: 0 20 * * 1-5 → CST 20:00 = ET 8:00 → 开盘前1.5h
```

## 发现的bug：cron时区错误

| 配置 | 修改前 | 修改后 | 影响 |
|------|--------|--------|------|
| 盘前扫描 | `0 9 * * 1-5` (CST 9:00=ET 21:00前一天) | `0 18 * * 1-5` (CST 18:00=ET 6:00) | 原来12.5h前数据+FTSeek预检后才有结果 |
| 盘后复盘 | `0 5 * * 2-6` (CST 5:00=ET 17:00) | 不变 ✅ | 收盘后1h，正确 |

## 关键教训

1. **"能跑吗"= 12项全过，不是凭记忆说"应该能"** — 这次验证在Layer 5发现了时区bug
2. **美股cron必须做CST→ET换算** — CST 9:00不是"早上9点跑"，是ET前一天晚上9点
3. **密钥不在环境变量里不代表读不到** — config.py的`_read_env()`从`.env.us`文件读取，cron环境也能用
4. **API可达性必须实测** — 不能假设"上次能用这次也能"，要发HTTP请求看status_code
5. **feedback_loop是函数式接口不是类** — `run_daily()`直接调，不`FeedbackLoop()`实例化
