# LLM 幻觉检测基础设施 (2026-07-11 辩论实证)

## 现状: 3层防护, 2层未接线

### 1. `_verify_sourced_numbers()` — 有计算无执行

- **位置**: `llm_synth.py:828`
- **功能**: 检查LLM输出的bull_case/bear_case中的数字是否在输入数据中
- **调用**: `synthesize()` L668调用, 结果写入 `result["_source_verification"]`
- **断点**: `pipeline.py` 和 `adapter.py` 都不消费 `_source_verification` 字段
- **修复**: 接线, `unverified_count > 3 → 降confidence` (~5行)

### 2. `_load_claim_ic_for_prompt()` — 已工作但范围太小

- **位置**: `llm_synth.py:568`
- **功能**: 注入top3/bottom3 claim IC反馈到LLM prompt
- **状态**: 已工作, 但只注入3+3个
- **修复**: 扩展, 对 IC<-0.1 的 claim_type 直接标注 "禁用" (~5行)

### 3. `_run_challenger()` — 抓到但不拦

- **位置**: `llm_synth.py:675`
- **功能**: deepseek-v4-pro独立审查, 38%命中率
- **数据**: 16条被挑战论据中6条含编造/选择性偏差 (38%)
- **断点**: 抓到后只降confidence(25-35), 信号仍写入DB仍执行
- **结果**: conf<40的8笔0%胜率, avg -$3.52/笔
- **修复**: weakness含"编造/与数据矛盾/不存在" → 直接SKIP (~8行)

## 幻觉模式分类 (3天bridge文件实证)

| 类型 | 案例 | 检测方法 | 修复 |
|------|------|---------|------|
| 编造证据 | META: "散户讨论热度飙升"但30帖0条提META | 挑战者能抓 | 迭代2: 幻觉→SKIP |
| 数据幻觉 | WDFC: "内部人增持MSPR=58.13"但5笔全shares=None | source verification能抓 | 迭代5: 接线_verify |
| 选择性同行 | NVDA: AMD210x是盈利低谷非正常锚; COIN: 漏MSCI/MCO | Finnhub peers API分类不准 | 迭代3: 扩展peers |
| 循环论证 | META: "创2024初最佳单周表现"=价格结果非催化原因 | 挑战者能抓 | 迭代2: 幻觉→SKIP |

## 5项迭代修复路径

1. **conf<40执行层硬拦截** (5行) — 止血, 阻止0%胜率信号执行
2. **幻觉→SKIP** (8行) — 挑战者抓到编造/选择性偏差 → 不写入DB
3. **同行列表扩展** (10行) — data_collector层扩展Finnhub peers + 同PE范围公司
4. **claim IC扩展** (5行) — IC<-0.1的claim_type在prompt中标注禁用
5. **source verification接线** (5行) — unverified>3 → 降confidence

## 辩论排除的非幻觉问题

| 问题 | 排除理由 |
|------|---------|
| 时效性(盘前≠盘中) | 属于entry zone方案范畴, 不是幻觉 |
| 市场环境(QQQ趋势变化) | 执行端_apply_market_state_overlay已有二次检查 |
| 隔夜跳空(gap) | 不是幻觉, 是信号质量问题 |
| 流动性幻觉(高价股) | 不是幻觉, 是执行质量问题 |

## 从美股市场特征的洞察

1. **机构主导(80%)** → 散户情绪数据(META案例社区帖子)价值有限
2. **earnings周期(每3个月)** → 数据新鲜度问题, claim IC反馈(迭代4)已部分覆盖
3. **板块轮动** → 已有SPY+industry_peers, 板块ETF是P2增量

## 来源

- 辩论文档: `ftseek-us/docs/debates/DEB-20260711-llm-hallucination-optimization.md`
- 计划文档: `ftseek-us/.hermes/plans/2026-07-11_124500-entry-zone-type-redesign.md`
- 数据: 3天bridge文件(opportunity_scan_2026-07-08/09/10.json) + DB查询
