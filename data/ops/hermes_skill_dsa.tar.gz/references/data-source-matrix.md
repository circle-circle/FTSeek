# Data Source Matrix — 完整数据源可用性矩阵

## futu-api SDK 版本兼容性

| Python环境 | futu-api版本 | 状态 | 问题 |
|-----------|-------------|------|------|
| hermes-agent venv (python3.11) | 10.2.6218 | ❌ | protobuf 6.33.6 冲突, import直接失败 |
| FTSeek venv default (python3.8) | 10.3.6308 | ⚠️ | 旧版, 无F10/研究API, 无OrderBookType |
| FTSeek venv python3.11 | 10.05.6508 | ✅ | 唯一可用环境, 有OrderBookType兼容fix |

**正确调用方式**: `/opt/ftseek/FTSeek-US/venv/bin/python3.11`

## OpenD API 可用方法 (futu-api 10.05.6508)

### OpenQuoteContext — 可用

| 方法 | 字段/说明 |
|------|----------|
| get_market_snapshot | 130+字段: 价格/PE/PB/EPS/市值/52周高低/换手率/盘前盘后/Bid-Ask |
| get_cur_kline | 实时K线(需num参数) |
| request_history_kline | 历史K线(start/end/ktype/autype/max_count) |
| get_stock_filter | 全市场筛选(SimpleFilter+StockField+SortDir) |
| get_capital_flow | 资金流向历史(大/中/小单) |
| get_capital_distribution | 当日大中小单买卖分布 |
| get_owner_plate | 所属行业/概念板块 |
| get_technical_unusual | 技术异动(K线形态/MACD/RSI/KDJ/CCI等) |
| get_financial_unusual | 资金异动(分布/经纪商/流向/卖空) |
| get_derivative_unusual | 衍生品异动(期权大单/IV/量价/情绪) |
| get_broker_queue | 经纪队列(仅港股) |
| get_option_chain / get_option_expiration_date | 期权链/到期日 |
| get_market_state | 市场状态(开盘/休市) |
| get_rt_data / get_rt_ticker | 分时/逐笔 |

### 不可用 (此SDK版本无此方法, 需新版SDK)

| 方法 | 替代 |
|------|------|
| get_financials_statements | Finnhub stock/metric |
| get_research_analyst_consensus | Finnhub stock/recommendation |
| get_valuation_detail | Finnhub stock/metric (PE/PB/PS) |
| get_insider_trade_list | Finnhub insider-transactions |
| get_short_interest / get_daily_short_volume | Finnhub (部分覆盖) |
| get_corporate_actions_buybacks | 暂无替代 |
| get_research_morningstar_report | 暂无替代 |
| get_shareholders_holding_changes | 暂无替代 |
| get_financials_earnings_price_history | Finnhub calendar/earnings |

## Finnhub 免费层 API

### 可用端点

| 端点 | 数据 | KO示例对应 |
|------|------|-----------|
| stock/metric?metric=all | 133字段: 营收增长(YoY/5Y)/ROE/ROA/利润率/PE/PB/PS/Beta | "Q1营收+12.1%, ROE45.8%" |
| stock/recommendation | strongBuy/buy/hold/sell(按月) | "26家机构目标价" |
| stock/insider-transactions | 交易明细(日期/人/方向/股数/价格) | "高管套现8175万" |
| stock/insider-sentiment | MSPR(月度净买卖比) | 管理层信心信号 |
| stock/profile2 | 行业/国家/交易所/市值/流通股 | 公司分类 |
| calendar/earnings | 下次财报日期+EPS/营收预期 | "7/28财报撞FOMC" |

### 403 Forbidden (免费层不可用)

| 端点 | 替代 |
|------|------|
| stock/price-target | 从研报标题LLM提取 |
| calendar/economic | 外部知识(CPI/FOMC日期) |
| stock/candle | OpenD get_kline |
| company-news | 富途news_search |

## 富途HTTP API (无需认证)

| 端点 | 用途 |
|------|------|
| ai-news-search.futunn.com/news_search?news_type=1 | 新闻(最新10条) |
| ai-news-search.futunn.com/news_search?news_type=3 | 研报(最新5条) |
| ai-news-search.futunn.com/stock_feed | 社区帖子(30条) |

**参数**: keyword=标的代码, size=数量, lang=zh-CN/en, sort_type=2(时间排序)

## 密钥来源

| 密钥 | 环境变量 | 文件来源 | 注意 |
|------|---------|---------|------|
| DashScope | DASHSCOPE_API_KEY | /opt/ftseek/FTSeek-US/.env.us | 禁硬编码, 完整key才不401 |
| Finnhub | FINNHUB_API_KEY | 同上 | 免费层60 calls/min |

## 关键修复记录

1. **common.py OrderBookType**: 10.05.6508无此枚举 → try/except fallback为None
2. **get_snapshot.py脚本只返12字段**: 直接调get_market_snapshot API取130+字段
3. **DashScope key 401**: 硬编码key不完整 → 从config.py读.env文件
4. **signal_tracker.py删除**: FTSeek已有signal_ic_tracker + ic_tracker, 重复造轮子
5. **F10 API不可用**: futu-api 10.05.6508的OpenQuoteContext无get_financials等F10方法 → Finnhub替代
