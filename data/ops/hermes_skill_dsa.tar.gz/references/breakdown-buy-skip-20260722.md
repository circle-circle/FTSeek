# 破位硬买拦截 (2026-07-22, 用户B授权)

## 问题
DA 连续多日 100% BUY (7/20-7/22 零 SHORT)。溯源:
- 7/18 取消"保底2空"配额 (改按 conviction 择优) → 正确, 但副作用:
  44 只固定优质 watchlist conviction 恒高, 把 scanner 跌幅榜候选挤出前 N。
- 更深层: prompt 双向、动量方向已算 (pipeline.py:113-119)、冲突已检测
  (signal_gate.py:105-114), 但冲突仅 quality_score-10 (soft), 高质量价值叙事
  仍能以 WARN/tiny 出 BUY = 逢跌硬买接飞刀。

## 判断
DA 定位=优质大盘股日内多头选股器。对该池"逢跌买价值"是合理立场
(日内无方向edge, 追跌做空成本/风险更高)。故:不让 DA 做空自己的优质池,
但也不该"破位还硬买"。做空机会交由 UE 不设限浮现负责 (UE 已双向, 每日1L1S)。

## 改动
signal_gate.py 最终决策段, 2 档降级后追加:
  if scanner_direction == "bearish" and direction == "BUY":
      tier = "SKIP"   # → BLOCK (pipeline.py:438 不写DB不执行)
仅 bearish动量+BUY 生效; bullish+SELL_SHORT 仍走原降档; 顺势/震荡不误伤。

## 验证
bearish+BUY→BLOCK; bullish+BUY→WARN; neutral+BUY→WARN (测试通过)。
生效时机: 次日 ET06:00 Hermes DA job。
回滚: 删除该 if 块 (备份 scripts/signal_gate.py.bak-20260722_preB)。
