# 交易经验注入：个股复盘+赢亏pattern归因 (v0.8)

> v0.7的方向门禁方案已被v0.8取代。v0.7说"LONG弱就不让BUY"——太粗暴。
> v0.8改为个股级复盘+pattern匹配：提供历史信息让LLM自己判断，不强制。
>
> 用户原话："市场也是动态的 不能完全依赖历史的整体方向经验，
> 还是需要根据个股的复盘和归因等信息能够识别到高概率真正的机会点
> 不要被完全束缚了"

## 设计理念

核心转变：从"方向门禁"到"个股级智能归因"。

- v0.7（废弃）：LONG整体胜率<40% → BUY score门槛提高到8+ → 大概率SKIP
  - 问题：NVDA在$189.8+GB300催化可能是那20%会赢的long，一刀切SKIP错杀机会
- v0.8（当前）：提供个股历史+赚钱/亏钱setup+退出效果 → LLM自己判断
  - NVDA历史3笔全亏但GB300催化够强 → 仍输出BUY，但constraints标注历史全亏+入场更谨慎

## 5层经验文本结构

`_get_trade_experience()` 查询FTSeek trade_records，生成5层信息注入LLM prompt。

### Layer 1: 个股历史复盘（不限时间窗口，最近5笔）
```sql
SELECT direction, exit_reason, realized_pnl, holding_hours,
       signal_strength, entry_price, exit_price, trade_date
FROM trade_records
WHERE symbol = ? AND realized_pnl IS NOT NULL
  AND strategy_id NOT IN ('manual','manual_sync','reconciler','futu_sync','broker_reconcile')
ORDER BY trade_date DESC
LIMIT 5
```
输出格式：
```
本股US.NVDA近期3笔交易: 0胜3负 PnL=$-2905 方向=LONG,SHORT 退出=PRE_CLOSE_EXIT,STRUCTURE_EXIT
  2026-05-01 LONG 亏 PnL=$-815 reason=PRE_CLOSE_EXIT hold=0.0h
  2026-05-01 SHORT 亏 PnL=$-1302 reason=STRUCTURE_EXIT hold=2.5h
  2026-04-30 LONG 亏 PnL=$-787 reason=PRE_CLOSE_EXIT hold=5.6h
```

### Layer 2: 近期赚钱setup（7天内，pnl>0）
```sql
SELECT direction, exit_reason, COUNT(*) as cnt,
       SUM(CASE WHEN realized_pnl > 0 THEN 1 ELSE 0 END) as wins,
       ROUND(SUM(realized_pnl), 0) as pnl,
       ROUND(AVG(holding_hours), 1) as avg_hold
FROM trade_records
WHERE trade_date >= ? AND realized_pnl > 0
  AND strategy_id NOT IN (...)
GROUP BY direction, exit_reason
ORDER BY pnl DESC
LIMIT 3
```
输出：`近期赚钱setup: SHORT+EOD_FORCE_CLOSE(4笔4胜 PnL=$419 hold=17.2h)`

### Layer 3: 近期亏钱setup（7天内，pnl<0）
同Layer 2但 `realized_pnl < 0`，`ORDER BY pnl ASC`

### Layer 4: 30天方向参考（标注"不强制"）
```sql
SELECT direction, COUNT(*) as cnt,
       SUM(CASE WHEN realized_pnl > 0 THEN 1 ELSE 0 END) as wins,
       ROUND(SUM(realized_pnl), 0) as pnl
FROM trade_records
WHERE trade_date >= ? AND realized_pnl IS NOT NULL
  AND strategy_id NOT IN (...)
GROUP BY direction
```
输出：`30天方向参考(不强制): LONG:31笔 WR=42% PnL=$-3187 | SHORT:22笔 WR=55% PnL=$+1686`

### Layer 5: 退出效果（30天，cnt>=2）
```sql
SELECT exit_reason, COUNT(*) as cnt,
       SUM(CASE WHEN realized_pnl > 0 THEN 1 ELSE 0 END) as wins,
       ROUND(SUM(realized_pnl), 0) as pnl
FROM trade_records
WHERE trade_date >= ? AND realized_pnl IS NOT NULL
  AND strategy_id NOT IN (...)
GROUP BY exit_reason
HAVING cnt >= 2
ORDER BY pnl DESC
LIMIT 5
```
输出：`退出效果: EOD_FORCE_CLOSE(14笔 WR=86% PnL=$+1786); PRE_CLOSE_EXIT(4笔 WR=50% PnL=$+194)`

## LLM Prompt使用原则

写在USER_PROMPT_TEMPLATE末尾（指导原则，不是硬规则）：

```
【交易经验参考——如果提供了"近期交易经验"数据，按以下原则使用】
- 这不是方向门禁！不要因为"LONG整体弱"就一律拒绝BUY。市场是动态的，个股setup才是关键。
- 个股复盘优先：如果本股历史交易全亏（如"NVDA 3笔0胜PnL=-$2904"），需要更强的理由才输出同方向信号
- pattern匹配：如果当前个股的setup接近"近期赚钱setup"（如SHORT+EOD_FORCE_CLOSE），可以更积极；如果接近"近期亏钱setup"（如LONG+sl_hit），需要额外确认
- 退出效果参考：如果DAY_TRADE_TP胜率100%但TRAILING_STOP胜率51%且PnL为负，说明当前市场环境下"快止盈"比"让利润奔跑"更有效——在execution_plan中倾向更紧的止盈
- 方向参考是背景信息不是硬约束：30天LONG胜率40%不代表这只股的LONG一定亏，但如果本股历史LONG也全亏，那就是双重确认应该更保守
- 如果本股无历史交易记录，用整体方向参考+pattern匹配做判断，不要因为缺数据就SKIP
```

## 验证：NVDA vs AVGO

### NVDA（历史3笔全亏 PnL=-$2905）
- direction: **BUY** (不SKIP!) score=7
- LLM判断：GB300/Nemotron催化 > 历史全亏
- constraints: "[HIGH] 近期3笔NVDA交易全亏(PnL -$2905)，LONG+PRE_CLOSE_EXIT模式失效，需规避盘中追涨"
- risks: "近期LONG交易3连亏，市场微观结构不利于多头持仓过夜"
- entry: 分2批+触发条件(15min K线站稳$192.5+量>1.2倍均量)

### AVGO（历史2笔1胜1负，7/2 SHORT赢$169）
- direction: **SKIP** score=5
- LLM判断：MSPR=-88.69(比NVDA更极端)+CEO亲自卖+跌幅-24.7% > 目标价空间+52.6%
- entry: "严禁左侧接刀"，等$356前低企稳+MA10突破+MACD金叉

### v0.7 vs v0.8 对比
| 维度 | v0.7方向门禁 | v0.8个股归因 |
|------|---|---|
| NVDA | SKIP（错杀） | BUY score=7，constraints标注历史全亏 |
| AVGO | 也会SKIP（但理由错） | SKIP（因为MSPR更差+跌幅更大，不是因为LONG弱） |
| 个股复盘 | 无 | ✅ "3笔全亏PnL=-$2905"放进constraints |
| pattern匹配 | 无 | ✅ "LONG+PRE_CLOSE_EXIT模式失效" |
| 退出效果 | 无 | ✅ EOD_FORCE_CLOSE 86%→倾向隔夜持有 |
| 一刀切 | 是 | 否——LLM自己判断个股setup是否值得冒历史风险 |

## 真实交易赢亏pattern（2026-07-05诊断）

### 赢的pattern（全量383笔）
- DAY_TRADE_TP: 13笔 100%胜率 PnL=+$13100 ← 日内止盈最赚
- EOD_FORCE_CLOSE: 14笔 86%胜率 PnL=+$1785 ← 隔夜到收盘平
- 赢的avg_hold=4.0h vs 亏的avg_hold=2.7h ← 赢的拿得久一点

### 亏的pattern
- sl_hit: 115笔 17%胜率 ← 止损被打是最大亏损源
- BREAKEVEN_STOP: 2笔 0% PnL=-$6125 ← 保本止损反而巨亏
- SHORT_PROXY_OPTION: 全亏 ← 期权做空血洗

### 个股级表现（关键发现）
- NVDA: 3笔全亏 PnL=-$2904 ← 不是"LONG弱"，是"NVDA这只股弱"
- QCOM: 43笔 23%胜率 PnL=-$3768 ← 高频亏钱
- ARM: 36笔 36% PnL=+$83 ← 高频但不赚
- ORCL: 22笔 45% PnL=+$1950 ← 有赚头
- SNDK: 7笔 57%胜率 PnL=+$1283 ← SHORT赚钱

## 实现位置

- `deep_analyzer.py`: `_get_trade_experience()` 方法 + `_synthesize()` 调用
- `llm_synth.py`: `synthesize(collected, trade_experience="")` 参数 + USER_PROMPT_TEMPLATE使用原则
