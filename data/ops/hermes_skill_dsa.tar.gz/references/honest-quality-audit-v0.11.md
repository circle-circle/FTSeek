# v0.11 诚实质量审计 — 7项修复

> 2026-07-05: 用户问"完整和完美了吗"，诚实列出11个gap后改掉能改的7项。

## 修复前的核心问题

NVDA实跑输出看起来很好——14/14数据源ok、Gate PASS score=70、推荐TRAILING_STOP退出。但深入检查发现：

| 维度 | 表面 | 真实 |
|------|------|------|
| 数据质量 | 14/14 ok | capital_flow全0、anomalies全0、earnings_calendar空壳 → 只有11项有信息量 |
| LLM论据 | "ROE 111.7%" | 无溯源约束，LLM可能从新闻标题摘数字当事实 |
| 社区情绪 | 30条帖子 | HTML实体乱码(`$&#38328;`)，LLM无法理解 |
| pattern推荐 | "推荐TRAILING_STOP" | 基于7笔50%WR——统计意义为零，是噪声 |
| Gate决策 | PASS(70) normal | 用噪声数据强推退出方式，应该是WARN+small |

## 7项修复

### 1. 数据质量三级评估 (llm_synth.py)
- `_has_meaningful_data(d)`: 遍历dict每个值，全0/None/空列表→False
- 审计输出: "11完整/1降级/3缺失" + 降级明细 + "降级维度不可作为论据依据"
- 修复前: 只检查`_error`和空值 → API返回200但内容全0也算"完整"

### 2. LLM论据溯源清单 (llm_synth.py)
- `_extract_source_numbers(collected)`: 从snapshot/fundamentals/insider/analyst/earnings提取24个关键数字
- 生成"论据溯源清单"注入prompt
- USER_PROMPT加硬性约束: "每个数字必须来自溯源清单，不得编造；ROE必须从基本面指标section引用，不得从新闻标题摘取"
- 修复前: LLM无约束，可能编造数字

### 3. 社区情绪HTML解码 (llm_synth.py + deep_analyzer.py)
- `_strip_html()`: 先`re.sub(r'<[^>]+>','')`去标签，再`html.unescape()`反转义实体
- 修复前: `$&#38328;&#36844;` → 修复后: `$美光科技 (MU.US)$`

### 4. pattern置信度标注 (strategy_memory.py)
- `_confidence_level(trades)`: <5→very_low / 5-19→low / 20-49→medium / 50+→high
- win_patterns/loss_patterns/exit_effectiveness都带confidence字段
- format_hint_for_prompt: 低置信pattern标注"[低置信,仅参考]"

### 5. Gate低置信不强推退出 (signal_gate.py)
- 赚钱pattern匹配: 低置信只加5分(原10)，不设recommended_exit
- 退出效果推荐: 低置信只提示"13笔样本不足"不设为recommended_exit
- 修复前: 7笔50%WR强推TRAILING_STOP → 修复后: "退出参考(低置信): DAY_TRADE_TP PnL=$13100 但仅13笔样本不足"

### 6. scanner市值过滤提升 (data_collector.py)
- `--min-market-cap 100`→`500` (1亿美元→5亿美元)
- 修复前: 扫到LOBLY/SPIIY/VARRY等小盘ADR → 修复后: AZN/SAN/UPS/AAPL/NVDA等大盘股

### 7. scanner主流标的偏好 (market_scanner.py)
- `_quick_score()`加市值评分: <5B降0.5 / ≥100B加0.3
- 80+主流ticker(NVDA/AAPL/MSFT等)加0.2分+标注"主流标的"

## 修复前后NVDA Gate对比

| 维度 | 修复前 | 修复后 |
|------|--------|--------|
| Gate decision | PASS (70) | WARN (50) |
| recommended_exit | TRAILING_STOP | 空（不强推） |
| position_size | normal | small |
| pattern_match | 有匹配 | null（样本不足） |
| 退出推荐理由 | "推荐退出TRAILING_STOP" | "退出参考(低置信): DAY_TRADE_TP PnL=$13100 但仅13笔样本不足" |

## 仍不完美的（能力边界，非bug）

- IC样本不足: 需7天积累（cron每天+4条）
- FTSeek冻结期: 7/24后才能验证真实执行
- Finnhub免费层: 无机构目标价列表（KO示例的"26家均值85.97"需付费）
- 休市日数据: 周日scan的change_pct=0

## 教训

**"能跑" ≠ "完美"**：核心链路通了、API通了、IC写入了——这是"能用"，不是"好用"。用户问"完美了吗"时，正确回答不是"全部验证通过"，而是诚实列出具体gap，然后改掉能改的。
