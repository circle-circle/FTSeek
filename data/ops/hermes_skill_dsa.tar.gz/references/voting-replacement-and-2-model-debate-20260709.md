# Voting Replacement & 2-Model Debate + Bridge Direct-Write DB (v0.39-v0.40)

## Context

User requested: "取消三模型投票阶段, 重点是将信息采集和行业市场和个股关联做高质量分析, 可以考虑在计划阶段通过两个模辩论分析决策出的方向和指令"

Then: "上我需要实现指令产生 和 交易执行进行模块化解耦, 通过skills +交易管线分开, 可以分别迭代"

## Problem Diagnosis

### 3-Model Voting Accuracy: 47% ≈ Random

From decisions.db (7/7 04:xx batch, 38 stocks):
- **deepseek_v4_pro**: 37 SHORT / 5 LONG (88% bearish) — systematic short bias
- **qwen3.7_max**: 37 LONG / 5 SHORT (88% bullish) — systematic long bias  
- **glm_5_2**: 23 LONG / 19 SHORT (relatively balanced) — actual decision-maker

DeepSeek and qwen cancel each other out → glm becomes the sole decider.

### Noise Trading in 48-52 Strength Zone

```
BABA: final=51 → SHORT (1 point difference)
COIN: final=51 → SHORT
CRM:  final=50 → LONG
```

### Conditions vs Direction Contradiction (30% of instructions)

Conditions (from screener): `above_ma20`, `macd_golden_cross` (bullish technicals)
Direction (from voting): `SELL_SHORT`

Result: "做空, 条件是MACD金叉+价格在均线上方" — self-contradictory.

## v0.39: Cancel 3-Model Voting

### 1. FTSeek: NullVotingAdapter (cut noise source)

**File**: `app/core/scheduler_core.py` + `app/playbook/pipeline.py`

**Before**: bridge missing → VotingCoordinator (47% ≈ random)
**After**: bridge missing → NullVotingAdapter (all SKIP, no trading)

NullVotingAdapter.vote() always returns None → pipeline SKIPs all candidates.

### 2. Skill: Enhanced Data Collection (16 → 18 dimensions)

**`collect_market_context()`**: SPY/QQQ daily K-line (MA5/MA20/MA50/trend) + VIX
**`collect_industry_peers()`**: Same industry top 5 peers' recent performance via Finnhub `/stock/peers` + Futu snapshots

### 3. Skill: 2-Model Debate

**Pass 1 (Analyst)**: qwen3.7-max — comprehensive analysis with 18-dimension context
**Pass 2 (Challenger)**: deepseek-v4-pro — reads Pass 1, challenges weak claims, gives independent direction

**Why deepseek as challenger?** It's 88% bearish — that's a feature for a "devil's advocate" role.

**Merge logic**:
- Same direction + agree → confidence +1 tier
- Different direction + score gap >3 → direction=SKIP
- Different direction + score close → confidence -1 tier

**AAPL test result**: Analyst SKIP(5), Challenger SELL_SHORT(3), Challenger found QQQ DOWN -3.4%, shrinking top pattern, insider selling.

## v0.40: Bridge Direct-Write Instruction to DB (P0 Fix)

### P0-1: Bridge candidates never become instructions (CRITICAL)

**Root cause**: `_write_bridge_file()` only writes bridge JSON, but `run_playbook_generate()` has idempotency check (DB has instructions → skip). VotingCoordinator runs at ET 04:17 → creates 42 DEC-format instructions → idempotency → bridge at ET 09:00 can't regenerate.

**Evidence**: 23 bridge candidates, 42 instructions all DEC-format (VotingCoordinator), 0 DA-format (deep_analysis), 12 trades all [voting], 0 [bridge].

**Fix**: `_write_bridge_file()` now also calls `PlaybookDB.save_instruction()` to direct-write instruction to DB. UPSERT by date+symbol handles duplicates (bridge overwrites VotingCoordinator's instructions).

**Verification**: After clearing today's instructions and running bridge generation → DB has DA-format instructions (NVDA BUY conf=70 entry=$197.8 SL=$191.0).

### P0-2: Debate results not in bridge file

**Root cause**: `_debate`/`debate_outcome` are in `llm_synth.synthesize()` return dict, stored by `deep_analyzer._apply_llm_result()` to `self.result._llm_output`, then `asdict(self.result)` → `a["_llm_output"]["_debate"]`. Direct `a.get("_debate")` = None.

**Fix**: `a.get("_llm_output", {}).get("_debate", {})` — extract from _llm_output.

### P0-3: NullVotingAdapter SKIP overwrites bridge BUY

**Root cause**: NullVotingAdapter.vote() → None → pipeline SKIP → `save_instruction` UPSERT overwrites bridge's BUY with SKIP.

**Fix**: `run_playbook_generate()` type check — if voting_coordinator is NullVotingAdapter, return None immediately (~8 lines).

## Verification

```
✅ Bridge→DB: US.NVDA BUY conf=70 DA-format instruction
✅ Debate in bridge: "⚠️ 2-model disagreement(BUY vs SKIP)" + challenger details
✅ NullVotingAdapter: bridge missing → all SKIP, doesn't overwrite bridge BUY
✅ FTSeek service: restart OK, bridge loaded (23 candidates → BridgeVotingAdapter)
```

## Ponytail + Karpathy Principles

- No new modules/interfaces/services — reused `PlaybookDB.save_instruction()`
- No changes to auto_execute — already sorts by confidence, DA- prefix first
- No changes to scheduler_core — NullVotingAdapter already deployed
- No changes to re-price mechanism — bridge entry/SL/TP are estimates, auto_execute uses real-time bid/ask
- 3 surgical edits ~60 lines, no FTSeek runtime code changes

## v0.41: Exit Parameter Tightening

### Background

MFE median = 1.5%, 85% of profit given back. EOD is only stable profit (86% WR +$1786). SL is biggest bleed (0% WR -$2865).

### Changes (playbook_horizon.yaml factor_exit_rules)

| Parameter | Old | New | Rationale |
|---|---|---|---|
| default breakeven_at_pct | 1.5% | 1.0% | Earlier breakeven, reduce SL bleed |
| default drawdown_from_peak_pct | 0.8% | 0.5% | Tighter profit locking, reduce giveback |
| Trend types drawdown (macd/ma20/ma50 etc) | 0.6-0.7% | 0.5-0.6% | Align with default |
| Fundamental types drawdown (insider/revenue/roe) | 0.6% | 0.5% | Align with default |
| Sentiment types drawdown (sentiment_bullish) | 0.6% | 0.5% | Align with default |

### What NOT changed (YAGNI)

- `rr_ratio=999` (no TP) — MFE too low, TP=3% never triggers
- SL parameters (vol_buckets) — wait for MFE/MAE data-driven decision after 20+ trades
- EOD_FORCE_CLOSE — only stable profit source, don't touch
- No partial profit-taking — position size too small ($3,280/trade), commission ratio too high

### Expected effect

```
Old: entry→+1.5%→breakeven → +2%→pullback 0.8%→lock 0.7% profit
New: entry→+1.0%→breakeven → +1.5%→pullback 0.5%→lock 0.5% profit
```

Earlier breakeven reduces SL_FIXED_PCT bleeding. Tighter drawdown reduces giveback from 85%. EOD remains the stable fallback.

### Lesson

Exit parameter tuning should look at data first. MFE median 1.5% means TP=3% never triggers — should use drawdown_from_peak + EOD to take profit, not TP. breakeven 1.5%→1.0% for earlier capital protection. Wait for 20+ MFE/MAE trades before data-driven SL/TP decisions.

## Complete Chain (Expected Flow)

```
CST 21:00 (ET 09:00): deep_analysis cron → full pipeline
  18-dim collection (SPY/QQQ/industry peers) → 2-model debate (qwen→deepseek)
  → bridge JSON + instruction direct-write to DB (DA-format)

CST 21:30 (ET 09:30): FTSeek service
  → bridge exists → BridgeVotingAdapter
  → run_playbook_generate → NullVotingAdapter skip (doesn't overwrite)
  → auto_execute → read DA-format instruction → sort priority → re-price → execute
```
