# Trigger Zone Fix + factor_detail List Type Bug — 2026-07-09

## Fix 1: Trigger Zone ±1% → ±5% + Extreme Gap >8%

### Diagnosis
User asked: "执行计划和指令是否有基于盘中具体数据和情况能够动态感知调整？"

DB query showed 5 bridge instructions, all triggered=0, executed=0, 0 trades.
auto_execute ran twice (09:43 + 10:08 ET), all 3 gap-up stocks skipped:

```
2026-07-09 21:43:07 ⚔️ US.PSX gap过大, 跳过触发: current=$188.27 entry=$178.98 gap=5.2%
2026-07-09 21:43:25 ⚔️ US.VLO gap过大, 跳过触发: current=$282.87 entry=$271.30 gap=4.3%
2026-07-09 21:43:48 ⚔️ US.MPC gap过大, 跳过触发: current=$281.62 entry=$265.00 gap=6.3%
```

### Root Cause
LLM produces "pullback buy" strategies (entry=MA5, "wait for pullback to $178.98").
But stocks gap up 3-6% at open → price never reaches entry±1% → 0% trigger rate.

Old trigger logic:
```python
_touch_zone = 0.01  # ±1%
triggered = current_price <= entry_price * (1 + _touch_zone)  # BUY
# gap filter: abs(gap) > 3% → skip (不分方向)
```

### Fix (pipeline.py:2420-2441)
```python
_chase_zone = 0.05  # ±5% 追入区
if is_short:
    _trigger_lower = entry_price * (1 - _chase_zone)
    triggered = current_price >= _trigger_lower
else:
    _trigger_upper = entry_price * (1 + _chase_zone)
    triggered = current_price <= _trigger_upper

# 极端gap过滤 (>8%): 暴涨暴跌中不入场
_price_gap = abs(current_price - entry_price) / entry_price
if _price_gap > 0.08:
    return False
```

### Live Verification (after restart)
```
22:45:19 [playbook] 方向穿越触发: US.VLO price=$281.85 entry=$271.30 dir=BUY
22:45:19 [playbook] 盘中触发: US.VLO BUY
22:45:27 [playbook] re-price: US.VLO BUY 盘前=$271.30 → 实时=$281.72 SL=269.04 (4.50%) TP=304.54
22:44:14 [playbook] 方向穿越触发: US.NVDA price=$200.71 entry=$197.80 dir=BUY
22:44:14 [playbook] re-price: US.NVDA BUY 盘前=$197.80 → 实时=$200.71 SL=191.67 (4.50%) TP=216.96
22:44:37 [playbook] 方向穿越触发: US.TTE price=$78.57 entry=$76.80 dir=BUY
22:44:45 [playbook] re-price: US.TTE BUY 盘前=$76.80 → 实时=$78.57 SL=76.08 (3.17%) TP=83.05
```

3/5 triggered successfully. PSX(5.5%) and MPC(6.3%) correctly skipped (>5% chase zone).

### What NOT to do (YAGNI)
- No LLM intraday re-evaluation (latency + cost)
- No entry_strategy text parsing (NLP complexity, low ROI)
- No batch execution (wait for infrastructure validation)

---

## Fix 2: factor_detail list type → save_trade "unsupported type"

### Symptom
NVDA and TTE triggered successfully, broker order filled, but `save_trade` failed:
```
22:44:18 ERROR: [playbook] futu_simulate trade_record 写入失败, 回滚平仓 US.TTE: Error binding parameter 34 - probably unsupported type.
22:44:18 WARNING: [playbook] futu_simulate US.TTE 成交价=0, 用实时报价$78.55兜底记账
```

Trade_record write failed → attempted rollback close → broker had no position (already filled) → orphan position.

### Root Cause Chain
```
PlaybookDB._row_to_dict() in app/playbook/db.py:
  → auto-parses JSON fields: conditions_json, raw_instruction_json, etc.
  → conditions_json: string '["news_positive",...]' → list ["news_positive",...]

playbook_service.py line 925:
  "factor_detail": inst.get("conditions_json", "")
  → passes list (not string) to save_trade

trade_store.py line 664:
  if isinstance(factor_detail, dict):        ← only handles dict!
      factor_detail = json.dumps(...)
  elif not factor_detail:                    ← list is non-empty, doesn't enter
      factor_detail = None
  # factor_detail stays as list → sqlite3 → "unsupported type"
```

### Reproduction
```python
# Reproduces the exact error:
record = {
    ...
    'factor_detail': ['news_positive', 'pe_below_industry', 'sentiment_bullish'],  # LIST
    ...
}
ts = TradeStore('data/ftseek_us.db')
ts.save_trade(record)
# → ProgrammingError: Error binding parameter 35: type 'list' is not supported
```

Parameter 35 (1-indexed) = factor_detail in the INSERT statement.
(Initial logs said "parameter 34" due to a voting_data setdefault shifting the count.)

### Fix (trade_store.py:664)
```python
# Old: if isinstance(factor_detail, dict):
# New: if isinstance(factor_detail, (dict, list)):
```

### Verification
```python
# Before fix: FAILED: ProgrammingError: Error binding parameter 35: type 'list' is not supported
# After fix:  SUCCESS: rowid=1033
```

### General Pattern
**Any auto-JSON-parse layer** (`_row_to_dict`, `to_dict`, etc.) converts TEXT columns from string to list/dict. All downstream consumers must handle ALL possible types:

```python
# WRONG (only handles dict):
if isinstance(factor_detail, dict):
    factor_detail = json.dumps(factor_detail, ...)

# CORRECT (handles dict AND list):
if isinstance(factor_detail, (dict, list)):
    factor_detail = json.dumps(factor_detail, ...)
```

### Orphan Position Cleanup
- TTE: 1 share orphan in open_positions (qty=1, avg=78.54, owner=auto_main, acct=sim)
- NVDA: already rolled back (qty=0)
- Manual cleanup needed: `DELETE FROM open_positions WHERE symbol='US.TTE' AND owner_strategy='auto_main'`

### VLO confidence gate (not a bug)
VLO triggered + re-priced successfully, but was skipped by quality gate:
```
22:45:27 [playbook] US.VLO confidence=60 < 70.0, 跳过
```
This is by design — 2-model debate produced confidence=60 (direction disagreement BUY vs SKIP). The min_confidence=65 gate is working correctly. Whether to lower it to 60 should wait for new pipeline data validation.
