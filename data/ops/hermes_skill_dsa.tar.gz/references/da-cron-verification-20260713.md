# DA 18:00 Cron 扫描状态验证方法 (2026-07-13)

## 触发条件
用户问"DA扫描是否正常执行" / "18:00扫描和指令生成是否正常" / "DA cron状态"

## 验证步骤 (3个DB查询 + 1个cron列表)

### Step 1: Cron 状态检查
```python
# 查 cronjob list, 找 job_id=e0d574cc1a3c (DA 18:00扫描)
# 关键字段: last_status, last_delivery_error, enabled, state
# last_status=ok → 脚本执行成功
# last_delivery_error 非空 → 投递失败(不影响脚本执行)
# state=paused → 任务已暂停
```

### Step 2: signal_snapshots.db — DA 决策写入验证
```sql
-- 连接 data/signal_snapshots.db
SELECT decision_id, symbol, direction, strength, confidence, strategy_id, trade_mode
FROM signal_snapshots
WHERE date(created_at) = date('now','localtime')
ORDER BY created_at;
```
- 预期: 30-40 条 deep_analysis 决策, strategy_id='deep_analysis', trade_mode='simulate'
- 每条 decision_id 格式: `DA-YYYYMMDDHHMMSS-US.SYM-XXXX`

### Step 3: ftseek_us.db — playbook_instructions 验证
```sql
-- 连接 data/ftseek_us.db
SELECT symbol, direction, entry_price, stop_loss, take_profit,
       triggered, executed, confidence, decision_id,
       json_extract(raw_instruction_json, '$.source') as source,
       json_extract(raw_instruction_json, '$.debate_outcome') as debate,
       created_at
FROM playbook_instructions
WHERE date(created_at) = date('now','localtime')
ORDER BY created_at;
```
- 预期: 仅 direction != NEUTRAL/SKIP 的标的生成指令
- source 应为 'deep_analysis'
- debate_outcome 显示2模型辩论结果(✅一致 / ⚠️分歧)
- confidence: 2模型一致=70, 分歧=25(降conf)

### Step 4: 投递状态验证
```python
# cronjob list → 检查 last_delivery_error
# [99992402] field validation failed = Feishu thread_id 投递失败
# 不影响脚本执行, 但用户收不到报告
# Fix: hermes cron update <job_id> --deliver feishu:oc_<chat_id> (去掉:omt_后缀)
```

## 状态判定矩阵
| 环节 | OK | 异常 |
|------|-----|------|
| cron执行 | last_status=ok | last_status≠ok 或 state=paused |
| DA决策写入 | signal_snapshots today=30-40条 | 0条=扫描未运行 |
| 指令生成 | playbook_instructions today≥1 | 0条=全NEUTRAL或写入失败 |
| 投递 | last_delivery_error=null | [99992402]=thread_id格式被拒 |

## 2026-07-13 实际数据
- signal_snapshots: 35条 (LONG 18, NEUTRAL 14, SHORT 3)
- playbook_instructions: 2条 (KO BUY conf=25, RIVN SELL_SHORT conf=70)
- 投递: ❌ [99992402] field validation failed (4个DA cron job均受影响)
- bridge generation job (13dde1f65703): ⏸️ paused 7/13 00:32

## 关键 DB 路径映射
| DB | 路径 | 内容 |
|----|------|------|
| signal_snapshots.db | data/signal_snapshots.db | DA 18维采集+2模型辩论结果 (IC写入) |
| ftseek_us.db | data/ftseek_us.db | playbook_instructions (DA直写, 绕过run_playbook_generate) |
| decisions.db | data/decisions.db | 旧voting decisions (7/10后0条, 已停用) |
