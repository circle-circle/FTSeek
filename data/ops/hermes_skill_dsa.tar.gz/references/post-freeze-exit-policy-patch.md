# 7/24冻结期后执行：分桶×分方向 SL/TP 代码消费

## 背景

exit_policy.yaml已预配置`direction_override`和`take_profit_pct`，
但当前FTSeek代码不消费这两个字段。
7/24冻结期后需要改3个文件让代码消费新配置。

## 改动清单

### 1. exit_policy_guardian.py — 改get_max_loss_pct + 新增get_take_profit_pct

位置: `/opt/ftseek/FTSeek-US/app/risk/exit_policy_guardian.py`

#### 1a. 改 get_max_loss_pct (L268-279)

当前代码:
```python
def get_max_loss_pct(self, atr_pct: float = 0) -> float:
    rules = self.policy.get('exit_rules', {})
    atr_config = rules.get('atr_stop', {})
    vol_buckets = atr_config.get('vol_bucket_multipliers', {})

    if atr_pct > 0 and vol_buckets:
        bucket_loss = self._select_vol_bucket(atr_pct, vol_buckets, 'max_loss_pct')
        if bucket_loss is not None:
            return float(bucket_loss)

    return float(atr_config.get('max_loss_pct', 2.0))
```

改为:
```python
def get_max_loss_pct(self, atr_pct: float = 0, direction: str = '') -> float:
    """按桶×方向获取max_loss_pct (2026-07-05: 分方向覆盖)"""
    rules = self.policy.get('exit_rules', {})
    atr_config = rules.get('atr_stop', {})
    vol_buckets = atr_config.get('vol_bucket_multipliers', {})

    if atr_pct > 0 and vol_buckets:
        # 先选桶, 再检查direction_override
        selected = self._select_vol_bucket_cfg(atr_pct, vol_buckets)
        if selected:
            bucket_name, bucket_cfg = selected
            # 优先用direction_override
            if direction:
                dir_key = direction.upper()
                override = bucket_cfg.get('direction_override', {}).get(dir_key, {})
                if 'max_loss_pct' in override:
                    return float(override['max_loss_pct'])
            # fallback到桶全局值
            if 'max_loss_pct' in bucket_cfg:
                return float(bucket_cfg['max_loss_pct'])

    return float(atr_config.get('max_loss_pct', 2.0))
```

#### 1b. 新增 _select_vol_bucket_cfg (返回桶名+完整配置)

在 _select_vol_bucket 旁边加:
```python
def _select_vol_bucket_cfg(self, atr_pct: float, vol_buckets: dict) -> Optional[tuple]:
    """选桶并返回(桶名, 桶配置), 供direction_override读取"""
    for name in ['low', 'medium', 'high', 'extreme']:
        cfg = vol_buckets.get(name, {})
        max_pct = float(cfg.get('atr_pct_max', 999.0))
        if atr_pct < max_pct:
            return (name, cfg)
    return ('extreme', vol_buckets.get('extreme', {}))
```

#### 1c. 新增 get_take_profit_pct

```python
def get_take_profit_pct(self, atr_pct: float = 0, direction: str = '') -> float:
    """按桶×方向获取盘中TP阈值 (2026-07-05新增)
    Returns: TP百分比, 0=不启用盘中TP"""
    rules = self.policy.get('exit_rules', {})
    atr_config = rules.get('atr_stop', {})
    vol_buckets = atr_config.get('vol_bucket_multipliers', {})

    if atr_pct > 0 and vol_buckets:
        selected = self._select_vol_bucket_cfg(atr_pct, vol_buckets)
        if selected:
            _, bucket_cfg = selected
            if direction:
                dir_key = direction.upper()
                override = bucket_cfg.get('direction_override', {}).get(dir_key, {})
                if 'take_profit_pct' in override:
                    return float(override['take_profit_pct'])
            return float(bucket_cfg.get('take_profit_pct', 0))

    return 0.0
```

### 2. atr_stop_engine.py — 调用方传direction

位置: `/opt/ftseek/FTSeek-US/app/risk/atr_stop_engine.py` L275-281

当前代码:
```python
if direction == "SHORT":
    max_loss_pct = float((policy or {}).get("short_overrides", {}).get("max_loss_pct", 10.0)) / 100.0
    hard_stop = entry_price * (1 + max_loss_pct)
else:
    max_loss_pct = float(atr_stop_cfg.get("max_loss_pct", 15.0)) / 100.0
    hard_stop = entry_price * (1 - max_loss_pct)
```

改为 (需传入atr_pct和direction, 从guardian获取):
```python
# 优先用guardian的分桶×分方向值
if policy_guardian and atr_pct > 0:
    max_loss_pct = policy_guardian.get_max_loss_pct(atr_pct, direction) / 100.0
elif direction == "SHORT":
    max_loss_pct = float((policy or {}).get("short_overrides", {}).get("max_loss_pct", 10.0)) / 100.0
else:
    max_loss_pct = float(atr_stop_cfg.get("max_loss_pct", 15.0)) / 100.0
```

注意: atr_stop_engine.compute_stop_lines需要额外接收policy_guardian和atr_pct参数,
或者由调用方(position_exit_monitor)预先算好max_loss_pct传入。

### 3. pre_close.py — 加盘中TP检查

位置: `/opt/ftseek/FTSeek-US/app/risk/exit_rules/pre_close.py`

在 check_pre_close_exit 函数开头加:
```python
# 盘中TP: 盈利达桶配置阈值 → 部分止盈(50%)
# 2026-07-05: 复活DAY_TRADE_TP思路, 分桶×分方向阈值
from app.risk.exit_policy_guardian import ExitPolicyGuardian
guardian = ExitPolicyGuardian()
guardian.load()

# 计算当前盈利%
entry_price = float(position.get("entry_price", 0))
current_price = float(market_data.get("current_price", 0))
direction = str(position.get("direction", "LONG")).upper()
atr = float(market_data.get("atr", 0))
if entry_price > 0 and atr > 0:
    atr_pct = atr / entry_price
    profit_pct = abs(current_price - entry_price) / entry_price * 100
    tp_threshold = guardian.get_take_profit_pct(atr_pct, direction)
    if tp_threshold > 0 and profit_pct >= tp_threshold:
        return {
            "reason": "INTRADAY_TP",
            "reason_cn": f"盘中止盈(盈利{profit_pct:.2f}%≥{tp_threshold}%)",
            "exit_price": current_price,
            "close_ratio": 0.5,  # 平50%
            "description": f"盈利{profit_pct:.2f}%达到桶TP阈值{tp_threshold}%, 减仓50%",
        }
```

注意: 需要market_data包含atr字段, 且position包含entry_price。
ExitReason枚举需加 INTRADAY_TP。

## 验证步骤

1. 改完后跑: `python3.11 -c "from app.risk.exit_policy_guardian import ExitPolicyGuardian; g=ExitPolicyGuardian(); g.load(); print(g.get_max_loss_pct(0.005, 'LONG')); print(g.get_take_profit_pct(0.005, 'LONG'))"`
   - 期望: 0.3 和 0.4 (low桶LONG)
2. 跑test: `python3.11 -m pytest tests/test_exit_modules.py -x`
3. 跑test: `python3.11 -m pytest tests/test_playbook_exit_rules.py -x`
4. 启动FTSeek后查日志: `ExitMonitor 止损参数校验` 应显示新参数

## 数据依据

374笔真实交易数据 (2026-07-05):
- low桶(<1.5%ATR): 129笔LONG+157笔SHORT, 亏损中位数0.24%/0.31%
- medium桶(1.5-3.5%): 16笔LONG+25笔SHORT, 亏损中位数2.25%/2.26%
- high桶(3.5-8%): 12笔LONG+16笔SHORT, 亏损中位数4.27%/7.47%
- extreme桶(≥8%): 样本不足, 维持现状

SL = 亏损中位数 × 1.2 (给50%亏损仓反转空间)
TP = 盈利中位数 × 1.5 (让盈利继续跑一点)

## 同时生效的配置改动(已改yaml, 无需等7/24)

1. `loss_flat: true → false`: 亏损仓不等盘末, 由硬止损管理 (数据: 均亏$27 vs $500)
2. `high桶 max_loss_pct: 3.0 → 5.0`: 数据推导亏损中位4.27%/7.47%远超3.0%
3. 新增`take_profit_pct`字段: 各桶预配置TP阈值, 等代码消费
4. 新增`direction_override`: 各桶×方向SL/TP, 等代码消费
