# Playbook退出架构 vs ExitMonitor — 确认实际退出决策路径

## 核心事实

Playbook仓位(SIM/LIVE/SHADOW)的退出决策由 **playbook管线** 自管,
不由 `position_exit_monitor.scan_positions()` 处理.

## 代码证据

### 1. Playbook管线退出入口
`scheduler_core.py:1917-1918`:
```python
from app.playbook.pipeline import monitor_playbook_sim_exits
monitor_playbook_sim_exits(self)  # playbook管线自管退出
```

### 2. Playbook退出规则
`pipeline.py:4169` — `_check_playbook_exit_rules()`:
- 规则1: SL_INITIAL (止损兜底, 用DB里的stop_loss)
- 规则2: TIME_EXIT (持仓>2h且亏损>0.5%)
- 规则3: PRE_CLOSE_EXIT (收盘前8min)

### 3. ExitMonitor明确跳过playbook仓位
`position_exit_monitor.py:798-801`:
```python
_pb_owner = (getattr(p, 'owner_strategy', '') or '').strip().lower()
if _pb_owner in ('playbook_sim', 'playbook_live', 'playbook_shadow'):
    _skipped_playbook += 1
    continue  # playbook仓位由monitor_playbook_sim_exits自管退出
```

## ATR=0日志的含义

ExitMonitor的ATR=0日志(如"US.EOG effective_atr=0.0000 < price_floor")是**噪声**:
- ExitMonitor的`_quote_ctx=None` (重连后未update_quote_ctx)
- `_calc_atr_from_kline`返回0 → 走0.5%底限
- 但playbook退出用的是DB里的stop_loss字段, 不依赖ExitMonitor的ATR
- 这些日志不影响实际退出决策

## 根因: Futu重连后quote_ctx未更新

1. 21:34 Futu连接断开重连(force_reconnect)
2. 重连后新建QuoteContext, 但未通过`update_quote_ctx()`注入ExitMonitor
3. ExitMonitor仍持有旧的/None的quote_ctx → ATR=0

## 启示

看到ExitMonitor的ATR=0日志时, 先确认该仓位是否是playbook仓位:
- 是 → 日志是噪声, playbook管线用DB stop_loss做退出, 不受影响
- 否 → 真实问题, ExitMonitor的quote_ctx需要修复
