# DA脑→执行脑 一致性全链路审计 (2026-07-12)

## 背景

用户要求检查"DA脑到执行脑整个工程框架和代码逻辑是否有需要调整和优化的地方"。
系统追踪从 DA skill → playbook_instructions DB → auto_execute re-price → trade_records → exit_monitor 的完整数据流。

## 实际数据流路径 (代码+DB验证)

```
DA skill (scripts/pipeline.py:432-457)
  ↓ save_instruction(_inst) → 直写 playbook_instructions DB
  ↓ _inst含: entry/SL/TP/confidence/thesis/decision_id/horizon ✓
  ↓ 但 invalidation 在 raw_instruction 里, 不在 _inst 顶层 ✗
  ↓ position_size 不在 _inst 里 ✗
playbook_instructions DB表
  ↓ pipeline.py:1326 幂等检查: DB已有 → run_playbook_generate 跳过
  ↓ BridgeVotingAdapter.vote() 不被调用 (死代码)
auto_execute (pipeline.py:2270+)
  ↓ re-price块: 实时bid/ask + ATR vol_bucket 重算 entry/SL/TP
  ↓ position_size兜底计算 (DB全0 → 此处算, 但不写回DB)
  ↓ custom_params覆盖DB原值 → 传executor
trade_records
  ↓ metadata_json 记录 re-price后SL/TP (非DA原值)
  ↓ 无invalidation key → invalidation_shadow 永不触发
exit_monitor (pipeline.py:2880+)
  ↓ 用trade_records.metadata的SL → breakeven/trailing 退出
```

## 6个断裂点

### [1] ❌ position_size 全0 (13/13条)

**DB验证**: `SELECT position_size FROM playbook_instructions WHERE date(created_at) >= '2026-07-09' AND direction != 'SKIP'` → 全0.

**根因**: DA skill `_inst` dict (pipeline.py:432-456) 不含 `position_size` 字段。save_instruction 写入 NULL。

**兜底**: re-price块 (pipeline.py:2334-2357) 有兜底计算: `risk_amount / per_share_risk × conf_factor`, 截断 `max_position_pct`。但计算结果只在 `_reprice_params` 中传给 executor, **不写回 playbook_instructions**。

**影响**: 
- 交易执行不受影响 (re-price兜底正确计算)
- 但审计断裂: DB中position_size全0, 无法从DB追溯实际仓位计算
- trade_records.quantity 记录了实际成交qty (NVDA=15, GOOG=9, NU=235)

**与旧文档的关系**: `position-size-gap-and-fallback-20260709.md` 已记录此问题并给出了re-price兜底方案。本次审计确认兜底**已生效** (trade_records有正确qty), 但**写回DB缺失**仍未修复。

**修复方案**: re-price块兜底计算后, 在 `db.update_instruction_tracking(inst["id"], _reprice_params)` 中加入 `position_size`。需确认 `position_size` 在 `_TRACKING_FIELDS` 中。

### [2] ❌ invalidation 全空 (13/13条)

**DB验证**: `SELECT invalidation FROM playbook_instructions WHERE date(created_at) >= '2026-07-09' AND direction != 'SKIP'` → 全NULL。

**根因**: DA skill `_inst` dict (pipeline.py:432-456) 把 invalidation 放在 `raw_instruction.invalidation` 里:
```python
_inst = {
    ...
    "raw_instruction": {
        "source": "deep_analysis",
        "invalidation": vr["invalidation"],  ← 在这里
        ...
    },
    # 顶层没有 "invalidation": vr["invalidation"]  ← 缺!
}
```
而 db.py:180 `save_instruction` 读 `inst.get("invalidation", "")` → 读的是顶层 → None → 列空。

**但 raw_instruction_json 里有值**: DB中 raw_instruction_json.invalidation 确实包含DA的失效条件文本 (如 "若7/14前未回调至$615以下且MSPR进一步恶化至-15以下，取消建仓计划")。

**修复方案** (1行): DA skill pipeline.py _inst dict 顶层加:
```python
"invalidation": vr["invalidation"],
```

### [3] ❌ invalidation_shadow 永不触发

**代码路径**: pipeline.py:3454-3462:
```python
if not meta.get("invalidation_shadow") and (meta.get("invalidation") or ""):
    _sh = evaluate_invalidation_shadow(...)
```
`meta` = trade_records.metadata_json。但 metadata 中**没有 invalidation key** (7/7条全无) → `meta.get("invalidation")` → None → 永远跳过。

**根因链**: 
1. DA写invalidation到raw_instruction.invalidation (不在顶层)
2. save_instruction读不到 → playbook_instructions.invalidation列空
3. auto_execute读DB instruction → inst.get("invalidation") → 空
4. custom_params不包含invalidation → trade_records.metadata无invalidation key
5. exit_monitor读metadata → meta.get("invalidation") → None → shadow不触发

**影响**: Stage2a影子评估骨架就位 (pipeline.py:3454-3462 + invalidation_shadow.py模块) 但数据断裂 → 永远空跑。DA的失效条件对执行和退出完全不可见。

**修复方案**: 修[2]后, 在 auto_execute custom_params 中加:
```python
"invalidation": inst.get("invalidation", ""),
```
让executor写入trade_records.metadata → shadow评估自然接线。

### [4] ⚠️ re-price覆盖DA的SL/TP

**DB验证** (DA bridge JSON vs trade_records.metadata):
| Symbol | Date | DA SL | Exec SL | SL Diff% | DA TP | Exec TP | TP Diff% |
|---|---|---|---|---|---|---|---|
| NVDA | 7/10 | $193.99 | $197.59 | 1.9% | $225.00 | $223.66 | 0.6% |
| GOOG | 7/10 | $338.59 | $338.59 | 0% | $370.89 | $383.26 | 3.3% |
| NU | 7/10 | $13.23 | $13.23 | 0% | $15.50 | $14.97 | 3.4% |
| NVDA | 7/9 | $192.87 | $192.87 | 0% | $236.30 | $218.32 | 7.6% |

**根因**: re-price块 (pipeline.py:2300-2323) 用 `_compute_volatility_based_sl_tp(atr_pct, _dir, _hp, pb_cfg)` 重算SL/TP, 覆盖DA的structural SL。

**已记录**: `sl-tp-reprice-kill-chain-20260711.md` 已详细分析此问题并提出 sl_basis=structural→shift / atr→recalc 方案。

### [5] ⚠️ BridgeVotingAdapter 死代码

**验证**: 
- DA直写DB (pipeline.py:421-457)
- pipeline.py:1326 幂等检查: DB已有instruction → 跳过 run_playbook_generate
- BridgeVotingAdapter.vote() 从不被调用
- BridgeVotingAdapter内的confidence合成逻辑 (0.50±0.20 debate调整, pipeline.py:390-404) 从未执行
- DB中confidence = DA原始值 (25/35/70), 非BridgeVotingAdapter合成值

**BridgeVotingAdapter唯一有实际作用的代码**: `_try_load_bridge()` (pipeline.py:436-502) 中注入bridge候选到daily_active_pool (pipeline.py:478-498)。

**影响**: 
- 不是bug — DA直写DB是设计决策, pipeline跳过是幂等保护
- 但意味着 BridgeVotingAdapter.vote() 的confidence合成逻辑是纯死代码
- 如果未来DA不再直写DB, vote()会被调用 → 那时confidence合成才生效

### [6] ✅ voting_predictions 已停

**DB验证**: 7/10后0条。7/9的42条是旧pipeline残留 (symbol与DA不重叠, 16:05-16:17 UTC写入)。

## 一致性评分

| 环节 | 一致性 | 说明 |
|---|---|---|
| entry_price | ✅ 100% | DA直写DB, re-price在trade_records用实时价 |
| direction | ✅ 100% | DA→DB→executor 完全一致 |
| confidence | ✅ 100% | DA→DB (BridgeVotingAdapter合成未生效但不影响) |
| stop_loss | ⚠️ 有条件一致 | DB保留DA值, 执行用re-price后值(NVDA差1.9%) |
| take_profit | ⚠️ 有条件一致 | 同上(GOOG差3.3%, NU差3.4%) |
| position_size | ❌ 断裂 | DB全0, 兜底计算不写回 |
| invalidation | ❌ 断裂 | DA值在raw_instruction里, 顶层列空, 执行不可见 |
| thesis/strategy | ✅ 100% | DA→DB完整传递 |

## 审计方法论: DA JSON → DB → trade_records 三层对比

此方法可复用于未来的一致性审计:

1. **DA bridge JSON**: 读 `data/opportunity_scan_YYYYMMDD.json` 的 candidates
2. **playbook_instructions DB**: 查 `SELECT * FROM playbook_instructions WHERE decision_id LIKE 'DA-%'`
3. **trade_records metadata**: 查 `SELECT metadata_json FROM trade_records WHERE source_type='PLAYBOOK_SIM'`

对比每个字段在三层中的值, 差异即为断裂点。

### 审计SQL模板
```sql
-- DA bridge JSON
-- → 读 data/opportunity_scan_YYYYMMDD.json

-- playbook_instructions (DA直写)
SELECT symbol, direction, entry_price, stop_loss, take_profit, confidence,
       position_size, invalidation, decision_id, raw_instruction_json
FROM playbook_instructions
WHERE decision_id LIKE 'DA-%' AND date(created_at) >= '2026-07-09'
ORDER BY created_at;

-- trade_records (re-price后)
SELECT symbol, entry_price, quantity,
       json_extract(metadata_json, '$.stop_loss') as exec_sl,
       json_extract(metadata_json, '$.take_profit') as exec_tp,
       json_extract(metadata_json, '$.invalidation') as exec_invalidation,
       exit_reason, realized_pnl
FROM trade_records
WHERE source_type = 'PLAYBOOK_SIM' AND date(entry_time) >= '2026-07-09'
ORDER BY entry_time;

-- 填充率检查
SELECT
  count(*) as total,
  sum(CASE WHEN position_size > 0 THEN 1 ELSE 0 END) as has_ps,
  sum(CASE WHEN invalidation IS NOT NULL AND invalidation != '' THEN 1 ELSE 0 END) as has_inv
FROM playbook_instructions
WHERE date(created_at) >= '2026-07-09' AND direction != 'SKIP';
```

## 第二轮审计: 5个新增断裂点 (2026-07-12 v2)

### [7] ❌ bridge cron 实际 schedule 与文档不一致 — bridge 生成于收盘后非盘前

**验证**: `cronjob action=list` → job `13dde1f65703`:
- handoff.md 说 "ET 09:00 生成"
- bridge-link-audit-methodology.md 说 "CST 16:00 = ET 03:00"
- **实际 cron**: `0 4 * * 2-6` = CST 04:00 = ET 16:00 (收盘后!)

bridge 07-10: mtime=2026-07-11 04:33 CST = 2026-07-10 16:33 ET (收盘后30分钟)
bridge 07-09: mtime=2026-07-09 21:10 CST = 2026-07-09 09:10 ET (盘前, 但与cron schedule不一致)

**根因**: cron schedule 被改过但未同步到所有文档。实际 `0 4 * * 2-6` 在 ET 16:00 运行, 生成当天 ET 日期的 bridge 文件。但 scheduler 在 ET 04:23 盘前运行时查找 `opportunity_scan_{today_et}.json`, 该文件要到 ET 16:00 才生成 → **scheduler 永远找不到今日 bridge**。

### [8] ❌ BridgeVotingAdapter 死代码根因: 日期不匹配 + scheduler 不重载

v0.54 审计 [5] 说 BridgeVotingAdapter 是死代码, 但未解释根因。本次追踪:

1. `_try_load_bridge()` (pipeline.py:436-502): 用 `datetime.now(ET)` 生成文件名
2. `scheduler_core.py:254-267`: 只在 `__init__` 调用 `_try_load_bridge()`, **盘中不重载**
3. service 重启时间: 2026-07-12 11:24 CST = 07-12 03:24 ET (周日, 无 bridge)
4. 周一 04:23 ET scheduler 运行时: 找 `opportunity_scan_2026-07-13.json` → 不存在 (cron 在 ET 16:00 生成)
5. **即使 bridge 文件后来生成了, scheduler 也不会重载** — voting_coordinator 已固定为 TechnicalFallbackAdapter

**结论**: BridgeVotingAdapter 路径完全是死代码。DA 信号实际通过 DB 直写路径进入 auto_execute, 不经过 BridgeVotingAdapter。

### [9] ❌ DA 直写 DB 绕过 confidence 闸门

**验证**:
- run_playbook_generate 的 confidence 闸门在 pipeline.py:1059: `if confidence < _min_conf_for_dir (70) → SKIP`
- DA skill 的 `_write_bridge_file` (scripts/pipeline.py:457) 直接 `save_instruction(_inst)` 到 DB, **绕过 run_playbook_generate**
- DA 指令 conf=25/35 的信号照样执行, 尽管 gate=70

**DB实证**:
```
DA conf=25: 4条, 1 triggered, 1 executed (NVDA 07-10, -$6.9, SL_FIXED_PCT)
DA conf=35: 4条, 2 triggered, 2 executed (NU -$5.88, GOOG -$15.39, 全亏)
DA conf=60: 2条, 0 triggered
DA conf=70: 6条, 1 triggered, 2 executed (NVDA 07-09, +$0.79)
```

**影响**: signal_gate 的 WARN 降 conf 到 0.25, 但这些信号仍能进 auto_execute 执行。闸门只拦 DEC 路径, DA 路径完全不受 confidence 闸门保护。

**修复方案**: DA skill `_write_bridge_file` 写 DB 前加 confidence 检查: `if conf < 70: 不写 DB 或标记 SKIP`。

### [10] ⚠️ re-price 覆盖 SL 的实盘 kill-chain 验证 (NVDA 07-10)

v0.54 [4] 记录了 re-price 覆盖 SL/TP, 本次追踪到退出端:

```
Bridge JSON: NVDA entry=$204.0, SL=$193.99 (4.9% structural, MA60)
DB instruction: entry=$204.0, SL=$193.99 (DA原值保留)
Trade record: entry=$206.6997 (re-price到实时价), exit=$206.24
  exit_reason=SL_FIXED_PCT, MFE=0.5323%, MAE=0.0%
  退出距entry仅0.22% ← 不是SL被触及
```

**分析**: re-price 块用 vol_bucket low sl_floor_pct=2.0% 重算 SL=$202.57。但 exit=$206.24 远在 SL 之上。实际触发的是 `drawdown_from_peak_pct=0.5%`:
- Peak = $206.70 × (1 + 0.53%) = $207.80
- Drawdown threshold = $207.80 × (1 - 0.5%) = $206.76
- Exit at $206.24 < $206.76 → drawdown 触发

**影响**: DA 的 structural SL (MA60=$193.99, 4.9% 空间) 被 re-price 覆盖为 2% ATR SL, 再被 drawdown_from_peak=0.5% 在浮盈仅 0.53% 时砍掉。三层退出逻辑叠加, 赢家被锁在 0.5% 浮盈。

### [11] 📊 DA vs DEC 执行对比 (量化)

| 指标 | DA 路径 | DEC 路径 |
|---|---|---|
| 指令数 | 16 | 169 |
| 触发率 | 25% (4/16) | 43% (73/169) |
| 执行率 | 31% (5/16) | 45% (76/169) |
| 已平仓 | 4 | 65 |
| 胜率 | **25% (1/4)** | **46% (30/65)** |
| 平均PnL | -$1.71 | -$2.53 |
| conf<70 占比 | **63% (10/16)** | 0% |

DEC 路径全部 conf≥70 (闸门过滤生效), DA 路径 63% 信号低于闸门但照常执行。DA 胜率(25%) 显著低于 DEC(46%), 但因样本量极小 (n=4) 不具统计显著性。

## 7个DB验证查询 (可复用)

```sql
-- Q1: DA 指令执行率 (按 confidence 分桶)
SELECT
  CASE WHEN confidence >= 70 THEN '>=70'
       WHEN confidence >= 60 THEN '60-69'
       ELSE '<60' END as bucket,
  COUNT(*) as total, SUM(triggered) as trig, SUM(executed) as exec_
FROM playbook_instructions WHERE decision_id LIKE 'DA-%'
GROUP BY bucket ORDER BY bucket;

-- Q2: DA vs DEC 胜率对比
SELECT
  CASE WHEN decision_id LIKE 'DA-%' THEN 'DA'
       WHEN decision_id LIKE 'DEC-%' THEN 'DEC' ELSE 'OTHER' END as src,
  COUNT(*) as total, SUM(triggered) as trig, SUM(executed) as exec_,
  SUM(CASE WHEN pnl > 0 THEN 1 ELSE 0 END) as wins,
  SUM(CASE WHEN pnl < 0 THEN 1 ELSE 0 END) as losses,
  ROUND(AVG(CASE WHEN pnl IS NOT NULL THEN pnl END), 2) as avg_pnl
FROM playbook_instructions WHERE created_at >= '2026-06-12'
GROUP BY src ORDER BY total DESC;

-- Q3: DA 交易退出原因分布
SELECT exit_reason, COUNT(*) as cnt, ROUND(AVG(realized_pnl), 2) as avg_pnl
FROM trade_records WHERE decision_id LIKE 'DA-%'
GROUP BY exit_reason ORDER BY cnt DESC;

-- Q4: SL_FIXED_PCT 退出详情 (drawdown kill-chain 验证)
SELECT id, trade_date, symbol, direction, entry_price, exit_price,
       realized_pnl, mfe_pct, mae_pct, signal_confidence, decision_id
FROM trade_records WHERE exit_reason = 'SL_FIXED_PCT'
AND trade_date >= '2026-06-12' ORDER BY trade_date;

-- Q5: bridge 文件存在性检查
-- ls -la /opt/ftseek/FTSeek-US/data/opportunity_scan_*.json

-- Q6: scheduler bridge 加载日志
-- grep "bridge.*加载\|bridge.*不存在\|TechnicalFallback\|NullVoting" logs/ftseek_us.log | tail -10

-- Q7: confidence_sizing_enabled 配置验证
SELECT value FROM ... -- 或: grep confidence_sizing config/unified_config.yaml
```

## 修复优先级 (v2 更新)

| # | 修复 | 行数 | 风险 | 优先级 |
|---|---|---|---|---|
| 1 | DA _inst顶层加invalidation | 1行 | 零风险 | P0 |
| 2 | custom_params传invalidation到trade_records | 1行 | 零风险 | P0 |
| 3 | position_size写回DB (TRACKING_FIELDS) | 1-3行 | 低 | P1 |
| 4 | DA _write_bridge_file 写DB前加confidence闸门 | 2-3行 | 低 | P1 |
| 5 | bridge cron schedule修正 (ET 16:00→ET 03:00 盘前) | cron配置 | 中 | P2 |
