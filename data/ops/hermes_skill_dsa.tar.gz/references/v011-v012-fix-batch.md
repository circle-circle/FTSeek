# v0.11-v0.12 修复批次详情

## 16. ✅ 数据质量审计撒谎"14/14 ok" — 已修复 v0.11
**根因**: 数据质量审计只检查`_error`和空值——API返回200但内容全0(如capital_flow全0)也被算"完整"。NVDA实跑显示"14/14 ok"但capital_flow全0、anomalies全0、earnings_calendar空壳——14/14 ok是撒谎。
**修复**: 三级评估——`_has_meaningful_data()`遍历dict的每个值，全0/None/空列表的标为"降级(空壳)"。审计输出"11完整/1降级/3缺失"并标注降级明细。LLM被约束"降级维度不可作为论据依据"。
**验证**: NVDA实跑——earnings_calendar被标降级(API返回但无实质数据)，capital_flow/analyst_rating/insider_tx被标缺失。

## 17. ✅ LLM论据无溯源约束可能编造数字 — 已修复 v0.11
**根因**: LLM输出"ROE 111.7%"但这个数字是从新闻标题摘的还是从Finnhub基本面指标引用的？无从验证。LLM可能从新闻里摘一个数字当事实用。
**修复**: `_extract_source_numbers()`从输入数据提取24个关键数字(roe_ttm/avg_mspr_6m/strong_buy等)生成"论据溯源清单"，注入prompt。USER_PROMPT加硬性约束："每个数字必须来自溯源清单或输入数据，不得编造；ROE/营收增长率必须从基本面指标section引用，不得从新闻标题摘取当事实"。
**验证**: NVDA溯源清单包含`roe_ttm=111.66`、`avg_mspr_6m=-77.39`、`strong_buy=24`等24个真实数字。

## 18. ✅ 社区情绪HTML实体乱码 — 已修复 v0.11
**根因**: 富途社区帖子含HTML实体编码(`$&#38328;&#36844;`)，`_strip_html()`只去HTML标签不反转义实体，LLM收到乱码无法理解情绪。
**修复**: `_strip_html()`先`re.sub(r'<[^>]+>','')`去标签，再`html.unescape()`反转义实体。llm_synth.py和deep_analyzer.py两处都修。
**验证**: 修复后帖子1="$美光科技 (MU.US)$ 跌到770"（可读），修复前="$&#38328;&#36844;"（乱码）。

## 19. ✅ pattern统计样本不足却强推退出方式 — 已修复 v0.11
**根因**: signal_gate用7笔50%WR的LONG+TRAILING_STOP pattern推荐退出方式——7笔的统计意义几乎为零，是噪声不是信号。Gate说"推荐TRAILING_STOP"但这个推荐基于噪声数据。
**修复**: `_confidence_level()`四级置信度标注——`<5笔:very_low` / `5-19:low` / `20-49:medium` / `50+:high`。Gate评估时：低置信pattern(very_low/low)只加分5(原10)不强推退出方式；exit_effectiveness推荐也检查置信度，低置信只提示"13笔样本不足"不设为recommended_exit。
**验证**: NVDA Gate从PASS(70)→WARN(50)，recommended_exit从"TRAILING_STOP"→空，position_size从normal→small。诚实承认样本不足。

## 20. ✅ scanner市值过滤太松扫到小盘股 — 已修复 v0.11
**根因**: `--min-market-cap 100`(1亿美元)扫到LOBLY/SPIIY/VARRY等小盘ADR，与KO示例($84大盘股)对标差距大。
**修复**: 提升到`--min-market-cap 500`(5亿美元)；market_scanner._quick_score加市值评分——`<5B降0.5分`/`≥100B加0.3分`；加主流标的偏好(NVDA/AAPL/MSFT等80+ ticker加0.2分)。
**验证**: 修复后scan候选含AZN/SAN/UPS/AAPL/NVDA/INTC/HSBC等大盘股，小盘ADR被降分。

## 21. ✅ 跨模块数据流审计 — v0.12发现并修复8个结构gap
**根因**: v0.10的"12项上线前验证"只检查模块级，没检查跨模块数据流。全部验证通过后仍有8个结构问题。
**核心教训**: 模块导入✅ + API可达✅ + pipeline跑完✅ ≠ 跨模块数据流正确。
**8个发现+修复**:
1. **[HIGH] ic_writer非交易日trade_date** → `_get_et_trade_date()`周末前推到周五+假日检查。7/5周日→7/2周四。清理15条错误记录。
2. **[HIGH] run_full()没集成ic_writer/gate** → Stage 3循环后加ic_writer+gate+adapter，与run_analyze_only对齐。
3. **[MEDIUM] cron prompt** → 验证: 调scan+analyze模式，analyze已集成ic_writer。无需改。
4. **[MEDIUM] exit_meta兜底["default"]** → 改为`[]`空列表。
5. **[MEDIUM] LLM溯源无代码验证** → 加`_verify_sourced_numbers()`后验证。NVDA: 17verified/35unverified。
6. **[MEDIUM] feedback_loop用CST日期** → 加`_get_et_today()`用ET时区。
7. **[LOW] capital数据源永远空** → data_collector加capital_flow+distribution，14源→16源。net_main_flow有值了。
8. **[LOW] direction映射** → 验证: trade_records存LONG/SHORT，与signal_gate一致。✅
