# DA skill 已闭环陷阱归档 (Pitfalls ✅ closed archive)

> **来源**: 从 `../SKILL.md` `## 关键陷阱 (Pitfalls)` 段**逐字迁出**（2026-09-06 文档形态收敛批）。
> **性质**: 全部为 v0.4–v0.52 时代（现役 v0.75）已实施/已修复/已定论的历史记录，**不含任何仍在生效的硬规**；
>   仍在生效的约束以代码为单一真源（`scripts/llm_synth.py` SYSTEM_PROMPT/USER_PROMPT、`scripts/signal_gate.py`、
>   FTSeek `config/unified_config.yaml`）。
> **编号纪律**: 原编号逐字保留、**不重排**——skill 内代码注释按号引用（`llm_synth.py:228` 引 #22、
>   `strategy_memory.py:478` 引 #35）。历史遗留的重复编号（22/23/24/25/38/39/40/48/49/54/55/71）与缺号
>   （16-21/52/58）**照原样保留**，不做「修复式重排」（重排会打断既有引用与 DEB/commit 的可追溯性）。
> **条目内若有与现役代码矛盾的描述，以代码为准**；矛盾点已在 SKILL.md 正文的"已失效描述更正"段逐条登记。

共 58 条。目录（按原编号顺序）:

- `#6` ✅ ic_writer trade_date必须用ET日期(不是CST) — 已修复 v0.4  ← 原 SKILL.md L148
- `#7` ✅ scanner过滤仙股 — 已修复 v0.4  ← 原 SKILL.md L154
- `#8` ✅ LLM prompt KO级增强 — 已修复 v0.4  ← 原 SKILL.md L159
- `#9` ✅ market_narrative增强 — 已修复 v0.4  ← 原 SKILL.md L164
- `#10` ✅ cron job环境固定 — 已修复 v0.4  ← 原 SKILL.md L169
- `#11` ✅ conditions方向一致性 — 已修复 v0.5 （最关键修复）  ← 原 SKILL.md L174
- `#12` ✅ SKIP时conditions=['default']非法枚举 — 已修复 v0.5  ← 原 SKILL.md L187
- `#13` ✅ scanner PE估值粗糙 — 已修复 v0.5  ← 原 SKILL.md L191
- `#14` ✅ cron top_bearish可能为空 — 已修复 v0.5  ← 原 SKILL.md L196
- `#15` ✅ 盘前扫描cron时区错误 — 已修复 v0.10  ← 原 SKILL.md L200
- `#22` ✅ Code review: 字段名跨模块不匹配 + dead code — 已修复 v0.13  ← 原 SKILL.md L208
- `#22` ✅ Code review: 字段名跨模块不匹配 + dead code — 已修复 v0.13  ← 原 SKILL.md L231
- `#23` ✅ Alpha IC前视偏差(look-ahead bias) — v0.16审计发现, v0.17修复  ← 原 SKILL.md L251
- `#24` ✅ claim_type分类用硬编码关键词——脆弱且不可验证 — v0.16审计发现, v0.17修复  ← 原 SKILL.md L258
- `#26` ✅ pattern_memory全量累计不区分时间窗口 — v0.16审计发现, v0.17修复  ← 原 SKILL.md L270
- `#27` ✅ feedback_loop + deep_analyzer回退SQL用CST日期 — v0.16审计发现, v0.17修复  ← 原 SKILL.md L276
- `#48` ✅ 富途snapshot无change_rate字段 — v0.23修复  ← 原 SKILL.md L295
- `#49` ✅ 数据真实性验证方法 — v0.23教训  ← 原 SKILL.md L304
- `#51` ✅ 规划-执行分离架构 — 5个FTSeek数据通道 — v0.24实施  ← 原 SKILL.md L320
- `#69` ✅ 退出参数收紧 — breakeven 1.5→1.0, drawdown 0.8→0.5 — v0.40实施 (2026-07-09)  ← 原 SKILL.md L347
- `#73` ✅ Trigger逻辑修复 — ±1%→±5%追入区+极端gap>8%过滤 — v0.44诊断/v0.45落地 (2026-07-09)  ← 原 SKILL.md L359
- `#75` ✅ confidence第一性原理: 三系统零预测力, 改用辩论结果 — v0.46实施 (2026-07-10)  ← 原 SKILL.md L390
- `#74` ✅ factor_detail list类型导致save_trade写入失败 — _row_to_dict自动json.loads — v0.45修复 (2026-07-09)  ← 原 SKILL.md L412
- `#72` ✅ 动静结合: --symbols传熟股列表 — v0.43实施 (2026-07-09)  ← 原 SKILL.md L434
- `#71` ✅ 日cap 40%→60% — v0.42实施 (2026-07-09)  ← 原 SKILL.md L443
- `#70` ✅ Bridge entry_price是LLM建议价不是实时价 — v0.42教训 (2026-07-09)  ← 原 SKILL.md L445
- `#71` ✅ 日cap 40%→60% — v0.42实施 (2026-07-09)  ← 原 SKILL.md L461
- `#54` ✅ signal_gate 接线 P0 — BLOCK 信号不写 DB — v0.48实施 (2026-07-10)  ← 原 SKILL.md L467
- `#55` ✅ vol_ratio 量能门移除 P0 — _vol_ok=True — v0.48实施 (2026-07-10, FTSeek侧)  ← 原 SKILL.md L473
- `#54` ✅ Bridge Link Audit Methodology — v0.28 (2026-07-09)  ← 原 SKILL.md L501
- `#53` ✅ bridge→下单执行链路4个断点 — v0.26盘中验证发现  ← 原 SKILL.md L517
- `#64` ✅ 取消3模型投票→NullVotingAdapter+2模型辩论 — v0.39实施 (2026-07-09)  ← 原 SKILL.md L537
- `#65` ✅ Bridge候选直写instruction到DB — v0.39 P0修复 (2026-07-09)  ← 原 SKILL.md L548
- `#66` ✅ 辩论结果从_llm_output提取 — v0.39字段路径修复 (2026-07-09)  ← 原 SKILL.md L556
- `#67` ✅ NullVotingAdapter跳过run_playbook_generate — v0.39防覆盖修复 (2026-07-09)  ← 原 SKILL.md L563
- `#76` ✅ 计划-执行四大断裂: 价格+趋势+范围+SL/TP联动 — v0.52诊断 (2026-07-11)  ← 原 SKILL.md L570
- `#68` ✅ Ponytail+Karpathy原则: 最简方案优先 — v0.39用户偏好 (2026-07-09)  ← 原 SKILL.md L590
- `#62` ✅ M1数据基础设施 + 三方辩论复盘 — v0.37实施 (2026-07-09)  ← 原 SKILL.md L628
- `#60` ✅ strategy_type方向矛盾检查 — v0.34修复 (2026-07-09)  ← 原 SKILL.md L657
- `#59` ✅ 空跑管线止血 + Obsidian闭环 + claim_ic兼容 — v0.34实施 (2026-07-09)  ← 原 SKILL.md L684
- `#56` ✅ 回撤止损替代步进trailing + SL距离数据驱动调优 + 仓位缩小增加笔数 — v0.33 (2026-07-09)  ← 原 SKILL.md L701
- `#55` ✅ 退出规则审计 — SL_ATR_STOP=方向错非SL太紧 + rr_ratio=999无TP + EOD最佳 — v0.32 (2026-07-09)  ← 原 SKILL.md L713
- `#50` ✅ 多渠道扫描+四信号评分+板块叙事+操作分桶 — v0.23实施  ← 原 SKILL.md L744
- `#33` ✅ 3股全链路模拟验证发现12个跨阶段优化点 — v0.20  ← 原 SKILL.md L766
- `#34` ✅ scanner方向冲突无人检测 — v0.20修复  ← 原 SKILL.md L791
- `#35` ✅ pattern匹配全市场通用不标注来源 — v0.20修复  ← 原 SKILL.md L794
- `#36` ✅ 财报日历过期日期fallback — v0.20修复  ← 原 SKILL.md L797
- `#37` ✅ claim_type重复不去重 — v0.20修复  ← 原 SKILL.md L800
- `#38` ✅ deep_analysis方向门禁(BUY+SELL_SHORT)接入FTSeek — v0.21实施, v0.21.2扩展  ← 原 SKILL.md L803
- `#47` ✅ Obsidian per-symbol 深度分析归档 — v0.22实施  ← 原 SKILL.md L810
- `#46` ✅ sl_multiplier根因修复: 0.7×ATR→1.5×ATR — v0.21.2实施  ← 原 SKILL.md L835
- `#38` ✅ deep_analysis LONG门禁已接入FTSeek执行路径 — v0.21实施  ← 原 SKILL.md L851
- `#38` 5 ✅ playbook_horizon.yaml 退出参数调优 — v0.21实施, v0.21.2修正  ← 原 SKILL.md L866
- `#41` ✅ FTSeek多DB地图 — 数据查询路径 (v0.21发现, v0.29验证更新)  ← 原 SKILL.md L933
- `#42` ✅ 04:xx模板投票检测: LLM返回200但strength是模板值 — v0.21实施  ← 原 SKILL.md L953
- `#43` ✅ backfill cron路径缺失cd前缀 — 从未运行 — v0.21发现+修复  ← 原 SKILL.md L965
- `#49` ✅ 数据真实性验证方法 — "这种扫描和分析是真实的吗？不要虚构" — v0.23教训  ← 原 SKILL.md L1013
- `#48` ✅ 多渠道扫描+四信号评分+板块叙事+操作分桶 — v0.23实施  ← 原 SKILL.md L1038

---

### 6. ✅ ic_writer trade_date必须用ET日期(不是CST) — 已修复 v0.4
**根因**: `datetime.now()`返回CST(UTC+8)时间，但FTSeek backfill按ET日期匹配日K线。CST=7/5 11:23时ET=7/4 23:23，写入trade_date="2026-07-05"是周日——非交易日，backfill cron找不到日K线→跳过→IC永远为0。
**修复**: `_get_et_trade_date()`用ET时区(UTC-4 DST/UTC-5 EST)，与FTSeek `get_trade_date()`对齐。
**验证**: 写入后`SELECT trade_date FROM signal_snapshots WHERE decision_id LIKE 'DA-%'` → trade_date=2026-07-04(ET) ✅。旧2条CST错误记录已清理。
**复现命令**: `cd scripts && python3 -c "from ic_writer import _get_et_trade_date; print(_get_et_trade_date())"`

### 7. ✅ scanner过滤仙股 — 已修复 v0.4
**根因**: `collect_top_volume/gainers/losers`调`get_stock_filter.py`不传过滤参数，扫到LIMN $0.14/CWD $1.23等仙股。
**修复**: 三个collect函数加`--min-price 5 --min-market-cap 100`(100亿≈14亿美元)。
**验证**: 修复后top_bullish=MKC $53/GPC $133/RIVN $19，全部正经大盘股。`--min-market-cap`单位是"亿"(人民币)，sf.filter_min = val * 1e8。

### 8. ✅ LLM prompt KO级增强 — 已修复 v0.4
**根因**: SYSTEM_PROMPT只要求"引用具体数据"，LLM输出通用数据罗列("营收+12%, PE 27.7")而非KO示例的公司独有事件("万豪换约"/"印度IPO")。
**修复**: SYSTEM_PROMPT加KO示例对标(3条bull+3条bear范例) + 6项KO级深度要求(A-F)。USER_PROMPT加7条硬性要求(公司独有事件/独有计算/机构目标价空间/MSPR引用/财报日历风险/分批入场/数据质量量化)。
**验证**: NVDA输出bull_case="GB300碾压前代20倍"(公司独有)+"Nemotron被政府客户采纳"(独有故事)+"联博$315目标价距+61.7%"(独有计算) ✅。详见 `references/llm-prompt-ko-pattern.md`。

### 9. ✅ market_narrative增强 — 已修复 v0.4
**根因**: `_market_narrative()`只输出"0涨0跌，震荡分化"——无板块/无极值/无资金切换。
**修复**: 4要素叙事——①方向定调(普涨/普跌/震荡/休市) ②涨跌极值标注(领涨/跌幅最深) ③资金切换(多头/空头信号集中股) ④量能特征(放量股)。
**验证**: "扫描44只候选：0涨0跌44平，休市/盘前无变动。多头信号集中在US.MKC,US.GPC。空头信号集中在US.PLTR,US.TSLA。放量股：US.GPC,US.RIVN。"

### 10. ✅ cron job环境固定 — 已修复 v0.4
**根因**: cron prompt用"python3(hermes venv)"，但futu-api只在FTSeek venv。PATH环境差异可能导致cron用错python。
**修复**: cron prompt改为显式`/opt/ftseek/FTSeek-US/venv/bin/python3.11` + 加交易日检查(Step 0) + workdir=skill scripts目录。
**验证**: cron job e0d574cc1a3c 已更新，next_run=2026-07-06 09:00 CST。

### 11. ✅ conditions方向一致性 — 已修复 v0.5 （最关键修复）
**根因**: `_map_conditions()`把bull_case和bear_case的conditions混在一起输出。NVDA direction=BUY，但conditions里有`insider_net_sell`(BEARISH)和`below_ma20`(BEARISH)——方向冲突。
**后果**(三层):
1. FTSeek方向冲突检查(pipeline.py 714行): 如果`net_score < -0.05`且`direction=BUY` → SKIP。目前侥幸没触发(IC值小)，但IC样本增加后BUY信号会被拦截
2. 语义错误: bear_case是"看空理由"不是"退出条件"——退出策略不应该匹配到它
3. factor_ic统计会把bearish condition的收益算到LONG头上，污染IC
**修复**: 拆成`_map_bullish_conditions()`和`_map_bearish_conditions()`，根据direction只输出方向一致的conditions:
- direction=BUY → 只输出bullish conditions (从bull_case映射)
- direction=SELL_SHORT → 只输出bearish conditions (从bear_case映射)
- direction=SKIP → 输空列表 (SKIP不进_submit_order)
**验证**: NVDA修复后 conditions=['news_positive','roe_high'], bearish hits=[] ✅
**复现命令**: `cd /opt/ftseek/FTSeek-US && python3.11 -c "import sys; sys.path.insert(0,'.'); sys.path.insert(0,'/root/.hermes/skills/deep-stock-analysis/scripts'); from adapter import _map_conditions; print(_map_conditions({'direction':'BUY','bull_case':[{'source_type':'news'}],'bear_case':[{'source_type':'sentiment','thesis':'MSPR -77'}]}))"`

### 12. ✅ SKIP时conditions=['default']非法枚举 — 已修复 v0.5
**根因**: direction=SKIP时返回`conditions=["default"]`，但`"default"`不在FTSeek 27个合法枚举里，`validate_conditions()`会返回invalid。
**修复**: direction=SKIP → `conditions=[]` (空列表，SKIP信号不进_submit_order，不需要conditions)。

### 13. ✅ scanner PE估值粗糙 — 已修复 v0.5
**根因**: PE估值只有2档(0-15低/+60高)，PE<0(亏损股)无处理，RIVN PE=-6.4无标注score=6.5(不该)。
**修复**: 5档PE估值——亏损-0.5 / 低估+0.3 / 合理0 / 偏高-0.1 / 高估-0.3 / 极度高估-0.5。
**验证**: RIVN PE=-6.4 → 标注"PE-6.4亏损" score=6.0(降分) ✅

### 14. ✅ cron top_bearish可能为空 — 已修复 v0.5
**根因**: cron prompt说"取top_bearish前1只"，但普涨日top_bearish为空数组，cron会尝试分析不存在的symbol。
**修复**: cron prompt加"如果top_bearish为空，不要编造做空候选，只输出做多候选"。

### 15. ✅ 盘前扫描cron时区错误 — 已修复 v0.10
**根因**: 盘前扫描cron设`0 9 * * 1-5`(CST 9:00)，但CST=UTC+8与ET=UTC-4(夏令时)差12小时。CST 9:00 = ET 21:00前一天——离开盘12.5h，扫描到的是前日收盘数据，且分析结果在FTSeek盘前预检(CST 20:00)之后才产出，FTSeek无法参考。
**修复**: 改为`0 18 * * 1-5`(CST 18:00 = ET 6:00)，开盘前3.5h跑完，正好给FTSeek盘前预检(CST 20:00=ET 8:00)参考。
**时区换算**: CST=UTC+8, ET=UTC-4(夏令时)/UTC-5(标准时间)。美股9:30 ET开盘 = CST 21:30(夏令时)/22:30(标准时间)。
**教训**: 涉及美股的cron必须做CST→ET时区换算，不能直接用CST时间。盘前任务要在ET 6:00-8:00(CST 18:00-20:00)之间跑，盘后任务要在ET 16:00-18:00(CST 4:00-6:00)跑。

### 16-21. v0.11-v0.12 修复批次
详见 `references/v011-v012-fix-batch.md`（数据质量审计三级评估、LLM论据溯源约束、HTML实体乱码修复、pattern样本不足降级、scanner市值过滤收紧、跨模块数据流8个gap修复）。
### 22. ✅ Code review: 字段名跨模块不匹配 + dead code — 已修复 v0.13

### 22. ✅ Code review: 字段名跨模块不匹配 + dead code — 已修复 v0.13
**根因**: data_collector产出`capital_flow`+`capital_distribution`+`analyst_consensus`+`insider_transactions`，但llm_synth读`capital`(L96)+`analyst_rating`(L292)+`insider_tx`(L293)——字段名不匹配导致资金面section从不输出+数据质量审计把有数据的标为missing。
**修复**: llm_synth字段名全部对齐collector产出名。资金面section改用`capital_distribution`(顶层字段capital_in_super等)+降级用`capital_flow`({code,data:[...]}格式正确解包)。
**验证**: NVDA实跑资金面section出现("超大单净:17038198")，数据质量审计16项15完整1降级(earnings_calendar)。
**其他7个code review修复**:
1. vol_change=`volumes[2]`→`volumes[-2]` index bug（dead variable，直接删）
2. PE>200 elif在PE>60之后→dead code（调换顺序）
3. capital_flow返回dict但deep_analyzer当list切片→潜在TypeError（正确解包{code,data}）
4. owner_plates collector不采集→改用company_profile.industry
5. RSI change赋值两次→dead code（简化为3行）
6. FLASH_EXIT不在FTSeek exit_reason里→改为BREAKEVEN_STOP
7. adapter exit_meta兜底["default"]→[]（v0.12已修，此处确认）
**方法论**: 静态分析(跨模块字段名追踪)+实跑验证(查输出section是否出现)缺一不可。详见 `references/code-review-checklist.md`。
1. 读取全部模块源码（不只读改过的文件）
2. 跨模块数据字段追踪（上游输出有没有下游读的键）
3. 验证FTSeek侧是否真的消费了数据（查backfill回填率）
4. 检查兜底值合法性（default是否在合法枚举里）
5. cron调用链验证（prompt完整内容+调的mode+那个mode是否调了ic_writer/gate）
6. 非交易日运行场景测试（周末/假日跑时trade_date/today是否正确）

### 23. ✅ Alpha IC前视偏差(look-ahead bias) — v0.16审计发现, v0.17修复
**位置**: `alpha_backfill.py:229-233`
**问题**: 容差匹配顺序`[0, 1, -1]`——offset=1会匹配到**后一天**的SPY价格，但后一天的收盘价在信号时刻是未来数据。如果trade_date是假日/非交易日，会用未来的SPY收益算alpha。
**修复**: 改为`[0, -1, -2, -3]`只用当天或之前最近的交易日，不用offset=1。
**验证**: 916条重跑alpha，IC结果一致（offset=0命中，无偏差case触发），但修复防止未来边界case。
**量化影响**: 不修则alpha IC不可信——可能高估信号预测力。

### 24. ✅ claim_type分类用硬编码关键词——脆弱且不可验证 — v0.16审计发现, v0.17修复
**位置**: `ic_writer.py:87-138` `_classify_claim()` + `llm_synth.py` prompt
**问题**: 关键词匹配无法处理否定句("PE 25不是低于行业中枢"也会匹配valuation_cheap)和多信号论点("Revenue增长20%但PE高"会先匹配earnings_beat)。同一类论点可能被分到不同claim_type，污染IC统计。
**修复**: ①llm_synth prompt JSON schema加`claim_type`字段+11种枚举说明 ②ic_writer._extract_claim_factors()优先用LLM标注的claim_type，只在LLM没标注时fallback到_classify_claim关键词推断 ③加`llm_labeled`布尔标记标注来源 ④_VALID_CLAIM_TYPES枚举校验
**验证**: LLM标注=True走直取，=False走_classify_claim。两种路径都测过。
**教训**: 结构化分类不应该靠后处理关键词匹配——让LLM在输出时直接标注更准。

### 26. ✅ pattern_memory全量累计不区分时间窗口 — v0.16审计发现, v0.17修复
**位置**: `strategy_memory.py:226-278` get_strategy_hint()
**问题**: 3个月前的交易和今天的交易同等权重。如果市场regime变了，老的LONG赢钱pattern会继续拉高LONG的win_rate，让Gate误判。
**修复**: get_strategy_hint的赢/亏pattern+退出效果查询都加`WHERE last_trade_date >= cutoff_30d`，只看30天内活跃的pattern。全量数据保留(供其他分析用)，但Gate决策只看rolling window。
**验证**: NVDA查询只返回30天内活跃pattern(SHORT+EOD_FORCE_CLOSE 24笔/LONG+SL_ATR_STOP 12笔等) ✅

### 27. ✅ feedback_loop + deep_analyzer回退SQL用CST日期 — v0.16审计发现, v0.17修复
**位置**: `feedback_loop.py:340` run_daily() + `deep_analyzer.py:462` _get_trade_experience()回退SQL
**问题**: run_daily()用`datetime.now().strftime("%Y-%m-%d")`返回CST日期，但trade_records.trade_date用ET日期。周末跑会查错日期→空数据→教训缺失。deep_analyzer回退SQL的cutoff_7d/cutoff_30d也用CST now()。
**修复**: ①run_daily改用`_get_et_today()` ②run_backfill用ET时区计算起始日期 ③deep_analyzer回退SQL用`datetime.now(timezone(timedelta(hours=-4)))`计算cutoff。
**验证**: ET today=2026-07-05 ✅。run_daily源码含_get_et_today ✅。
**教训**: 时区bug是反复出现的pattern——v0.4的ic_writer、v0.12的feedback_loop、v0.16的deep_analyzer回退SQL。凡是`datetime.now()`生成日期用于查trade_records/signal_snapshots的地方，都要用ET时区。

### 48. ✅ 富途snapshot无change_rate字段 — v0.23修复
**位置**: `market_scanner.py` `_four_signal_score()` + `_collect_sector_data()` + `data_collector.py` `collect_snapshot()`
**问题**: `get_stock_filter`返回的stock_list对象没有行情数据(`has_data=False`), 脚本用`get_market_snapshot`补全。但`get_market_snapshot`返回的列里**没有`change_rate`字段** — 只有`pre_change_rate`(盘前)/`after_change_rate`(盘后)/`overnight_change_rate`(隔夜)。`_snapshot_to_record`里`row.get("change_rate")`=None→0.0。
**后果**: 所有候选的`change_rate`永远=0.0, 即使盘中交易时段NVDA实时涨+0.86%也显示0%。市况叙事显示"0涨0跌, 休市/盘前无变动"——即使实际是盘中正常交易时段。板块轮动全0%。
**用户发现**: 用户质疑"目前是美股正式交易阶段, 你说的休市时段change_rate=0是怎么判定的?" → 直接暴露了bug。我之前错误归因"休市", 实际是API字段缺失。
**修复**: 在`_four_signal_score`的snapshot采集段, 用`(last_price - prev_close_price) / prev_close_price * 100`计算`change_pct`, 不依赖API返回`change_rate`字段。同样修复`_collect_sector_data`里板块ETF涨跌计算。`collect_snapshot`输出增加`prev_close_price`字段。
**验证**: 修复前19只候选全0%, 修复后17/19非零(NVDA +0.65%, PENG +16.5%, HELE -9.7%)。板块轮动11/11非零(Energy +2.1%, Consumer Discretionary -3.0%)。
**教训**: ①API返回的字段名不一定和代码假设的一致 — 必须打印实际列名验证。②当所有值都=0时, 先怀疑数据源bug, 不要急于归因"休市/非交易时段"。③`get_market_snapshot`有last_price/volume/prev_close但无change_rate — 需自行计算。④用户质疑数据真实性是最高价值信号 — 直接暴露了隐藏bug。

### 49. ✅ 数据真实性验证方法 — v0.23教训
**用户原话**: "这种扫描和分析是真实的吗？不要虚构"**背景**: 用户在看到扫描输出(39只候选, 四信号评分, 板块轮动)和深度分析(ANET bull_case/bear_case)后, 质疑数据是否虚构。
**验证方法 (逐源验证 + LLM输入→输出对照)**:
1. **逐源API验证**: 对每个数据源直接调API, 打印返回值:
   - 富途OpenD: `collect_top_gainers('US',3)` → 返回BABA/XIACY/NBIS (真实)
   - Finnhub基本面: `collect_fundamentals('US.ANET')` → revenue_growth=30.57, roe=30.58 (真实)
   - Finnhub分析师: `collect_analyst_consensus('US.ANET')` → 34位分析师, 94.1%买入 (真实)
   - DashScope LLM: API返回"OK"测试 → qwen3.7-max真实可达 (真实)
2. **LLM输入→输出对照**: 对比LLM收到的数据 vs LLM输出的论据:
   - 输入revenue_growth=30.57 → 输出"营收+30.57%" ✅
   - 输入roe_ttm=30.58 → 输出"ROE 30.58%" ✅
   - 输入avg_mspr=-46.08 → 输出"MSPR -46.08" ✅
   - 每个论据数字都能追溯到API输入, 无编造
3. **休市时段局限性**: 休市运行时change_rate=0(正常, 非假数据), K线和快照是上一交易日收盘数据(真实但非实时), Finnhub基本面/分析师是最近报告期(真实, 非实时)。盘中运行时change_rate/volume/last_price是实时值。
**教训**: 呈现skill输出时, 不能只展示结果——必须展示数据来源链(API→数据→LLM推理), 让用户能验证每个数字的出处。LLM论据中的数字必须能追溯到API输入, 否则就是虚构。

### 51. ✅ 规划-执行分离架构 — 5个FTSeek数据通道 — v0.24实施
**位置**: `ic_writer.py` + `pipeline.py` + `feedback_loop.py`
**背景**: 用户要求"deep_analysis独立输出策略, FTSeek基于其输出执行, 规划和执行分开, 形成良性循环". 方案文档: `docs/proposals/PROPOSAL-plan-execute-separation.md`.
**5个数据通道** (全部skill侧写入, FTSeek侧已有或冻结后读取):
1. **factors_json enrichment** (ic_writer.py): signal_snapshots的factors_json从纯claim列表升级为结构化dict, 含strategy_type/position_size_hint/bucket_reason/signal_scores/conditions/claims. FTSeek门禁(627)查询时能读到.
2. **daily_active_pool.json** (pipeline.py): scan的top_bullish+top_bearish追加到FTSeek factor_engine已读的pool文件(source="SCAN", 当日过期). 0行FTSeek改动.
3. **dynamic_blacklist.json** (pipeline.py): avoid桶(falling knife)写入文件, FTSeek risk_stage冻结后加3行读取.
4. **deep_sector_rotation.json** (pipeline.py): 板块轮动(strongest/weakest/sector_changes/symbol_sectors), 格式与plan_validator兼容.
5. **exit_param_override.json** (feedback_loop.py): 持续亏损pattern(样本≥10, WR<45%)生成退出参数override建议(time_exit放宽50%, trailing关闭). FTSeek pipeline冻结后加5行读取.
**pipeline.py新增**: `_write_ftseek_data_channels()`方法(Stage 6, 3个文件写入, best-effort) + Stage3注入scanner的strategy_type/position_size_hint/signal_scores到analysis对象(4行).
**feedback_loop.py新增**: `_write_exit_param_override()`函数, run_daily和run_backfill都调用. 30天72笔交易→1个override: LONG+TIME_EXIT(14笔,WR=35.7%,PnL=-$1103)→time_exit=8h,trailing=False.
**5个反馈通道** (3个已有+2个新增):
- IC反馈: claim_ic_cache → llm_synth prompt (已有)
- 策略记忆: trade_records → strategy_memory → signal_gate (已有)
- 退出参数: trade_records → exit_param_override.json → FTSeek factor_exit_rules (新增)
- 候选池: scan结果 → daily_active_pool.json → factor_engine (新增, 0行FTSeek)
- 黑名单: avoid桶 → dynamic_blacklist.json → risk_stage (新增)
**FTSeek消费端已落地 (2026-07-08, 4个改动)**:
1. **改动2 — pipeline.py:664 deep conditions注入**: 门禁通过后读factors_json的conditions, 替换voting的粗粒度factors → `factors = dict.fromkeys(_deep_conditions, True)`. 效果: factor_exit_rules根据deep conditions选退出策略. 同时读strategy_type/position_size_hint并log.
2. **改动5b — pre_trade_check.py:33 动态黑名单**: `_load_blacklist()`合并dynamic_blacklist.json(avoid桶/falling knife). 60s缓存, best-effort. 验证: US.INTC(falling knife -25% 5d)被拦截.
3. **改动7b — plan_validator.py:103 板块轮动fallback**: premarket_scanner无sector_rotation时, 读deep_sector_rotation.json. 格式兼容(strongest/weakest/sector_changes).
4. **改动9 — pipeline.py:2515 退出参数override**: 读exit_param_override.json, 按方向+退出原因匹配, 覆盖factor_exit_rules的time_exit_hours/trailing_enabled/breakeven_at_pct. 当前override: LONG+TIME_EXIT(14笔WR=35.7%PnL=-$1103)→time_exit=8h,trailing=False.
**跳过的改动**: NEUTRAL fallback(改动3+4) — NEUTRAL 51条0%胜率, deep_analysis样本不足(11条), 补位风险>收益. 等deep_analysis样本30+再考虑.
**不做的事**: 多批次入场(过度设计, 日内分批收益<0.1%) + deep干预老仓退出(ExitMonitor是安全机制) + bridge文件(辩论已否决) + 审查官/裁定(辩论已否决).
**验证**: 全部4个改动import OK + blacklist含US.INTC + exit_param_override 1 override读取 + deep_analysis snapshots含conditions(PENG=['news_positive','sentiment_bullish','above_ma20']) + strategy_type=quality_breakout.
**教训**: 规划-执行分离不需要bridge文件或新接口 — 复用FTSeek已有的5个数据读取点(factor_engine/risk_stage/plan_validator/门禁/factor_exit_rules), skill侧写文件, FTSeek侧加几行读取. 最短路径. 消费端改动总计~85行, 全部best-effort(读取失败不影响主流程).

### 69. ✅ 退出参数收紧 — breakeven 1.5→1.0, drawdown 0.8→0.5 — v0.40实施 (2026-07-09)
**背景**: MFE中位数仅1.5%, 85%利润被giveback。EOD是唯一稳定盈利(86%WR+$1786)。SL全亏是最大出血(0%WR-$2865)。
**改动**: playbook_horizon.yaml factor_exit_rules全量调整:
- default: breakeven 1.5→1.0, drawdown_from_peak 0.8→0.5
- 趋势类(macd_golden_cross/above_ma20/above_ma50/ma_golden_cross/bollinger_upper/bollinger_squeeze/near_52w_high): drawdown 0.6-0.7→0.5-0.6
- 基本面类(insider_net_buy/revenue_growth_high/roe_high/earnings_beat_streak/post_earnings_momentum): drawdown 0.6→0.5
- 情绪类(sentiment_bullish): drawdown 0.6→0.5
- 波动/反转类(volume_expansion/rsi_oversold): 不变(无drawdown, 快速证伪)
**效果**: 浮盈1%→保本(亏不了) → 浮盈1.5%→回撤0.5%→锁1.0%(落袋)
**不碰**: rr_ratio=999(无TP, MFE太低设TP永远不触发)、SL参数(等MFE/MAE数据驱动决策)、EOD(唯一稳定盈利源)
**教训**: 退出参数调优应该先看数据再改。MFE中位数1.5%意味着TP=3%永远不触发, 应该靠drawdown_from_peak+EOD落袋而不是TP。breakeven从1.5%降到1.0%是为了更早保本减少SL出血。等新管线跑出20+笔MFE/MAE数据后再做数据驱动决策。

### 73. ✅ Trigger逻辑修复 — ±1%→±5%追入区+极端gap>8%过滤 — v0.44诊断/v0.45落地 (2026-07-09)
**位置**: `app/playbook/pipeline.py:2420-2441` `_check_intraday_trigger()`
**用户问题**: "执行计划和指令是否有基于盘中具体数据和情况能够动态感知调整？"
**事实**: 5条bridge instruction全部triggered=0/executed=0, 0笔成交. auto_execute跑了2次(09:43+10:08 ET), PSX/VLO/MPC全部因gap>3%被跳过.
**根因三层**:
1. **触发区太窄(±1%)**: LLM产出"回调买入"策略(entry=MA5), 但开盘gap up 3-6%时价格永远不回到entry±1% → 0%触发率.
2. **gap过滤方向不分**: `abs(current - entry) / entry > 0.03`一律跳过. BUY+gap up(动量确认=好事)和BUY+gap down(暴跌=该跳过)被同等对待.
3. **entry_strategy被忽略**: LLM在raw_instruction_json写了RSI/量比/K线条件, trigger只做价格距离检查.
**修复(v0.45)**:
```python
# 旧: _touch_zone = 0.01  # ±1%
# 新: _chase_zone = 0.05  # ±5% 追入区
# BUY: current <= entry * 1.05 → 触发(回调或小幅追入)
# SHORT: current >= entry * 0.95 → 触发

# 旧: abs(gap) > 3% 一律跳过
# 新: abs(gap) > 8% 才跳过(极端暴涨暴跌)
```
**实盘验证(重启后)**:
| symbol | entry | current | gap | 旧结果 | 新结果 |
|---|---|---|---|---|---|
| VLO | $271.30 | $281.85 | +3.9% | SKIP(gap>3%) | ✅ TRIGGER + re-price |
| NVDA | $197.80 | $200.71 | +1.5% | SKIP(未穿越1%) | ✅ TRIGGER + re-price |
| TTE | $76.80 | $78.57 | +2.3% | SKIP(未穿越1%) | ✅ TRIGGER + re-price |
| PSX | $178.98 | $188.90 | +5.5% | SKIP(gap>3%) | SKIP(>5%追入区, 合理) |
| MPC | $265.00 | $281.62 | +6.3% | SKIP(gap>3%) | SKIP(>5%追入区, 合理) |
3/5触发成功, 触发后re-price用实时ATR重算SL/TP.
**不做(YAGNI)**: 不做LLM盘中重估(延迟+成本); 不解析entry_strategy文本(NLP复杂, ROI低); 不做分批执行(等基础设施验证后).
**教训**: ①LLM产出"回调买入"策略, 但市场不给回调机会时, ±1%触发区=0%执行率. 扩展到±5%允许追入, 同时用re-price的ATR分桶保护SL. ②gap up对BUY是动量确认(好事), 不该和gap down(暴跌)同等处理. 极端gap>8%才统一跳过. ③审计trigger逻辑必须用实际gap+价格数据验证, 不能只读代码.
> 详见 `references/trigger-logic-gap-analysis-20260709.md`

### 75. ✅ confidence第一性原理: 三系统零预测力, 改用辩论结果 — v0.46实施 (2026-07-10)
**第一性原理**: confidence = P(trade profitable | signal), 唯一合法功能是排序信号。
**用户要求**: "基于ponytail和karpathy选择 分析confidence的第一性原理和功能"
**数据验证** (45笔PLAYBOOK_SIM + 35笔有voting_result + 41笔MAIN_PIPELINE非零):
- compute_confidence (数据质量分, ok×12+条件×28, 封顶90): r=-0.073, conf=90胜率31%
- LLM定性confidence (3模型自评0.0-1.0): r=-0.211, 负相关, 比随机还差
- SignalQualityScorer (5维市场微观结构): r=-0.038, 77%交易conf=0.000(scorer未触发), 5个factor列全constant
- 模型一致度 (consensus): r=+0.102, 唯一弱正相关
**三个confidence系统根因**:
1. adapter.py: confidence=score/10.0 — 同义反复, LLM定性confidence被丢弃
2. pipeline.py L1014: confidence=compute_confidence(data,...) — 数据质量分覆盖bridge的LLM confidence
3. BridgeVotingAdapter: confidence=cand.get("confidence",score/10.0) — 也是score/10
**错误改法(已回退)**: 用LLM定性confidence(高/中高/中)+辩论±调整 → LLM自评变体, r=-0.211证明无预测力
**最终方案**: confidence=0.50+debate_adjustment(只用唯一正相关信号)
- 2模型一致+AGREE → 0.70 (通过gate≥70)
- 2模型方向分歧 → 0.35 (BLOCKED, 正确)
- 无辩论 → 0.50 (BLOCKED)
**YAGNI**: 不接SignalQualityScorer(r=-0.038); 不做校准(0样本); 不修LLM prompt(LLM自评负相关)
**3文件surgical edit**: adapter.py(skill) _compute_confidence改为debate-only; pipeline.py(FTSeek) BridgeVotingAdapter同步; pipeline.py(skill)移除llm_confidence字段
**教训**: ①LLM自评无校准锚点, 说"高"不知道对应多少胜率 ②垃圾进垃圾出: 无预测力信号经调整仍无预测力 ③Ponytail: 用唯一正相关信号(辩论), 不是更复杂合成 ④真正预测信号(退出IC/claim IC/个股pattern)已存在, 只是不叫"confidence" ⑤SignalQualityScorer的5个factor列全constant说明从未正确记录, 需验证
> 详见 `references/confidence-first-principles-20260710.md`

### 74. ✅ factor_detail list类型导致save_trade写入失败 — _row_to_dict自动json.loads — v0.45修复 (2026-07-09)
**位置**: `app/storage/trade_store.py:664` + `app/playbook/db.py` `_row_to_dict()`
**现象**: NVDA/TTE触发后`save_trade`报`Error binding parameter 35: type 'list' is not supported`, trade_record写入失败→broker订单已成交→回滚平仓→产生孤儿仓.
**根因链路**:
```
PlaybookDB._row_to_dict()
  → 自动json.loads了conditions_json (line: "conditions_json" in auto-parse list)
  → 从string '["news_positive",...]' 变成 list ["news_positive",...]
playbook_service.py line 925:
  "factor_detail": inst.get("conditions_json", "")
  → 传list给save_trade
trade_store.py line 664:
  if isinstance(factor_detail, dict):  ← 只处理dict, 不处理list!
  elif not factor_detail:              ← list非空, 不进这个分支
  # factor_detail保持list → 传给sqlite3 → "unsupported type"
```
**修复**: `isinstance(factor_detail, dict)` → `isinstance(factor_detail, (dict, list))`
**复现验证**: 改动前传list → `FAILED: ProgrammingError`; 改动后传list → `SUCCESS: rowid=xxx`
**教训**: ①`_row_to_dict`的自动json.loads会改变字段类型(string→list/dict), 下游消费者如果不处理所有可能的类型就会报错. ②跨模块类型一致性: 上游(DB读取层)做了隐式类型转换, 下游(存储层)只处理部分类型 → 裂缝. ③sqlite3的`Error binding parameter N`中N是1-indexed, 对应INSERT中第N个`?`占位符. ④trade_record写入失败但broker订单已成交 → 孤儿仓. save_trade失败后回滚平仓, 但broker可能已无持仓(broker_no_position) → 不可逆孤儿仓.
**通用模式**: 任何自动JSON解析层(_row_to_dict/to_dict等)都会把TEXT列的string值变成list/dict. 所有消费这些字段的代码都必须用`isinstance(x, (dict, list))`而非只`isinstance(x, dict)`.
> 详见 `references/trigger-and-save-trade-fix-20260709.md`

### 72. ✅ 动静结合: --symbols传熟股列表 — v0.43实施 (2026-07-09)
**用户需求**: "除了市场扫描并投票选择出的动态池股 对于watchlist中的静态股是否可以进行分析和投票 给出指令和策略 动静结合 熜股和新扫描股"
**已有能力**: `pipeline.py --symbols US.X,US.Y`参数已存在(argparse第540行), `run_full()`里extra_symbols合并到deep_candidates(第65-69行), 去重逻辑已有(`_existing` set). 0行代码改动.
**落地**: 只改bridge cron的prompt, 加`--symbols`参数传15只熟股: `US.MSFT,US.AAPL,US.NVDA,US.META,US.AMZN,US.JPM,US.LMT,US.CRM,US.ORCL,US.LLY,US.UBER,US.COIN,US.TSLA,US.AVGO,US.MU`
**熟股选择**: trade_records有PLAYBOOK_SIM交易记录的12只 + Obsidian 3次以上深度分析的10只, 合并去重选15只.
**Ponytail审视**: 不改pipeline.py代码(--symbols已支持); 不新建"熟股管理"模块(cron prompt硬编码); 不做自动熟股列表提取(等数据更多后考虑); 不分两条cron(一条搞定, 合并bridge).
**效果**: cron 21:00 CST跑: 动态扫描top 5新机会 + 15只熟股(去重后约18-20只), 合并到同一个bridge. 熟股有历史交易记录+Obsidian分析归档, LLM能通过_get_trade_experience()和_get_obsidian_history()读到上次分析结论.
**教训**: ①先检查已有能力再写新代码——--symbols参数和extra_symbols逻辑已存在, 只需在cron prompt中启用. ②"熟股"定义来自两个数据源交叉: 交易过的(trade_records) + 分析过的(Obsidian 3次+). ③动静结合不需要分两条管线——同一个pipeline.py调用, 合并去重, 同一个bridge输出.

### 71. ✅ 日cap 40%→60% — v0.42实施 (2026-07-09)

### 70. ✅ Bridge entry_price是LLM建议价不是实时价 — v0.42教训 (2026-07-09)
**用户问题**: "entry SL为什么和实际在富途上显示的盘前价格都相差比较大 这些price值怎么获取的"
**根因**: bridge文件中的entry_price来自LLM的execution_plan.entry_price, 这是LLM建议的"期望回调入场价"(如"回调至MA5($178.98)附近建仓"), 不是实时现价。
**价格链路**: llm_synth.synthesize() → result["execution_plan"]["entry_price"] → adapter.to_voting_result()取plan.get("entry_price") → bridge文件 → DB instruction
**实际执行**: FTSeek auto_execute触发时用_reprice_params覆盖:
  - entry = 实时ask(BUY)或bid(SHORT)
  - SL = entry × (1 - sl_pct%), sl_pct由ATR分桶决定(2-5%)
  - TP = entry × (1 + sl_pct×tp_mult), rr_ratio=999时TP=0(无止盈)
**所以bridge里的entry/SL/TP不影响实际执行价格** — 实际买入价是触发瞬间的实时bid/ask。
**推送修复**: 钉钉推送同时显示现价(Finnhub实时)和LLM建议价, 标注"实际以re-price为准":
```
US.PSX: LONG conf=0.7 现价$187.81
  LLM建议入场$178.98 SL$172.0 (实际以re-price为准)
```
**教训**: ①bridge里的价格是LLM的分析建议, 不是执行价。用户看到推送会误以为系统会在$178.98买入, 实际会在$187.81附近买入。②re-price机制是保护——盘前推测值被实时价覆盖。③推送信息必须区分"建议价"和"执行价", 否则误导用户。

### 71. ✅ 日cap 40%→60% — v0.42实施 (2026-07-09)
**位置**: `app/playbook/config.py` daily_notional_cap_pct
**背景**: bridge候选直写DB后, deep_analysis信号质量提升, 更多资金给bridge候选执行, 积累更多交易数据验证方向+退出策略。
**效果**: equity ~$157K, 日cap=60%→$94K, 每仓$6,300→可开15笔(受max_daily_positions=10限制, 但预算不再提前耗尽)。
**教训**: 提高日cap不增加单笔仓位大小(max_position_pct不变4%), 只增加可用笔数。bridge候选不再因"预算耗尽"被跳过。

### 54. ✅ signal_gate 接线 P0 — BLOCK 信号不写 DB — v0.48实施 (2026-07-10)
**问题**: `pipeline.py` Stage3 L147-153 计算 `gate_result` (含 PASS/WARN/**BLOCK**) 存入 `analysis["_signal_gate"]`, 但 `_write_bridge_file` L358-361 写 DB 时只判断 `direction in (BUY, SELL_SHORT)`, 从不读 gate 决策. 一个 `quality_score<40 / decision=BLOCK` 的信号照样写进 DB 照样执行. signal_gate 的 7 维质量门 (个股历史/pattern/claim IC/RR比) 对实盘零作用.
**修复**: 在 `_write_bridge_file` 循环里, direction 检查通过后、`to_voting_result` 之前, 读 `a["_signal_gate"]["decision"]`: BLOCK → continue (不写 DB); WARN → `a.setdefault("position_size_hint", "small")`; PASS/gate缺失 → 正常流程.
**代码**: `pipeline.py` `_write_bridge_file()` L362-371, 约10行. gate 缺失时默认 PASS (fail-open, 不阻断).
**效果**: 直接拦截"个股全亏/匹配亏钱pattern/RR<1/用负IC论据"的信号. 对胜率提升结构性有效.

### 55. ✅ vol_ratio 量能门移除 P0 — _vol_ok=True — v0.48实施 (2026-07-10, FTSeek侧)
**问题**: `_check_intraday_trigger` 的量能门 `_vol_ok` 经历三次迭代:
1. 原版 `(vol_ratio is None) or (vol_ratio <= 0) or (vol_ratio >= 1.5)` — `market_data_router.setdefault("volume_ratio", 1.0)` 使哨兵=1.0, 不触发 fail-open → 所有追入被永久阻断
2. Agent修复 `<= 1.0` — 解决了哨兵问题但留下 dead zone: vol_ratio 1.01-1.49 的正常股票被无理由阻断 (~45%)
3. 终局 `_vol_ok = True` — 日级别 vol_ratio 对盘中突破量能确认零预测力, 移除门
**根因**: `get_daily_kline` 返回历史日线(最后一根=昨日完整bar), `lv3_technical_calculator._calc_volume_ma` 用日volume算 vol_ratio → 测的是昨日相对量, 不是今日盘中突破量. 真正的盘中量能确认需要1分钟K线聚合今日累计量/同时段均量, 未来实现后再加回.
**保护仍来自**: +5%追入带 + 3%接飞刀下限 + 8%极端gap过滤 + SL检查.
**代码**: `app/playbook/pipeline.py` L2493, `_vol_ok = True` (一行).
**用户问题**: "ftseek管线中的voting是否可以移除或者转移补充到skills中，规划充分完整后再由ftseek来执行交易"
**数据驱动结论**: voting_llm是已死的出血源 (182笔42.3%WR PnL=-7.73%, 33天没出交易). playbook_sim已接管全部活跃交易 (8个持仓). voting_predictions表1900行 LONG WR=45.8%/SHORT WR=51.1%/NEUTRAL WR=0%.
**关键发现**: playbook pipeline已经在用deep_analysis的conditions覆盖voting的factors (pipeline.py:693 `factors = dict.fromkeys(_deep_conditions, True)`). voting实际上只是触发器, 真正的alpha来自deep_analysis. 5个数据通道已有(factors_json/dynamic_blacklist/daily_active_pool/deep_sector_rotation/exit_param_override), bridge文件是唯一缺失环节.
**落地方案 — BridgeVotingAdapter模式** (比原方案更简, Ponytail):
- 原方案: 新建`_read_bridge_candidates()`替换`_build_instructions_from_votes`的500行过滤逻辑
- 实际方案: 创建`BridgeVotingAdapter`类, 实现`.vote(symbol, ctx)`接口从bridge JSON文件读, **零改动**`_build_instructions_from_votes`的500行过滤逻辑
- 装载点: `scheduler_core.py`初始化时调`_try_load_bridge()`, bridge存在→`self.voting_coordinator = BridgeVotingAdapter`, 不存在→保持`VotingCoordinator`(安全fallback)
- signal_stage.py和playbook/pipeline.py都通过`scheduler.voting_coordinator`获取, **无需感知bridge存在**
**3个文件改动, ~165行**:
1. skill `pipeline.py`: `_write_bridge_file()` — deep_analysis输出→bridge JSON (~60行)
2. `app/playbook/pipeline.py`: `BridgeVotingAdapter` + `_try_load_bridge()` (~95行)
3. `app/core/scheduler_core.py`: bridge覆盖`voting_coordinator` (~10行)
**安全降级**: bridge文件不存在→VotingCoordinator(LLM投票,原行为); bridge无候选→VotingCoordinator; bridge损坏→logger.warning+VotingCoordinator
**验证**: 语法✅+导入无循环✅+roundtrip(skill写bridge→FTSeek读bridge→vote()返回正确格式)✅+方向转换BUY→LONG✅+SKIP不写bridge✅+未知symbol返回None✅
**盘中实跑验证(2026-07-08 ET 13:08, 市场OPEN)**: pipeline --mode full --limit 10 --top 3 跑完5只深度分析(TTE/ANET/PENG/ASML/NOK). 3只LONG写入bridge(TTE 76.8/ANET 168.86/ASML 1730), 2只NEUTRAL跳过. 5条IC写入signal_snapshots.db确认. bridge文件5496字节, 3 candidates. 市况叙事="震荡分化，板块轮动资金切向Energy+Technology".
**方向映射bug(测试中发现)**: adapter.to_voting_result()返回direction="BUY"/"SELL_SHORT"(LLM格式), 但BridgeVotingAdapter.vote()期望"LONG"/"SHORT"(VotingCoordinator格式). 修复: bridge writer加`_dir_long_short = "LONG" if vr["direction"] == "BUY" else "SHORT"`. 不修则adapter.vote()返回None(direction不在LONG/SHORT枚举里).
**bridge文件路径一致性**: skill pipeline.py和FTSeek _try_load_bridge()都用ET日期(`datetime.now(_et_tz).strftime("%Y-%m-%d")`)生成文件名. 两边必须用同一时区, 否则bridge文件找不到→fallback到VotingCoordinator.
**盘中重启安全评估**: 9个持仓全在simulate账户, 止损单在broker侧(sl_broker_order_id全部有值). startup_reconcile()从DB恢复持仓(DB是SSOT). _restore_signal_cooldown_from_db()恢复信号冷却. 重启期间约10-30s无监控, simulate模式无真实资金风险. 判断: 可安全重启.
**教训**: 替换复杂模块时, 先找接口边界(duck-type compatible class)而不是改消费方. 删500行过滤逻辑=风险, 建adapter=0行消费方改动. Ponytail: 删除>新增, 但接口兼容>删除.

### 54. ✅ Bridge Link Audit Methodology — v0.28 (2026-07-09)
**位置**: `references/bridge-link-audit-methodology.md`
**背景**: 用户要求审计FTSeek-US bridge链路的真实当前状态，回答5个具体问题(bridge文件/runtime读取/voting代码/DB执行/脚本状态)。
**5点审计法**:
1. **Bridge文件生成**: `ls data/opportunity_scan_*.json` + 读最新文件结构
2. **Runtime读取**: grep `BridgeVotingAdapter|_try_load_bridge` in scheduler_core.py + pipeline.py
3. **Voting路径**: grep `VotingCoordinator|vote(` — 确认是否双轨(bridge优先+voting兜底)
4. **DB执行**: sqlite3查trade_records/playbook_instructions/open_positions/voting_predictions/signal_snapshots
5. **脚本状态**: grep `_write_bridge_file|ic_writer` in skill scripts
**关键发现**:
- **DB位置陷阱**: 根目录`ftseek_us.db`是空壳(4096B,0表), 生产DB在`data/ftseek_us.db`
- **列名陷阱**: open_positions用`size`(非qty/quantity), 无`status`列; playbook_instructions用`executed`+`triggered`(非status)
- **时序gap(新)**: bridge文件13:19 ET生成(盘中), 但盘前voting 04:23 ET运行时bridge不存在→走VotingCoordinator. bridge只在盘中重启后才生效. deep_analysis cron设06:00 ET但盘前voting 04:00 ET已开始→cron时间需前移或接受双轨.
- **断点确认**: bridge候选(TTE/ANET/ASML) instruction created但triggered=0/executed=0, v0.27的4个断点仍活跃
**教训**: 审计bridge链路不能只看"文件存在+代码存在"——必须查DB确认instruction的triggered/executed状态+trade_records有无对应记录. 文件生成≠执行成功.

### 53. ✅ bridge→下单执行链路4个断点 — v0.26盘中验证发现
**背景**: bridge文件生成+FTSeek重启加载成功后, 用户问"bridge目标股如何能实现下单计划". 实跑发现bridge加载≠bridge候选能下单.
**完整链路**: ①skill写bridge JSON (opportunity_scan_YYYYMMDD.json) → ②daily_active_pool→factor_engine→_get_watchlist()→screener.screen() → ③playbook_instructions(triggered=1)→auto_execute→下单
**断点1 — bridge候选不在daily_active_pool ✅ FIXED (v0.30, 2026-07-09)**: `_write_ftseek_data_channels`只从`scan_result.top_bullish+bearish`追加候选到pool. 但bridge候选来自`analyses`(深度分析输出), 两个集合不重叠时bridge标的在FTSeek里不可见. **根因**: `BridgeVotingAdapter.vote(symbol)`是被动查询——pipeline只在遍历pool已有symbol时调vote(). 候选不在pool→vote()永不被调用→deep_analysis信号零执行. **修复(两层)**: ①skill侧`_write_ftseek_data_channels`同时从analyses追加BUY/SELL_SHORT标的到pool(proactive,但重启可能被清) ②**runtime侧`_try_load_bridge()`末尾追加~25行(关键修复)**: 加载bridge成功后,把候选symbol注入`daily_active_pool.json`(source=SCAN,metadata={bridge:true,strategy_id:deep_analysis}). 幂等设计(已存在不重复). runtime侧修复是关键——skill侧写入的entries在FTSeek重启时可能被清理(断点4),runtime侧在每次scheduler初始化时重新注入,确保bridge候选一定在pool里. **验证**: 重启后日志`[scheduler] bridge文件加载成功`+pool 30→33 entries+vote()返回正确direction/SL/TP+非bridge候选正确跳过(None)+37 entries unique无重复.
**断点2 — playbook_generate幂等**: DB已有instruction→跳过generate→新bridge候选不会生成instruction. TRADING catch-up调用不带force=True. **临时解决**: 手动插入instruction(triggered=1)到playbook_instructions表. **长期**: bridge writer直接写instruction到DB或增量generate.
**Pitfall (v0.55): bridge cron 实际在 ET 16:00 (收盘后) 运行, 非盘前。**
scheduler 在 service 启动时 (ET 04:23 盘前) 调用 `_try_load_bridge()` 查找今日 bridge 文件,
但 bridge 要到 ET 16:00 才生成 → scheduler 永远找不到今日 bridge → fallback TechnicalFallbackAdapter。
且 scheduler 只在 `__init__` 加载 bridge, **盘中不重载**。
实际生效路径: DA skill 直写 `playbook_instructions` DB 表 → auto_execute 读 DB → 触发执行。
BridgeVotingAdapter 路径 (包括 vote() 里的 confidence 合成) 是死代码。
**DA 直写 DB 还绕过了 run_playbook_generate 的 confidence 闸门 (pipeline.py:1059, conf<70→SKIP)**。
→ 修复: DA skill `_write_bridge_file` 写 DB 前加 conf≥70 检查 (2行)。
详见 `references/da-to-executor-consistency-audit-20260712.md` [7]-[9]。
**断点3b — bridge候选confidence=70 < VotingCoordinator的88-100 → 排序靠后吃不到预算 (v0.32, 2026-07-09)**: auto_execute按confidence降序排序(pipeline.py:2099), bridge候选conf=70(adapter.py:174 `confidence=score/10.0`,score=7.0)排到最后,即使触发也吃不到budget. **修复**: 排序key改为`(1 if decision_id.startswith("DA-") else 0, confidence)`,bridge候选排前面. **验证**: 7/8 instruction表13个非bridge conf=90 + 3个bridge conf=70, 修复后bridge排前. **双保险**: 当bridge文件盘前已存在(cronjob),所有非bridge候选被SKIP(vote返回None),不存在竞争. 排序优先级是fallback场景(bridge加载失败→VotingCoordinator)的保险.
**预算机制确认 (v0.32, 2026-07-09)**: `capital_safety.get_available_budget_for_auto()`返回$57,040(基于current_equity=$98,844). `daily_notional_cap=equity×daily_notional_cap_pct`(配置默认0.20=$19,768). `max_daily_positions`配置默认5. auto_execute每30分钟跑一次(pipeline.py:1970+). 检查顺序: confidence排序→broker持仓检查→re-price→confidence门禁(≥65)→购买力上限→单日notional上限→单日开仓数上限→执行.
**断点4 — pool过期清理**: FTSeek重启时daily_active_pool的SCAN entries可能被清理(即使expires_at未到). pipeline写的entries在重启后消失. **修复**: bridge writer同时写pool(断点1修复), 且pool过期逻辑需检查expires_at而非重启全清.
**教训**: 信号生成成功≠执行成功. 信号链路的每一环(pool→watchlist→screener→instruction→auto_execute→预算)都必须验证, 不能只验证bridge文件写入+scheduler加载. 两个独立候选集合(scanner top vs analyses)必须有同步点.
> 详见 `references/voting-removal-migration-20260709.md` 的"bridge→下单执行链路断点分析"段

### 64. ✅ 取消3模型投票→NullVotingAdapter+2模型辩论 — v0.39实施 (2026-07-09)
**用户需求**: "取消三模型投票阶段, 重点是将信息采集和行业市场和个股关联做高质量分析, 可以考虑在计划阶段通过两个模辩论分析决策出的方向和指令"
**根因**: 3模型投票方向准确率47%≈随机(DeepSeek 88%偏空/qwen 88%偏多/glm独裁). 48-52噪声区间1分之差翻转方向. conditions与direction矛盾率30%.
**3个改动**:
1. **FTSeek侧切断VotingCoordinator fallback** (`scheduler_core.py`): bridge不存在→NullVotingAdapter(全SKIP), 不再用噪声投票替代信号. ~15行.
2. **skill侧增强数据采集** (`data_collector.py`): 新增`collect_market_context()`(SPY/QQQ日K线+VIX)和`collect_industry_peers()`(同行业top5 peer近期表现+行业平均). 16→18维数据. ~165行.
3. **skill侧2模型辩论** (`llm_synth.py`): Pass1分析师(qwen3.7-max)→Pass2挑战者(deepseek-v4-pro做魔鬼代言人)→融合(方向一致提confidence/分歧降confidence或SKIP). deepseek天生偏空正好适合做挑战者. ~150行.
**验证**: AAPL实测——分析师SKIP(score=5), 挑战者SELL_SHORT(score=3), 挑战者发现QQQ趋势DOWN+缩量顶+内部人卖出等被忽视风险. NVDA实测——分析师BUY, 挑战者SKIP, debate_outcome="方向分歧→降confidence".
**教训**: ①deepseek 88%偏空是feature不是bug——天生适合做"魔鬼代言人"挑战者. ②不交易>噪声交易——bridge不存在时全SKIP, 不用47%随机的投票替代. ③数据先于推理——先增强采集(SPY/QQQ/peers), 再增强辩论. 输入质量决定辩论质量.
> 详见 `references/voting-replacement-and-2-model-debate-20260709.md`

### 65. ✅ Bridge候选直写instruction到DB — v0.39 P0修复 (2026-07-09)
**位置**: `scripts/pipeline.py` `_write_bridge_file()` + FTSeek `app/playbook/pipeline.py` `run_playbook_generate()`
**根因**: bridge候选永远不能变成instruction! `_write_bridge_file()`只写bridge JSON文件, 但FTSeek `run_playbook_generate()`有幂等检查(DB已有instruction就跳过). VotingCoordinator在ET 04:17先跑→生成42条DEC-格式instruction→幂等→bridge在ET 09:00生成→但instruction不会重新生成→auto_execute消费VotingCoordinator的旧instruction, bridge候选0条执行.
**实证**: 今日bridge有23候选(TTE/ANET/VLO/CI/...), 今日instruction 42条全是DEC-格式(VotingCoordinator), 0条DA-格式(deep_analysis), 今日trade_records 12笔全部[voting], 0笔[bridge].
**修复**: `_write_bridge_file()`同时调`PlaybookDB.save_instruction()`直写instruction到DB. UPSERT by date+symbol天然处理重复(bridge候选覆盖VotingCoordinator的旧instruction). ~40行. 复用已有接口, 不新建表/接口/服务.
**验证**: 清理今日instruction→跑bridge生成→DB出现2条DA-格式instruction(NVDA BUY conf=70 entry=$197.8 SL=$191.0, ANET BUY conf=70 entry=$164.91 SL=$156.65). decision_id=DA-20260709191059-US.NVDA-ec12.
**教训**: 信号生成成功≠执行成功. bridge文件写入成功≠bridge候选能下单. 信号链路的每一环(bridge文件→instruction→triggered→auto_execute→预算)都必须验证. 幂等检查是双刃剑——防止重复生成, 但也阻止高质量信号覆盖低质量信号.

### 66. ✅ 辩论结果从_llm_output提取 — v0.39字段路径修复 (2026-07-09)
**位置**: `scripts/pipeline.py` `_write_bridge_file()`
**问题**: `_write_bridge_file()`用`a.get("_debate")`取辩论结果, 但`_debate`/`debate_outcome`是`llm_synth.synthesize()`返回的result dict中的字段, 经过`deep_analyzer._apply_llm_result()`存到`self.result._llm_output`, 再通过`asdict(self.result)`变成`a["_llm_output"]["_debate"]`. 直接`a.get("_debate")`=None.
**修复**: `a.get("_llm_output", {}).get("_debate", {})` — 从_llm_output中取辩论结果.
**验证**: 修复后bridge文件中`debate_outcome="⚠️ 2模型方向分歧(BUY vs SKIP)"`, `challenger_direction=SKIP`, `challenged_claims=2条`.
**教训**: 跨模块字段传递必须追踪完整路径. llm_synth→deep_analyzer._apply_llm_result→asdict→pipeline._write_bridge_file. 中间的`_llm_output`是中间层, 不能跳过.

### 67. ✅ NullVotingAdapter跳过run_playbook_generate — v0.39防覆盖修复 (2026-07-09)
**位置**: FTSeek `app/playbook/pipeline.py` `run_playbook_generate()`
**问题**: NullVotingAdapter.vote()返回None→pipeline SKIP→`save_instruction`会UPSERT覆盖bridge已写的BUY/SELL_SHORT instruction为SKIP, 破坏bridge候选.
**修复**: `run_playbook_generate()`开头加type check——如果`voting_coordinator`是`NullVotingAdapter`就直接return None, 跳过整个generate流程. ~8行.
**验证**: 逻辑分析——NullVotingAdapter时generate跳过→不会产生SKIP instruction→不会覆盖bridge的BUY/SELL_SHORT. auto_execute直接从DB读bridge写的instruction.
**教训**: UPSERT的覆盖语义是危险的——新写入的SKIP会覆盖旧写入的BUY. 当两个写入源(VotingCoordinator vs bridge直写)写同一张表时, 必须确保后写的不覆盖先写的. type check是最简防护.

### 76. ✅ 计划-执行四大断裂: 价格+趋势+范围+SL/TP联动 — v0.52诊断 (2026-07-11)
**用户需求**: "盘前和开盘价格的不一致, 包括计划没有变化快的现象, 从价格 趋势 以及范围 基于第一性原则进行重新考虑设计" → 用户追问 "结合止损止盈退出策略的联动" → 发现第4个断裂
**诊断方法**: 全链路代码追踪(pipeline.py 2700行 + instruction_generator.py 470行 + adapter.py + skill pipeline.py + playbook_service.py + db.py _TRACKING_FIELDS) + DB实查(7/1-7/11的playbook_instructions + trade_records + 实际reprice日志)
**四大断裂**:
1. **价格断裂**: LLM输出"在$204-205区间挂限价单"(区间) → DB存entry_price=204(单点) → 执行端只看单点±5%. 60-80%指令从不触发. DB实证: 7/8的8/10、7/9的4/6、7/10的5/8候选未触发.
2. **趋势断裂**: 4:00ET生成"NVDA突破MA20 BUY"(趋势确认) → 9:35ET价格已跌回MA20下方(突破失败) → 8% gap filter只检查价格偏离不检查趋势失效 → 无方向一致性检查 → 可能逆势入场.
3. **范围断裂**: LLM输出"若7/14前未回调至$615以下则取消"(失效日期) → 执行端不检查日期 → 计划可挂到下周 → 过期信号在错误时间触发.
4. **SL/TP联动断裂 (v0.52新发现)**: re-price块(pipeline.py L2356-2466)用vol_bucket重算SL, 覆盖LLM的结构止损. NVDA 7/10: LLM SL=$193.99(MA60下方), vol_bucket SL=$197.59(ATR-based), 差0.5%但$197.59在MA60上方→结构止损被噪声止损替代. 但DB实查4笔DA-交易: vol_bucket与LLM SL差异仅0-0.5%, 不是主凶. **真凶是breakeven_at_pct=0.5%**: 浮盈0.5%→SL跳到entry→8分钟后价格回撤→止损. MFE=0的13笔avg-$223: 入场时机错误, 任何SL都救不了. **核心洞察: 入场质量>止损位置>止盈位置**.
**reprice审计字段丢失**: _reprice_params含reprice_from/reprice_to/reprice_original_sl, 但_TRACKING_FIELDS不含这些键→update_instruction_tracking静默丢弃. 顶层entry_price/stop_loss虽在_TRACKING_FIELDS中, 但盘后skill cron重新save_instruction(UPSERT)可能覆盖回原始值.
**设计方案 (Ponytail+Karpathy)**: 结构化字段+SL联动, 零DB schema变更:
- LLM输出 `entry_zone_low/high` + `entry_type`(limit/breakout) + `sl_basis`(structural/atr) + `valid_days` → 存raw_instruction_json JSON列
- 触发逻辑: limit=价格进入区间触发, breakout=穿越边界触发
- 方向一致性: BUY时价格<entry×0.95=趋势逆转不入场(5%=现有chase_zone, 不引入新参数)
- 计划失效: valid_days过期自动SKIP
- **SL联动**: sl_basis=structural → re-price时SHIFT(平移, 不重算); sl_basis=atr → vol_bucket recalculate(原逻辑). 默认atr向后兼容.
- **SL来源决策集中在re-price块一个地方**: re-price → custom_params → trade_records.metadata.stop_loss → exit monitor. 下游全部透明消费, 不需要改退出系统/DB schema/executor.
**不做(YAGNI)**: 不解析entry_strategy文本(脆弱); 不做分批建仓(需仓位重构); 不改breakeven_at_pct(数据: breakeven=true的19笔avg+$92, 正期望; 待20-30笔structural SL样本后再调); 不加volume/RSI条件; 不加复杂趋势指标; 不加DB列
**Deep_analysis confidence旁路发现**: deep_analysis候选(conf=25-35)直写DB绕过confidence gate(buy_min_confidence=85). 0/13 BUY候选若走gate会被全部拦截. 这是BY DESIGN(signal_gate BLOCK/WARN已预过滤), 但意味着confidence只影响排序和仓位, 不拦截.
> 详见 `references/plan-execute-gap-first-principles-20260711.md`（四大断裂DB证据+zone+type+sl_basis+validity设计模式+SL/TP联动kill-chain分析+向后兼容策略+审计SQL模板）

### 68. ✅ Ponytail+Karpathy原则: 最简方案优先 — v0.39用户偏好 (2026-07-09)
**用户原话**: "请通过ponytail和karpathy的原则进行分析 给出合理高效的方案"
**应用场景**: 修复bridge候选→instruction→auto_execute链路时.
**原则**:
- Ponytail: 剃过度设计, 只改真问题, 最简最短方案, YAGNI, stdlib first, 不加未请求的抽象
- Karpathy: 显式假设, 最简方案, surgical edit, goal-driven verification
**具体应用**:
- 没新建模块/接口/服务 — 复用`PlaybookDB.save_instruction()`
- 没改auto_execute — 已按confidence排序, DA-开头排前面
- 没改scheduler_core — NullVotingAdapter已在前一步落地
- 没改re-price机制 — bridge的entry/SL/TP是推测值, auto_execute触发时用实时bid/ask覆盖
- 3个surgical edit ~60行, 不动FTSeek运行时代码
**教训**: ①先找接口边界(duck-type compatible class)而不是改消费方. ②删除>新增, 但接口兼容>删除. ③改参数后旧数据立即失效, 用旧数据推荐新参数是方法论错误. ④不交易>噪声交易——没有bridge=没有高质量信号=不交易.

### 62. ✅ M1数据基础设施 + 三方辩论复盘 — v0.37实施 (2026-07-09)
**背景**: 用户要求"深度真实复盘检查"信号/策略/交易链路/框架逻辑. 启动3个并行子代理(多头/空头/架构师)辩论, 加上亲自验证DB数据.
**三方辩论关键收敛**:
- **voting_llm方向准确率T1=47.2%/T5=47.5%(均低于随机)**. 空头辩手发现实际IC=0.2938(n=19,不显著), 非之前声称的0.62(n=11).
- **持仓4-8h是唯一盈利窗口**: 33笔60.6%WR +$11,263. 其他时段全亏. 但这不是"持有更久所以赚", 是DAY_TRADE_TP(13笔100%WR+$13,101)在这个时段触发.
- **TRAILING_STOP 84笔51.2%WR但PnL=-$224**: 多头声称TRAILING_STOP盈利+$5,515是错误的(可能混了其他exit_reason). TRAILING_STOP接近break-even但不盈利.
- **STRUCTURE_EXIT和FLASH_EXIT不在playbook路径**: 它们来自旧position_monitor(MAIN_PIPELINE/SCALPING). playbook只产生5种: SL_FIXED_PCT/TAKE_PROFIT/PRE_CLOSE_EXIT/TIME_EXIT/MAX_HOLD. 禁用它们不需要改playbook代码.
- **期权13笔-$12,457是数据污染主体**: 清理后纯股票211笔PnL=-$1,470(从-$13,927降到-$1,470).
**M1数据基础设施(3项, 反馈闭环前提)**:
1. **MFE/MAE采集**: trade_records新增mfe_pct/mae_pct/entry_vix/entry_session列. monitor_playbook_sim_exits每60秒更新metadata的mfe_pct/mae_pct(只增不减). _close_trade_record平仓时从metadata提取写入独立列. **没有MFE/MAE无法区分"好信号+差执行"vs"差信号"**.
2. **decision_id贯穿**: attribution_scheduler.py INSERT trade_attribution时从trade_records查decision_id写入(之前0/214非空). 信号→交易→归因全链路可JOIN.
3. **f1-f5因子快照**: playbook_service.py写trade_records时从conditions_json提取因子标记到f1_trend/f2_momentum/f3_volume/f4_orderflow/f5_lifecycle(之前全零). factor_detail写conditions_json原文.
**6项P0修复(当天落地)**:
1. daily_notional_cap从DB查当日已开仓(原每次调用从0开始=风控失效)
2. 盘中_check_intraday_trigger加gap>3%过滤(原无gap检查=暴跌中入场)
3. feedback_loop用_get_all_closed_trades全部211笔历史(原只当天十来笔=永远达不到≥10阈值)
4. feedback_loop override移到early return前(原当天无交易时直接return不更新override)
5. 期权13笔从trade_records/signal_lifecycle/trade_attribution/voting_predictions清理
6. feedback_loop重新生成override用干净数据: 2个override(LONG+PRE_CLOSE_EXIT n=26 wr=27% + SHORT+STRUCTURE_EXIT n=33 wr=30%)
**架构师核心论点**: "反馈闭环在物理上存在(feedback_loop能跑), 但在逻辑上是断的(没有可归因的数据流过)." M1修复后, 从明天开始每笔新交易都带MFE/MAE+decision_id+因子快照. 4周后(~100笔)可做第一次有效归因分析.
**教训**: ①子代理报告是自述, 关键数据必须亲自验证(多头说TRAILING_STOP+$5,515实际是-$224). ②三方辩论收敛点: 亏损根因不是单一因素, 是"信号无edge(47%≈随机)+退出碎片化+无归因基础设施"三层叠加. ③"先跑1-2周积累数据"在当前数据管道下是错的——没有MFE/MAE, 积累的数据不可分析. 先修测量系统再跑.

### 60. ✅ strategy_type方向矛盾检查 — v0.34修复 (2026-07-09)
**位置**: `pipeline.py` Stage 3 (analysis注入strategy_type处)
**问题**: scanner的`_bucketing`把ASML分到bearish桶(strategy_type=trend_short), 但LLM分析后输出BUY(LONG). pipeline直接注入scanner的strategy_type到analysis → ic_writer写入factors_json的strategy_type=trend_short, 但direction=LONG. FTSeek门禁读factors_json时strategy_type和direction矛盾.
**根因**: scanner分桶基于技术面(空头排列→trend_short), LLM判断基于全维度(基本面催化→BUY). 两者方向可以矛盾, 但strategy_type应该反映最终判断(LLM), 不是初始分桶(scanner).
**修复**: 注入strategy_type时检查LLM方向和scanner分桶的一致性:
- scanner=trend_short/avoid 但 LLM=BUY → strategy_type降级为watch, position_size_hint=small, bucket_reason标注矛盾
- scanner=quality_breakout/oversold_bounce 但 LLM=SELL_SHORT → 同上
- 方向一致 → 保持scanner的strategy_type
**验证**: ASML修复后strategy_type=watch(非trend_short), direction=LONG, 矛盾在bucket_reason中标注
**教训**: 两个阶段(scanner分桶 vs LLM分析)的方向判断可能矛盾, 注入下游字段时必须做一致性检查. 不能盲目传递上游的标签.

### 59. ✅ 空跑管线止血 + Obsidian闭环 + claim_ic兼容 — v0.34实施 (2026-07-09)
**止血 (3项)**:
1. **ORB engine停用**: `config/unified_config.yaml` `orb.enabled: false`. ORB daemon 6/22后16天无交易, PnL=-$1002, daemon线程空跑占CPU. 重启后日志确认ORB引擎已停止.
2. **PLAYBOOK_SHADOW cron停用**: crontab注释掉`shadow_eod_replay.py`. 23笔shadow仓位全是6/22-6/23的, 15天无新仓位, cron每日16:30空跑.
3. **SCALPING/ORB/SHADOW历史数据排除**: `feedback_loop.py`的SQL加`AND source_type NOT IN ('SCALPING','ORB_ENGINE','PLAYBOOK_SHADOW')`. 这些已废弃策略的历史交易不再污染strategy_memory的pattern学习和exit_param_override的亏损pattern检测.

**闭环 (2项)**:
4. **Obsidian symbol page读回注入LLM prompt**: `deep_analyzer.py`新增`_get_obsidian_history()`方法. 分析某标的前读该标的的Obsidian md文件, 提取上次分析的日期/方向/verdict/核心论据, 注入`_get_trade_experience()`返回的文本. LLM现在能看到"上次分析(7/9): BUY, verdict=ANET营收+30.6%..., 核心论据=KeyBanc上调目标价$200", 实现分析→记录→下次分析读回的闭环. 只匹配`## YYYY-MM-DD`格式的section(不匹配`## 同行业`等非日期section). verdict从`>`引用块提取(不是`verdict:`字段).
5. **alpha_backfill + ic_writer兼容新factors_json格式**: factors_json从纯claim列表升级为`{"claims":[...], "strategy_type":"...", "conditions":[...], ...}`结构化dict后, alpha_backfill.py和ic_writer.py的`get_ic_summary`都需要`if isinstance(factors, dict) and "claims" in factors: factors = factors["claims"]`解包. 不修则claim IC统计全部返回0(无法解析新格式).

**验证**: 13/13 ad-hoc验证通过(语法4+ORB disabled+cron off+feedback_loop排除3个source_type+Obsidian读回含日期/verdict+alpha_backfill/ic_writer dict兼容+FTSeek active+无ORB日志).
**当前**: Obsidian symbol pages(51个)只写不读. deep_analysis分析某标的前不看该标的历史页面(上次bull/bear_case, 上次verdict, 上次交易计划是否成功).
**断点1**: Obsidian只写不读 → deep_analyzer._get_trade_experience()从trade_records读, 但不从Obsidian读上次分析结论
**断点2**: claim_ic_cache overall_ic_t1=0.0062(253样本) → 论据强度与后续收益几乎无相关性, 不是缺数据是论据质量问题
**断点3**: deep_analysis单模型(qwen3.7-max)无交叉验证, voting有3模型交叉
**建议**: deep_analyzer._get_trade_experience()加几行读Obsidian md文件提取上次分析结果注入prompt; IC近0的根因是claim_type分类不准(关键词+LLM标注混用)

### 56. ✅ 回撤止损替代步进trailing + SL距离数据驱动调优 + 仓位缩小增加笔数 — v0.33 (2026-07-09)
**位置**: `app/playbook/pipeline.py` `_compute_dynamic_effective_sl()` + `config/playbook_horizon.yaml` + `config/unified_config.yaml`
**背景**: 用户问"止损策略如何更好配置" + "前期降低单股qty增加交易笔数验证方向".
**数据发现1 — MFE中位数=1.5%**: 33笔盈利交易MFE分布: <1%=10笔, 1-2%=10笔, 2-3%=8笔. trailing_step=2.0%但MFE中位数1.5%→**步进trailing永远触发不了**(step触发需MFE≥breakeven+step=3%).
**数据发现2 — SL距离vs胜率**: <2%=WR47%+SL触发率41%(太紧); **2-3%=WR59%最优**; >5%=WR14%(太松).
**数据发现3 — TIME_EXIT giveback 83-93%**: GOOG SHORT MFE=2.0%→actual=0.3%(giveback=86%). 峰值后有回撤但trailing没触发→浮盈全回→time_exit砍在近零.
**修复1 — 回撤止损(drawdown_from_peak_pct)**: 新逻辑`SL=peak×(1-drawdown%)`. 趋势类0.7%, 基本面类0.6%, default 0.8%. 兼容回退(无配置走原步进). 回测+7.3%利润(7改善/40持平/1变差). **关键属性: 价格一路涨到EOD时不触发(SL跟peak但current>SL), 只在峰值后回撤时锁定利润.**
**修复2 — SL区间收紧**: low floor 1.5→2.0%, high ceil 8.0→5.0%, extreme ceil 6.0→5.0%, long.high ceil 8.5→5.0%. 全部SL落在2-5%区间(WR最优区).
**修复3 — 仓位max_position_pct 8%→4%**: 日notional cap=$19.8K, 8%→每仓$6.5K→3笔/天; 4%→每仓$3.3K→**6笔/天(翻倍)**. risk_pct 1.0→0.5%. 前期重验证不重单笔利润.
**验证**: 5场景单元测试(回撤SL计算)+历史回测+配置加载确认+FTSeek重启bridge加载正常.
> 详见 ftseek-playbook-shadow-system `references/drawdown-stoploss-and-position-sizing-20260709.md`

### 55. ✅ 退出规则审计 — SL_ATR_STOP=方向错非SL太紧 + rr_ratio=999无TP + EOD最佳 — v0.32 (2026-07-09)
**位置**: `config/playbook_horizon.yaml` + `app/playbook/instruction_generator.py` `_compute_volatility_based_sl_tp()`
**背景**: 用户问"当前的止损止盈退出规则是否合理". 用真实DB数据+配置值+代码路径完整审计.
**ATR止损参数(实际配置)**:
| 桶 | atr_pct范围 | SL倍数 | SL下限% | SL上限% | TP倍数 | SHORT加宽 |
|---|---|---|---|---|---|---|
| low | <1.5% | 1.2× | 1.5 | 2.5 | 2.0× | +0.2pp |
| medium | 1.5-3.5% | 1.5× | 2.5 | 4.5 | 1.8× | +0.3pp |
| high | 3.5-8% | 1.5× | 3.5 | 8.0 | 1.5× | +0.5pp |
| extreme | >8% | 1.2× | 3.5 | 6.0 | 1.5× | +0.8pp |
**SL_ATR_STOP 7笔实际数据**(近30天,全亏-$2,847):
| symbol | dir | entry | exit | SL距离 | PnL | 持仓 |
|---|---|---|---|---|---|---|
| ORCL | LONG | $165 | $160 | 3.3% | -$976 | 0.0h |
| XOM | LONG | $140 | $136 | 2.8% | -$823 | 0.0h |
| LMT | LONG | $504 | $493 | 2.0% | -$601 | 0.1h |
| NTES | LONG | $122 | $119 | 2.0% | -$114 | 0.0h |
| PDD | LONG | $78 | $77 | 2.0% | -$114 | 0.3h |
| MSFT | SHORT | $367 | $375 | 2.0% | -$110 | 0.1h |
| AVGO | LONG | $392 | $384 | 2.0% | -$110 | 0.0h |
**关键发现**: 7笔中6笔持仓≤0.1h(6分钟), 6笔在6/24大跌日. **根因=方向判断错误(大跌日开LONG), 不是SL太紧.** SL参数已7/8调宽(0.7→1.5×ATR).
**EOD_FORCE_CLOSE 14笔**: 86%WR, avg+$128/笔, 持仓7-18h. 最佳退出方式.
**rr_ratio=999(无TP)**: short_horizon移除TP, 让EOD捕获利润. 数据支持(EOD 86%WR avg+$203). 但风险: 盘中大涨后回落会损失利润.
**退出规则优先级**: SL_FIXED_PCT > PRE_CLOSE_EXIT > TIME_EXIT(盘中) + EOD_FORCE_CLOSE/MAX_HOLD_T5(盘后)
**time_exit_hours**: default=4h(仅亏损触发), 看跌类0.5-1h, 趋势类6-8h
**breakeven_at_pct**: default=1.5%, 趋势类0.5-1.0%
**trailing**: 趋势类开启(step 1.5-2%), 波动/看跌类关闭
**结论**: 退出参数合理. 最大改进空间不在SL/TP调参, 在信号质量(用deep_analysis替代VotingCoordinator).
**审计命令**: `sqlite3 data/ftseek_us.db "SELECT symbol,direction,entry_price,exit_price,realized_pnl,holding_hours,exit_reason FROM trade_records WHERE exit_reason='SL_ATR_STOP' AND exit_time >= date('now','-30 days')"`
> 详见 `references/bridge-priority-exit-rules-audit-20260709.md`（bridge排序优先级修复+预算机制完整流程+auto_execute检查链+7/8日志实证+ATR止损7笔详情+退出规则配置值+结论）

### 50. ✅ 多渠道扫描+四信号评分+板块叙事+操作分桶 — v0.23实施
**位置**: `scripts/data_collector.py` + `scripts/market_scanner.py`
**背景**: agent-debate辩论(DEB-20260708)收敛后, 实施方案D+的Phase 1 — 扩大候选池+四信号评分, 只改skill脚本不碰FTSeek运行时。
**data_collector.py新增3个collect函数**:
- `collect_earnings_surprise()`: Finnhub /calendar/earnings, 取今日+昨日财报, 计算EPS超预期%
- `collect_insider_movers()`: 占位(Finnhub免费版无全市场insider API, 返回空)
- `collect_after_hours_movers()`: 复用富途get_stock_filter
**market_scanner.py新增6个方法**:
- `_collect_multi_channel()`: 6渠道(涨幅榜+跌幅榜+量榜+财报超预期+内部人异动+夜盘)合并去重, 记录渠道命中
- `_quality_gate()`: 市值>$2B + 价格>$5 + 非杠杆ETF过滤(对标参考报告252→137)
- `_four_signal_score()`: 替代旧_quick_score. 四维度0-10: catalyst(渠道命中+财报超预期) + momentum(MA/动量/量比) + sentiment(bid_ask/vol_ratio代理) + value(PE/52周位置). 含featured override(momentum≥8)和value trap检测(PE低但5日跌>10%→降分)
- `_collect_sector_data()`: 11个SPDR板块ETF涨跌排名 + 个股sector映射(Finnhub company_profile.industry)
- `_sector_narrative()`: 5要素叙事——方向定调+涨跌极值+板块轮动叙事+资金切换+量能特征
- `_bucketing()`: 4桶——quality_breakout/oversold_bounce/trend_short/avoid/watch, 每桶带strategy_type+position_size_hint
**scan()方法重写**: 从3渠道→6渠道, 从单维度评分→四信号评分, 从简单分类→操作分桶, 从无板块→板块轮动叙事
**format_scan_result()更新**: 输出含板块轮动+渠道质量+四信号分数(M/V/C/S)+操作分桶+strategy_type+position_size_hint
**验证**: 32/32 ad-hoc验证通过(导入+3个collect函数存在性+6个方法存在性+_quality_gate正确过滤ETF/低价/低市值+_bucketing正确分5桶+端到端scan真实API调用: 12只候选, 5/6渠道green, signal_scores四键完整, sector_rotation非空)
**辩论收敛体现**: 0行FTSeek运行时改动(冻结期安全) + 0个新接口/bridge文件(复用signal_snapshots) + 0次新LLM调用(扫描层纯规则) + 不删voting(门禁627保留, NEUTRAL fallback是Phase 2冻结期后的事)

### 33. ✅ 3股全链路模拟验证发现12个跨阶段优化点 — v0.20
**方法**: 用MU/CVNA/MRVL三只股票实跑 `pipeline.py --mode analyze --synth llm` 全链路(扫描→采集→LLM分析→IC写入→门禁), 逐阶段检查输出, 发现12个跨阶段问题。

**发现的12个问题**:
| # | 阶段 | 问题 | 严重度 | 状态 |
|---|------|------|--------|------|
| 1 | S1→S5 | scanner做空MRVL(空头排列+5日-12.8%)但LLM输出BUY——方向冲突无人检测 | P1 | 待修 |
| 2 | S2 | PE(TTM)=0/EPS=0三只都出现, OpenD快照API系统性异常 | P2 | 待修 |
| 3 | S2 | 52周高低=0三只都出现, LLM静默用K线推导替代而非上报降级 | P2 | 待修 |
| 4 | S1→S3 | MRVL scanner做空Top3→LLM BUY, 技术面破位vs基本面催化判断分歧 | P1 | 待修 |
| 5 | S3 | MRVL盈亏比1.14极差但LLM仍给BUY+7分——prompt无盈亏比下限约束 | P1 | 待修 |
| 6 | S3 | MU财报日2026-06-24已过期但系统仍标注"距今-11天"——过期数据未清洗 | P2 | 待修 |
| 7 | S3 | 三只LLM论据溯源验证率<50%(MU 48%/CVNA 45%/MRVL 45%), 研报数字从新闻标题摘取 | P1 | 待修 |
| 8 | S4 | MU direction=SKIP→ic_writer写NEUTRAL, FTSeek backfill对NEUTRAL是否算IC未确认 | P2 | 待确认 |
| 9 | S4 | CVNA 2个valuation_expensive重复claim_type, ic_writer不去重 | P2 | 待修 |
| 10 | S5 | 三只都匹配到全市场通用pattern(LONG+SL_ATR_STOP), 非个股特定——pattern匹配无symbol过滤 | P1 | 待修 |
| 11 | S5 | 三只都推荐EOD_FORCE_CLOSE(全市场通用), 未考虑个股波动率(Beta) | P2 | 待修 |
| 12 | S5 | MU pattern_match=null但CVNA/MRVL有值, SKIP direction的pattern匹配分支逻辑不一致 | P2 | 待确认 |

**关键发现**: scanner和LLM方向冲突(MRVL: scanner做空→LLM BUY)是P1级新问题——signal_gate没有检查scanner_direction和llm_direction的一致性。这个冲突在7/2半导体血洗场景下特别危险: scanner看到空头排列+5日-12.8%给出做空信号, 但LLM看到瑞银上调目标价+营收+34%就翻多。两个视角都有道理但需要在Gate中标注冲突让用户知晓。

**pattern匹配非个股特定**: 三只从未交易过的股票(CVNA/MRVL无历史记录)都能匹配到LONG+ORB_TAKE_PROFIT和LONG+SL_ATR_STOP——这些是全市场通用的pattern, 对个股没有参考价值。pattern_memory的查询逻辑是direction+exit_reason+strength_bucket, 没有按symbol过滤。应该: 有个股历史时用个股pattern, 无历史时明确标注"无个股特定pattern, 使用全市场参考(置信度very_low)"。

> 详见 `references/full-pipeline-simulation-20260705.md`（3股全链路实跑数据+5阶段逐阶段输出+12个优化点详细分析+修复建议）

### 34. ✅ scanner方向冲突无人检测 — v0.20修复
位置: signal_gate.py + pipeline.py。问题: scanner做空Top3的MRVL,到LLM分析却输出BUY——方向完全冲突但无人检测。signal_gate只看LLM输出,不读scanner方向。修复: ①pipeline.run_full把candidate的scanner方向(bullish/bearish)注入`analysis["_scanner_direction"]` ②signal_gate加Stage 0: scanner方向冲突检测,scanner=bearish但LLM=BUY→-10分。验证: MRVL 60→50 WARN,reasons含"方向冲突: scanner=bearish但LLM=BUY"。教训: 两个阶段的方向判断必须交叉验证,不能各管各的。

### 35. ✅ pattern匹配全市场通用不标注来源 — v0.20修复
位置: signal_gate.py。问题: 三只股票(MU/CVNA/MRVL)都匹配到同样的pattern——LONG+ORB_TAKE_PROFIT(2笔)和LONG+SL_ATR_STOP(12笔)。这是全市场通用pattern,不是个股特定的。一只从未交易过的股票也能匹配到"LONG+SL_ATR_STOP"——这个pattern对它没有参考价值。修复: Gate在pattern匹配reasons里标注来源("个股" vs "全市场"),当个股无历史记录时标注"全市场"。不改逻辑只改标注——让用户和Gate知道pattern参考价值。教训: 全市场pattern对个股的参考价值是有限的,必须标注来源让决策者知道。

### 36. ✅ 财报日历过期日期fallback — v0.20修复
位置: data_collector.py:397-409。问题: collect_earnings_calendar在无未来财报日期时fallback到`cal[-1]`(最后一条,可能已过期)。MU返回next_earnings=2026-06-24,系统标注"距今-11天(已过期)",LLM注意到异常但仍作为约束列出。修复: 不再用cal[-1]过期数据,改为返回None+`_quality=degraded`+`_degraded_reason`。验证: MU next_earnings=None, quality=degraded。教训: 数据源不应把过期数据当有效数据传给LLM——应该标记降级让LLM知道不可用。

### 37. ✅ claim_type重复不去重 — v0.20修复
位置: ic_writer.py:147-170。问题: CVNA有2个valuation_expensive(bear_case的看空②和看空③被LLM标了同样的claim_type)。ic_writer的_extract_claim_factors不做去重——同一claim_type出现多次会扭曲IC统计权重。修复: 加`seen_claim_types`集合,同side下同一claim_type只保留第一条。验证: 2个valuation_expensive→1个。教训: IC统计的factors列表应该是一组不重复的论据类型,重复论据不应多次计数。

### 38. ✅ deep_analysis方向门禁(BUY+SELL_SHORT)接入FTSeek — v0.21实施, v0.21.2扩展
**位置**: `/opt/ftseek/FTSeek-US/app/playbook/pipeline.py` `_build_instructions_from_votes()`
**v0.21.2扩展**: 从只过滤BUY扩展到BUY+SELL_SHORT. 用户指出: "deep_analysis输出的标的结果和策略方向能否替代voting, 本身都有LLM的分析". 正确方案不是模板检测(形式), 是用deep_analysis的内容质量验证voting_llm的形式共识.
**门禁逻辑**: voting输出BUY→查deep是否=LONG; voting输出SELL_SHORT→查deep是否=SHORT. 方向冲突→SKIP. 无deep→放行. 查询失败→放行.
**设计理由**: 这是两个独立信息源的交叉验证, 不是补丁. voting_llm是3模型consensus(广度), deep_analysis是1模型16源采集(深度). 两者方向一致=高置信, 冲突=不赌.
**验证**: NVDA(deep=LONG,voting=BUY)→PASS. MU(deep=NEUTRAL,voting=BUY)→BLOCKED. TSLA(无deep)→ALLOWED.

### 47. ✅ Obsidian per-symbol 深度分析归档 — v0.22实施

> **v0.50 新增参考文档**:
> - `references/dual-brain-ic-conflict-20260710.md` — 双脑IC冲突根因(双重方向调整+Pearson极端值绑架)与A+B+C修复方案
> - `references/bridge-not-pushed-cron-skip-20260710.md` — bridge-generation cron job跳过7/10的根因分析
**位置**: `/opt/ftseek/FTSeek-US/app/core/obsidian_writer.py` 新增 `write_symbol_analysis()` 方法 + `scripts/pipeline.py` 两个调用点
**问题**: deep_analysis的bull_case/bear_case/verdict/execution_plan写入signal_snapshots.factors_json(机器格式),从不以人类可读格式归档。每次分析是一次性的,形不成US.AAPL的连续演进史。
**修复**: 扩展现有ObsidianWriter(已有59个trade/daily md文件),加`write_symbol_analysis(analysis)`方法:
- 创建`symbols/US.XXX.md`(不存在时), 追加`## 日期 | 评级 | 信心 | 方向` section
- section含: 结论/看多论据(带强度+来源)/看空论据/交易计划(入场/止损/止盈/支撑阻力)/风险/因果链
- frontmatter同步刷新: latest_direction/score/rating + 从strategy_memory.db读total_trades/win_rate
- 幂等: decision_id作为HTML注释锚点`<!-- id:xxx -->`,同id不重复追加
- best-effort: 全try/except, 失败只log warning不阻塞pipeline
**调用点**: pipeline.py的`run_full()`和`run_analyze_only()`中,在`ic_writer.write_signal_snapshot()`后各加6行
**验证**: US.AAPL实跑产出 obsidian_vault/symbols/US_AAPL.md(2861字节), 含3条看多+3条看空+交易计划+因果链+frontmatter战绩(total_trades=3/win_rate=1.0)
**教训**: 用户指出"最核心的是deep_analysis每支标的深度解读+战绩+结果沉淀"。系统已有ObsidianWriter(2026-05-04创建)但只写trade/daily,缺per-symbol深度分析归档。扩展已有基础设施比新建系统短。
**发现过程**: agent-debate R1错误声称"系统无Obsidian集成",Claude Code R1 grep纠正发现ObsidianWriter已存在。教训: 提议新功能前必须grep现有代码。

**Gap 1/3/4 扩展 (v0.22后续)**:
- **Gap 1 (历史回填)**: `scripts/backfill_symbol_pages.py` 从signal_snapshots.db读历史deep_analysis信号(54条),灌入43个symbol pages。兼容旧格式(字符串数组factors_json)和新格式(对象数组)。每条section含IC验证结果(fwd_ret_t1/alpha_t1)。幂等: 已存在的decision_id跳过。
- **Gap 3 (wikilinks)**: frontmatter新增industry字段。`_find_industry_peers()`扫描symbols/目录按industry匹配生成`[[US_MSFT]]` wikilink。AAPL→MSFT(Technology),随重新分析wikilinks逐步建立全网。
- **Gap 4 (IC标注)**: 每条论据后附`[IC=+0.56✅n=9]`标注(从claim_ic_cache.json读取)。section底部新增"论据IC验证"段: overall IC + effective/ineffective claims列表。SHEL页面可看到product_catalyst IC=+0.56✅, insider_bearish IC=+0.42✅。
- **新增helper方法**: `_load_claim_ic()` `_claim_ic_tag()` `_build_ic_summary()` `_find_industry_peers()` (全在ObsidianWriter内)
- **pipeline.py调用**: 两个调用点(run_full batch + run_analyze_only), 在`ic_writer.write_signal_snapshot()`后各加6行best-effort调用

### 46. ✅ sl_multiplier根因修复: 0.7×ATR→1.5×ATR — v0.21.2实施
**位置**: `/opt/ftseek/FTSeek-US/config/playbook_horizon.yaml` vol_buckets (short_horizon + long_horizon)
**问题**: sl_multiplier=0.7(medium)/0.6(high) 导致 SL=0.7×ATR% — 止损在1个ATR以内=统计噪声, 正常日内波动必触发.
**公式**: `sl_pct = max(sl_floor, min(sl_ceil, atr_pct × 100 × sl_multiplier))`
**7/7实证**(全部走VOL_medium/VOL_high路径, 非fallback):
| 股票 | ATR% | 旧SL% | 旧SL/ATR | 新SL% | 新SL/ATR |
|---|---|---|---|---|---|
| BA | 2.79% | 1.95% | 0.70× | 4.19% | 1.5× |
| AMZN | 3.45% | 2.42% | 0.70× | 4.50% | 1.3× |
| NVDA | 3.27% | 2.29% | 0.70× | 4.80% | 1.5× |
| TSLA | 4.76% | 3.36% | 0.71× | 7.64% | 1.6× |
| PLTR | 5.10% | 3.56% | 0.70× | 8.15% | 1.6× |
**修复**: sl_multiplier: low 0.8→1.2, medium 0.7→1.5, high 0.6→1.5, extreme 0.5→1.2. sl_ceil同步提高(medium 2.8→4.5, high 5.0→8.0), 否则min()截断使multiplier失效.
**用户纠正**: "统一的值对于波动不同股票无意义". vol_buckets已经是分桶的(按ATR%), 但sl_multiplier太小导致所有桶的SL都在1个ATR以内. 根因不是fallback值, 是multiplier.
**Karpathy教训**: 【防加法思维】改config前先trace active code path. buy_fixed_stop_loss_pct只在vol_buckets返回None时触发=ATR数据缺失时. 7/7所有交易ATR完整→全部走vol_buckets→改fallback值=改了个没用的参数. 应该改的是active路径上的sl_multiplier.

### 38. ✅ deep_analysis LONG门禁已接入FTSeek执行路径 — v0.21实施
**位置**: `/opt/ftseek/FTSeek-US/app/playbook/pipeline.py` `_build_instructions_from_votes()` 函数 (BUY方向过滤链末尾, MACD/MA50审计前)
**改动**: BUY方向生成instruction前, 查signal_snapshots.db当日deep_analysis对该股的判断:
- deep=LONG → ✅ 放行 (有背书)
- deep=NEUTRAL/SHORT → ❌ SKIP (deep_analysis不认同)
- 无deep_analysis记录 → ✅ 放行 (不阻断, 避免deep宕机时全部SKIP)
- 查询失败 → ✅ 放行 (只警告不阻断)
**数据依据**: voting_llm LONG IC=-0.0674(负预测), 169笔LONG 29.6%WR -$5,865. deep_analysis LONG IC=+0.6242(n=11, 90.9%WR).
**设计决策**:
- 用deep_analysis的正IC过滤voting_llm的负IC, 不需要deep_analysis生成instruction
- 无背书时放行而非SKIP — 避免deep_analysis cron宕机时所有BUY被阻断 (故障隔离原则)
- filter_audit增加3个计数器: buy_no_deep_endorsement / buy_no_deep_analysis / buy_deep_query_error
**验证**: NVDA(7/2 deep=LONG)→PASS, MU(7/2 deep=NEUTRAL)→BLOCKED, TSLA(7/7 无记录)→ALLOWED
**这是deep_analysis第一次影响FTSeek执行路径** — 之前deep_analysis只写IC不参与交易决策

### 38.5 ✅ playbook_horizon.yaml 退出参数调优 — v0.21实施, v0.21.2修正
**IC=0.62 质量警告 (2026-07-09审计)**: pipeline.py:759引用的`deep_analysis IC=+0.6242 (n=11, 90.9%WR)`是**forward return IC**(Spearman rank correlation between strength和T+1 alpha return), **不是trade IC**(含滑点/止损/gap). n=11统计显著性极低(无p-value计算). 代码全局搜索`decay/half_life/signal_age`在`app/playbook/`下零匹配——IC是静态值,不随信号年龄衰减. 用n=11的forward return IC作为方向门禁决策依据有小样本偏差风险. trade IC(含实际交易摩擦)很可能远低于0.62. 详见 ftseek-troubleshooting-playbook `references/signal-strategy-deep-audit-20260709.md` Issue #2.
**v0.21.2修正(Karpathy+Ponytail自审)**:
- ❌ 撤销 `buy_fixed_stop_loss_pct: 2.5→3.0` — 这是ATR数据缺失时的fallback路径, 7/7全部6笔交易都走vol_buckets(src=VOL_medium/VOL_high), 没一笔走fallback. 改了没用的参数.
- ✅ 保留 `default.time_exit_hours: 2.0→4.0` — 2-4h死亡区间-$10,229 vs 4-8h黄金时段+$14,573
- ✅ 保留 `default.breakeven_at_pct: 0.5→1.5` — 0.5%太早触发保本
- ✅ 新增根因修复: sl_multiplier 0.7/0.6/0.5→1.5/1.5/1.2 + sl_ceil同步提高 (见pitfall #46)
**教训**: 改config前必须trace实际code path确认参数在active路径上. buy_fixed_stop_loss_pct只在`_compute_volatility_based_sl_tp()`返回None时触发, 但7/7所有交易ATR数据完整→全部走vol_buckets→fallback值无关.
**验证**: YAML解析✅ + PlaybookConfig加载✅ + FTSeek重启后运行系统验证✅

### 41. ✅ FTSeek多DB地图 — 数据查询路径 (v0.21发现, v0.29验证更新)
**关键gotcha**: trade_records.db(独立文件)是空的——真实交易记录在ftseek_us.db里。query时必须查ftseek_us.db不能用trade_records.db。

**v0.29验证更新**: 根目录`/opt/ftseek/FTSeek-US/ftseek_us.db`(4KB空壳,无表)和`ftseek.db`/`ftseek_us_live.db`/`signals.db`/`signal_snapshots.db`(全0字节)都是空文件。真实数据全在`data/`子目录下。首次查询必须先`.tables`验证非空。

| DB路径 | 大小 | 用途 | 关键表 |
|--------|------|------|--------|
| **data/ftseek_us.db** | 8.2M | **主库**: 交易+持仓+信号+退出 | trade_records(403行), open_positions, signals, signal_lifecycle, failures, shadow_trades, order_tracking, performance_stats |
| **data/signal_snapshots.db** | 1.7M | IC+前向收益 | signal_snapshots(1500行), regime_history |
| **data/decisions.db** | 1.9M | 投票决策+模型票 | decisions(1425行30天), model_votes, trade_outcomes |
| data/rejections.db | 980K | 信号拒绝记录 | rejections |
| data/strategy_memory.db | — | 策略记忆库 | pattern_memory, symbol_memory, lesson_log |
| ftseek_us.db (根目录) | 4K | **空壳!** 无表 | — |
| ftseek.db / ftseek_us_live.db / signals.db (根目录) | 0 | 空文件 | — |
| data/trade_records.db | — | 空表(已废弃) | trade_records(0行) |

**failures表gotcha**: 列名是`timestamp`不是`created_at` — 查`created_at`会报`no such column`错误。

> 交易表现分析方法论+SQL模板——详见 `references/trade-performance-analysis-20260709.md`

### 42. ✅ 04:xx模板投票检测: LLM返回200但strength是模板值 — v0.21实施
**位置**: `/opt/ftseek/FTSeek-US/app/agents/voting/voting_coordinator.py` 新增 `_detect_template_votes()` 方法
**问题**: 7/7 04:xx批次deepseek_v4_pro对38只不同行业市值股票全投37/47(std=5.06, unique=2)。LLM API返回200+reasoning文本(内容是股票特定的事实分析),但strength值高度重复=DashScope模板/缓存行为。这种"隐性降级"不会被degraded_vote捕获(没有timeout/error),污染consensus和IC。
**数据对比**(7/7 04:xx批次decisions.db实算):
- deepseek_v4_pro: 38票, 2个unique值(37/47), std=5.06 → 模板
- glm_5_2: 38票, 11个unique值, std=7.5 → 正常
- qwen3.7_max: 38票, 5个unique值, std=10.5 → 正常
**修复**: VotingCoordinator.__init__加`_batch_strength_history` dict跟踪每个模型最近10次strength。`_detect_template_votes()`在aggregate前检查: 历史≥5条且(std<6 OR unique_values≤2) → 标记degraded_vote=True。被标记的票: 权重降至30%+不参与consensus计算(复用已有degraded_vote处理逻辑)。
**阈值依据**: std<6 catches deepseek(5.06) not glm(7.5)/qwen(10.5); unique≤2 catches any model with only 2 distinct values across many stocks.
**验证**: 5场景全过 — 模板[37,47]✅, 正常方差[30,45,55,72,35]✅, 全同值[50,50,50,50,50]✅, 低方差[40,42,41,40,42]✅, 已降级跳过✅
**教训**: LLM"隐性降级"(API 200+reasoning但strength是模板值)比显性降级(timeout/error)更危险——它通过了所有现有degraded检测但产出的是垃圾信号。批次级方差检测是唯一能发现它的方法,因为单看一只股票的37/47是合法的,但38只股票全是37/47就是模板。

### 43. ✅ backfill cron路径缺失cd前缀 — 从未运行 — v0.21发现+修复
**位置**: crontab
**问题**: backfill cron行`30 5 * * 2-6 /opt/ftseek/FTSeek-US/venv/bin/python scripts/backfill_forward_returns.py >> logs/backfill.log 2>&1`缺少`cd /opt/ftseek/FTSeek-US &&`前缀。cron默认cwd=/root,所以`scripts/backfill_forward_returns.py`解析为`/root/scripts/...`=不存在。log文件`logs/backfill.log`也从未创建。**backfill cron自创建以来从未运行**——T5/T20 IC回填静默断裂。
**检测**: `ls /opt/ftseek/FTSeek-US/logs/backfill*`=不存在 → cron从未执行。
**修复**: 加`cd /opt/ftseek/FTSeek-US &&`前缀 + `python`→`python3.11`(venv默认python=3.8)。手动跑回填1401条, T5从344→467(64.8%)。
**Meta-pattern**: 每个使用相对路径(scripts/..., logs/...)的cron行MUST有`cd /project/dir &&`前缀。审计: `crontab -l | grep -v '^#' | grep -v 'cd '` — 有相对路径但无cd前缀的都是broken。

### 49. ✅ 数据真实性验证方法 — "这种扫描和分析是真实的吗？不要虚构" — v0.23教训
**用户原话**: "这种扫描和分析是真实的吗？不要虚构"
**背景**: 用户在看到扫描输出(39只候选, 四信号评分, 板块轮动)和深度分析(ANET bull_case/bear_case)后, 质疑数据是否虚构。
**验证方法 (逐源验证 + LLM输入→输出对照)**:
1. **逐源API验证**: 对每个数据源直接调API, 打印返回值:
   - 富途OpenD: `collect_top_gainers('US',3)` → 返回BABA/XIACY/NBIS (真实)
   - Finnhub基本面: `collect_fundamentals('US.ANET')` → revenue_growth=30.57, roe=30.58 (真实)
   - Finnhub分析师: `collect_analyst_consensus('US.ANET')` → 34位分析师, 94.1%买入 (真实)
   - DashScope LLM: API返回"OK"测试 → qwen3.7-max真实可达 (真实)
2. **LLM输入→输出对照**: 对比LLM收到的数据 vs LLM输出的论据:
   - 输入revenue_growth=30.57 → 输出"营收+30.57%" ✅
   - 输入roe_ttm=30.58 → 输出"ROE 30.58%" ✅
   - 输入avg_mspr=-46.08 → 输出"MSPR -46.08" ✅
   - 每个论据数字都能追溯到API输入, 无编造
3. **休市时段局限性**: 休市运行时change_rate=0(正常, 非假数据), K线和快照是上一交易日收盘数据(真实但非实时), Finnhub基本面/分析师是最近报告期(真实, 非实时)。盘中运行时change_rate/volume/last_price是实时值。
**教训**: 呈现skill输出时, 不能只展示结果——必须展示数据来源链(API→数据→LLM推理), 让用户能验证每个数字的出处。LLM论据中的数字必须能追溯到API输入, 否则就是虚构。
**验证命令模板**:
```bash
cd ~/.hermes/skills/deep-stock-analysis/scripts
# 逐源验证
/opt/ftseek/FTSeek-US/venv/bin/python3.11 -c "import data_collector as dc; r=dc.collect_fundamentals('US.ANET'); print(f'revenue_growth={r.get(\"revenue_growth_yoy\")}')"
# LLM输入→输出对照
grep -E '(30.57|38.32|94.1|MSPR.*-46|179.80)' /opt/ftseek/FTSeek-US/obsidian_vault/symbols/US_ANET.md
```

### 48. ✅ 多渠道扫描+四信号评分+板块叙事+操作分桶 — v0.23实施
**位置**: `scripts/data_collector.py` + `scripts/market_scanner.py`
**背景**: agent-debate辩论(DEB-20260708)收敛后, 实施方案D+的Phase 1 — 扩大候选池+四信号评分, 只改skill脚本不碰FTSeek运行时。
**data_collector.py新增3个collect函数**:
- `collect_earnings_surprise()`: Finnhub /calendar/earnings, 取今日+昨日财报, 计算EPS超预期%
- `collect_insider_movers()`: 占位(Finnhub免费版无全市场insider API, 返回空)
- `collect_after_hours_movers()`: 复用富途get_stock_filter
**market_scanner.py新增6个方法**:
- `_collect_multi_channel()`: 6渠道(涨幅榜+跌幅榜+量榜+财报超预期+内部人异动+夜盘)合并去重, 记录渠道命中
- `_quality_gate()`: 市值>$2B + 价格>$5 + 非杠杆ETF过滤(对标参考报告252→137)
- `_four_signal_score()`: 替代旧_quick_score. 四维度0-10: catalyst(渠道命中+财报超预期) + momentum(MA/动量/量比) + sentiment(bid_ask/vol_ratio代理) + value(PE/52周位置). 含featured override(momentum≥8)和value trap检测(PE低但5日跌>10%→降分)
- `_collect_sector_data()`: 11个SPDR板块ETF涨跌排名 + 个股sector映射(Finnhub company_profile.industry)
- `_sector_narrative()`: 5要素叙事——方向定调+涨跌极值+板块轮动叙事+资金切换+量能特征
- `_bucketing()`: 4桶——quality_breakout/oversold_bounce/trend_short/avoid/watch, 每桶带strategy_type+position_size_hint
**scan()方法重写**: 从3渠道→6渠道, 从单维度评分→四信号评分, 从简单分类→操作分桶, 从无板块→板块轮动叙事
**format_scan_result()更新**: 输出含板块轮动+渠道质量+四信号分数(M/V/C/S)+操作分桶+strategy_type+position_size_hint
**验证**: 32/32 ad-hoc验证通过(导入+3个collect函数存在性+6个方法存在性+_quality_gate正确过滤ETF/低价/低市值+_bucketing正确分5桶+端到端scan真实API调用: 12只候选, 5/6渠道green, signal_scores四键完整, sector_rotation非空). 详见 `references/market-scanner-gap-analysis-20260708.md` (5个差距+P0-P2优先级)
**辩论收敛体现**: 0行FTSeek运行时改动(冻结期安全) + 0个新接口/bridge文件(复用signal_snapshots) + 0次新LLM调用(扫描层纯规则) + 不删voting(门禁627保留, NEUTRAL fallback是Phase 2冻结期后的事)
