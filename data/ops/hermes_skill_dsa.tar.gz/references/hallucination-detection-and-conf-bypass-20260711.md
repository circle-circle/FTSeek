# LLM Hallucination Detection & Confidence Gate Bypass (2026-07-11)

## Hallucination Rate: 38% of Challenged Claims

From 3 bridge files (7/8-7/10), challenger examined 16 claims and flagged 6 as hallucination or selective bias (38%).

### Top Hallucination Pattern: Selective Peer Comparison (50%)

3 of 6 hallucinations were the analyst LLM **choosing its own peer set** to make valuation arguments:

| Symbol | Analyst Claim | Reality (caught by challenger) |
|--------|--------------|-------------------------------|
| NVDA | "PE 43x vs AMD 210x = discount" | AMD PE 210x is earnings trough, not normal anchor. AVGO 84x includes software premium. Selective peer selection. |
| COIN | "PE 35.7x vs peer avg 27.6x = premium" | Cherry-picked CBOE/NDAQ/ICE, omitted MSCI(38.5x) and MCO(35.6x) which are at same level. |
| TTE | "59.4% analysts say BUY" | Omitted 40.6% non-buy (hold=10, sell=3). UBS was *lowering* target price. |

**Root cause**: Peer list is LLM-generated, not data-provided. LLM can cherry-pick to support any narrative.

### Other Hallucination Types

| Symbol | Claim | Reality |
|--------|-------|---------|
| META | "散户社区讨论热度飙升" | 30 community posts, 0 mention META — **fabricated evidence** |
| WDFC | "内部人持续增持 MSPR=58.13" | 5 insider trades all shares=None, total=$0 — **data phantom** |
| META | "创2024年初以来最佳单周表现" | Price result ≠ causal catalyst — **circular reasoning** |

## Challenger Catches Them — But Doesn't Block

Current flow in `_merge_debate_results()` (llm_synth.py L745-825):

```
Challenger catches hallucination
  → confidence lowered from 70 to 25-35
  → signal still written to DB via save_instruction()
  → auto_execute still picks it up
  → trade executes with hallucination-based signal
  → loses money
```

**Data proof**: conf<40 trades (all DA- 2-model disagreement signals):
```
conf <40: 8 trades, 0 wins (0% WR), avg -$3.52
conf 70+: 88 trades, 10 wins (11% WR), avg +$4.53
```

Every single conf<40 trade lost money. The system executed them anyway.

## Confidence Gate Bypass Bug

`_build_instructions_from_votes()` in pipeline.py has a confidence gate at L1151:
```python
if confidence < _min_conf_for_dir:  # default BUY=70, SHORT=65
    → SKIP
```

But DA- candidates **never go through this function**. The skill's `_write_bridge_file()` calls `PlaybookDB.save_instruction()` directly, bypassing the entire pipeline filtering chain.

This means:
- Config `buy_min_confidence: 85` → would block 0/13 DA- BUY candidates IF they went through the gate
- But they bypass it entirely → confidence only affects sort order and position sizing
- `auto_execute` has NO confidence check (was removed at L2467 on 7/10)

## 5-Iteration Fix Plan (Ponytail: ~33 lines total)

### Iteration 1: confidence<40 hard block in auto_execute (5 lines, highest priority)

```python
# In run_playbook_auto_execute(), for loop, before trigger check:
_conf = int(inst.get("confidence", 0) or 0)
if _conf < 40:
    logger.info(f"[playbook] {inst['symbol']} confidence={_conf}<40, skip")
    skipped_count += 1
    continue
```

**Effect**: 8 conf<40 signals → 0 executed. Saves -$3.52/penalty per trade.

### Iteration 2: Hallucination → SKIP not lower confidence (8 lines)

In `_merge_debate_results()` (llm_synth.py):
```python
for cl in challenge.get("challenged_claims", []):
    w = (cl.get("weakness", "") + cl.get("counter_evidence", "")).lower()
    if any(kw in w for kw in ["编造", "与数据矛盾", "不存在", "无任何", "选择性偏差"]):
        initial["direction"] = "SKIP"
        initial["debate_outcome"] = f"❌ 幻觉拦截: {cl.get('original_thesis','')[:40]}"
        break
```

**Effect**: 6 hallucination-flagged signals → not written to DB. META/WDFC/COIN on 7/10 would be SKIP.

### Iteration 3: Force peer list in LLM prompt (10 lines)

Change prompt from "analyze NVDA valuation" to "analyze NVDA valuation. Peers=[AMD, AVGO, TXN, MRVL] (from sector classification)."

**Effect**: Eliminates 50% of hallucinations (3/6 were peer selection bias).

### Iteration 4: Claim IC enforcement (5 lines)

Expand `_load_claim_ic_for_prompt()`: for claim types with IC < -0.1, add "DISABLED: do not use" instead of just listing them.

**Effect**: LLM stops using historically disproven argument types.

### Iteration 5: Wire _verify_sourced_numbers() (5 lines)

`_verify_sourced_numbers()` already checks if LLM output numbers exist in input data. Currently writes to `result["_source_verification"]` but nobody reads it.

Wire it: if unverified numbers > 3 → lower confidence by 1 tier.

**Effect**: Numeric hallucinations auto-detected without relying on challenger.

## Existing Defenses (Already Implemented, Just Not Wired)

| Defense | Status | Location |
|---------|--------|----------|
| `_verify_sourced_numbers()` | ✅ Implemented, ❌ not consumed | llm_synth.py L828 |
| `_load_claim_ic_for_prompt()` | ✅ Implemented, ⚠️ only top3/bottom3 | llm_synth.py L568 |
| Challenger debate | ✅ Implemented, ❌ catch→lower conf not catch→SKIP | llm_synth.py L745 |
| Signal gate (BLOCK/WARN) | ✅ Implemented, ✅ wired to DB write | signal_gate.py |
| Confidence gate in pipeline | ✅ Implemented, ❌ bypassed by DA- direct DB write | pipeline.py L1151 |

**Core insight**: The hallucination problem is NOT a model capability issue. The defenses exist. They're just not wired together. 33 lines of code connects them.

## Audit Queries

```sql
-- Hallucination rate from bridge files
-- Run: python3 -c "
-- import json, glob
-- files = sorted(glob.glob('data/opportunity_scan_*.json'))[-3:]
-- for f in files: ...

-- Confidence vs outcome
SELECT
    CASE WHEN confidence < 40 THEN '<40'
         WHEN confidence < 60 THEN '40-59'
         WHEN confidence >= 70 THEN '70+' END as conf,
    COUNT(*), SUM(CASE WHEN outcome='win' THEN 1 ELSE 0 END) as wins,
    AVG(pnl) as avg_pnl
FROM playbook_instructions
WHERE date >= '2026-07-01' AND direction != 'SKIP'
GROUP BY conf;

-- Debate outcome vs result
SELECT
    CASE WHEN raw_instruction_json LIKE '%2模型一致%' THEN 'agree'
         WHEN raw_instruction_json LIKE '%方向分歧%' THEN 'disagree'
         ELSE 'no_debate' END as debate,
    direction, COUNT(*), AVG(pnl)
FROM playbook_instructions
WHERE direction != 'SKIP' AND date >= '2026-07-01'
GROUP BY debate, direction;
```
