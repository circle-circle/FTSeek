# FTSeek Integration — 分工边界与集成路径

## 重叠检查方法论

**问题**: 构建deep-stock-analysis时，初始版本重复了FTSeek已有的3个模块(signal_tracker/data_collector大部分/market_scanner部分)，导致"什么都做不好"。

**教训**: 构建任何新分析模块前，必须先读FTSeek现有代码确认重叠。

### 检查清单

```bash
# 1. 找FTSeek已有的数据采集模块
grep -rn "def collect\|def fetch\|def get_data\|Provider" /opt/ftseek/FTSeek-US/app/ --include="*.py" | head -30

# 2. 找IC追踪器
find /opt/ftseek/FTSeek-US/app -name "*ic_tracker*" -o -name "*signal_tracker*"

# 3. 找退出规则
grep -rn "def.*exit\|def.*stop_loss\|_check.*exit" /opt/ftseek/FTSeek-US/app/risk/ --include="*.py"

# 4. 找执行入口
grep -n "def _submit_order\|hard_switch\|source_type" /opt/ftseek/FTSeek-US/app/pipeline/order_executor.py
```

### 重叠处理规则

| 情况 | 处理 |
|------|------|
| FTSeek已有且更好 | **删除自己的模块** (signal_tracker → 已删) |
| FTSeek有但场景不同 | **保留并定位差异** (screener: FTSeek=watchlist内, 本skill=全市场) |
| FTSeek没有 | **保留为增量价值** (3维异动, 富途社区情绪, Finnhub基本面) |

## FTSeek链路关键文件

### 1. 信号生成 → 执行入口
- `app/pipeline/signal_pipeline.py`: `run_signal_scan()` → `_submit_order()`
- `app/pipeline/order_executor.py`: `_submit_order()` 是硬开关
  - 仅 `PLAYBOOK_SIM` / `PLAYBOOK_LIVE` / `ORB_ENGINE` 可开仓
  - 非白名单 source_type 被拦截
  - `_submit_order_inner()`: AbsoluteCircuitBreaker → VIX fail-close → 风控链

### 2. 入场计算 (确定性, LLM不参与数值)
- `app/playbook/instruction_generator.py`: `compute_instruction_values()`
  - entry_price: BUY用ask, SELL_SHORT用bid (非last_price, 避免盘前滞后)
  - SL: ATR波动率分桶 → 固定百分比回退 (BUY=2.5%, SHORT=2.0%)
  - TP: R:R ratio (short=1.0, long=2.5)
  - position_size: risk_amount / (entry - SL)
- `Instruction` dataclass: symbol/direction/entry_price/stop_loss/take_profit/position_size/confidence/thesis/conditions

### 3. 退出规则 (5条, 因子级配置)
- `app/playbook/pipeline.py`: `_check_playbook_exit_rules()`
  - [1] SL_FIXED_PCT: effective_sl 触及 (含 breakeven ratchet + trailing stop)
  - [2] OVERNIGHT_GAP_STOP: cohort B 隔夜仓跳空 >3%
  - [3] PRE_CLOSE_EXIT: 收盘前 8min (cohort B 盈利可跳过)
  - [4] TIME_EXIT: 持仓 > factor_time_exit_hours 且 盈利<0
  - [5] MAX_HOLD_T5: cohort B 持仓≥5 交易日
- `config/playbook_horizon.yaml`: `factor_exit_rules` per-factor配置

### 4. 已有IC追踪器 (signal_tracker.py已删除, 不重复)
- `app/analysis/signal_ic_tracker.py` — 主线IC (31KB, 完整backfill+DB+按策略分解)
- `app/playbook/ic_tracker.py` — Playbook IC (19KB, Spearman rank correlation)
- `app/evolution/shadow_tracker.py` — Shadow信号追踪

### 5. FTSeek深度分析引擎 (本skill的互补, 非替代)
- `app/plan/deep_analysis_engine.py`: 9次LLM调用多空辩论 (对标MU_research-deep.md)
- `app/plan/deep_research_pipeline.py`: Stage6-8: 4分析师→辩论→综合→风险辩论
- `app/llm/prompts/deep_target_analysis.py`: SYSTEM_PROMPT + USER_PROMPT_TEMPLATE (KO级prompt设计)
- 本skill的llm_synth.py是1次LLM调用的轻量版, 复用FTSeek的prompt设计理念

### 6. FTSeek数据Provider (本skill的Finnhub直调是互补)
- `app/data/providers/fundamental_provider.py`: 多源降级(Futu→Finnhub→Yahoo→AlphaVantage)
- `app/data/providers/futu_extended_provider.py`: 空头/分析师/内部人(需新版SDK)
- `app/data/providers/insider_provider.py`: SEC Form 4
- `app/data/social_sentiment.py`: Reddit/HackerNews(非富途社区)
- `app/data/news_provider.py`: RSS sources(WSJ/CNBC, 非富途原生)

## _submit_order硬开关集成

```python
# app/pipeline/order_executor.py line ~3076
# 现在的:
if _source != 'PLAYBOOK_SIM' and _source != 'PLAYBOOK_LIVE' and _source != 'ORB_ENGINE':

# 改为:
if _source not in ('PLAYBOOK_SIM', 'PLAYBOOK_LIVE', 'ORB_ENGINE', 'DEEP_ANALYSIS'):
```

冻结期(7/24)结束后做此改动。

## 适配器: LLM输出→FTSeek Instruction

v0.3的adapter直接映射LLM生成的具体价位:
- LLM输出 `entry_price=294.8, stop_loss_price=288.46, take_profit_price=330`
- adapter映射为 `voting_result['entry_price']`, `voting_result['stop_loss']`, `voting_result['take_profit']`
- FTSeek `instruction_generator` 最终确认/微调这些数值

## 铁律 (Ponytail + Karpathy)

1. **不碰退出规则** — FTSeek退出系统是安全机制 (Ponytail: never simplify away stop-loss checks)
2. **不碰执行逻辑** — 硬开关+AbsoluteCircuitBreaker+VIX fail-close 是安全层
3. **不独立追踪IC** — FTSeek已有3个IC追踪器 (signal_tracker.py已删除)
4. **不重复FTSeek的data_collector** — 增量采集(异动/社区情绪/Finnhub基本面)是唯一保留理由
5. **规则评分做不了深度分析** — v0.1规则评分全SKIP, v0.3 LLM合成后才达KO质量
6. **LLM只做合成不做数值** — entry/SL/TP由FTSeek instruction_generator确定性计算, LLM的建议价位仅作参考

## 解耦设计 (v0.4)

### config.py — 唯一配置中心
所有路径/密钥/模型参数在config.py，改环境只改这一个文件:
- PYTHON路径 / OpenD地址 / 脚本路径
- DASHSCOPE_KEY / FINNHUB_KEY (从.env.us读)
- LLM_MODEL / LLM_TEMPERATURE / LLM_MAX_TOKENS

### LLM可注入策略
`DeepAnalyzer(data, synth_module=None)`:
- `None` (默认): 尝试import llm_synth, 失败降级到规则
- `'rule'`: 强制纯规则模式, 不调LLM (秒级, 用于快速扫描)
- 任意模块: 注入自定义合成策略 (需有synthesize方法)

### 降级链
LLM故障 → 规则评分 (deep_analyzer._rule_synthesize)
数据采集故障 → {"_error": "..."} (不阻塞其他采集)
pipeline阶段故障 → try/except跳过 (后续阶段继续)

## 已知数据差距(vs KO示例)

| KO示例有 | FTSeek有 | 本skill有 | 状态 |
|---------|---------|----------|------|
| Q1营收+12%分部数据 | FundamentalProvider | Finnhub stock/metric (营收增长) | ✅ v0.3已补 |
| 26家机构目标价均值 | FutuExtendedProvider | Finnhub recommendation (评级数) | ⚠️ 无目标价(403) |
| 高管套现8175万 | InsiderProvider(SEC) | Finnhub insider-transactions | ✅ v0.3已补 |
| 降息→债券代理推理 | 无 | LLM自行推理(无宏观数据输入) | ⚠️ 低 |
| 7/14 CPI风险日历 | economic_calendar | Finnhub calendar/earnings(财报日) | ⚠️ 有财报日无宏观日 |
