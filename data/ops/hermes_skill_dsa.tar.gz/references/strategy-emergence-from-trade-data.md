# Strategy Emergence from Trade Data

从362笔真实交易数据中涌现的3个可收益策略规则。
数据来源: strategy_memory.db (64 patterns, 92 symbols, 362 trades, 90天回填)。

## 规则1: 不开盘前后30分钟入场

**数据**:
```
时段                 方向    笔数   WR     PnL
开盘前后(21-22h CST) SHORT   55    33%   -$9382  ← 最大亏损源
开盘前后(21-22h CST) LONG    65    29%   -$2210
上午盘(23-1h CST)    SHORT   81    46%   +$7222  ← 最大盈利源
上午盘(23-1h CST)    LONG    41    27%   +$878
```

**洞察**: CST 21-22h = ET 9-10h（开盘前后30分钟）。此时波动大、方向未定，信号质量最差。
等开盘1小时后入场(CST 23h = ET 11h)，SHORT胜率从33%→46%，PnL从-$9382→+$7222。

**执行规则**: signal_gate检查入场时段，21-22h CST的信号降分或BLOCK。

**SQL验证**:
```sql
SELECT
    CASE WHEN CAST(strftime('%H', entry_time) AS INT) IN (21,22) THEN '开盘前后'
         WHEN CAST(strftime('%H', entry_time) AS INT) IN (23,0,1) THEN '上午盘'
         ELSE '其他' END as slot,
    direction, COUNT(*), SUM(CASE WHEN realized_pnl>0 THEN 1 ELSE 0 END), SUM(realized_pnl)
FROM trade_records WHERE realized_pnl IS NOT NULL
  AND strategy_id NOT IN ('manual','manual_sync','reconciler','futu_sync','broker_reconcile')
GROUP BY slot, direction ORDER BY SUM(realized_pnl) DESC;
```

## 规则2: SHORT+快止盈是当前市场最赚的setup

**数据**:
```
退出方式            方向    笔数   WR    avgWin   PnL      盈亏比
DAY_TRADE_TP       SHORT   11    100%  $981     $10786   ∞
EOD_FORCE_CLOSE    SHORT   9     78%   $206     $1315    3.3
tp_hit             SHORT   5     100%  $149     $747     ∞
TRAILING_STOP      SHORT   41    59%   $299     -$2652   0.5  ← 让利润奔跑反而亏
```

**洞察**: SHORT+日内止盈(DAY_TRADE_TP/tp_hit)100%胜率。当前市场环境SHORT比LONG有效。
但"让利润奔跑"(TRAILING_STOP)对SHORT反而亏(盈亏比0.5)——说明当前市场SHORT的窗口短，快止盈比持有更有效。

**执行规则**: signal_gate的strategy_hint按direction查表推荐退出方式:
- SHORT → DAY_TRADE_TP / EOD_FORCE_CLOSE (不推荐TRAILING_STOP)
- LONG → TRAILING_STOP (盈亏比1.9，唯一正期望的LONG退出)

## 规则3: LONG+SL_ATR_STOP是确定性亏损——必须避免

**数据**:
```
退出方式            方向    笔数   WR    avgLoss   PnL
SL_ATR_STOP        LONG    12    0%    $456      -$5474   ← 12笔全亏
sl_hit             LONG    53    8%    $21       -$995
BREAKEVEN_STOP     SHORT   3     0%    $0        -$6235
```

**洞察**: LONG+ATR止损12笔全亏，因为ATR止损太紧被日内噪音打掉(hold=0.1h)。
LONG要么用更宽的止损(TRAILING_STOP盈亏比1.9)，要么不做。

**执行规则**: signal_gate对LONG+SL_ATR_STOP组合直接BLOCK。

## 单股洞察

**最赚单股**:
- US.XLF SHORT 2笔 PnL=+$8642 (但avg=-$208，说明1笔大赢1笔小亏)
- US.ORCL SHORT 22笔 WR=52% PnL=+$3243
- US.XLE LONG 3笔 WR=100% PnL=+$2915

**最亏单股**:
- US.QQQ SHORT_PROXY_OPTION 2笔 PnL=-$5984
- US.GOOGL SHORT 4笔 WR=67% PnL=-$5979 (胜率67%但PnL负→单笔亏损>盈利)
- US.QCOM SHORT 40笔 WR=23% PnL=-$3020

## 时间分布完整矩阵

```
hour  trades  wins  WR    PnL
 0h    51     17   33%  -$984
 1h    31     14   45%  +$243
 2h    25      8   32%  -$2471
 3h    56     19   34%  -$753
14h    10      7   70%  +$363    ← 下午盘胜率最高
21h    46     17   37%  -$8615   ← 开盘前最大亏损
22h    75     20   27%  -$5911   ← 开盘后最大亏损
23h    43     18   42%  +$3367   ← 开盘1h后转盈
```

## 从数据到执行规则的映射

| 涌现规则 | signal_gate实现 | 状态 |
|---------|-----------------|------|
| 不开盘前后30分钟入场 | 检查entry_time小时，21-22h降分 | 待实现 |
| SHORT推荐快止盈 | strategy_hint按direction查表 | 部分实现(已推荐最高PnL退出，但未按方向查表) |
| LONG+SL_ATR_STOP直接BLOCK | 检查direction+recommended_exit组合 | 待实现 |

**重要**: 这些规则来自FTSeek历史交易(362笔)，不是deep_analysis的信号。
deep_analysis的信号质量要等IC样本积累(7天+30样本)后才能评估。
先用历史pattern优化signal_gate，再用deep_analysis的IC验证信号本身。
