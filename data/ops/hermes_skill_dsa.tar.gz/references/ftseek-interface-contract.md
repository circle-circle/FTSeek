# FTSeek Interface Contract (2026-07-05)

deep-stock-analysis → FTSeek 的4种接口格式和6个关键匹配点。

## 6个接口不匹配及修复

| # | 问题 | deep-analysis输出 | FTSeek期望 | 修复 |
|---|------|------------------|-----------|------|
| 1 | direction枚举 | BUY/SELL_SHORT/SKIP | Direction.LONG/SHORT (Enum) | adapter: BUY→LONG, SELL_SHORT→SHORT |
| 2 | source_type白名单 | DEEP_ANALYSIS | 仅PLAYBOOK_SIM/LIVE/ORB_ENGINE | adapter输出PLAYBOOK_SIM走playbook pipeline |
| 3 | confidence量纲 | 0-100整数 | 0.0-1.0浮点 | adapter: confidence/100 |
| 4 | SignalScore缺字段 | 无signal_id/strategy_id | 需signal_id/strategy_id/strength | adapter补uuid+deep_analysis+score*10 |
| 5 | exit_meta缺字段 | 无cohort/peak_price | 需cohort/peak_price/conditions | adapter补cohort=A+peak=entry |
| 6 | IC未写入DB | 只输出格式 | 需写入signal_snapshots表 | ic_writer.py直接写SQLite |

## 4种FTSeek接口格式

### 1. voting_result → _submit_order
```python
{
    "source_type": "PLAYBOOK_SIM",  # 必须在白名单内
    "direction": "BUY",             # BUY/SELL_SHORT/SKIP
    "confidence": 0.7,              # 0.0-1.0 (不是0-100!)
    "strategy_id": "deep_analysis",
    "conditions": ["revenue_growth_high", "news_positive"],  # 27个合法枚举
    "entry_price": 191.22,
    "stop_loss": 185.0,
    "take_profit": 218.0,
    "thesis": "...",
    "position_suggestion": {"stop_loss_pct": 3.25, "take_profit_pct": 14.0},
}
```

### 2. signal_score → SignalScore dataclass
```python
{
    "signal_id": "uuid",
    "trace_id": "deep_analysis_1234567890",
    "strategy_id": "deep_analysis",
    "symbol": "US.NVDA",
    "direction": "LONG",  # LONG/SHORT/NEUTRAL (不是BUY/SELL_SHORT!)
    "strength": 70,       # 0-100整数
    "confidence": 0.7,    # 0.0-1.0浮点
    "metadata": {
        "source_type": "PLAYBOOK_SIM",
        "thesis": "...",
        "conditions": [...],
    }
}
```

### 3. exit_meta → _check_playbook_exit_rules
```python
{
    "cohort": "A",              # A=日内可隔夜, B=日内平仓
    "_skip_allowed": False,     # 盈利仓是否跳过EOD
    "_log_tag": "deep_analysis",
    "_symbol": "US.NVDA",
    "conditions": ["revenue_growth_high", "news_positive"],
    "stop_loss": 185.0,
    "peak_price": 191.22,       # 初始peak = entry_price
    "entry_time": "2026-07-05T10:00:00",
    "horizon": "short",
}
```

### 4. ic_snapshot → record_signal_snapshot
```python
{
    "decision_id": "DA_US.NVDA_1234567890",
    "symbol": "US.NVDA",
    "direction": "LONG",   # LONG/SHORT
    "strength": 70,        # 0-100
    "confidence": 0.7,     # 0.0-1.0
    "strategy_id": "deep_analysis",
    "factors": ["fundamental", "news", "sentiment"],
}
```

## FTSeek 27个合法condition枚举

来源: `app/playbook/condition_taxonomy.py`

### BULLISH_CONDITIONS (13个)
above_ma20, above_ma50, ma_golden_cross, macd_golden_cross, rsi_oversold, bollinger_upper, bollinger_squeeze, pe_below_industry, revenue_growth_high, roe_high, near_52w_high, insider_cluster_buy, insider_net_buy, news_positive, sentiment_bullish, earnings_beat_streak, post_earnings_momentum

### BEARISH_CONDITIONS (10个)
below_ma20, below_ma50, ma_dead_cross, macd_dead_cross, rsi_overbought, bollinger_lower, pe_above_industry, near_52w_low, insider_net_sell, news_negative, sentiment_bearish

### ⚠️ 方向一致性规则 (v0.5修复 — 最关键)
**conditions必须与direction方向一致**:
- direction=BUY → 只输出BULLISH_CONDITIONS (从bull_case映射)
- direction=SELL_SHORT → 只输出BEARISH_CONDITIONS (从bear_case映射)
- direction=SKIP → 输空列表 `[]`

**不要把bear_case的conditions混入BUY信号的conditions列表**。虽然FTSeek的`_get_factor_exit_config`有方向感知会跳过不一致的condition，但：
1. FTSeek方向冲突检查(pipeline.py 714行): `net_score < -0.05`且`direction=BUY` → **SKIP拦截**
2. factor_ic统计会把bearish condition的收益算到LONG头上 → **IC污染**
3. 语义错误: bear_case是"看空理由"不是"退出条件"

**adapter实现**: `_map_conditions()`按direction分流到`_map_bullish_conditions()`或`_map_bearish_conditions()`，不混输出。

### 方向感知匹配逻辑
`_get_factor_exit_config(conditions, factor_rules, direction)`:
1. 第一轮: 优先匹配方向一致(BULLISH for LONG, BEARISH for SHORT) + 有exit_rule的condition
2. 第二轮: 退回第一个有exit_rule的condition
3. 兜底: default规则(trailing=False, max_hold=1d)

## exit_rules配置 (playbook_horizon.yaml)

关键退出规则:
| condition | trailing | breakeven | max_hold |
|-----------|----------|-----------|----------|
| revenue_growth_high | True | 0.5% | 5d |
| roe_high | True | 0.5% | 5d |
| insider_cluster_buy | True | 0.5% | 5d |
| above_ma20 | True | 1.0% | 3d |
| news_positive | True | 0.5% | 2d |
| sentiment_bullish | True | 0.5% | 2d |
| default | False | 0.5% | 1d |

## FTSeek source_type白名单

`_submit_order`硬开关:
```python
if _source != 'PLAYBOOK_SIM' and _source != 'PLAYBOOK_LIVE' and _source != 'ORB_ENGINE':
    return None  # 被拦截
```
deep-analysis输出`source_type=PLAYBOOK_SIM`直接通过，不需要改FTSeek代码。

## signal_snapshots.db schema

```sql
CREATE TABLE signal_snapshots (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    decision_id TEXT NOT NULL UNIQUE,
    symbol TEXT NOT NULL,
    direction TEXT NOT NULL,      -- LONG / SHORT
    strength INTEGER,             -- 0-100
    confidence REAL,              -- 0.0-1.0
    consensus_level REAL,
    strategy_id TEXT,
    created_at TEXT NOT NULL,
    trade_date TEXT NOT NULL,
    price_at_signal REAL,
    close_t0 REAL, close_t1 REAL, close_t5 REAL, close_t20 REAL,
    fwd_ret_t1 REAL, fwd_ret_t5 REAL, fwd_ret_t20 REAL,
    realized INTEGER DEFAULT 0,
    ic_batch_date TEXT,
    created_at_snap TEXT NOT NULL,  -- ⚠️ 必填! 遗漏会导致INSERT失败
    trade_mode TEXT DEFAULT "simulate",
    weight_version TEXT DEFAULT 'v1',
    factors_json TEXT
);
```

DB路径: `/opt/ftseek/FTSeek-US/data/signal_snapshots.db` (独立文件)

## Finnhub免费层可用API

| endpoint | 数据 | 状态 |
|----------|------|------|
| stock/metric?metric=all | 133个基本面指标(营收增长/ROE/利润率/PE/PB/Beta) | ✅ |
| stock/recommendation | 分析师评级(strongBuy/buy/hold/sell, 按月) | ✅ |
| stock/insider-transactions | 内部人交易(日期/姓名/买卖/股数/价格) | ✅ |
| stock/insider-sentiment | 内部人情绪MSPR(月度净买卖比) | ✅ |
| stock/profile2 | 公司概况(行业/市值/流通股) | ✅ |
| calendar/earnings | 财报日历(下次财报日/EPS预期) | ✅ |
| stock/price-target | 目标价 | ❌ 403(付费) |
| calendar/economic | 宏观日历(CPI/FOMC) | ❌ 403(付费) |
| stock/candle | K线 | ❌ 403(付费) |

Finnhub key从FTSeek .env.us读取: `FINNHUB_API_KEY=d604po9r01qihi8ofon0d604po9r01qihi8ofong`
