# Skill→Execution Chain Audit + WARN Fix Evolution (2026-07-10)

## The Field Flow That Matters

```
confidence is the ONLY field that flows from skill analysis → execution sizing.

pipeline.py _write_bridge_file:
  vr["confidence"] (from adapter._compute_confidence)
  → bridge JSON: "confidence": vr["confidence"]
  → DB: confidence = int(vr["confidence"] * 100)

FTSeek auto_execute:
  _conf = inst["confidence"]  # from DB
  _conf_factor = max(0.6, min(1.4, _conf / min_confidence))
  _risk_amount = risk_base * (risk_pct/100) * _conf_factor
  → position_size = int(_risk_amount / per_share_risk)
```

## WARN Fix: Three Attempts

### Attempt 1 (FAILED): setdefault position_size_hint
```python
a.setdefault("position_size_hint", "small")
```
- Stage3 (pipeline.py L108-116) ALWAYS sets `analysis["position_size_hint"]` before _write_bridge_file
- setdefault doesn't overwrite existing keys → dead code
- Even if it worked: auto_execute doesn't read raw_instruction.position_size_hint

### Attempt 2 (FAILED): override stored but not applied
```python
a.setdefault("_warn_confidence_override", _warn_conf)
# ... later ...
vr = _adapter.to_voting_result(a)  # recalculates confidence, ignores override
```
- Override was on `analysis` dict, but `to_voting_result` recomputes confidence fresh
- Override never reached `vr["confidence"]`

### Attempt 3 (WORKING): override applied to vr after to_voting_result
```python
# WARN branch:
_vr_pre = _adapter.to_voting_result(a)
_warn_conf = max(0.25, _vr_pre.get("confidence", 0.5) - 0.15)
a.setdefault("_warn_confidence_override", _warn_conf)

# After main vr = to_voting_result(a):
_warn_conf = a.get("_warn_confidence_override")
if _warn_conf is not None:
    vr["confidence"] = _warn_conf  # override BEFORE writes
```

**Critical ordering:** `to_voting_result()` < override `vr["confidence"]` < bridge JSON write < DB write

## P0-P4 Audit Summary

| ID | Finding | Status |
|----|---------|--------|
| P0 | signal_gate BLOCK not wired to DB | ✅ FIXED (BLOCK→continue) |
| P1 | Debate anti-long bias (challenger偏空) | Confirmed, deferred |
| P1-data | Agent claimed conf=35, actual was 60-70 | ❌ Agent data error |
| P2 | conditions keyword matching | Confirmed, deferred |
| P3 | pullback vs chase entry conflict | Confirmed, deferred |
| P4 | position_size_hint not consumed by exec | Confirmed, deferred |

## Cross-Agent Evaluation Pitfall

When another agent reports "X is broken" or "value=Y":
1. Read the actual source file at the cited lines
2. Run the actual DB query to verify data claims
3. Check OKR status (okr_status.py) for ground truth
4. Verify the recommended fix has nonzero impact (check historical data)
5. Distinguish old system data (voting_llm) from new system (deep_analysis)

Example: Agent recommended fixing oversold_bounce bucket.
Query showed 0/363 snapshots ever had that bucket → zero impact fix.
