# 单笔交易全链路复盘方法论

> 2026-07-14 NVDA LONG 实盘验证。从信号生成到退出完整追踪一笔交易，提炼可复用经验。

## 适用场景

用户要求"详细复盘某笔交易的选股→下单→退出整个链路"时使用。
与 EOD 每日汇总复盘不同，这是对单笔交易的全链路深度追踪。

## 核心原则

1. **DB验证优先**：不信任报告数字，从原始DB逐表追踪
2. **多DB交叉**：ftseek_us.db(执行) + signal_snapshots.db(信号) + decisions.db(投票)
3. **链路完整性**：信号→bridge→instruction→entry→持仓快照→退出telemetry→归因
4. **诚实边界**：样本=1不构成统计结论，需标注

## 全链路追踪流程 (7步)

### Step 1: trade_records 全字段
```sql
SELECT * FROM trade_records
WHERE symbol = 'US.XXX' AND trade_date = 'YYYY-MM-DD';
```
关键字段：
- `metadata_json`: 含完整 exit_telemetry, attribution, shadow_exits, thesis
- `signal_details`: entry/SL/TP 的 JSON (执行时值)
- `signal_id`, `decision_id`, `trace_id`: 关联其他表的key
- `factor_detail`: 入场因子列表

### Step 2: signal_snapshots (信号生成层)
```sql
-- signal_snapshots.db
SELECT * FROM signal_snapshots
WHERE decision_id = 'DA-YYYYMMDDHHMMSS-US.XXX-XXXX';
```
关键发现点：
- `strength` vs `confidence`: signal_snapshot值 vs trade_records值可能不同
- `factors_json`: 完整claim列表(bull/bear, source_type, claim_type, strength, side)
- `alpha_t1`, `fwd_ret_t1`: 前瞻收益(已realized的行才有)
- `market_context_json`: 生成时的市场上下文

### Step 3: playbook_instructions (指令层)
```sql
SELECT * FROM playbook_instructions WHERE id = NNN;
-- 或
SELECT * FROM playbook_instructions
WHERE symbol = 'US.XXX' AND date = 'YYYY-MM-DD';
```
关键对比点：
- `entry_price`(计划) vs `execution_price`(实际) → 入场偏差
- `stop_loss`(计划) vs trade_records的signal_details.stop_loss(执行) → SL是否被re-price覆盖
- `take_profit`(计划) vs 实际TP → TP偏差
- `confidence` vs signal_snapshot的confidence → 是否被debate降级
- `thesis`: LLM分析原文
- `risks_json`: 挑战者列出的风险
- `raw_instruction_json`: 含debate_outcome, score, planned_entry/SL/TP
- `invalidation`: 失效条件
- `entry_low`, `entry_high`: 入场区间

### Step 4: position_snapshots (持仓追踪)
```sql
SELECT * FROM position_snapshots
WHERE symbol = 'US.XXX' AND snapshot_time LIKE 'YYYY-MM-DD%'
ORDER BY snapshot_time;
```
关键点：
- SL在快照中的演变 (initial → breakeven → trail lock)
- `unrealized_pnl` 和 `pnl_pct` 的时序变化
- 注意：hourly快照可能不包含盘中所有SL变动

### Step 5: metadata_json 深度解析 (退出telemetry)
```python
import json
meta = json.loads(trade_record['metadata_json'])
# exit_telemetry: 完整退出数据
#   - entry_price, exit_price, peak_price, trough_price
#   - mfe_pct, mae_pct, pnl_pct, holding_hours
#   - breakeven_triggered, initial_sl, take_profit
# _exit_shadow: 替代退出参数的shadow结果
# attribution: LLM归因(direction/entry/exit/duration/efficiency 5维评分)
```

### Step 6: signal_snapshots 历史序列 (信号连贯性)
```sql
SELECT decision_id, created_at, direction, strength, confidence,
       price_at_signal, close_t0, close_t1, fwd_ret_t1, alpha_t1, realized
FROM signal_snapshots
WHERE symbol = 'US.XXX'
ORDER BY created_at DESC LIMIT 10;
```
关键点：
- 连续多日方向一致 = 信号连贯性
- alpha_t1 正负 = 信号预测力
- strength/confidence 变化趋势

### Step 7: 7日上下文 (防单笔幸存者偏差)
```sql
SELECT trade_date, COUNT(*) as 笔数,
  ROUND(100.0 * COUNT(CASE WHEN realized_pnl > 0 THEN 1 END) / COUNT(*), 0) as 胜率,
  ROUND(SUM(realized_pnl), 2) as 盈亏
FROM trade_records
WHERE trade_date >= date('YYYY-MM-DD', '-7 days')
GROUP BY trade_date ORDER BY trade_date;
```

## DB 表地图 (全链路)

```
signal_snapshots.db
  └─ signal_snapshots: 信号生成 (strength, confidence, factors_json, claims)
  └─ regime_history: 市场状态

decisions.db
  └─ decisions: 投票决策 (旧DEC路径, DA不经过此表)
  └─ model_votes: 模型投票明细 (旧路径)

ftseek_us.db
  └─ playbook_instructions: 指令层 (DA直写, 含thesis/SL/TP/risks)
  └─ trade_records: 执行层 (含metadata_json完整telemetry)
  └─ signal_lifecycle: 信号生命周期 (direction_aligned, trade_win)
  └─ position_snapshots: 持仓时序快照
  └─ order_tracking: 订单状态追踪
  └─ stoploss_events: 止损事件 (可能为空)
  └─ entry_context_snapshot: 入场上下文 (可能为空)
  └─ event_log: 事件日志
  └─ trade_attribution: LLM归因 (可能为空)
  └─ capital_state: 资金状态
```

## 评价维度 (6项)

| 维度 | 数据来源 | 检查点 |
|------|----------|--------|
| **信号质量** | signal_snapshots factors_json | bull方HIGH claim数 > bear方HIGH? |
| **debate影响** | playbook_instructions raw_instruction_json | 方向分歧是否降confidence? 降了多少? |
| **入场精度** | trade_records entry vs position_snapshots trough | 入场价接近trough=精准入场 |
| **SL/TP偏差** | playbook_instructions vs trade_records signal_details | 计划vs实际SL/TP, 是否被re-price覆盖 |
| **退出效率** | metadata_json exit_telemetry | MFE捕获率 = pnl% / mfe% (目标>80%) |
| **shadow对比** | metadata_json _exit_shadow | 当前退出参数 vs 替代参数, 哪个更优? |

## NVDA 7/14 案例提炼的可复用pattern (样本=1, 需验证)

### Pattern 1: debate降confidence但信号仍有alpha
- signal_snapshot conf=0.70 → debate分歧 → 降到0.35
- 实际+3.11%盈利, alpha_t1=+3.7%(7/13信号)
- 启示: conf被debate降低不等于信号无效, 可能只是保守

### Pattern 2: 宽SL(4.4%)+晚breakeven(1.0%)+紧drawdown(0.5%)=趋势捕获最优
- shadow exit证明更紧参数(be0.3/dd0.3)会损失97%利润
- 当前参数在此笔交易上最优
- 注意: 样本=1, 不能据此调参

### Pattern 3: HIGH强度claim数量比>1:1时方向预测力强
- 3 bull(2 HIGH) vs 3 bear(1 HIGH) → 方向正确
- 连续2天LONG信号(7/13+7/14), alpha均为正

### Pattern 4: 计划入场(限价) vs 实际入场(市价)偏差
- 计划$201.88(MA20限价), 实际$204.77(市价)
- 如果等限价, 不会成交(NVDA没跌到$201.88)
- 启示: 高质量信号可能需要市价入场而非限价等待

## 诚实边界声明

- 上述pattern基于1笔NVDA交易, 不具统计显著性
- shadow exit对比只证明"这笔交易"当前参数最优
- 需积累20-30笔干净样本后才能验证pattern的统计显著性
- **建议: 保持当前参数运行, 继续积累样本, 不要基于1笔交易调参**
