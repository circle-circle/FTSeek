# 数据流审计方法论 (v0.19)

## 审计触发条件

用户要求"检查数据源，数据不一致，不匹配，冲突，并行执行，重复，覆盖等逻辑错误"时执行。

## 8类数据流问题检查清单

### 1. 重复写入 (P0)
- 同一数据被两个模块各写一次，产生两条不同ID的记录
- 检查: grep decision_id/id生成逻辑，确认只有一个写入点
- 案例: ic_writer和adapter各自生成不同格式的decision_id（DA- vs DA_）

### 2. 地址/配置不一致 (P0)
- 一个模块用config读地址，另一个硬编码
- 检查: grep硬编码的IP/端口/路径，对比config定义
- 案例: collect_snapshot硬编码127.0.0.1:11111，其他函数用config.OPEND_HOST

### 3. 代码注入风险 (P0)
- subprocess执行Python代码字符串时用f-string注入变量
- 检查: grep f-string + subprocess + code
- 修复: 改为sys.argv参数传递

### 4. 变量覆盖 (P0)
- 局部变量和dict key同名，无意覆盖前面的调整
- 检查: grep "score = " 看是否有重置而非累加
- 案例: market_scanner的score=5.0覆盖了result["score"]的市值/主流加分

### 5. 分类系统冗余 (P1)
- 两个独立函数对同一输入做分类，命名不同需手动映射
- 检查: grep分类函数，看是否有两套并行的分类逻辑
- 案例: adapter的_map_bullish_conditions vs ic_writer的_classify_claim
- 不修理由: 两套系统各有用途（FTSeek 27枚举 vs IC claim_type），映射表是合理桥接

### 6. 并行限流 (P1)
- ThreadPoolExecutor并发调用外部API但无rate limit
- 检查: grep ThreadPoolExecutor + max_workers + API调用
- 判断: 单批次API调用数 × max_workers 是否超过API限流阈值

### 7. 冗余函数 (P2)
- 一个函数的功能完全被另一个包含
- 检查: grep函数调用方，如果没人调就是冗余
- 案例: collect_incremental被collect_all完全包含

### 8. 重复计算 (P2)
- 同一函数被多次调用做相同计算
- 检查: grep函数调用，看同一函数在一个流程里被调几次
- 案例: adapter的to_voting_result被调3次（自身+to_signal_score+to_exit_meta）

## 审计流程

1. 读取全部模块源码（不只读改过的文件）
2. 画数据流图：哪个模块产出什么 → 谁消费它
3. 对每个数据流节点，检查上面8类问题
4. 按OKR影响排序：P0先修，P1看情况，P2用YAGNI判断
5. 修完后grep同类pattern扫全模块（参见时区审计方法论）

## 修复决策框架

| 问题 | 修不修 | 判断依据 |
|------|--------|---------|
| 重复写入 | 当前不冲突就不修 | 设计冗余但无实际数据冲突 |
| 地址不一致 | 修 | 一处改config就够 |
| 代码注入 | 修 | 安全风险 |
| 变量覆盖 | 修 | 直接影响评分正确性 |
| 分类冗余 | 不修 | 两套系统各有用途 |
| 并行限流 | 看规模 | 当前不超限就不修 |
| 冗余函数 | 删 | YAGNI |
| 重复计算 | 修 | 缓存就几行 |
