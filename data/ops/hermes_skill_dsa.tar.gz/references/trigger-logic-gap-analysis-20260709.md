# Trigger Logic Gap Analysis — 2026-07-09

## 诊断背景

**用户问题**: "是否有成交记录 执行计划和指令是否有基于盘中具体数据和情况能够动态感知调整？"

**方法论**: 查DB实际成交 + 读trigger源码 + 对比LLM entry_strategy与执行层逻辑

## 事实数据

### 今日成交: 0笔
- trade_records: 0笔成交
- 5条playbook_instructions: triggered=0, executed=0 (全部未触发)
- auto_execute跑了2次 (09:43 + 10:08 ET), 全部SKIP

### auto_execute日志
```
2026-07-09 21:43:02 [playbook] auto_execute 开始: 5 条指令 (now=09:43 ET)
2026-07-09 21:43:07 ⚔️ US.PSX gap过大, 跳过触发: current=$188.27 entry=$178.98 gap=5.2%
2026-07-09 21:43:25 ⚔️ US.VLO gap过大, 跳过触发: current=$282.87 entry=$271.30 gap=4.3%
2026-07-09 21:43:48 ⚔️ US.MPC gap过大, 跳过触发: current=$281.62 entry=$265.00 gap=6.3%
2026-07-09 22:08:42 [playbook] auto_execute 开始: 5 条指令 (now=10:08 ET)
2026-07-09 22:08:47 ⚔️ US.PSX gap过大, 跳过触发: current=$188.90 entry=$178.98 gap=5.5%
2026-07-09 22:08:50 ⚔️ US.VLO gap过大, 跳过触发: current=$282.20 entry=$271.30 gap=4.0%
```

### 5条instruction详情
| symbol | entry | SL | TP | conf | gap | 触发? |
|--------|-------|-----|-----|------|-----|-------|
| PSX | $178.98 | $172.0 | $212.0 | 70 | +5.5% | gap过大跳过 |
| VLO | $271.30 | $248.0 | $294.0 | 60 | +4.0% | gap过大跳过 |
| MPC | $265.00 | $248.32 | $315.0 | 60 | +6.3% | gap过大跳过 |
| NVDA | $197.80 | $191.0 | $236.3 | 70 | ~0.6% | 未触发(未穿越?) |
| TTE | $76.80 | $74.7 | $85.17 | 70 | ~1.6% | 未触发(未穿越?) |

### 近7天trade_records统计
| 日期 | 笔数 | 胜负 | avg_pnl | total_pnl |
|------|------|------|---------|-----------|
| 2026-07-08 | 12 | 2W/10L | -0.001% | -$94.31 |
| 2026-07-07 | 7 | 1W/6L | +0.002% | +$24.02 |
| 2026-07-06 | 8 | 3W/5L | +0.004% | +$157.58 |
| 2026-07-02 | 10 | 7W/3L | +0.006% | +$233.25 |

## 根因分析

### 断裂1: entry_strategy被完全忽略

LLM在`raw_instruction_json.entry_strategy`中写了丰富的入场条件:
- "日线收盘站稳$268且量比>1.0"
- "RSI回落至50以下且出现阳包阴K线组合"
- "30分钟K线企稳不破"
- "缩量回踩MA20且RSI<40超卖确认"

但`_check_intraday_trigger()` (pipeline.py:2420-2428) 只做简单的价格距离检查:
```python
_touch_zone = 0.01  # ±1%
if is_short:
    triggered = current_price >= entry_price * (1 - _touch_zone)
else:
    triggered = current_price <= entry_price * (1 + _touch_zone)
```

LLM的精细入场策略完全被丢弃。

### 断裂2: gap过滤方向不分好坏

```python
# pipeline.py:2433-2439
_price_gap = abs(current_price - entry_price) / entry_price
if _price_gap > 0.03:
    return False  # 一律跳过
```

问题: gap up(股票朝盈利方向跑)和gap down(朝亏损方向跑)被同等对待。

- BUY + gap up 5% = 股票在涨 = 动量确认 = **应该允许追入**
- BUY + gap down 5% = 暴跌 = **应该跳过**(正确)

今日PSX: LLM说"回调至$178.98买入", 但PSX开盘$188+ (gap up 5.5%), 根本没回调。gap过滤直接跳过, 错过了动量确认的机会。

### 断裂3: 无重估机制

如果回调不发生(股票一路涨), 指令永远卡住, 直到日失效。没有盘中重估: thesis是否仍成立? 是否应该追入?

## trigger逻辑完整路径 (pipeline.py:2355-2463)

```
1. 获取实时行情 (price, day_high, day_low, vol_ratio)
2. BUY触发: current <= entry * 1.01 (回到入场价±1%)
3. gap过滤: abs(current - entry) / entry > 3% → 跳过
4. SL检查: 已越过stop_loss → 不入场
5. 触发后: re-price(用实时bid/ask覆盖entry/SL/TP)
6. 执行
```

## LLM entry_strategy vs trigger逻辑对比

| 维度 | LLM entry_strategy | trigger逻辑 |
|------|-------------------|-------------|
| 价格条件 | "回调至MA5($178.98)附近" | current <= entry*1.01 |
| 量比条件 | "量比>1.0" | ❌ 不检查 |
| RSI条件 | "RSI<40超卖确认" | ❌ 不检查 |
| K线形态 | "30分钟K线企稳不破" | ❌ 不检查 |
| 分批入场 | "第1批30%仓位, 第2批40%" | ❌ 不支持分批 |
| gap处理 | 无明确gap逻辑 | >3%一律跳过(不分方向) |
| 追入逻辑 | 无(假设会回调) | ❌ 不支持追入 |

## 建议方案 (Ponytail + Karpathy, ~30行3处)

### 改动1: gap过滤分方向 (pipeline.py:2433-2439)
```python
# 现在: gap > 3% 一律跳过
# 改为: BUY时只有gap DOWN > 3%才跳过; gap UP不跳过
_price_gap = (current_price - entry_price) / entry_price  # 有符号
if is_short:
    # SHORT: gap up(价格上涨) = 朝亏损方向, >3%才阻止
    if _price_gap > 0.03:
        return False
else:
    # BUY: gap down(价格下跌) = 朝亏损方向, >3%才阻止
    if _price_gap < -0.03:
        return False
```

### 改动2: 追入触发 (pipeline.py:2426-2428)
```python
# 现在: BUY只有 current <= entry*1.01 才触发
# 增加: 允许小幅追入 current <= entry*1.05
if not is_short:
    _trigger_upper = entry_price * 1.01  # 回调触发(原逻辑)
    _chase_upper = entry_price * 1.05   # 追入触发(新增)
    triggered = current_price <= _trigger_upper or (
        current_price <= _chase_upper and vol_ratio and vol_ratio > 1.0
    )
```

### 改动3: 日志增强
记录追入vs回调触发, 记录gap方向。

## 不做什么 (YAGNI)

- 不做LLM盘中重估(需要实时调用LLM, 延迟+成本, 过度设计)
- 不解析entry_strategy的文本条件(NLP解析复杂, ROI低)
- 不做分批执行(等基础设施验证后再考虑)

## 教训

1. **信号生成层与执行层脱节**: deep_analysis产出精细的entry_strategy(RSI/量比/K线形态), 但trigger只看价格距离。两层完全脱节, LLM的精细条件全部被忽略。
2. **gap过滤方向不分**: 动量确认的股票(gap up)被误杀。BUY+gap up = 好事不该跳过; BUY+gap down = 该跳过。
3. **审计trigger必须用实际数据**: 读代码逻辑不够, 必须用实际gap+价格数据验证哪些指令被跳过、为什么。
4. **0成交是系统性问题**: 不是偶然。5条指令全部未触发, 说明trigger逻辑和LLM入场策略之间存在结构性断裂。

## 审计命令

```bash
# 查auto_execute日志
cd /opt/ftseek/FTSeek-US && grep -E "auto_execute|trigger|gap过大|未触发|已越过|盘中触发" logs/ftseek_us.log | tail -30

# 查今日instruction状态
sqlite3 data/ftseek_us.db "SELECT symbol, direction, entry_price, triggered, executed FROM playbook_instructions WHERE date = date('now','localtime')"

# 查今日成交
sqlite3 data/ftseek_us.db "SELECT symbol, direction, entry_price, exit_price, realized_pnl FROM trade_records WHERE date(trade_date) = date('now','localtime')"

# 查LLM entry_strategy (raw_instruction_json)
sqlite3 data/ftseek_us.db "SELECT symbol, raw_instruction_json FROM playbook_instructions WHERE date = date('now','localtime')"
```
