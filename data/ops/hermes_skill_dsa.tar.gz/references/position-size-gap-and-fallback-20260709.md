# Position Size Gap: bridge直写DB绕过compute_instruction_values

## v0.54 更新 (2026-07-12): 兜底已生效但写回DB仍缺失

**DB验证**: 13/13条 position_size=0。re-price块兜底计算**已生效** (trade_records有正确qty: NVDA=15, GOOG=9, NU=235), 但计算结果**不写回playbook_instructions** → 审计断裂。

**待修复**: 确认 `position_size` 在 `_TRACKING_FIELDS` 中, 则 re-price块 `db.update_instruction_tracking(inst["id"], _reprice_params)` 已包含 position_size → 自然写回。

详见 `references/da-to-executor-consistency-audit-20260712.md` 断裂点[1]。

## Date: 2026-07-09

## Problem
bridge直写DB时, skill构造的`_inst`字典没有`position_size`字段, 导致DB中该列为空. auto_execute执行时 `inst.get("position_size", 1)` 取到空值 → 默认1股.

## Root Cause Chain
```
正常路径: voting → compute_instruction_values() → position_size = risk_amount / per_share_risk
bridge直写路径: skill构造_inst → save_instruction() → DB position_size列为空
执行路径: auto_execute → inst.get("position_size", 1) → 空值 → 默认1股
```

## Position Sizing Formula (normal path)
```
risk_amount = risk_base($82K) × risk_pct(0.5%) = $410
per_share_risk = |entry_price - stop_loss|
position_size = int(risk_amount / per_share_risk)
截断: max_position_pct(4%) × risk_base = $3,280上限
```

## Actual Impact (2026-07-09 instructions)
| Symbol | Should Be | Actually |
|--------|-----------|----------|
| NVDA   | 16股 ($3,211) | 1股 |
| TTE    | 41股 ($3,221) | 1股 |
| VLO    | 11股 ($3,104) | 1股 |

## Fix (pipeline.py:2261-2282, re-price block)
```python
_inst_ps = inst.get("position_size") or 0
if _inst_ps <= 0 and _new_sl > 0:
    _risk_base = float(pb_cfg.get("risk_base_capital", 82000.0))
    _risk_pct = float(pb_cfg.get("risk_pct", 0.5))
    _max_pos_pct = float(pb_cfg.get("max_position_pct", 0.04))
    _risk_amount = _risk_base * (_risk_pct / 100)
    _per_share_risk = abs(_new_entry - _new_sl)
    if _per_share_risk > 0:
        _inst_ps = int(_risk_amount / _per_share_risk)
    _max_pos_val = _risk_base * _max_pos_pct
    if _inst_ps * _new_entry > _max_pos_val:
        _inst_ps = max(1, int(_max_pos_val / _new_entry))
```

## Config Values
- risk_base_capital: $82,000
- risk_pct: 0.5% (was 1.0%, lowered in v0.37)
- max_position_pct: 0.04 (was 0.08, lowered in v0.37)

## Lessons
1. bridge直写DB绕过的不仅仅是幂等检查, 还有compute_instruction_values的仓位计算. 每个被绕过的计算函数都需要在消费端兜底.
2. position_size=1在模拟盘看起来无害, 但在实盘会严重限制仓位规模.
3. 诊断: 先查DB中position_size列的值(是否为空), 再追instruction的生成路径.

## DB Query for Diagnosis
```sql
SELECT id, symbol, position_size, entry_price, stop_loss, confidence
FROM playbook_instructions WHERE date = date('now','localtime');
```
