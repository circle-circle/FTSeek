# deep_analysis 架构gap + 替代voting_llm三阶段方案 — 2026-07-08

## Session Context
User asked: (1) 有必要进行分桶设置调整被动止损止盈 (2) Deep-stock-analysis输出的标的结果和策略方向能否替代多模型llm_voting

## Finding 1: deep_analysis无执行路径 — 只写IC不执行交易

**Data**: deep_analysis在signal_snapshots.db有19条记录(7/2-7/7)，在trade_records.db(ftseek_us.db)有0条执行记录。

**Root cause**: adapter.py有`to_voting_result()`格式转换函数，但没有任何FTSeek代码调用它。

**FTSeek playbook pipeline的实际数据流** (app/playbook/pipeline.py `_build_instructions_from_votes`):
```
screen_results → voting_coordinator.vote() → vote_result
  → record_signal_snapshot()           ← 写signal_snapshots (strategy_id=voting_llm)
  → compute_instruction_values()       ← 算SL/TP/仓位 (从playbook_horizon.yaml读配置)
  → Instruction(BUY/SELL_SHORT/SKIP)   ← 写playbook_instructions
  → _submit_order()                    ← 执行
```

**deep_analysis skill的数据流** (Hermes侧):
```
pipeline.py → llm_synth.py             ← 1模型(qwen)深度分析
  → ic_writer.write_signal_snapshot()  ← 只写signal_snapshots (strategy_id=deep_analysis)
  → signal_gate.evaluate_signal()      ← 只评估不执行
  → adapter.to_voting_result()         ← 有格式但无人调用
```

## Finding 2: voting_llm方向级IC拆解 — LONG IC为负

**Data source**: signal_snapshots.db 524条非NEUTRAL信号实算。

| 方向 | n | Pearson IC | T1胜率 | 诊断 |
|------|---|------------|--------|------|
| LONG | 293 | **-0.0674** | 54.6% | 🔴 负IC: strength越高回报越差 |
| SHORT | 231 | +0.0592 | 52.8% | ⚠️ 微弱正IC |
| NEUTRAL | 54 | — | **0.0%** | 🔴 完全无用 |

**全局IC=0.1075掩盖了方向级问题** — LONG方向的负IC被SHORT的正IC抵消。

## Finding 3: Strength与结果倒挂

**ftseek_us.db 391笔实算**:

| Strength区间 | n | 胜率 | 总PnL |
|--------------|---|------|-------|
| low(<40) | 172 | 44.8% | +$6,437 |
| mid(40-55) | 10 | 20.0% | -$581 |
| high(55-70) | 102 | 20.6% | +$2,816 |
| vhigh(70+) | 107 | 42.1% | **-$1,101** |

**核心含义**: voting_llm的LONG方向不仅是"信号不够强"，是"方向反了"。高confidence=反向指标。

## Finding 4: 04:xx批次模板投票实锤

**decisions.db model_votes 7/7 04:xx batch**:

| model_id | strength | n |
|----------|----------|---|
| deepseek_v4_pro | 47 | 20/38 (53%) |
| deepseek_v4_pro | 37 | 18/38 (47%) |
| qwen3.7_max | 45 | 18/38 (47%) |
| qwen3.7_max | 35 | 12/38 (32%) |
| glm_5_2 | 50 | 16/38 (42%) |

38只不同行业不同市值的股票全部投37/47或35/45——不是分析是fallback。且未被标记degraded→污染consensus。

**Audit SQL**:
```sql
SELECT mv.model_id, mv.strength, COUNT(*) as n
FROM model_votes mv
JOIN decisions d ON mv.decision_id = d.decision_id
WHERE d.created_at LIKE '2026-07-07T04%'
GROUP BY mv.model_id, mv.strength
ORDER BY n DESC;
-- If any (model_id, strength) pair has n>5, likely template/fallback
```

## Finding 5: playbook_horizon.yaml SL/TP配置链

**SL来源**: `instruction_generator.py compute_instruction_values()`按以下优先级:
1. `_compute_volatility_based_sl_tp()` 按ATR%选桶(low/medium/high/extreme)
2. ATR缺失(atr_14=0) → fallback到固定百分比
3. 固定百分比: `buy_fixed_stop_loss_pct: 2.5` / `sell_fixed_stop_loss_pct: 2.0`
4. `rr_ratio=999` → 无TP(让EOD捕获利润)

**factor_exit_rules** in playbook_horizon.yaml, 按conditions匹配:
- default: time_exit_hours=2.0, breakeven_at_pct=0.5, trailing=false
- 趋势类(above_ma20等): time_exit=6h, trailing=true
- 波动类(volume_expansion等): time_exit=0.5h, trailing=false

**vol_buckets** (short_horizon):
| 桶 | ATR%范围 | sl_floor | sl_ceil | max_hold_hours |
|----|---------|----------|---------|----------------|
| low | <1.5% | 1.2% | 1.8% | 6 |
| medium | 1.5-3.5% | 1.8% | 2.8% | 4 |
| high | 3.5-8% | 2.5% | 5.0% | 2 |
| extreme | ≥8% | 2.5% | 4.0% | 1 |

## Finding 6: 2-4h死亡区间 + 主动退出=亏损引擎

**ftseek_us.db 391笔持仓时间×PnL**:

| 时段 | n | 胜率 | PnL |
|------|---|------|-----|
| 0-1h | 116 | 30% | +$2,344 |
| 1-2h | 28 | 50% | +$804 |
| **2-4h** | 49 | 47% | **-$10,229** |
| **4-8h** | 38 | **74%** | **+$14,573** |
| 8-24h | 25 | 68% | +$8,013 |
| 24h+ | 135 | 21% | -$7,934 |

**被动退出vs主动退出**:
- 被动(PRE_CLOSE+EOD+DAY_TP): 61笔 62%WR +$22,473
- 主动(sl_hit+TRAILING+STRUCTURE+TIME): 249笔 28%WR -$10,146
- **系统越"管理"越亏。**

## Finding 7: 方向×策略PnL汇总

| 方向 | n | 胜率 | PnL |
|------|---|------|-----|
| LONG | 169 | 29.6% | -$5,865 |
| SHORT | 209 | 44.5% | +$25,893 |
| SHORT_PROXY_OPTION | 13 | 15.4% | -$12,457 |

| 策略 | n | 胜率 | PnL |
|------|---|------|-----|
| voting_llm | 182 | 42.3% | -$13,371 |
| playbook_sim | 32 | 46.9% | -$871 |
| playbook_shadow | 23 | 56.5% | +$242 |
| manual_sync | 8 | 87.5% | +$3,655 |

## 替代voting_llm三阶段方案

### Phase 1: deep_analysis作为LONG方向门禁 (立即可做)
- voting_llm输出LONG时，查signal_snapshots里有没有deep_analysis对该股的同日分析
- 如果deep_analysis方向=LONG且score≥7 → 放行
- 如果deep_analysis方向=SKIP/NEUTRAL或无分析 → voting_llm的LONG降级为SKIP
- **不需要改FTSeek运行时代码** — 在pipeline的过滤逻辑中加一个DB查询

**最小实现(5行代码)**:
```python
# 在 _build_instructions_from_votes() 的BUY分支前
deep_snap = query_signal_snapshots(symbol, trade_date=today, strategy_id='deep_analysis')
if direction == 'BUY' and (not deep_snap or deep_snap.direction != 'LONG'):
    instructions.append(Instruction(symbol=symbol, direction='SKIP', 
        skip_reason='deep_analysis未背书LONG'))
    continue
```

### Phase 2: deep_analysis生成playbook_instructions (积累30+样本后)
- 让deep_stock_analysis的adapter.to_voting_result()输出直接注入playbook_instructions表
- 用source_type=DEEP_ANALYSIS标记，走PLAYBOOK_SIM执行路径
- voting_llm退化为"扫描层"（广度筛选），deep_analysis成为"执行层"（深度决策）

### Phase 3: deep_analysis完全替代voting_llm (IC验证后)
- voting_llm只保留signal_snapshots写入（维持IC对比基线）
- 所有playbook_instructions由deep_analysis生成
- 3模型投票降级为"影子系统"（shadow tracking对比但不执行）

## 多DB地图

| DB路径 | 用途 | 关键表 |
|--------|------|--------|
| data/ftseek_us.db | 交易记录+playbook指令 | trade_records(391行), playbook_instructions |
| data/signal_snapshots.db | IC+前向收益 | signal_snapshots(763行) |
| data/decisions.db | 投票决策+模型票 | decisions, model_votes |
| data/ftseek_us_live.db | 实盘持仓+退出 | trade_records(17行), open_positions |
| data/trade_records.db | **空表(已废弃)** | trade_records(0行) — 不要用 |
| data/strategy_memory.db | 策略记忆库 | pattern_memory, symbol_memory, lesson_log |

**Key gotcha**: trade_records.db(独立文件)是空的——真实交易记录在ftseek_us.db里。

## 最小改动方案 (只改config)

playbook_horizon.yaml改3处:
1. `default.time_exit_hours: 2.0 → 4.0` — 跨过死亡区间
2. `short_horizon.buy_fixed_stop_loss_pct: 2.5 → 3.0` — BA级别的1.8%不该出现
3. `default.breakeven_at_pct: 0.5 → 1.5` — 0.5%保本太早，正常波动就触发
