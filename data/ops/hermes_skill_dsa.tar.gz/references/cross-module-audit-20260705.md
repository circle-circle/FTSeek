# 跨模块数据流审计 — 2026-07-05

## 背景

v0.11完成7项诚实质量审计修复后，用户问"还有哪些功能模块和逻辑需要检查和优化的？"
这次没有只看单个模块——而是**读取全部11个模块源码 + 检查跨模块数据流 + 验证FTSeek backfill是否真的工作**。

发现8个问题，其中2个HIGH会直接导致IC数据无法积累。

## 核心教训：实跑验证 ≠ 跨模块正确

v0.10的"12项上线前验证"检查的是：模块能否导入、API能否调通、pipeline能否跑完。
但这些都通过后，仍然存在跨模块数据流断裂：

| v0.10验证项 | 状态 | 实际跨模块问题 |
|------------|------|---------------|
| 模块导入 | ✅ 10/10 OK | — |
| API可达 | ✅ Finnhub+DashScope 200 | — |
| 单股analyze | ✅ pipeline跑完输出JSON | — |
| IC写入DB | ✅ INSERT不报错 | ❌ trade_date=周末→backfill找不到日K线→IC永远0 |
| scan模式 | ✅ 输出候选列表 | — |
| — | 未检查 | ❌ run_full()没调ic_writer/gate（只有run_analyze_only调了） |
| — | 未检查 | ❌ adapter.to_exit_meta兜底conditions=["default"]非合法枚举 |
| — | 未检查 | ❌ deep_analyzer读capital_flow但data_collector没采集→永远空 |

**教训**：验证方法论需要增加第13项——**跨模块数据流审计**：
1. 写入DB后不只看INSERT成功——查backfill是否真的回填了（`SELECT fwd_ret_t1 FROM ... WHERE strategy_id='deep_analysis'`）
2. pipeline每个mode都要验证——不只看analyze模式，还要看full模式是否调了ic_writer/gate
3. 读源码追踪数据字段——deep_analyzer读的`capital_flow`字段在data_collector的`collect_all()`返回里是否存在
4. 检查兜底值合法性——adapter的conditions兜底`["default"]`是否在FTSeek 27个合法枚举里

## 8个发现（按严重程度）

### HIGH-1: ic_writer非交易日trade_date bug

**模块**: ic_writer.py `_get_et_trade_date()`
**问题**: 返回当前ET日期。周末/假日运行时trade_date=非交易日。
**数据验证**: 
```
SELECT trade_date, realized, fwd_ret_t1 FROM signal_snapshots WHERE strategy_id='deep_analysis'
→ 15条记录全是2026-07-04(周六)/2026-07-05(周日)，0条被回填
```
对比: voting_llm 579条有535条被回填T1（因为只在交易日写入）。
**根因**: backfill cron查`WHERE realized < 3 AND trade_date < today`，找到了记录，但拉日K线时找不到7/5(周六)的收盘价→跳过。
**修复方向**: `_get_et_trade_date()`改为返回最近的**真实交易日**（周末前推到周五，考虑假日）。或直接查FTSeek的交易日历。

### HIGH-2: pipeline.run_full()没集成ic_writer和signal_gate

**模块**: pipeline.py `run_full()` Stage 3
**问题**: `run_analyze_only()`调了ic_writer.write_signal_snapshot和signal_gate.evaluate_signal，但`run_full()`的Stage 3循环里没有。cron如果调full模式→IC不写入→Gate不评估。
**代码验证**: 
- `run_analyze_only()` 第156-186行：有ic_writer + adapter + signal_gate ✅
- `run_full()` 第75-97行：只有data_collector + deep_analyzer + adapter，没有ic_writer/signal_gate ❌
**修复方向**: 在run_full() Stage 3的analysis循环后，对每个analysis调ic_writer和signal_gate（复制run_analyze_only的逻辑）。

### MEDIUM-3: cron prompt内容未验证

**模块**: cron job e0d574cc1a3c
**问题**: 完整prompt未检查。从preview看是"自动执行步骤"，但不确定调scan/analyze/full哪个模式。如果调scan模式→不写IC不跑Gate；如果调full模式→HIGH-2导致IC不写入。
**修复方向**: 检查cron完整prompt，确认调用方式。最安全是调`pipeline.py --mode analyze --symbol <从scan结果取top4>`。

### MEDIUM-4: adapter.to_exit_meta的conditions兜底用了非法枚举

**模块**: adapter.py 第248行
**问题**: `to_exit_meta`的conditions兜底是`["default"]`，但FTSeek 27个合法枚举里没有`"default"`。当voting_result的conditions为空时（如SKIP信号），exit_meta传非法值给FTSeek退出规则。
**代码**: 
```python
# adapter.py:248
"conditions": to_voting_result(analysis).get("conditions", ["default"]),
```
**修复方向**: 改为`[]`空列表（SKIP信号不进退出规则匹配）。

### MEDIUM-5: LLM论据溯源只有prompt约束，没有代码级后验证

**模块**: llm_synth.py
**问题**: v0.11加了"论据溯源清单"（24个真实数字）注入prompt，告诉LLM"必须引用这些数字不得编造"。但没有代码验证LLM输出的bull_case/bear_case中的数字是否真在溯源清单中。LLM仍可能编造。
**修复方向**: 加`_verify_numbers()`后验证函数——解析LLM输出中的数字，检查是否在溯源清单中。不在的标注⚠️或降级confidence。

### MEDIUM-6: feedback_loop用CST日期取交易

**模块**: feedback_loop.py 第42行 `_get_today_trades()`
**问题**: 用`datetime.now()`取今天日期，但FTSeek的trade_records用ET日期。CST 5:00跑时是ET 17:00同一天——恰好对齐。但如果cron时间偏移或非交易日跑，日期不匹配。
**修复方向**: 用ET时区的today（复用ic_writer的`_get_et_trade_date()`逻辑）。

### LOW-7: deep_analyzer的capital数据源永远空

**模块**: deep_analyzer.py `_analyze_capital()`
**问题**: 读`self.data.get("capital_flow", [])`和`"capital_distribution"`，但`data_collector.collect_all()`没采集这两个字段（不在14个数据源里）。capital永远是`{"_error": "no capital data"}`。
**验证**: NVDA实跑输出`"capital": {"net_main_flow": 0, "net_total_flow": 0, ...}`全0。
**修复方向**: 
- 选项A: data_collector加`collect_capital_flow()`（富途OpenD有`get_capital_flow`）
- 选项B: deep_analyzer去掉capital维度（如果资金面数据不可靠）

### LOW-8: strategy_memory的direction映射（验证结果：不是bug）

**模块**: strategy_memory.py `update_from_trade()`
**担心**: trade_records的direction可能是BUY/SELL_SHORT，而signal_gate的dir_map期望LONG/SHORT。
**验证**: 
```sql
SELECT DISTINCT direction FROM trade_records → 'SHORT', 'LONG', 'SHORT_PROXY_OPTION'
```
trade_records存的是LONG/SHORT，和signal_gate映射一致。**不是bug**。
但`SHORT_PROXY_OPTION`不在dir_map里——如果有这种方向的交易，pattern_memory会存原始值，signal_gate匹配时dir_map.get("SHORT_PROXY_OPTION")返回None→不匹配。影响极小（很少量的proxy option交易）。

## 审计方法论

### 第一步：读取全部模块源码
不是只读改过的文件——读全部11个模块。这次发现了adapter.py的`["default"]`和deep_analyzer的capital_flow问题，都是之前没碰过的文件。

### 第二步：跨模块数据字段追踪
对每个模块的输入输出，追踪数据字段是否在上游模块的输出中存在：
- deep_analyzer读`self.data.get("capital_flow")` → data_collector.collect_all()的返回里有没有`capital_flow`键？→ 没有 ❌
- signal_gate读`analysis.get("_ftseek", {}).get("voting_result", {})` → pipeline.run_analyze_only()是否设了`_ftseek`？→ 是 ✅
- pipeline.run_full()的analysis是否设了`_ftseek`？→ 否 ❌（只有run_analyze_only设）

### 第三步：验证FTSeek侧是否真的消费了数据
不只看deep_analysis侧写入成功——查FTSeek的backfill是否真的回填了：
```sql
SELECT strategy_id, COUNT(*), 
       SUM(CASE WHEN fwd_ret_t1 IS NOT NULL THEN 1 ELSE 0 END) as t1_filled
FROM signal_snapshots GROUP BY strategy_id;
```
结果: deep_analysis 15条0回填 vs voting_llm 579条535回填 → deep_analysis的IC写入有问题。

### 第四步：检查兜底值和默认值
每个`.get("key", default)`的default值是否合法：
- `to_voting_result(analysis).get("conditions", ["default"])` → "default"在27枚举里吗？→ 不在 ❌
- `_map_conditions` SKIP时返回`[]` → 空列表合法吗？→ 是 ✅（v0.5已修复）

### 第五步：cron调用链验证
cron的prompt完整内容必须检查——不只看schedule和workdir：
- cron调的是pipeline的哪个mode？
- 那个mode是否调了ic_writer和signal_gate？
- cron环境是否用对了python？
