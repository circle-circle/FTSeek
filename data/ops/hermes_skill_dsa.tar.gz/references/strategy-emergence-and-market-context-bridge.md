# 策略涌现分析 + 市场上下文桥接层设计

## 一、从交易数据涌现的可收益规则（362笔真实交易挖掘）

### 规则1：不开盘前后30分钟入场

方向×时段 PnL矩阵（CST时间，ET=CST-12h）：

| 时段 | 方向 | 笔数 | WR | PnL |
|------|------|------|-----|-----|
| 开盘前后(21-22h CST) | SHORT | 55 | 33% | **-$9382** |
| 开盘前后(21-22h CST) | LONG | 65 | 29% | -$2210 |
| 上午盘(23-1h CST) | SHORT | 81 | 46% | **+$7222** |
| 上午盘(23-1h CST) | LONG | 41 | 27% | +$878 |
| 午盘(2-4h CST) | SHORT | 39 | 41% | +$2592 |
| 下午盘(14-16h CST) | SHORT | 8 | 75% | +$339 |

**洞察**：开盘前后30分钟（ET 9:00-10:00）信号质量最差。等1小时后入场，SHORT胜率33%→46%，PnL从-$9382→+$7222。

### 规则2：SHORT+快止盈是当前市场最赚的setup

退出方式盈亏比表：

| 退出方式 | 方向 | 笔数 | WR | avgWin | avgLoss | PnL | 盈亏比 |
|----------|------|------|-----|--------|---------|-----|--------|
| DAY_TRADE_TP | SHORT | 11 | 100% | $981 | $0 | $10786 | ∞ |
| EOD_FORCE_CLOSE | SHORT | 9 | 78% | $206 | $62 | $1315 | 3.3 |
| TRAILING_STOP | LONG | 43 | 44% | $367 | $189 | $2428 | 1.9 |
| TRAILING_STOP | SHORT | 41 | 59% | $299 | $578 | -$2652 | 0.5 |
| SL_ATR_STOP | LONG | 6 | 0% | $0 | $456 | -$2737 | 0.0 |
| sl_hit | LONG | 53 | 8% | $5 | $21 | -$995 | 0.3 |

**洞察**：SHORT+日内止盈(DAY_TRADE_TP/tp_hit)100%胜率。SHORT+TRAILING_STOP盈亏比0.5——让利润奔跑对SHORT反而亏。

### 规则3：LONG+SL_ATR_STOP是确定性亏损——必须BLOCK

LONG+SL_ATR_STOP：12笔0胜，PnL=-$5474，hold=0.1h（ATR止损太紧被日内噪音打掉）。
LONG+sl_hit：53笔4胜(8%)，PnL=-$995。

### signal_gate实现映射

1. **时间门禁**：入场时段检查，21-22h CST的信号降分或BLOCK
2. **方向×退出矩阵**：strategy_hint按direction查表——SHORT推荐DAY_TRADE_TP/EOD_FORCE_CLOSE，LONG推荐TRAILING_STOP
3. **硬规则BLOCK**：LONG+SL_ATR_STOP 0%胜率→Gate直接BLOCK

**注意**：这些pattern来自FTSeek历史交易(362笔)，不是deep_analysis的信号。deep_analysis信号质量要等IC样本积累后验证。

---

## 二、技术债清单（5项，按优先级）

### 🟡 应修

1. **ic_writer DST判断粗糙** — `3<=month<=11`把3月上旬(EST)和11月下旬(EST)错判为EDT，差1小时。修法：用`zoneinfo.ZoneInfo("America/New_York")`。影响小——backfill按trade_date匹配不按小时。

2. **market_scanner硬编码81个ticker** — 需手动维护，新上市热门股不加分。修法：按市值>$50B自动加分。当前列表覆盖主流标的，YAGNI。

3. **ic_writer模块级`_now = datetime.now()`** — 进程长期运行DST不更新。但cron每次新进程，影响极小。

### 🟢 可不修（YAGNI）

4. **deep_analyzer三个降级函数重叠** — `_rule_fallback`(LLM crash→SKIP) vs `_rule_synthesize`(强制rule→评分) vs `llm_synth._fallback_synthesize`。`_rule_fallback`应调`_rule_synthesize`。但LLM crash极少(DashScope稳定)，YAGNI。

5. **函数内重复`import re`** — llm_synth里3处内联。不影响功能(Python缓存import)，代码风格问题。

---

## 三、市场上下文桥接层——关键架构gap

### 问题：三系统各干各的

```
Deepulse雷达 ──→ theme_context.json ──→ FTSeek playbook读取 ✅
                                          ↓
deep-stock-analysis ──→ 16数据源采集 ──→ LLM分析 ──→ ❌ 不读theme_context
                                                      ❌ 不注入市场上下文
                                                      ❌ 不知道板块在轮动
```

deep-stock-analysis的LLM在分析NVDA时不知道"半导体板块BEARISH、资金从设备股切向存储芯片"——在真空中分析个股。

### 泛化问题

Deepulse只覆盖3个domain 23只股。如果scanner扫到KO/CAT/UBER，theme_context是空的。但FTSeek的premarket_scanner覆盖11个SPDR板块ETF（全市场），sector_leader有Livermore板块龙头检测——任何股票都至少属于一个GICS板块。

### FTSeek已有的市场上下文数据源（deep-stock-analysis未利用）

| 数据源 | 文件 | 覆盖 | 内容 |
|--------|------|------|------|
| premarket_scanner | app/us_pipeline/premarket_scanner.py | 全市场11板块 | SPDR ETF涨跌排名+经济事件+no_trade_windows |
| sector_leader | app/risk/sector_leader.py | 全市场 | Livermore板块龙头检测+相对强度 |
| economic_calendar | app/data/economic_calendar.py | 全市场 | FOMC/CPI/NFP日期+影响等级 |
| daily_battle_plan | data/daily_battle_plan_us.json | 全市场 | market_regime+VIX+factor_validation |
| theme_context | data/theme_context.json | 3 domain 23股 | Deepulse主题动量+叙事+催化 |
| premarket_scan_cache | data/premarket_scan_cache.json | 全市场11板块 | strongest/weakest板块+economic_events |

### 三层认知架构方案

**第一层：市场全景图（泛化到任何股票）**
- 读取premarket_scanner的11个SPDR ETF涨跌排名
- 读取sector_leader的Livermore龙头检测
- 读取economic_calendar的FOMC/CPI/NFP
- 读取daily_battle_plan的market_regime+VIX
- 融合成market_brief文本注入llm_synth的prompt
- **关键**：11个SPDR板块ETF覆盖全市场——任何股票都能查到它属于哪个板块+板块当日强弱

**第二层：交叉验证引擎（不是堆数据，是找共振）**
- 告诉LLM维度间的逻辑关系规则：
  - 个股技术破位 + 板块弱势 = 趋势确认(看空权重×1.5)
  - 个股技术破位 + 板块强势 = 可能假突破(看空权重×0.5)
  - 个股利好 + 板块弱势 = 板块拖累(看多但需等板块企稳)
  - VIX>25 + 任何信号 = 降仓位, 放宽止损
  - 宏观事件前3日 = 不开新仓

**第三层：情境记忆（特征向量匹配代替固定查表）**
- strategy_memory增加context_pattern表：
  - context_features: {"sector":"BEARISH","technical":"breakdown","insider":"net_sell"}
  - outcome: SHORT AVGO +$375 EOD_FORCE_CLOSE
- 查询时: 当前context_features → 找最相似的historical context → 返回"上次类似情境的结果"
- 不是direction×exit_reason固定组合——是特征向量相似度匹配

### 落地路径

新增两个模块（不重构现有系统）：
1. `market_context.py` — 读FTSeek已有数据，融合成market_brief，注入llm_synth prompt
2. `context_memory.py` — 扩展strategy_memory，增加context_pattern表，特征向量匹配

现有deep_analyzer/llm_synth/signal_gate/feedback_loop都不用改——只加一层"市场上下文"和"情境记忆"。

**泛化保证**：
- 11个SPDR板块ETF覆盖全市场任何股票
- 交叉验证规则方向无关（不限于特定股票）
- 情境记忆是特征匹配（不限于预定义组合）
- LLM做最终推理（不是查表出结果）
