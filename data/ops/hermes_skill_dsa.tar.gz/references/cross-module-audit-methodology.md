# 跨模块数据流审计方法论

> v0.12 总结论：模块导入✅ + API可达✅ + pipeline跑完✅ ≠ 跨模块数据流正确。
> 必须追踪数据字段在上下游模块间是否真正传递 + 查FTSeek侧是否真的消费了数据。

## 审计6步法

### 1. 读取全部模块源码（不只读改过的文件）
**问题**：只读改过的文件会漏掉没改但有bug的模块。v0.12发现ic_writer.py在v0.4"修复"后仍有非交易日bug——因为只改了时区没考虑周末/假日。

**方法**：`read_file` 全部模块（config/data_collector/market_scanner/llm_synth/deep_analyzer/adapter/ic_writer/strategy_memory/signal_gate/feedback_loop/pipeline），不只读本次改的。

### 2. 跨模块数据字段追踪
**问题**：deep_analyzer `_analyze_capital()` 读 `self.data.get("capital_flow", [])` 和 `"capital_distribution"`，但 data_collector `collect_all()` 没采集这两个字段 → capital永远空。

**方法**：对每个模块，列出它读的 `self.data.get("key")` 或 `analysis.get("key")`，然后查上游模块的输出里有没有这个key。

### 3. 验证FTSeek侧是否真的消费了数据
**问题**：ic_writer INSERT成功 ≠ FTSeek backfill真的回填了。deep_analysis 15条IC记录0条被回填，而voting_llm 579条535条被回填——说明FTSeek backfill不认识deep_analysis的trade_date。

**SQL验证**：
```sql
SELECT strategy_id, COUNT(*) as total,
       SUM(CASE WHEN fwd_ret_t1 IS NOT NULL THEN 1 ELSE 0 END) as t1_filled
FROM signal_snapshots GROUP BY strategy_id;
```
如果 t1_filled=0 而 total>0 → IC永远不回填。

### 4. 检查兜底值合法性
**问题**：`adapter.to_exit_meta()` 的 `conditions` 兜底用 `["default"]`，但FTSeek 27个合法枚举里没有 `"default"`。

**方法**：搜全部 `.get("key", default)` 调用，检查default值是否在FTSeek合法枚举里。

### 5. cron调用链验证
**问题**：cron prompt只看了preview，不确定调scan/analyze/full哪个模式。如果调full模式→run_full()没集成ic_writer→IC不写入。

**方法**：
```python
# cron配置在 ~/.hermes/cron/jobs.json
import json
with open("/root/.hermes/cron/jobs.json") as f:
    data = json.load(f)
jobs = data.get("jobs", [])
for j in jobs:
    if j.get("id") == "TARGET_JOB_ID":
        print(j.get("prompt", ""))  # 看完整prompt
```

### 6. 非交易日运行场景测试
**问题**：ic_writer `_get_et_trade_date()` 返回当前ET日期，但7/5周日跑时trade_date=2026-07-05(周六)→backfill找不到日K线。

**方法**：
```python
from datetime import datetime
dt = datetime(2026, 7, 5)
print(f"2026-07-05 is {dt.strftime('%A')}")  # Sunday
# 如果在非交易日运行，trade_date/today必须前推到最近的真实交易日
```

## v0.12 8个发现详情

### [HIGH] 1. ic_writer非交易日trade_date
- **根因**：`_get_et_trade_date()` 返回当前ET日期，周末/假日运行时trade_date=非交易日
- **修复**：周末前推到周五 + 已知假日检查(7/3独立日observed/7/4/12/25/1/1/11/26感恩节/11/27)
- **验证**：7/5周日→7/2周四(跳过7/3独立日observed) ✅
- **数据清理**：删除15条trade_date=2026-07-04(周六)/2026-07-05(周日)的错误记录

### [HIGH] 2. run_full()没集成ic_writer/gate
- **根因**：只有`run_analyze_only()`调了ic_writer和signal_gate，`run_full()`的Stage 3循环没有
- **修复**：Stage 3循环后加ic_writer.write_signal_snapshot + signal_gate.evaluate_signal + adapter 4格式
- **影响**：cron如果调full模式→IC不写入→Gate不评估

### [MEDIUM] 3. cron prompt调用mode
- **验证结果**：cron调scan+analyze模式(先scan取top，再对每只调analyze)，analyze已集成ic_writer。无需改。

### [MEDIUM] 4. adapter exit_meta兜底["default"]
- **根因**：`to_exit_meta` 的conditions兜底 `["default"]` 不在FTSeek 27合法枚举里
- **修复**：改为 `[]` 空列表

### [MEDIUM] 5. LLM溯源无代码验证
- **根因**：溯源清单只是prompt约束，没有代码验证LLM输出的数字是否真在溯源清单中
- **修复**：加 `_verify_sourced_numbers()` 后验证
  - 从collected提取所有真实数字(snapshot/fundamentals/insider/analyst)
  - 解析LLM输出bull_case/bear_case/constraints中的数字
  - 检查每个数字是否在溯源清单中(差异>0.5才算unverified)
  - 返回 verified_count/unverified_count/flagged_claims
- **NVDA验证**：17 verified / 35 unverified
  - unverified包括: 256(Itau BBA前目标价-来自新闻), -1602.7(历史PnL-来自strategy_memory), 203.49(MA20-来自技术面计算)
  - 这些是合理引用但溯源清单没覆盖的——可改进但当前后验证已在工作

### [MEDIUM] 6. feedback_loop用CST日期
- **根因**：`_get_today_trades()` 用 `datetime.now()` 取今天日期，但FTSeek trade_records用ET日期
- **修复**：加 `_get_et_today()` 用ET时区(UTC-4 DST/UTC-5 EST)

### [LOW] 7. capital数据源永远空
- **根因**：deep_analyzer读 `self.data.get("capital_flow")` 但data_collector没采集
- **修复**：data_collector加 `collect_capital_flow()` + `collect_capital_distribution()`
  - 调富途OpenD的 get_capital_flow.py / get_capital_distribution.py
  - collect_all从14源→16源
- **验证**：NVDA capital: net_main_flow=-5.5M, super_in=165M(有值了)

### [LOW] 8. direction映射
- **验证结果**：trade_records存LONG/SHORT(不是BUY/SELL_SHORT)，与signal_gate的dir_map一致。✅无问题。
