# DA吞吐量瓶颈 + 盘中诊断SILENT Bug (2026-07-14)

## 1. DA吞吐量实测数据

### Signal Snapshots
```
Total DA: 334
With T1 returns: 287 (足够算IC, 但alpha_backfill尚未跑)
With T5 returns: 15
```

### Bridge文件 (可交易候选)
```
7/8:  3只 (conf 0.70)
7/9:  4只 (conf 0.60-0.70)
7/10: 4只 (conf 0.25-0.35) ← WARN降confidence后
7/13: 4只 (conf 0.25-0.70)
```

### Instructions → Triggered → Executed
```
Date       Total  Trig  Exec  Win  Loss
7/9        5      1     2     0    0
7/10       8      3     3     0    3
7/13       4      3     3     2    1
────────────────────────────────────────
Total:     17     7     8     2    4 (void=1, missed=10)
```

触发率: 41% (7/17) — 主要因入场区间太窄
胜率: 33% (2/6已平仓) — 样本太小不具统计显著性

## 2. 三个限流瓶颈

### 瓶颈1: Pipeline候选数量上限
```python
# pipeline.py L27
scan_limit=10, top_n=5

# L61-63
deep_candidates = (
    scan_result.get("top_bullish", [])[:self.top_n] +  # 最多5只做多
    scan_result.get("top_bearish", [])[:2]              # 最多2只做空
)
# = 最多7只进入深度分析 → 实际输出3-4只BUY/SELL_SHORT
```

### 瓶颈2: 触发率41%
17条instruction里10条never triggered。入场区间(entry_low/entry_high)设计问题。
不是分析质量问题, 是entry_band逻辑问题。

### 瓶颈3: 低confidence → 小仓位
7/10候选conf只有25-35%。KO conf=25%赢了$10.92但仓位极小。

## 3. 提升方案(不降原则)

| 改动 | 影响 | 是否降原则 |
|------|------|-----------|
| scan_limit 10→15, top_n 5→8 | 每日候选7→11只 | ❌ 不降 |
| top_bearish[:3]替代[:2] | 增加做空覆盖 | ❌ 不降 |
| 入场区间适度放宽 | 触发率41%→60%+ | ⚠️ 需看entry_band |
| gate BLOCK阈值不变 | 质量门禁维持 | ✅ 保持 |

## 4. 盘中诊断SILENT Bug

### 现象
intraday-diagnose cron (job_id=36cc015242ee) 正常运行:
- Schedule: `*/30 22-23,0-4 * * 1-5` (每30分钟, CST 22:00-04:00)
- Status: enabled, last_status=ok
- Output文件正常生成在 `/root/.hermes/cron/output/36cc015242ee/`

但用户从未收到飞书推送。

### 根因
cron prompt的SILENT规则矛盾:
```
规则说:
  Option A: 输出完整报告 (不加[SILENT])
  Option B: 输出[SILENT] (什么都不说)

LLM行为:
  "系统正常运行, 无新问题" → 触发"nothing new" → 加[SILENT]
  同时又输出了完整status report
  → 违反"不可同时输出内容+[SILENT]"
  → delivery系统抑制整条消息
```

### 验证
```
ls /root/.hermes/cron/output/36cc015242ee/ | tail -5
```
检查最近输出文件, 大部分以 `[SILENT]` 结尾 → 全部被抑制。

### 修复方向
盘中诊断cron去掉SILENT规则。状态报告本身就是用户要看的内容, 不该被静默。
或改为: 只在所有指标正常且无变化时静默, 有任何状态变化就报告(不加[SILENT])。

## 5. IC归属错误教训

讨论DA macro reasoning能力时, 用IC=-0.067论证DA没有预测力。
但IC=-0.067是voting_llm的IC(已废弃), 不是DA的。

验证命令:
```sql
SELECT strategy_id, COUNT(*) FROM signal_snapshots GROUP BY strategy_id;
-- voting_llm: 806, deep_analysis: 334
```

DA的IC需要等alpha_backfill跑完后才能计算, 目前是开放问题。
