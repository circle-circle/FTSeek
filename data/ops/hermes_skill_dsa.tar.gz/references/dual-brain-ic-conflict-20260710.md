# 双脑IC冲突根因与修复 — 2026-07-10

## 状态: 已修复 (A+B+C 三组方案, factor_ic_backfill.py)

## 冲突现象

`valuation_cheap` 在两条 IC 管道给出矛盾结论:

| 管道 | 位置 | 指标 | 值 | 分类 |
|------|------|------|-----|------|
| A (claim_ic) | skill侧 alpha_backfill.py | avg_alpha_t1 | -0.59% | INEFFECTIVE |
| B (factor_ic) | FTSeek侧 factor_ic_backfill.py | IC (Pearson) | +0.786 | ✅正alpha |

## 两条管道的完整解构

| 维度 | Pipeline A (claim_ic) | Pipeline B (factor_ic) |
|------|----------------------|------------------------|
| 返回指标 | `alpha_t1` (= fwd_ret - spy_ret, 剥离beta) | `fwd_ret_t1` (方向调整收益, 含beta) |
| 相关方法 | Spearman rank | Pearson |
| 强度处理 | raw strength (不翻转) | signed: LONG=+str, SHORT=-str |
| 样本范围 | deep_analysis-only (72) | ALL strategies pooled (342+) |
| NEUTRAL | 包含 | 排除 |
| 分类判据 | avg_alpha符号 (>+0.2%=有效) | IC > 0.05 |

## 关键发现: fwd_ret_t1 已经是方向调整过的

这是理解整个冲突的钥匙。

**验证 (RIVN SHORT信号):**
```
raw_return = +8.76% (stock went UP)
fwd_ret_t1 = -8.06% (= -raw, 方向已调整, SHORT correct = positive)
alpha_t1 = fwd_ret - spy = -8.06% - 0.85% = -8.90%
```

- LONG: `fwd_ret_t1 = raw_return` (stock up = positive)
- SHORT: `fwd_ret_t1 = -raw_return` (stock down = positive = SHORT correct)
- `alpha_t1 = fwd_ret_t1 - spy_ret_t1` (也方向调整过的超额收益)

代码注释 (alpha_backfill.py L272-273):
> "fwd_ret_t1已经按方向调整过了 (LONG=正涨, SHORT=正跌)"

## 根因 (3层, 按重要性排序)

### 根因1 (决定性): Pearson被单一极端值绑架

Pipeline B的 IC=0.786 看似"高度有效"。去掉 RIVN 一个信号后:

```
全部18个非NEUTRAL: Pearson(signed_str, fwd_ret) = 0.786
去掉RIVN后(17个):  Pearson(signed_str, fwd_ret) = -0.032
```

1 个 RIVN SHORT 信号(str=30, fwd_ret=-8.06%) 决定了整个 IC 的符号和量级。
Pearson 对极端值极度敏感; Spearman rank 天然抗极端值。

### 根因2: 双重方向调整

`fwd_ret_t1` 已是方向调整过的 (SHORT=-raw)。Pipeline B 又对 strength 做了方向调整 (SHORT=-str)。数学上:
- LONG: Pearson(+str, +raw) = Pearson(str, raw)
- SHORT: Pearson(-str, -raw) = Pearson(str, raw)

→ Pipeline B = Pearson(strength, raw_return) — 方向调整被抵消, 测的是"置信度是否预测个股raw收益"而非PnL。

### 根因3: IC ≠ 盈利能力

- IC高 = "置信度与收益相关" (预测力)
- avg_alpha高 = "持有这个因子的信号平均跑赢大盘" (盈利能力)

高IC + 负avg_return = "能预测但预测方向亏钱"。

Pipeline B 用 IC>0.05 标 "✅正alpha" — 概念错误。valuation_cheap 实际: IC=0.786 但 avg_alpha=-1.11%。

## 可信管道判定

**Pipeline A (claim_ic) 可信:**
1. Spearman 抗极端值
2. 用 alpha_t1 (剥离大盘 beta)
3. avg_alpha 分类 (盈利能力, 非预测力)
4. deep_analysis-only (不混入异构 taxonomy)

**Pipeline B (factor_ic) 修复前不可信:**
1. Pearson 被极端值绑架
2. 双重方向调整
3. IC 作为盈利标签 (概念错误)
4. 混入 voting_llm 异构样本

## 修复: A+B+C 三组方案

**文件**: `/opt/ftseek/FTSeek-US/scripts/factor_ic_backfill.py` (~30行 surgical edit)

### 方案A: 补存 avg_alpha 字段
- SQL 加 `alpha_t1` 列
- 每个因子计算 `avg_alpha = mean(alpha_t1)` (无alpha时降级用fwd_ret)
- `factor_ic_latest.json` 每个因子增加 `avg_alpha` 字段
- 下游消费者可查盈利能力, 不仅看IC

### 方案B: Pearson → Spearman rank
- `calc_ic` 函数从 Pearson 改为 Spearman
- 消除极端值绑架: IC 从 0.786 → 0.106
- 与 Pipeline A 方法一致

### 方案C: 去掉 strength signed 翻转
- `fwd_ret_t1` 已方向调整, 不需要再翻转 strength
- 原: `signed = str if LONG else (-str if SHORT else None)`
- 新: `strength = r["strength"]` (raw, 不翻转)
- 消除双重方向调整

### 修复后验证

```
valuation_cheap:
  BEFORE (signed Pearson): IC=+0.7860, avg_alpha=N/A
  AFTER  (raw Spearman):   IC=+0.1062, avg_alpha=-1.11%
```

IC 从 0.786 暴跌到 0.106 — RIVN 极端值不再绑架。
avg_alpha=-1.11% 首次可见 — 下游可查到"这个因子实际亏钱"。

### 下游消费者影响

3个消费者读 `ic` 和 `n` 字段 (仍存在, 值改变):
1. `pipeline.py` L917-963: 方向冲突门 (net IC score, n>=30 gate)
2. `screener.py` L187-210: 因子权重调整 (+1/-1, n>=30 gate)
3. `model_agent.py` L193-223: prompt 展示 IC tag (n>=5)

`avg_alpha` 是新增字段, 纯增量, 不影响现有逻辑。
未来可将分类判据从 IC-based 切换到 avg_alpha-based。

## 审查文档验证

审查文档 (`docs/reviews/2026-07-10_deep-analysis-claim-ic-conditions.md`) 声称的7组改动全部通过代码+数据交叉验证, **无虚构**。

关键验证:
- #1 IC符号反转: 6个claim确实IC/alpha符号冲突, 5个翻转 ✓
- #2 strategy_id隔离: 342→72 样本 ✓
- #4 claim_type覆盖: 30/30近期snapshot有claim_type ✓
- #7 trade_ic自相关: factor_ic_latest无trade_ic字段 ✓
- #8 _extract_factors: 3种形态归一化, 13个claim_type首次进入factor_ic ✓
