# IC分方向拆解 + Strength倒挂 + 4h生死线 + 退出调优 — 2026-07-08

## Session Context

用户要求"更真实客观的解决优化方案 需要尽快改进 提升胜率和盈利目标以及数据质量，请充分思考辩论"。
多DB实算: signal_snapshots.db(763条信号) + ftseek_us.db(391笔交易) + decisions.db(model_votes)。

## Finding 1: IC分方向拆解 — LONG IC为负 (P0)

**Data**: signal_snapshots.db 524条非NEUTRAL信号

| 策略 | 方向 | n | IC | T1胜率 | 诊断 |
|---|---|---|---|---|---|
| voting_llm | LONG | 293 | **-0.0674** | 54.6% | 🔴 负IC: strength越高LONG回报越差 |
| voting_llm | SHORT | 231 | +0.0592 | 52.8% | ⚠️ 微弱正IC，接近随机 |
| voting_llm | NEUTRAL | 54 | — | **0.0%** | 🔴 完全无用，浪费扫描预算 |
| deep_analysis | LONG | 11 | +0.6242 | 90.9% | ✅ 但n=11，远未达30门槛 |

**关键**: 全局IC=0.1075掩盖了LONG方向IC为负。voting_llm对LONG方向是反指标——高strength=错方向。

**计算方法**:
```sql
-- Per-direction IC: 取strength和direction-adjusted fwd_ret_t1，按方向分组算Pearson
SELECT strength, fwd_ret_t1, direction
FROM signal_snapshots
WHERE strategy_id='voting_llm' AND fwd_ret_t1 IS NOT NULL AND direction != 'NEUTRAL'
-- adj_ret = fwd_ret_t1 if LONG else -fwd_ret_t1
-- Pearson(strength, adj_ret) per direction
```

## Finding 2: Strength与实盘结果倒挂 (P0)

**Data**: ftseek_us.db 391笔交易

| Strength区间 | n | 胜率 | 总PnL | 诊断 |
|---|---|---|---|---|
| low(<40) | 172 | **44.8%** | **+$6,437** | ✅ 最低strength最赚 |
| mid(40-55) | 10 | 20.0% | -$581 | ⚠️ 样本少 |
| high(55-70) | 102 | 20.6% | +$2,816 | ⚠️ 胜率低但PnL正(DAY_TRADE_TP大单) |
| vhigh(70+) | 107 | 42.1% | **-$1,101** | ❌ 最高strength反而亏钱 |

**根因**: 高strength=高consensus=04:xx模板投票(见Finding 5)→错误方向集中→亏损。

## Finding 3: 退出P&L — 主动退出=亏损引擎 (P0)

**Data**: ftseek_us.db 391笔

| 类型 | 退出方式 | n | 胜率 | 总PnL | avg PnL |
|---|---|---|---|---|---|
| ✅被动 | DAY_TRADE_TP | 13 | 100% | +$13,101 | +$1,008 |
| ✅被动 | PRE_CLOSE_EXIT | 34 | 44% | +$7,587 | +$223 |
| ✅被动 | EOD_FORCE_CLOSE | 14 | 86% | +$1,786 | +$128 |
| ❌主动 | sl_hit | 115 | 17% | -$2,023 | -$18 |
| ❌主动 | TRAILING_STOP | 85 | 51% | -$3,802 | -$45 |
| ❌主动 | STRUCTURE_EXIT | 33 | 30% | -$3,106 | -$94 |
| ❌主动 | TIME_EXIT | 16 | 38% | -$1,215 | -$76 |

**汇总**: 主动退出249笔总亏**-$10,146**；被动退出61笔总赚**+$22,473**。系统越"管理"越亏。

## Finding 4: 4h生死线 (P0)

| 持仓时段 | n | 胜率 | PnL | 诊断 |
|---|---|---|---|---|
| 0-1h | 116 | 30% | +$2,344 | 快速止损，PnL正 |
| 1-2h | 28 | 50% | +$804 | 持平 |
| **2-4h** | 49 | 47% | **-$10,229** | 🔴 死亡区间 |
| **4-8h** | 38 | **74%** | **+$14,573** | ✅ 黄金时段 |
| 8-24h | 25 | 68% | +$8,013 | 过夜前窗口 |
| 24h+ | 135 | 21% | -$7,934 | 隔夜灾难 |

**7/7验证**: 4/5亏损交易持仓0.4-3.1h(SL/TIME杀掉)，唯一赢家TSLA持仓5.8h(PRE_CLOSE)。

## Finding 5: 04:xx批次模板投票实锤 (P0)

**Data**: decisions.db model_votes表

| 模型 | strength值 | 出现次数/38 | 占比 |
|---|---|---|---|
| deepseek_v4_pro | 47 | 20 | 53% |
| deepseek_v4_pro | 37 | 18 | 47% |
| qwen3.7_max | 45 | 18 | 47% |
| glm_5_2 | 50 | 16 | 42% |

38只股票全部投37/47或35/45——std<3，未被标记degraded→污染consensus。

**审计SQL**:
```sql
SELECT mv.model_id, mv.strength, COUNT(*) as n
FROM model_votes mv
JOIN decisions d ON mv.decision_id = d.decision_id
WHERE d.created_at LIKE '2026-07-07T04%'
GROUP BY mv.model_id, mv.strength
ORDER BY n DESC;
-- 若任意(model_id, strength)组合 n>5 → 模板/fallback值
```

## Finding 6: 方向×策略P&L

| 方向 | n | 胜率 | PnL | 诊断 |
|---|---|---|---|---|
| LONG | 169 | 29.6% | **-$5,865** | 系统性亏损 |
| SHORT | 209 | 44.5% | **+$25,893** | 唯一利润来源 |
| SHORT_PROXY_OPTION | 13 | 15.4% | **-$12,457** | 灾难，应禁用 |

| 策略 | n | 胜率 | PnL |
|---|---|---|---|
| voting_llm | 182 | 42.3% | **-$13,371** |
| playbook_sim | 32 | 46.9% | -$871 |
| playbook_shadow | 23 | 56.5% | +$242 |
| manual_sync | 8 | 87.5% | +$3,655 |

## 已实施的改动 (v0.21)

### 改动1: playbook_horizon.yaml (3处config)

```yaml
# factor_exit_rules.default:
time_exit_hours: 2.0 → 4.0      # 跨过2-4h死亡区间
breakeven_at_pct: 0.5 → 1.5     # 减少0.5%假保本出场

# short_horizon:
buy_fixed_stop_loss_pct: 2.5 → 3.0  # BA 1.80%不该出现
```

### 改动2: pipeline.py deep_analysis LONG门禁

位置: `_build_instructions_from_votes()` BUY方向过滤链末尾(MACD/MA50审计前)
逻辑: 查signal_snapshots.db当日deep_analysis对该股判断
- deep=LONG → 放行(有背书)
- deep≠LONG → SKIP(不认同)
- 无记录 → 放行(故障隔离, 避免deep宕机时全部SKIP)
- 查询失败 → 放行(只警告不阻断)
filter_audit增加3个计数器: buy_no_deep_endorsement / buy_no_deep_analysis / buy_deep_query_error

### 验证结果

| 测试 | 结果 |
|---|---|
| YAML解析(3个值) | ✅ |
| Python语法(pipeline.py) | ✅ |
| 功能测试(NVDA=LONG→PASS) | ✅ |
| 功能测试(MU=NEUTRAL→BLOCK) | ✅ |
| 功能测试(TSLA无记录→ALLOW) | ✅ |
| import+代码存在 | ✅ |
| PlaybookConfig加载 | ✅ |
| FTSeek重启(PID 351598) | ✅ |
| 运行系统全验证 | ✅ |

## 优化方案优先级矩阵

| 优先级 | 改进 | 影响路径 | 预期效果 | 冻结期可做 | 状态 |
|---|---|---|---|---|---|
| P0 | LONG需deep_analysis背书 | 执行层 | 砍LONG系统性亏损-$5,865 | ✅ | ✅ 已实施 |
| P0 | SL固定→ATR分桶(配置调优) | 退出层 | 减少假止损 | ✅ | ✅ 已实施 |
| P0 | 04:xx模板投票过滤(std<3) | 信号层 | 清除consensus污染 | ✅ | 待实施 |
| P1 | NEUTRAL不生成instruction | 信号层 | 节省预算 | ✅ | 待实施 |
| P1 | time_exit 2h→4h | 退出层 | 跨过死亡区间 | ✅ | ✅ 已实施 |
| P1 | SHORT_PROXY_OPTION禁用 | 执行层 | 止血-$12,457 | ✅ | 待实施 |
| P2 | T5/T20回填修复 | IC层 | 启用长期反馈 | ✅ | 待实施 |
| P2 | deep_analysis top 2→5 | IC层 | 加速graduation | ✅ | 待实施 |

## 三个根因联动

模板投票(04:xx) → 错误consensus → 错误方向+错误strength → 窄SL在错误方向上快速止损 → 亏损。
修任何一个都不够，必须同时修。

## 多DB诊断路径

| DB | 表 | 用途 | 关键注意 |
|---|---|---|---|
| data/signal_snapshots.db | signal_snapshots | IC+forward returns | trade_date=ET日期 |
| data/ftseek_us.db | trade_records | 交易PnL+退出+持仓 | 主交易DB(391笔) |
| data/decisions.db | model_votes | 投票模板检测 | 无degraded_vote列 |
| data/ftseek_us_live.db | trade_records | 实盘(17笔,多为manual) | 字段名与ftseek_us.db不同 |
| data/trade_records.db | trade_records | 独立文件(空) | 不用这个 |

## 审计SQL模板

```sql
-- IC by direction (signal_snapshots.db)
SELECT direction, COUNT(*) as n,
       SUM(CASE WHEN fwd_ret_t1 IS NOT NULL THEN 1 ELSE 0 END) as t1_filled,
       AVG(CASE WHEN fwd_ret_t1 IS NOT NULL THEN fwd_ret_t1 END) as avg_t1
FROM signal_snapshots WHERE strategy_id='voting_llm'
GROUP BY direction;

-- Exit reason P&L (ftseek_us.db)
SELECT exit_reason, COUNT(*) as cnt,
       SUM(CASE WHEN realized_pnl > 0 THEN 1 ELSE 0 END) as wins,
       ROUND(SUM(realized_pnl), 2) as pnl
FROM trade_records WHERE realized_pnl IS NOT NULL
GROUP BY exit_reason ORDER BY pnl DESC;

-- Holding time vs PnL (ftseek_us.db)
SELECT CASE WHEN holding_hours < 2 THEN '0-2h'
            WHEN holding_hours < 4 THEN '2-4h'
            WHEN holding_hours < 8 THEN '4-8h'
            WHEN holding_hours < 24 THEN '8-24h'
            ELSE '24h+' END as bucket,
       COUNT(*), SUM(CASE WHEN realized_pnl > 0 THEN 1 ELSE 0 END) as wins,
       ROUND(SUM(realized_pnl), 2) as pnl
FROM trade_records WHERE realized_pnl IS NOT NULL
GROUP BY bucket;

-- Strength vs outcome (ftseek_us.db)
SELECT CASE WHEN signal_strength < 40 THEN 'low'
            WHEN signal_strength < 55 THEN 'mid'
            WHEN signal_strength < 70 THEN 'high'
            ELSE 'vhigh' END as bucket,
       COUNT(*), SUM(CASE WHEN realized_pnl > 0 THEN 1 ELSE 0 END) as wins,
       ROUND(SUM(realized_pnl), 2) as pnl
FROM trade_records WHERE realized_pnl IS NOT NULL AND signal_strength IS NOT NULL
GROUP BY bucket;

-- 04:xx template vote detection (decisions.db)
SELECT mv.model_id, mv.strength, COUNT(*) as n
FROM model_votes mv
JOIN decisions d ON mv.decision_id = d.decision_id
WHERE d.created_at LIKE '2026-07-07T04%'
GROUP BY mv.model_id, mv.strength
ORDER BY n DESC;
```

## FTSeek重启方法

ftseek_us.sh的stop用`pkill -f "ftseek_us"`但实际进程名是`main.py --start`，pkill匹配不到。
需要直接kill PID:
```bash
# 获取PID
pgrep -af "main.py.*--start"

# SIGTERM → 等3s → SIGKILL if still running
kill -TERM <PID>; sleep 3
kill -9 <PID>  # if still running

# 启动
cd /opt/ftseek/FTSeek-US && bash ftseek_us.sh start
```
