# DA skill 版本史 (CHANGELOG)

> **来源**: 2026-09-06 从 `../SKILL.md` frontmatter `description` 字段**逐字迁出**（原字段 8,766 字符，占当时全文 7.8%）。
> **迁移理由**: frontmatter `description` 是技能的**选择期**载荷（三段披露第 1 段：name/description 在技能被选用前就可见），
>   应当「短而可判别」；把 16 个版本的 changelog 塞在里面 = 每次技能路由都要读一遍历史，且不改变任何决策。
> **纪律（单一真源）**: 本文件是版本史的唯一载体；SKILL.md frontmatter 只保留 `version:` 一行。
>   `pipeline.py:1080` 按 `^version:\s*(\S+)` 解析该行，作为每条 bridge 记录 `skill_version` 的**单一真源** —— 格式不可破。
> **⚠️ 改 skill 代码的提交必须同步改 SKILL.md 的 `version:`** —— 已发生两次漏更（v0.74.2 / v0.75，详见 v0.75 条），
>   后果是 9/1–9/4 四天的 bridge 全部错记版本号，归因基线无法切分。
> **条目内描述若与现役代码矛盾，以代码为准**（代码是行为的 SSOT，本文件只记「当时改了什么、为什么」）。

---

## v0.97 (2026-11-09)

**DA 推荐证据卡 v1 (record-only，用户裁「基于缺口做好补充和优化」)**:

- 新增 `recommendation_evidence.py`，把原始新闻引用、精确论点链接、市场数据时点、价格/行业对齐、
  挑战者反证与 evidence gaps 组成统一证据卡；新闻引用明确 `UNADJUDICATED`，不冒充已裁决利好/利空事件。
- `pipeline.py` 在分析后挂卡，并透传 bridge candidate 与 `raw_instruction.recommendation_evidence`；
  挂卡失败只落 `status=ERROR`，不抛给候选主流程。无 DB schema、cron、notifier 或 Playbook 执行契约变更。
- 不改生产 prompt、PROMPT_HASH 语义、Signal Gate、admission、VIX、仓位、候选数量或执行参数；
  不接入仓内离线 `app/event_stream` 原型，不改写历史 raw/checkpoint。
- 消费者/复现器：FTSeek `scripts/da_recommendation_evidence_replay.py`；36 份 2026-11-06 raw 回放
  36→36、prompt 36/36 不变、输入 36/36 未变异，LLM/DB/checkpoint 写入均为 0。
- 基线同时暴露未闭环项：174 条 bull/bear 论点只有 2 条可按完整标题精确链接新闻（其余不模糊硬配）；
  旧 raw 行业口径不支持相对收益回填，VIX 历史代理无观测日历日也不补造。详见 DEB-20261106 §61。

## v0.96 (2026-10-14)

**fresh-event 批 origin 三源分账 (RFC-136 execute 转正, 用户裁决 2026-10-14)**:

- 病灶: Path A (da_feed 并入 DA 主链) 与 Path B (premarket fresh-event 批) 的指令
  在 raw_instruction_json 里同为 origin="ue_candidate" — 两条供料链无法分账,
  违背用户"交易标的源头分类"要求 (execute 转正的前置条件③)。
- 修复: Stage 6b 两处 origin 写入点按 `self.ue_only` 分流 — fresh-event 批
  (ue_only=True) 写 origin="ue_fresh_event", Path A 仍 "ue_candidate", DA 自选仍 ""。
  字面量不含 universe_expansion (scorecard 归因不受扰)。
- 消费端: FTSeek source_attribution rfc117_v2→v3 新增 'DA-UE新事件' 腿
  (CASE 序在 ue_candidate 腿之前, 防 raw 同含两字面量时误归)。
- 同批 (FTSeek 侧): da_fresh_event_batch --execute 转正 (clobber 防护: output_dir
  两模式恒隔离, 生产触点仅 DB 指令; 当日已有指令标的去重防 UPSERT 覆盖) +
  UE brief 借券快照段 (ADR-046, 修 10-02 起空头供给归零)。

## v0.95 (2026-10-08)

**G2 方向冲突择时闸降为纯记录 (DEB-20261008 F2, 用户裁决)**:

- 背景: DEB-20261008 六道方向闸普查实测 — 模型自身提案 77.0% 多头 (闸只 +1.6pp),
  但 G2 (dir_conflict → tier 降2档) 净压空头: 近 15 交易日 SHORT 存活率 66.1% (37/56)
  vs BUY 78.7% (148/188), 与「多空不人为拦截限定」裁决冲突。
- 改动: `signal_gate.py` dir_conflict 命中时不再降 tier, 只向 reasons 留痕
  (「择时记录: …仅留痕不降档」); 判定人口不变 (仍限 tier∈优/良/中, 与历史序列同口径)。
- 2026-10-08 独立复查修正: 同步删除 `quality_score -= 10`; F2 语义从「不降 tier」
  收紧为「完全不产生方向冲突扣分/降档, 仅留痕」。
- 不动: G1 破位硬买门 (bearish+BUY→SKIP) 保留 — 防接飞刀, 用户裁决保留;
  G3/G4/G5/G6 在主仓侧 (F1 同批摘组合层三闸, 见主仓 handoff)。
- 回滚: signal_gate.py 恢复 tier 降2档分支 (ladder 三行), 版本退回 0.94。
- 零 prompt 变更 (PROMPT_HASH 不变), 零门槛/阈值/仓位变更; 纯判定层语义修改。
- 2026-10-13 追加 (v5 五模型链路审计取证): `llm_synth.py` list 型数据源
  (sentiment/kline/news/research) 读取处补 isinstance 归一化 — executor 异常写入
  {"_error":..} dict 时原 `sentiment[:5]` 抛 TypeError。附 tests/test_sentiment_error_dict.py
  (4 项全绿, 先复现后修复)。零 prompt 变更 (PROMPT_HASH 不变)。

---

## v0.94 (2026-10-07)

**fresh-event schema兼容 + 大盘行情趋势/扫描广度贯通**:

- `opportunity_scan` 旧 schema 的 `candidate_count` 在 `Pipeline.run_full` 与候选过滤漏斗两处均可回退; 2026-10-07 09:12 首跑 `KeyError: candidates_total` 不再复发。
- `collect_market_context()` 新增代码化 `market_trend`: SPY/QQQ 盘前快照按实际涨跌判定 `UP/DOWN/MIXED`, 日线按既有 `MA/涨跌` 判定单独输出, 两口径不互相覆盖。
- `collect_industry_peers()` 新增代码化 `industry_trend`: 同业peer均值按「今日/5日/综合」输出 `UP/DOWN/FLAT/MIXED`, 零peer如实 `UNKNOWN`; `llm_synth` 在「行业对比」渲染。
- DA 每个候选的 `market_context` 注入 `scan_condition` (当日候选池广度), `llm_synth` 在「大盘环境」渲染扫描广度与代码判定趋势; 仅改数据段, `PROMPT_HASH` 基线不变。
- 修正板块涨跌口径错标: `sector_changes` 来自板块ETF当前快照, prompt 标签从「上一交易日板块涨跌」改为「当前快照板块ETF涨跌」; 「上一交易日」仅保留给带日期守卫的 `sector_pulse`。
- FTSeek 侧配套: `da_bridge_dingtalk_push.py` 读取生产DB最终指令状态, 推送与 `da_push_instruction_summary.jsonl` 台账区分 bridge候选数、DB可交易数与 guardrail SKIP数 (2026-10-07 为 5候选/5指令/2可交易/3SKIP)。
- 回滚: 还原本批 `pipeline.py`/`llm_synth.py`/`data_collector.py` 改动; 不涉及阈值、方向或仓位。

---

## v0.93 (2026-10-06)

**DA 主链窗可见化 + 退出码吞没根因修 + ET 钟换 zoneinfo 真源**（2026-10-06 复查批 P1-b/P1-c, 用户裁「请修复优化异常问题」）：

- **退出码吞没根因修**: `__main__` 收尾原只计算 `_exit_code` 不使用 — 线程干净时解释器照常 exit 0, **所有失败路径** (`sys.exit(1)`/未捕获异常/窗拒绝) 全部被吞成「成功」。实测钉案: `--mode analyze` 缺 `--symbol` → 修复前 exit=0。修复: 收尾追加 `sys.exit(_exit_code)` (`os._exit` 强退路径不返回, 不受影响)。
- **DA 主链窗拒绝退出码非对称** (复查 P1-b): `DA_MAIN_ET_WINDOW` 过早拒绝 (hm<755, DST off-season 载体预期发车) 维持 skip JSON + exit 0; **过晚拒绝 (hm>815, 活跃季启动延迟越过窗尾) exit 2** — 不再与「跑了没事」同貌。背景: EDT 季 agent job 启动延迟 10-06 实测余量仅 4.2min, 超窗即 DA 全天零指令且 exit 0 静默。退出码约定: 0=正常/契约内跳过, 1=异常, 2=迟发窗拒绝, 124=timeout。
- **`_et_now()` 换 zoneinfo 真源**: 原按容器本地月份硬编码 offset (`3<=month<=11 → -4h`) 在 11 月 (EST 已生效) 与 3/1~3月第二个周日 (EDT 未生效) **钟错 1h** — 实测 2026-11-05 21:00 CST 发车: 真实 08:00 EST (窗内), 旧启发式读成 09:00 (窗外错拒 EST 季载体)。与 `llm_universe_scan._now_et` 8/26 修复同款病灶。tzdata 缺失时回退旧月份近似。
- 回滚: 三处均为 pipeline.py 单文件改动, `git revert` 即可; 退出码约定变更影响面 = 调用方 (agent job prompt 同批已补 skip 分支 / da_main_carrier 原样透传 rc / da_fresh_event_batch 走 `--fresh-event` 豁免不经过窗门)。

---

## v0.92 (2026-10-06)

**UE premarket fresh-event → DA same-day incremental candidate batch**（用户裁「当日新鲜事件做当日候选池」；先影子、后执行）：

- `_load_ue_short_candidates` 增加显式 `window` 参数（默认仍 `da_feed`，常规主链零变化）；`premarket` 仅供当日新鲜事件增量批消费，继续保持批次完整性/时效/窗口隔离。
- `Pipeline` 增加 `ue_window` / `ue_only`；CLI 新增 `--ue-window` 与 `--fresh-event`。fresh-event 批复用当日 `opportunity_scan` 市场上下文，跳过 Stage 1 重扫，只分析 UE premarket 候选（仍走 DA 数据采集、多模型分析、信号门、桥接与指令写出）。
- 常规 `--mode full`（非fresh-event）增加 DA主链 ET 07:55-08:15 启动窗；DST off-season发车输出 `DA_MAIN_ET_WINDOW` skip JSON，不扫描/不调LLM/不写库。人工补跑继续用 `--force`。
- FTSeek 新增 `scripts/da_fresh_event_batch.py`：默认隔离影子（`--no-db-write --no-pool-write --output-dir data/shadow/da_fresh_event/<ET日期>`），带 ET 0900-0929 启动窗、交易日、UE批次时效、当日幂等与事件审计；`--execute` 才写生产 DA 指令。
- 回滚：删除 fresh-event cron/调用；`--ue-window` 不传时常规 DA 仍读 `da_feed`；影子事件文件可整体归档。

---

## v0.91 (2026-10-03)

**[RFC-133] DA prompt 审计修正批 A+B**（PROMPT_HASH 变: `c66a9fcacc37` → `43d14dddcad1` — 归因基线切分点, 用户裁「如果无误 请执行」）：

- **A 时点错配修正**: HIGH 判据②删"量比<1.5"臂 — 量比/换手率在盘前时段为上一交易日收盘口径（数据段 `_t1_note` 自证）, 用昨日量能判"今日信息是否已被价格反映"= 结构性矛盾。实测暴露面（9/14–10/2, 15 交易日 308 份 checkpoint, 307 份有效 band）: HIGH 档 149 条中 20 条（13%）|盘前涨跌|≥2%（判据②第一臂不满足）, 其中 17 条仅靠昨日量比<1.5 通过第二臂（另 3 条量比≥1.5 属模型违约）; 20 条组 executed fwd1 −0.886%（n=19; 全体 executed +0.480%）, 17 条子组 −0.382%（n=16）。判据②改为盘前涨跌幅+盘前成交量口径, 校准原则同步标注禁用上一交易日口径字段。
- **B 死规则删除**: 删【校准原则】"同标的3天内连续推荐须新证据"条 + 【交易经验参考】③引用 — 三证: ①数据供给缺失（注入经验只含 obsidian 上次分析1条, "后续价格未确认方向"字段从未供给, 规则不可执行）②实测 245 条 executed 推荐中 133 条（54%）为3天内同方向再推, 规则零 binding ③方向与既有裁决相反（8/4 实证重复推荐标的是盈利主力 MRK/NVDA/BABA/LLY 全正 PnL, "去重=砍盈利来源"）。零行为变更。
- 预注册判据（切版后 15 交易日; 2026-10-04 复查修订, 见 FTSeek `docs/decisions/RFC-133-da-prompt-audit-fix-batch.md`）: ①A 生效硬门: HIGH 且 |盘前涨跌|≥2% 中论证文本引用"量比/换手率"支撑"未被反映"的占比 <3%（原占比硬门与新判据②语义冲突, 降为观察项）②无害硬门: HIGH executed 组 T+5 均值 ≥ +0.81% − 0.3pp = +0.51%（仅取 T+5 成熟行, 基线 n=100）。任一硬门不过 → 回滚 `llm_synth.py.bak-rfc133-20261003`。
- 同批登记不动项（审计发现, 零改动）: rating 六档死字段（消费链仅展示层）; claim_ic 多空混装尺子失真（gate 扣分落 quality_score 不参与 tier, 死门⑧, 引用读数须带警告）; challenger `independent_direction`≡`my_direction` 99.3%（防锚定观测字段已仪式化, 不再引用 anchor_divergence 当独立性证据）。

---

## v0.90.1 (2026-10-01)

**[P0] `_write_bridge_file` UE 元数据未绑定变量修复**：

- v0.90 提交版在 Stage6b 读取离开作用域的 `candidate`，每个 bridge/DB 候选都会触发 `NameError` 并被外层 except 跳过；已改为消费 Stage5 analysis 快照的 `a["_ue_direction"]/_ue_confidence/_ue_scanned_at`。
- 新增 `tests/test_write_bridge_ue_metadata.py`：AST 钉死 `_write_bridge_file` 不得读取未绑定 `candidate`，并钉死 bridge 文件与 DB `raw_instruction` 同源消费 `_ue_*` 字段。
- 验证：`18 passed`（新增 2 + 既有 anomaly_parse 16）。回滚：`git revert` 本提交。

---

## v0.90 (2026-09-30)

**[RFC-120] chase_cap 方向语义倒挂修复批**（PROMPT_HASH 变 — prompt 契约行 1081/1142 补 SHORT cap 语义 + 反例）：

- `llm_synth.py` 契约：`chase_cap_price` 字段定义补方向语义（BUY=上限必须>entry / SHORT=下限必须<entry，**不是** invalidation 上破失效位）；关键要求处补 SHORT 对称说明 + 9/30 BE 实证反例。
- `llm_synth.py` 校验器：新增 `chase_cap_inverted_short/_long` 机检（record-only，同 knife_geometry 哲学 — 只报告不 repair，修复后违约率应趋零，作为 prompt 合规率攒样尺子）。
- `pipeline.py` `_write_bridge_file`：倒挂 cap **源头归一化**（写库前）— 确定性退回入场带顺势沿（锚=生成入场价 `vr["entry_price"]`），归一 SSOT = FTSeek `app/playbook/entry_band.normalize_chase_cap`（导入失败走同口径本地降级副本，v0.88 momentum 同纪律）。bridge 候选与直写 DB 同 chokepoint 全覆盖。
- 病灶实证（FTSeek DB）：9/4 enforce 上线后 born-violated 空头 **18/18 零执行**（对照合规组 24/33），9/30 BE(cap=302/entry=298)/KMX(63/60.5)/TSLA(358/355) 三条空单全灭、TSLA 单指令空转 37+ 轮；BUY 侧同病 18 条零执行。FTSeek 侧同批（RFC-120）：执行层 chase 门同款归一兜底 + 日志方向分流 + VWAP/证伪斜率门 skip_reason 回写。
- 回滚：`git revert` 本批；执行层归一独立于本 skill（FTSeek RFC-120 commit 单独回滚）。

---

## v0.89 (2026-09-29)

**RFC-117 下游记录/统计适配批**：DA 行为零变更，`PROMPT_HASH` 不变；新增 record-only 字段与报表消费契约。

- `pipeline.py` / `ic_writer.py`：UE→DA 候选的 `ue_direction / ue_confidence / ue_scanned_at` 同步写入 bridge candidate、`raw_instruction` 与 `signal_snapshots.factors_json`，后续可统计"UE 原方向 vs DA 最终方向"的确认/翻转，不再只留下 `origin=ue_candidate`。
- FTSeek 侧配套：方向记分牌拆出 `DA自选 / DA-UE确认 / UE直写 / topup` 四分源；日报/周报信号漏斗加来源×方向；UE 盘前推送加 LONG 动量闸三态摘要。

回滚：`git revert` 本提交并同步回退 FTSeek 侧报表批；历史旧行无新增字段时按空值处理，不迁移。

---

## v0.88 (2026-09-29)

**RFC-117 共享 momentum 单一真源 + 跨仓 import fail-open（多Agent复核批，用户裁「继续」）**：行为口径零变化，`PROMPT_HASH` 逐字不变（85602fc7d09e，本轮未触 prompt），不切归因基线。

- `deep_analyzer.py` trend 分档改为调用 FTSeek 仓共享纯函数 `app.playbook.momentum.classify_ma_trend`（与 UE 直写闸同一真源，消除 v0.84 前「逐字复刻」双维护隐患）；`len<20 → no_data → 震荡` 与旧内联块行为等价。
- **复核 P1 修复**：该 import 原为顶层裸 `sys.path.append` + `from ... import`，仓路径变动即炸整条 DA 盘前链 —— 与同文件 `anomaly_parse` 的 fail-open 纪律不一致。本轮加 try/except，降级臂为同口径本地副本；仓内测试 `test_da_uses_repo_classifier_from_skill_cwd` 以 `__module__`+`co_filename` 双断言钉住「共享真源在线」，走降级臂即转红报警。
- `pipeline.py`：`_UE_CONFIG_PATH` 常量化（原硬编码在 `_load_ue_short_candidates` 内联），供仓内驱动器 monkeypatch 测 `da_candidate_feed_long=false` 回滚臂；行为零变化。

回滚：`git revert` 本提交；FTSeek 侧同批改动手见 RFC-117 §6。

---

## v0.87 (2026-09-26)

**异动 payload schema 错配修复批（ORCL 9/24 复盘 P2-9 真根因，用户裁「继续」）**：纯解析/渲染层尺子修正，零新采集、零判据改动、`PROMPT_HASH` 逐字不变（85602fc7d09e，实测新旧一致 ⇒ 不切归因基线，同 v0.70/v0.85/v0.86 先例）。

**病根（比原报告 P2-9 定级严重一级）**：futu 异动 provider 返回 `{"data": {err_code, retMsg, time_range, content}}`，`data` 是 **DICT**（`content` = 中文异动文本），旧代码一律当 **LIST** 用：
- `has_anomaly = bool(dict)` → 恒 `True`，连 `err_code=1「XX面异动无异常」` 也报 True（实测 **122 次假阳性**）
- `count = len(...) if isinstance(list) else 0` → 恒 `0`（自相矛盾的 has_anomaly=true + count=0）
- 渲染层 `len(adata)` → **dict 键数 = 4** → prompt 恒报「4条异动」，谎报条数
- `content` → **从不读取**：2026-09 实测 642 payload 中 **474 (74%) 有有效 content 被静默丢弃**

**被丢的 9/24 ORCL 实锤**（原报告称「上游全为 None」= 误判，数据一直在包里）：
- 技术面 9/23：「收盘价跌破MA5、MA10和MA30，暗示价格可能继续下跌。MA10跌破MA30形成死叉，表明下行动能可能延续」← **与当日 BUY 直接冲突**
- 衍生品 事件当晚：「9.24 03:40 卖出看涨期权 1079张 $458,575 K=190」+「02:51 卖出看涨 1405张 $258,520 K=240」← 机构卖 call
- 资金面 `err_code=1` → 原被谎报「4条异动」，现如实「无异动」

**修法（零新机制，单一真源）**：
- 新增中立模块 `scripts/anomaly_parse.py`：`parse_anomaly_payload()` + `render_anomaly_section()`。放中立模块是因为 `deep_analyzer` 会 import `llm_synth`（反向即循环），两处消费方各自 import ⇒ 尺子唯一，杜绝口径漂移
- `err_code` 语义严格三档，不再混淆：`0`=有条目 / `1`=如实报「无异动」/ `-12301`=报「采集失败」（**缺数据不编数据**）；不信任 `retMsg` 文本匹配，以 `err_code` + `content` 非空为准
- 渲染预算 `MAX_ITEMS=6 × MAX_ITEM_CHARS=160`（deriv content p90=7.6k / max=15.9k，不可裸渲染），超出显式写「…另有K条未展示」，不静默截断
- `_split_items()` 单遍逐行，支持实测混合格式：`[timestamp: N]` 块（tech/cap，260/260 命中）+ `9.24 03:40，…` 日期行（deriv 期权大单）+ 纯标题行跳过 + 跨行描述续接
- 两处 import 均带 try/except 降级（模块缺失 → 不渲染该段，绝不谎报 has_anomaly）

**实测验证**（真实 9/24 ORCL 包，端到端）：衍生品 谎报7条 → **真实31条**、技术面 9条、资金面「无异动」；恢复渲染出「跌破MA5」+「卖出看涨期权」。新增 `tests/test_anomaly_parse.py` **16 passed**（含 `test_render_never_reports_dict_key_count` 锁死「4条异动」谎报、`test_end_to_end_orcl_20260924` 真实产物回归）；DA 契约 **60 passed**。

**未动**：`result.anomalies` 结构化字段仍零消费方（FTSeek 侧 `anomalies` 同名命中是 `signal_quality_tracker` 的另一套），本次只修尺子不接线；是否把异动作为门禁输入属行为变更，另议。

---

## v0.86 (2026-09-26)

**新闻时间戳 + 社区爆发速率渲染批（ORCL 9/24 复盘 P1-6/P2-10 接线，用户裁「同意」）**：两处纯数据段渲染修复，零新采集、零判据改动、`PROMPT_HASH` 逐字不变（85602fc7d09e，实测新旧一致 ⇒ 不切归因基线，同 v0.70/v0.85 先例）。

**病根 1（新闻无时间感知）**：`llm_synth._format_data_for_prompt` 新闻段读 `n.get('time','')`，但 futu flash 的真键是 `publish_time`（unix 秒 string）⇒ 渲染恒为 `[] 标题`。9/24 ORCL 实锤：不可抗力 flash `publish_time=1790252999`（08:29:59 ET），采集延迟 91 秒，但 LLM 看到的是无时间戳标题 — 无法分辨「91 秒前的突发」还是「3 天前的旧闻」，新鲜度信息在渲染层丢失。修法：`_news_time_et()` 把 `publish_time` 转 `%m-%d %H:%M ET`（zoneinfo，失败回退原值/空串，缺时间不编时间）；段标题标注「时间为ET」。

**病根 2（爆发速率被聚合吃掉）**：社区情绪 30 条帖子各有 `publish_time`，但渲染只取前 5 条 title[:120] ⇒ 时间密度信号归零。9/24 ORCL 实锤：采集前 5 分钟 23 条刷屏（比新闻 flash 早 4 分钟，是最快的信号），prompt 零体现。修法：渲染前从已有 `publish_time` 算「最近一条前 5 分钟内 N 条 / 全部跨 X 分钟」，N≥15 追加 `⚠️ 爆发式刷屏` 标记（阈值依据：ORCL 案 23 条；常规标的 30 条跨 ~70min ⇒ 5min 窗典型 <5 条，不误标）；解析失败不渲染该行（不编数字）。

**边界（刻意不做）**：只加渲染，不加门、不改 bear/bull 判据、不动严重度定级（news_v2 summary 的结构化严重度提取属 ORCL 复盘建议 #4，须影子先行另裁）。回滚：`llm_synth.py.bak-v086-news-time-burst`。

## v0.85 (2026-09-24)

**盘前「大盘环境」口径保真批（DEB-20260924 F1 方案B，用户裁「同意」）**：`collect_market_context()` 的 SPY/QQQ 补 `snapshot` 盘前腿 + 显式 `current_asof` 基准日；prompt 的 `## 大盘环境` 段同步标注口径。

**病根（复核确认的机制，非猜测）**：`_get_index_kline(symbol)` 取 `collect_kline(symbol,"1d",60)`，而该调用**无 start/end** ⇒ 走 `get_kline.py` 的 realtime 分支（`get_cur_kline`）。盘前今日日K尚未形成 ⇒ 最后一根 bar = **昨日** bar ⇒ `current = closes[-1]` **恒等于昨收**。实测 2026-09-24 盘前 25/25 份 `da_checkpoint/*.raw.json` 的 `spy.current` 唯一值 = `767.81` = `prev_close`（diff 0.000000%）；同日 ET 10:25 盘中复跑 `765.85 ≠ 767.81`（差 0.255%）⇒ **病灶只在盘前，而 DA 只跑盘前**。后果：模型读到「大盘持平/趋势 UP」而个股普跌（当日 SPY 盘前 −0.50%、QQQ −0.83%、SOXX −1.86%），把系统性回调解读为「健康回调/错杀」⇒ 批量低吸 BUY（当日 5/5 条 LLM BUY 的 thesis 均为「回踩…分2批低吸建仓」）。`_MC_CACHE`(TTL 600s) 是加重因素而非根因（缓存未命中时首取即为昨收）。

**改动（两文件，纯输入保真，零判据改动）**：
1. `data_collector.py` `_get_index_kline`：新增 `collect_snapshot(symbol)` 盘前腿（`prev_close`/`pre_price`/`pre_chg_pct`/`session`/`snapshot_time`，失败记 `_error` 不拖垮父函数）+ 日K最后一根日期写入 `current_asof`；`_source` → `market_context_v040`。成本：market_context 有 600s 缓存，每轮 ±2 个 OpenD 子进程。
2. `llm_synth.py` `_format_data_for_prompt` 的 SPY/QQQ 行：追加口径标签 `[日线口径, 基准日=YYYY-MM-DD 收盘; 今日盘前 −0.50% (盘前价 … / 昨收 …; 快照 … <session>)]`；盘前腿缺失时写 **「盘前快照不可用 — 禁止推断今日盘前指数涨跌」**（对齐 9/14 VIX P0-2 先例：口径可疑的值必须自带标签，缺失必须显式禁止推断）。

**为何不改 `current` 本身（方案A）**：`current` 还参与 MA20/MA50/趋势判定，换成快照价会让「价 vs 均线」跨口径比较；标注 + 补盘前腿是最小改动（做减法）。**未动**判定逻辑、未加硬门、未改 `PROMPT_HASH`（指纹只含模板文本，数据段渲染不入指纹 —— 同 v0.70 先例）。

**验证**：离线渲染三态实测（快照正常 / 快照 `_error` / 旧结构回退）均输出预期文案；`collect_market_context()` 实弹返回 `current_asof=2026-09-24` + 盘前腿（SPY −0.501% / QQQ −0.832%，与独立市场真值一致）；`tests/` 中 DA 相关 6 个测试文件 **143 passed**；版本棘轮三处同步 0.84→0.85。

**回滚**：`.bak-deb20260924-indexcaliber` 两份；或 `.env.us` 无需改（无开关）。回退后 prompt 回到「只有数字、无口径标签」状态。

---

## v0.84 (2026-09-23)

**归因记账修缮批（复查裁决「全做」）**：补升版本 + 测量系统分桶 + 挑战者 tier 打标补全。本条同时**追记两批漏升版本的历史变更**（temp0 与 9/23 晨间两处修复）——按头注纪律「改 skill 代码的提交必须同步改 version」，这是第三次漏更的补课（前两次 v0.74.2/v0.75、v0.81，教训同构）。

**追记① temp0（实际落地 2026-09-21 12:45，当时未升版）**：`DA_LLM_TEMPERATURE` 单旋钮（默认 0.0），收口四处调用点（分析师 synthesize / 契约修补 / 挑战者链 / `_call_llm` 签名默认）；温度以 `_SAMPLING_TAG=t{temp:g}` 纳入 `PROMPT_HASH` 指纹 ⇒ 改温度自动切归因基线（断点 `85602fc7d09e`）。回滚：`.env.us` 写 `DA_LLM_TEMPERATURE=0.3`，无需改码。**版本影响**：9/21 前后运行的 `skill_version` 均为 0.83 不可区分，归因切分请用 `prompt_hash`（`b6b8034c471a→2cdcd4fa624e` 为 9/14 v0.80 断点，`→85602fc7d09e` 为 9/21 temp0 断点）。

**追记② 9/23 晨间两处修复（当时未升版，详见 SKILL.md IC 校准章节）**：dc 校准台账「配对补齐」（同 decision_id 双行取"有 fwd>已执行>日期更晚"，修 8/31 四笔永久挂账，pending 6→2、配对 212→216）+「截留率口径」（mean(v/d) 被小分母拉飞 0.47 → 改 Σ/Σ=0.20 + 中位 0.11；历史 state 中 9/23 及以前的 capture 为旧口径不可比）。

**本批新改动（2026-09-23 复查批）**：
1. **挑战者 tier 打标无条件化**（`llm_synth.py` `_run_challenger`）：此前仅回落分支写 `_challenger_tier`，primary 成功落 tier=null，与「v0.83 之前旧数据无此字段」不可区分（实测 9/21-9/22 34/35 次运行 tier=None）。现在 primary 也显式记 `"primary"`。行为零变更（`_challenger_self_debate` 对 primary 仍为 False，confidence 闸门不受影响）。
2. **dc 校准台账测量系统分桶**（`dc_calibration_collector.py`）：样本行补抄 gate 行的 `prompt_hash`/`challenger_prompt_hash`，报告新增 ⓪ 分桶段。背景：collector 自订纪律「prompt 再改则 MIN_TRADE_DATE 前移、旧样本作废重攒」，但 9/14/9/21 指纹两度切换而日期未前移 ⇒ 台账混 ≥3 届测量系统（实测 8 个指纹桶 + 111 无指纹旧样本；桶间差异显著，如 `2cdcd4fa624e` n=80 mean+1.62%/WR0.637 vs `b6b8034c471a` n=39 mean−0.14%/WR0.410）。经裁决改用**按指纹分桶**替代作废重攒：双窗判据（n≥100+15pp）裁决只在同指纹桶内做，跨桶不得混算。
3. **版本棘轮三处同步**：本文件 / SKILL.md frontmatter / `tests/test_da_output_contract.py` 字面量 → 0.84。

**测试**：`tests/test_da_output_contract.py` 56 passed（tier 断言只钉回落档，primary 打标零破坏）；collector 重跑回填 411 样本指纹成功（新增0/更新0，指纹为增量字段）。

**回滚**：tier 打标与分桶均为增量字段（下游 `.get()` 兼容 null/缺键），单独回退任一处不破坏契约；版本字面量三处需同步回退。

---

## v0.83 (2026-09-18)

**挑战者独立档 fallback 接线（用户裁「做」）**：把「挑战者模型失败 → 回落主模型 = 同模型自辩」换成**三级独立链**。

**病灶**：`_run_challenger` 原 fallback 直接调用 `_call_llm(challenger_system, challenger_user, temperature=0.4, max_tokens=2000)`——**不传 model ⇒ 落回 `MODEL`（qwen3.7-max）= 分析师本体**，即挑战者与分析师资同一模型 ⇒ 违反辩论协议硬规「**禁止一个模型自辩自裁**」（`multi-model-debate/SKILL.md:39`），且伪独立样本无信息量、污染挑战者归因。实测已从冷路径转热：全窗 5/109，9/18 当日 3/23=13%，这批样本笔均净 −$60.92（n=4 配对，方向性）。

**新链条（`llm_synth._run_challenger`）**：

| 档 | 模型 | 参数 | 角色 |
|---|---|---|---|
| T1 primary | `deepseek-v4.1-flash` | 思考+16000+t300 | 现役 |
| T2 fallback#1 | **`kimi-k2.6`**（Moonshot，换家族） | 思考+16000+t300（可比口径） | 独立档 |
| T3 fallback#2 | **`glm-5.2`**（智谱，再换家族） | 关思考+2000+t60 | **失败模式多样性**（若病根是"思考下的超时/JSON 解析失败"，全档开思考会一起死） |
| T4 末位兜底 | `qwen3.7-max`（= 分析师） | 关思考+2000+t60 | 同模型自辩，**显式标记 `_challenger_self_debate=true`**，不再伪装成独立挑战者 |

**选型依据（2026-09-18 实弹探针，5 模型 × 2 参数档，小 prompt 只读）**：`deepseek-v4.1-flash` 思考✅1.7s/关思考✅0.9s；`kimi-k2.6` ✅4.2s/✅1.1s；`glm-5.2` ✅5.4s/✅0.8s；**`glm-5.3` 关思考必 HTTP 400（强制思考模型）** ⇒ T3 只能用 glm-5.2；`deepseek-v4-pro` 双档可用但同 primary 家族 ⇒ 不用。`qwen3.8-flash`/`qwen3.7-max` 与分析师同家族 ⇒ 不用。成本：T2 ~$0.011/次 × ~1 次/日 ≈ **$0.01/日**。

**语义对齐（同批）**：`_merge_debate_results` 的「方向一致才升 confidence」闸门由 `not _is_fallback` 改为 **`not _self_debate`** —— 原写法会把换家族的 T2/T3 也误判成非独立；现在只有 T4 才抑制升档。新增归因字段 `challenger_tier` / `challenger_self_debate`（IC/判据记账据此排除自辩样本），`challenger_model` 记**真实使用的模型**（`_challenger_model_used`）。

**验证**：单测 `tests/test_da_output_contract.py` **56 passed**（新增 T3/T4 链条深度、家族独立性守卫，并把 T2 用例扩为断言 tier/model/self_debate 与 confidence 闸门）。**实弹端到端链验证**（把 T1/T2/T3 分别置为不存在的模型名，观察真实 API 回落）：① T1 坏 → 真实落 **kimi-k2.6**（tier=fallback_independent，`primary_error=HTTP 404` 已留痕，模型回显 kimi-k2.6）；② T1+T2 坏 → **glm-5.2**（tier=fallback_independent_nonthinking）；③ 全坏 → **qwen3.7-max** 且 `self_debate=True`、`debate_outcome` 明写「同模型自辩(非独立), confidence不升」。

**未做（留待定因）**：T1 primary 不动；`challenger_primary_*` 留痕照跑，下一次 DA 运行起可定因（若是 429 则加错峰/退避而非换模型）。挑战者「否决权/降权」仍不落，裁决载体是 `da_score_overwrite_counterfactual` / `divergence_arbitration_shadow`。

**回滚**：`llm_synth.py.bak-challengerchain-20260918` + `config.py.bak-challengerchain-20260918`（两个常量可留，零引用无害）。

---

## v0.82 (2026-09-18)

**伪独立辩论 (challenger fallback) 可观测性补 + 版本棘轮补齐**（用户令「按建议」执行 9/18 溯源建议③）。

**病灶**：`_run_challenger` 的 fallback 分支（挑战者模型失败 → 改调主模型 = 同模型自我辩论）**把原发失败原因整段丢弃**：`result` 直接被覆盖，`_debate` 里只剩 `challenger_fallback=true`。后果：伪独立率从"冷路径"转热后（全窗 **5/109**，9/18 当日 **3/23=13%**）只能观测到"发生了"，无法定因 —— 而两类原因的处置**相反**（429/超时 → 加重试/错峰；JSON 解析失败 → 改 prompt 或抬 max_tokens），所以不修留痕就永远只能猜。同期实测这批伪独立样本笔均净 **−$60.92**（n=4 配对，方向性）。

**修法（三处，均为增量字段，零行为变更）**：① `_call_llm` 失败路径在原有 `_finish_reason/_usage` 之外，**带 `_raw_len` + `_raw_tail`(≤200 字符 正文尾巴)** —— 此前只回 `str(e)`，无法区分"被 max_tokens 截断"（抬预算）与"模型回了废话"（改 prompt），这正是 `DEB-20260825 第13轮 P1` 遗留的双盲项；② fallback 分支先 `_primary = dict(result)` 再覆盖，把原发 `_error/_finish_reason/_raw_len/_raw_tail` 挂到 fallback 结果上；③ `_merge_debate_results` 把它们落进 `_debate.challenger_primary_*`（消费者可见）。

**探针（实弹，只读）**：现役挑战者参数（`CHALLENGER_MODEL=deepseek-v4.1-flash` + `enable_thinking=True` + `max_tokens=16000` + `timeout=300`）在同模型上 **3/3 正常**（2.0/2.0/2.9s，`reasoning_tokens=12`）⇒ **不是参数性拒绝**，故必须靠留痕定因；fallback 位（主模型 + 关思考 + 2000）3/3 正常（1.0s）。

**测试**：`tests/test_da_output_contract.py` 新增 `test_challenger_fallback_keeps_primary_diagnosis`（429 场景 + `_debate` 落地 + 模型名须记主模型）与 `test_challenger_primary_diagnosis_absent_on_clean_run`（正常路径不得凭空填字段），并把截断用例扩为断言 `_raw_tail`。

**版本棘轮补齐**：`v0.81`(2026-09-16 CLI 收尾挂死修复批) 落地时漏改 `tests/test_da_output_contract.py` 的同步棘轮字面量（frontmatter/changelog 已 0.81、断言仍写死 `"0.80"`）⇒ 该测试长期红；本批一并升到 **0.82**（三处同步：本文件 / `SKILL.md` frontmatter / 测试字面量）。

**待裁（未做）**：fallback 是否改调**另一个独立模型**（保留辩论独立性，成本 +1 次调用/候选）—— 需模型池与预算裁决；挑战者"反对/弃权"是否应有降权或否决权（COIN 9/18 的伪独立挑战者已正确指出反向证据，但方向仍 SHORT、conf 仍 50）。

**回滚**：`llm_synth.py.bak-scbfallbackdiag-20260918` 回退本文件（三处字段均增量，回退不破坏契约）。

---

## v0.81 (2026-09-16)

**CLI 收尾挂死修复批（用户裁「病灶修复」）**：修「`pipeline.py` 干完活却不退出 ⇒ cron agent 判挂起 ⇒ SIGTERM ⇒ 整条管线全量重跑」的收尾根因。

**病灶（两条互补泄漏路径）**：① `futu` SDK 的 `CallbackExecutor` 是**非 daemon** `threading.Thread`（永久阻塞在 `self._queue.get()`；`SysConfig.ALL_THREAD_DAEMON` 默认 `False`）⇒ 只要有一个 `OpenQuoteContext` 未 `close()`，解释器收尾时 `threading._shutdown()` 的 join **永不返回**，进程就此挂死（`NetManager._loop` 虽是 daemon，但它不决定退出）；② `FutuLV3Provider` 是**长命单例** (`app/data/futu_lv3_provider.py:442/1697` 建连，模块级 `_futu_lv3_instance`)，`close()` 只在异常路径被调 ⇒ 常态泄漏；DA 侧经 Stage 6b `MarketRegimeGate().assess()`（`pipeline.py:1762`）触达它，`signal_gate.py:49` 同路径。**症状偶发**：与「泄漏是否发生」（LV3 连接成功/退化分支）条件相关，故不能靠"没复现"判定无病。

**实证**：2026-09-16 第 1 轮 20:02:50 启动 → **20:21 活已干完**（`data/opportunity_scan_2026-09-16.json` + 6 条 instruction UPSERT + Obsidian 归档）→ 进程 25 分钟不退出 → cron agent `process_manage` 轮询 8 次后 **20:46:38 SIGTERM（`PIPELINE_EXIT=143`）** → **20:48:50 把整条管线全量重跑**（白烧一倍 LLM 预算；重跑幂等，见"读法"）。更早：2026-09-11 的孤儿进程**存活 2 天 16 小时**，持 `ftseek_us.db`+`-wal`+`-shm` 三句柄 + 一条 `127.0.0.1:11111` ESTAB。

**修法（三层，全部落在 `__main__` 边界 —— 内部 `main()` 一行未改）**：**A** `_futu_threads_daemon()` = `SysConfig.set_all_thread_daemon(True)`，让 SDK 内部线程全 daemon（治"线程拖住不退"）；**B** `_release_opend_singleton()` = `reset_futu_lv3_provider()` 显式释放 OpenD 单例（治"连接泄漏不退"），外加 `_futu_console_to_stderr()` 把 SDK **控制台**日志从 stdout 改道 stderr —— 保住 `--format json` 的**纯 JSON stdout 契约**（cron Step 4 按 JSON 取数；此前 SDK 日志会插在 `{` 之前 ⇒ 解析失败，文件日志保留不动供取证）；**C** `_cli_teardown(exit_code)` = 释放后对残余非 daemon 线程做**有界等待**（`DA_EXIT_GRACE_SEC`，默认 10s，env 可调），超时 `os._exit(exit_code)` **原样透传退出码**（绕过 `threading._shutdown()` 的无限 join）。**为什么不能写进 `main()`**：仓内 `tests/test_da_trading_day_guard.py` 在**进程内** import 本模块并调 `PL.main()`（52 例），`main()` 内强退会直接打死测试进程。

**验证**：A 层 —— 最小复现（`MarketRegimeGate().assess()` 建 LV3 连接）由改前 exit=124（挂死）变为 **4.36s 干净退出、非 daemon 线程 0**；C 层 —— 人为保持泄漏时 **13.09s 强制退出、exit code 0** 且打印具名告警；端到端 `pipeline.py --mode analyze`（生产安全旗标 `--no-db-write --no-pool-write --output-dir /tmp/…`）**EXIT=0 / 99.1s / stdout 合法 JSON / 无强退告警**；`tests/test_da_trading_day_guard.py` **52 passed**。

**归因**：`PROMPT_HASH` **不变**（本批只动 `pipeline.py` 的 CLI 收尾，未触 `llm_synth.py`；`pipeline.py` 内零 prompt 文本）；但**版本戳切分**（本版起 bridge 记录的 `skill_version` 为 0.81 —— 收尾行为变了，归因基线应在此切分）。

**自动化层配套（不在本 skill 内）**：cron 作业 `e0d574cc1a3c`（盘前扫描）命令加 `timeout 3600` 前缀，并在提示词里写明「超时/长耗时**不得盲目重跑**，先查产物是否已落盘」（改前该作业**无任何超时**，handoff §16.10(a) 早建议、未执行；备份 `~/.hermes/cron/jobs.json.bak-20260916-da-hangfix`，`schedule`/`enabled`/`next_run_at` 均未动）。同日「一起做掉」批扩面：同族 4 个作业（`3a6c83bbd84c` 盘后复盘 / `2d69370d5c91` 盘前综合预检 / `1e9c597b0262` 周日复盘 / `9ac3efd8c5e7` Deepulse）每步命令套 `timeout -k 30 N` + 同一条「exit=124 不得重跑」纪律（备份 `jobs.json.bak-20260916-timeout-family`）；`6af0648e3eb3` alpha-backfill 判定**无需改动**（`no_agent` 脚本已有内建 600s×2 + runner 3600s 双边界，6 次超时均 601–603s 干净退出）。**仓库侧**同批落地：`app/data/futu_lv3_provider.py` import 即 `set_all_thread_daemon(True)` + 单例 atexit **有界**释放（覆盖全仓进程，不止 DA）—— 详见 handoff.md 同日条目（含 A/B 实证与 6 钉）。

**回滚**：删除 `__main__` 块内的 A/B/C 与 `_futu_console_to_stderr()` 调用、恢复裸 `main()` 即可 —— 本批 diff 实测 **137 insertions / 1 deletion**，唯一删除行就是原来的 `    main()`（被 try/except 收尾块取代），`main()` 及其上游**无一行改动**，故未另存 `.bak`。（该 skill 目录由 `/root` 仓库跟踪：`cd <skill 目录> && git diff -- scripts/pipeline.py` 可见全部增删。）

---

## v0.80 (2026-09-14)

**飞刀几何一致性批（用户裁「落」）**：修「盘前暴跌日 LLM 产出结构性不可成交 LONG 指令」的生成侧根因。**病灶**：LLM 不知执行层两道门的存在 —— ① B门(RFC-068 硬门)对 LONG 语义 = 实时价 vs 昨收 < -5% 拒入场、回升出飞刀区自动复评；② `chase_cap_enforce`(P0-A) = 下单价越过 LLM 自报的禁追线即**终态跳过**。当盘前涨跌 < -5% 且 LLM 给低吸 LONG 时，它倾向把 chase_cap 定在深跌位（"禁止追涨"本意），而**价格回升出飞刀区（唯一可成交时刻）必然越过该禁追线** ⇒ 两道门各自合理、联合成空集。**实证 9/14**：HPE（昨收 62.09 / 禁追 58.00 < 飞刀线 58.98）、NOK（昨收 11.13 / 禁追 10.50 < 10.57）两条 LONG 全天无法成交，白占指令队列并污染「指令→成交」漏斗。**reprice 不能修**：盘中 re-price 重算 entry(实时 bid/ask)/SL(vol_bucket 钳制)/TP/size，但 B门线(昨收×0.95)与 chase_cap(LLM 写死在 raw_instruction_json)都不随 reprice 变 —— 空集是生成侧几何矛盾。**修法（prompt 教 + 机检报，零门禁改动）**：① `SYSTEM_PROMPT`【与执行层的接口事实】第2条补「飞刀几何一致性」三子条（chase_cap 必须 ≥ 昨收×0.95 / entry 可在飞刀线下方由限价路由接回 / 证据只支持深处接货则给 SKIP+右侧回补计划）；② `_USER_CONTRACT` 输出契约同步（下游机检声明）；③ **挑战者对称**（`challenger_system_v2` 验证维度 e 补飞刀几何核验，低于飞刀线的禁追线计 PARTIAL 实质硬伤）—— 遵守「多模型链必须对称」纪律，防分析师守规矩而挑战者不知；④ `_validate_output_contract` 新增 `knife_geometry_conflict` 机检（**record-only，只报告不 repair** —— 改 chase_cap = 改交易决策属门禁范畴，与本函数「零方向变更」哲学一致），签名加 kw-only `snapshot=None`，老调用点/测试不传即跳过判定（零行为变更）。**⚠️ 实现陷阱（已修）**：`pre_change_rate` 是**负数**字段，首版误用 `_as_num()`（只接受正数，-7.746 被判缺失）→ 门对全部真实样本静默失效；改直接 `float()` 解析。回放验证：今日 7 只 checkpoint 全量重放，HPE/NOK 命中、其余 5 只（含 SHORT×2）不误报，7/7 符合预期；无 snapshot 兼容路径零新违约。**PROMPT_HASH 变更** `b6b8034c471a → 2cdcd4fa624e`（SYSTEM_PROMPT 文本改动，非数据段渲染 ⇒ 归因基线在此切分，与 v0.79「数据段改动 hash 不变」不同）。回滚：`scripts/llm_synth.py.bak-knife-geometry-20260914`（整文件还原；回滚须另开辩论 —— 恢复即等于让飞刀日重新产出死指令）。

---

## v0.79 (2026-09-14)

**盘前数据有效性批（用户裁「全部处理」P0-2/P1-1/P2）**：① **VIX 从结构性恒缺 → 实时代理**：`data_collector._get_vix()` 原直查 `US.VIX`，而富途不供指数快照（实测 `_error: empty`，DEB-20260818 §89/144）⇒ 该维度自 8/11 起**恒缺失**却被 19 维覆盖审计掩盖（`market_context` 有 spy/qqq 即记 ok）；改为 `US.VIXY`×0.85，系数复用仓内单一真源 `app/data/vix_source.vixy_to_vix`（`data_collector` 头部 append 仓根到 sys.path，**不复制字面量系数**；导入失败如实 `_error`）；`llm_synth` 渲染补口径标签「代理值 VIXY×0.85，现货无盘前交易」，取不到时**显式写入「VIX 不可用，禁止引用具体数值」**（同 DA-A1 行业 PE 中枢先例）。② **覆盖审计不再掩盖复合源子项缺失**：`_classify_data_sources` 对 `market_context` 逐子项（spy/qqq/vix）校验，缺一即降级并具名（`market_context(vix缺失)`），总维数仍 19（口径不变，只是不再把"半个 market_context"记满分）。③ **板块脉搏日期/新鲜度守卫**：`Pipeline.run_full` 原只要 `sector_pulse.json` 存在就注入，标签 `盘中板块脉搏(15:30 ET)` **无日期**，而该文件由盘中 cron (ET 10:00-15:30) 写 ⇒ DA 08:00 ET 读到的**永远是上一交易日**读数（周一跨周末 = 3 天前），模型据此判当日板块顺逆风；逻辑抽为模块级 `build_sector_context(scan_result, today_et=None, pulse_path=None)`（可测性注入），标签改为「上一交易日(YYYY-MM-DD)盘中板块脉搏」，且**日期必须等于上一个已收盘交易日**（交易日历算，跨周末/跨假日正确）才注入，否则丢弃 + stderr 具名报警（板块涨跌段 fail-open 保留）；"昨日板块涨跌"→"上一交易日板块涨跌"。④ **快照 T-1 口径标注**：盘前/盘后 `成交量/换手率/振幅/量比/买卖盘比` 均为上一交易日收盘口径（盘前不刷新），原只标了"当前价格"，现整组标注并指明今日量能看盘前段（同 LIF 盘前盲区病灶族）。**PROMPT_HASH 不变** `b6b8034c471a`（改动全在数据段渲染，非 prompt 文本，同 v0.70 先例；已实测改前/改后一致）。回归覆盖：仓内侧 `tests/test_da_sector_pulse_freshness.py`（8 例，含棘轮）钉住注入侧。回滚：`scripts/pipeline.py.bak-deb20260914-vix` / `data_collector.py.bak-deb20260914-vix` / `llm_synth.py.bak-deb20260914-vix`（整文件还原，回滚须另开辩论 —— 恢复即等于让 VIX 再次恒缺、脉搏再次无日期）。

## v0.78 (2026-09-08)

**失效条件量纲契约修复**：`invalidation_triggers` 的原始成交量改为“当日累计成交量 ÷ 最近 20 个完整交易日平均成交量”的无量纲`量比`；Prompt 明确各指标单位及当前仅影子评估。`generic_claim` 文案与既有数字锚点校验器对齐，版本和 prompt hash 作为新基线。

## v0.77 (2026-09-07)

**Prompt 角色边界复核批**：移除命中率均值锚和 LLM 自评 confidence，补 `evidence_gaps`、挑战者反仪式化要求、`falsification_target`/`flip_condition`，同向挑战者降分改为影子记录。该版本代码已先落地，frontmatter/changelog 当时漏升，本条补记归因。

## v0.76 (2026-09-07)

**主链交易日守卫 + 消灭 DA 侧平行假日表** (SKILL.md pitfall `-6`; handoff「下一步」`0-假日`; 2026-09-06 立案, 2026-09-07 用户裁「按建议执行」= 立案时的 A+B 两案; C「只在 cron prompt 加 Step 0」被否)。

**根因 (三层证据, 全部实测到代码/DB)**: ①`pipeline.py::main()` 从 argparse 直接构造 `Pipeline(...)`, **零日期判断**; 全 skill `grep holiday_calendar|is_trading_day|get_holiday_calendar|is_us_holiday scripts/*.py` → **零命中**; cron `e0d574cc1a3c`(`0 20 * * 1-5`) 只排周末。②`ic_writer._get_et_trade_date()` 自带 6 条硬编码 `known_holidays` `(7,3)(7,4)(12,25)(1,1)(11,26)(11,27)`, **漏劳动节**及 MLK/总统日/耶稣受难日/阵亡将士日/六月节。③仓内本有 SSOT `app/utils/holiday_calendar.py`(Futu `request_trading_days` 权威 + 2026-2028 硬编码降级 + 周末兜底), UE `llm_universe_scan.py:152` 与 FTSeek `app/playbook/pipeline.py:523` 都接了, **DA 零引用** → 典型平行真源漂移。
**2026-09-07(劳动节,周一) 是 DA 7/9 上线以来第一个美股假日** (7/9→9/6 区间零假日) ⇒ 首次实弹, 恰逢 v0.75 生效次夜。DB 印证: `signal_snapshots` 落在美股假日的行仅 5 条 `voting_llm`@2026-07-03, **DA 零条**。

① **新增适配层 `scripts/trading_calendar.py`** (229 行, 纯函数零 IO 副作用)。三层降级, 上层优先, 每层独立 try, 任一层给出答案即返回: **L1 `ftseek_ssot`**(`app.utils.holiday_calendar`, 经 `sys.path.insert(0, FTSEEK_ROOT)`) → **L2 `rule`**(按 NYSE 规则**现算**, 不复制任何日期表: Good Friday 走复活节匿名格里高利算法、固定日假日 observed 平移周六→前一日/周日→后一日、元旦落周六 NYSE **不补休**特例; **不含**哥伦布日/退伍军人日/12-24, 因 NYSE 这三者照常开盘) → **L3 `legacy`**(原 6 条表逐字保留为 `_LEGACY_KNOWN_HOLIDAYS`, 只为"上层全灭时不改变既有行为", **禁止往里加日期**)。API: `resolve(d)->(bool, layer)`(`lru_cache(512)`, memo 掉 L1 对缓存窗口外日期的 Futu 重查重连) / `is_us_trading_day` / `latest_trading_day(d, max_back=12)` / `rule_holidays(year)` / `ET_TZ` / `now_et()` / `today_et()`。
   **比原 A 提案多做一层适配的三个理由**: ①原 A 的降级路径是"异常再降级到现有硬编码表"= **把漏劳动节的 bug 留在退路上**; ②`pipeline.py` 与 `ic_writer.py` 两个消费方必须同口径, 不能各接各的; ③需要 memo。
② **A — `ic_writer._get_et_trade_date()` 委托适配层**: 把原"周末前推"+"假日表前推"两套分叉逻辑合并成单一循环(周末与假日同口径判定); `trading_calendar` 整体不可用时退回**纯周末前推**(不改既有语义)并 stderr 留痕。实测 2026-09-07 → `2026-09-04` (**修复前实测返回 `2026-09-07`**, 已用还原的旧逻辑复算确认)。
   治的是最隐蔽的一类损失: `trade_date`=非交易日 → FTSeek `backfill_forward_returns.py` 找不到该日日K → `close_t0/t1` 恒 NULL → 该批 snapshot **静默永久退出 IC 样本且不报错**。
③ **B — `pipeline.main()` 交易日守卫**: 位置在 argparse/`--llm-model` 补丁之后、`Pipeline(...)` 构造**之前**(晚一步就已开始扫描)。判日用 `today_et()` 而非 `date.today()` —— 容器时区 CST(UTC+8), CST 周一凌晨 = ET 周日晚, `date.today()` 会把 ET 周日判成周一(实测 2026-09-07 06:47 CST: `date.today()`=09-07 而 `today_et()`=09-06)。非交易日 → stderr 消息 + (`--format json` 时吐 `{"skipped":true,"skip_reason":"NON_TRADING_DAY","trade_date_et":...,"calendar_layer":...,"stages":{},"message":...}` 保 JSON 契约, cron Step4 按 JSON 解析不能吐裸文本) + `return`, **exit 0**。新增 `--force` 逃逸口(人工假日复盘/调试用, **cron 不传**)。实测 0.23s 拦下、零 LLM/网络; 模拟 9/7、9/8、9/4、9/6、11/26、11/27、12/25、2027 元旦判定全对。
   治 (a) 白跑(30-40 只 × 30-60s LLM ≈ 20-40 分钟, 分析的是上一交易日陈旧行情) + (b) 写陈旧指令(`playbook_instructions` `date=9/7`, entry/SL/TP 全锚上一交易日收盘)。

**失败语义 = fail-open (用户批准的方案即此, 不得改成 fail-close)**: 三层全灭 → 视为交易日 → 照跑, 与 UE `_is_us_trading_day_today()` / FTSeek `_is_trading_day_today()` 同口径。理由: fail-close 会在日历故障日**静默停掉整条 DA 主链**, 代价远大于白跑一轮。`layer="fail-open"` 时两个消费方均 stderr 留痕。
**误交易风险本就已被两道闸排除(不夸大本次修复的收益)**: `run_playbook_auto_execute` 非交易日直接 return(`app/playbook/pipeline.py:3524`); 取指令走 `get_instructions_by_date` 严格 `WHERE date=?`(`app/playbook/db.py:602`) ⇒ 9/7 的陈旧行对 9/8 不可见。本批治的是**白跑 + 陈旧写入 + IC 丢样**, 不是误交易。
**纪律核查 (数据口径七律#2 新旧基线须切分)**: ② 改变 `trade_date` 口径 ⇒ 核查影响面 = **历史 0 条**(见上方 DB 印证) ⇒ **无需基线切分、不追溯改写任何既有 trade_date**; 结论已记入 `ic_writer._get_et_trade_date()` docstring。首个受影响日 = 2026-09-07。
**契约测试 (新增, 52 条)**: FTSeek 仓 `tests/test_da_trading_day_guard.py`(照 `tests/test_da_output_contract.py` / `test_da_fundamental_contract.py` 的"被测对象在仓外 skill, 不可用即 skip"惯例)。钉住: L2 规则层 2026-2028 **逐日精确**(10/10/9 天) · L2 与仓内 SSOT 离线表**跨仓一致**(唯一允许差异 = 2026-12-24) · 哥伦布日/退伍军人日**必须放行** · `latest_trading_day` 跨周末+假日前推 + 2026 全年穷举 · fail-open 语义 · ic_writer **不得再持有假日表**(AST 级反平行真源闸, docstring 提及不误判) · pipeline 守卫顺序/`--force`/JSON 契约/text 契约。全绿 0.72s。**回归有效性已验**: 用还原的旧 `_get_et_trade_date` 逻辑复算 2026-09-07 → 得 `2026-09-07`, 即本测试在修复前必红。

**④ Step4 形状契约补强 (落地后追加)**: 核实 cron `e0d574cc1a3c` 的 **Step 4 明文要提取 `candidates_total` / `analyses_count`**, 而这两个键在正常结果里位于 `stages.signal` / `stages.output` ⇒ 跳过时原本吐 `"stages": {}` 会让 agent **因缺键在假日自由发挥编摘要**。改为吐**同形状空值**(`stages.signal.candidates_total=0` + `market_condition="跳过: <date> (ET) 非美股交易日"` / `stages.output.analyses_count=0` + `analyses=[]`), Step4 既定提取路径照常命中得 0; 契约测试同步钉住该形状。

**🔶 本批新发现的残留缺口 → 已于同日 FTSeek 仓 07b 批补齐 (下方原文保留作立案取证)**: DA cron `e0d574cc1a3c` **不是裸调 `pipeline.py`, 而是四步 LLM agent prompt** (Step1 取 watchlist → Step2 `pullback_stats.py` 刷新回吐率 shadow(~2min 纯K线、无 LLM) → Step3 `pipeline.py --mode full --top 5 --symbols "$SYMBOLS" --format json` → Step4 出摘要)。**本守卫只覆盖 Step 3** ⇒ 假日仍会跑: agent 会话本身(编排 token) + Step1 + Step2(重写 `pullback_shadow.json`)。即后果 (a)「白跑」的**主体**(30-40 只 × 30-60s LLM ≈ 20-40 分钟)已消除, 但**未归零**; (b)(c) 已完全消除(都在 Step3 内)。**建议补法(待裁)**: cron prompt 加 **Step 0 早退, 判定仍由代码给出** —— `cd /root/.hermes/skills/deep-stock-analysis/scripts && python3 -c "import trading_calendar as t;d=t.today_et();ok,layer=t.resolve(d);print(d,ok,layer);raise SystemExit(0 if ok else 3)"`, 非 0 即报告「非交易日, 跳过本轮」并终止。**这与立案时被否的 C 案(纯提示词判断假日)不同**: 真源仍是 `trading_calendar`, prompt 只决定是否继续 Step1-2, 可靠性不变; 改的是 hermes cron 配置(`~/.hermes/cron/jobs.json`), 属自动化层变更, 故不擅动。
**[07b 更新]** 该缺口已闭合: DA cron Step 0 经 `hermes cron edit --prompt` 落地(判定仍由 `trading_calendar.py` 给出, exit 3 即终止不跑 Step1-3, 报错则 fail-open)。**同时挖出更大的一族病灶并从工具侧根治** —— FTSeek 仓 `scripts/trading_day_check.py` 自称「exit code 始终 0, 按 stdout 判断」, 而**全仓 9 个消费方无一读 stdout、全部读 exit code**(4 个 cron prompt 的 `EXIT=1` + `da_supply_reconcile_check.py:99` / `premarket_reprice_shadow.py:73` / `business_heartbeat.py:95` / 两条 `ops/hermes/intraday_diagnose*.py`) ⇒ **9 处假日分支全是死代码, 全系统交易日守卫实际退化为「只排周末」= 等于零守卫**。修法=改工具(exit 1 = 非交易日, stdout token 逐字不变, 周末判断前置于任何 import, 不确定一律 fail-open), 一处救活 9 个消费方; 并把其判定真源从「直接读 `US_HOLIDAYS` 常量」收敛到 SSOT 方法 `get_holiday_calendar().is_trading_day()`(旧写法绕过 Futu 权威层, 且继承离线表在 2026-12-24 上的误标)。两条 intraday 脚本另改为按 stdout 判定(崩溃时 fail-open 照报), 零行位移故仓内 8 处 `:198`/`:206` 行号引用继续有效, 三份副本(devops skill 上游 / 仓内 ops / cron 活体)sha1 校验一致。新增 `tests/test_trading_day_check_contract.py`(27 条), 全量 **3090 passed / 37 skipped / 0 failed**。**教训升级**: 除「仓内已有权威表就别硬编码副本」, 再加一条 —— **工具的 docstring 契约必须与全部调用方的实际读法对账**(本例 9/9 相反且 6 周无人发现, 因失效方向是「照跑」而非「报错」)。详见 FTSeek 仓 `handoff.md` `### 2026-09-07b`。
**顺带发现 (属仓内侧, 本批未改, 已登记 handoff)**: ①FTSeek SSOT 自身在 **2026-12-24** 自相矛盾 —— 离线 `US_HOLIDAYS` 表列为整休, Futu 权威路径返回 True(该日 NYSE 提前收盘 13:00 ET 而非全日休市, 按"是否交易日"口径应为 True)。L2 取 True; 这是 L1/L2 的**唯一**分歧日, 测试已把分歧范围钉死。②哥伦布日/退伍军人日是联邦假日(债市休市)但 NYSE **照常开盘** —— 拿债市日历套股市是本类修复最典型的复发方向。
**⚠️ 「未处理」结论已被同日扩批推翻**: 原记「两条 intraday-diagnose cron(`36cc015242ee` / `5513c8e94b06`)仍无假日守卫」—— **错**, 二者都有守卫(subprocess 调 FTSeek 仓 `scripts/trading_day_check.py`), 但**判据是死的**(该工具 exit code 恒 0, 而全仓 9 个消费方全部按 exit code 判断 ⇒ 假日分支恒不触发)。已在 FTSeek 仓侧根治(工具改 exit 1 = 非交易日, 一处修好 9 个消费方; 两条 intraday 脚本另改为按 stdout 判定以获得崩溃时 fail-open)。详见 FTSeek 仓 `handoff.md` `### 2026-09-07b` + `tests/test_trading_day_check_contract.py`(27 条)。
**验证**: `pytest tests/test_da_trading_day_guard.py -q` → **52 passed / 0.68s**; DA 测试簇 6 文件 **109 passed**; FTSeek 全量套件 **3063 passed / 37 skipped / 0 failed / 134s**(前基线 3011 passed / 37 skipped ⇒ 净增恰好 = 本批 52 条, **零回归**)。**回归有效性已验**: 用还原的旧 `_get_et_trade_date` 逻辑复算 2026-09-07 → 得 `2026-09-07`, 即本测试在修复前必红。`pipeline.py --help` 含 `--force`; `pipeline.py:1080` 的 `^version:` 解析复跑得 `0.76`; 生产 venv 实跑 `latest_trading_day(date.today())` → `(2026-09-04, 'ftseek_ssot')`(OpenD 在场, L1 走 Futu 权威源); `ic_writer._get_et_trade_date()` → `2026-09-04`; `py_compile` 三个改动文件通过; 模拟 9/7·9/8·9/4·9/6·11/26·11/27·12/25·2027 元旦判定全对。**按 cron Step3 原样命令实跑**(未带 `--no-db-write`, 即生产写入开启) → **0.197s 拦下、exit 0、零 LLM/零网络**, 输出合法 JSON 且与正常结果同形状。**今晚 (2026-09-07 20:00 CST = ET 周一 08:00 盘前, 劳动节) 为首次实弹验证窗口**: cron `e0d574cc1a3c` 输出应为 `skipped: NON_TRADING_DAY`(判定层 `ftseek_ssot`; OpenD 异常时走 L2 `rule` 亦应判 False)。
**回滚**: 删 `scripts/trading_calendar.py` + `git -C /root checkout -- .hermes/skills/deep-stock-analysis/scripts/ic_writer.py .hermes/skills/deep-stock-analysis/scripts/pipeline.py`(本批未 commit); 测试文件在 FTSeek 仓工作区, 随该仓回退。

## v0.75 (2026-09-06)

PROPOSAL-20260905 丙1/丙2 + 2026-09-02 双推收敛 (2026-09-06, 用户裁「如无问题可以实施」; ADR-038 项4; /root 仓提交 `fab0fdc`) —
① **丙1 打分去覆写**: `_merge_debate_results` AGREE 分支不再用挑战者低分覆写分析师 score。实证 HIGH 档 33/43=77% 被 8.0→6.0 拉平, score_band 单调性 (HIGH +35.70 / MEDIUM·0.9 +9.43 / MEDIUM·0.8 −29.93) 在合成层被摧毁。现 score 保留分析师 band 原值, 挑战者分落 `_challenger_score_shadow`, `_score_lowered_by_challenger` 改义为「若覆写本会生效」(纯归因不改判)。离线复算 (FTSeek-US `scripts/da_score_overwrite_counterfactual.py`, 237 行 gate 日志): tier 翻转 29/33 (良→优), decision 翻转 0, 仓位档翻转 29 — 而 position_size_hint 不参与真实 sizing ⇒ 实质=修尺子, 零准入变化零敞口变化。
② **丙2 band 落库**: `pipeline.py` bridge 落库新增 `score_band` / `challenger_score_shadow` / `score_lowered_by_challenger` 三字段 (band 是打分区分度的真载体, 此前只在 checkpoint 内, 指令级不可 join ⇒ 修覆写后无法回测档位表现)。消费方登记 (P7 军规): FTSeek-US `scripts/shadow_field_cardinality.py` 基数自检, 已挂日检 W2 棘轮 (`scripts/daily_invariant_check.py::_check_field_cardinality` + `data/field_cardinality_baseline.json`)。
③ **双推收敛** (2026-09-02, DEB-20260902 §八 P2, 与提案无关的同文件在途改动一并入库): Stage 6c 移除 skill 侧飞书盘前直推 — 服务侧 `run_playbook_morning_push` 自 07-11 起为唯一推送方, 两进程幂等标记互不可见致 09-02 实锤同内容双推 (skill 19:28:01 + 服务 19:28:07); 收敛为服务侧单点 (无跨进程共享状态/无竞态窗口, 并消除 VIX/SPY 双快照不一致)。Obsidian 盘前归档仍留 skill 侧不动; `--no-db-write` 的 A/B 隔离语义照旧。
④ **文档形态收敛** (同版本号, 本批 2026-09-06): frontmatter `version` 补更 0.74.1→0.75 (修两次漏更, 见下方 ⚠️) + `description` 8,766→约 500 字符 (版本史整体迁本文件) + 58 条 ✅ 已闭环 Pitfalls 迁 `references/pitfalls-closed-archive.md` (SKILL.md 112,708→52,881 字符, −53.1%) + 新增 `references/INDEX.md` 路由全部 66 份参考文档 (含 12 份从未被引用的孤儿) + 3 处「已失效的现状描述」更正为指向代码 SSOT 的指针。
⚠️ **归因事故留痕 (本条即修复)**: `version:` 自 v0.74.2 起**漏更两次** — `f9add74 [v0.74.2]` 与 `fab0fdc [v0.75]` 两个提交都只改 `scripts/*.py` 而未改 SKILL.md ⇒ `data/opportunity_scan_2026-09-0{1,2,3,4}.json` 的 `skill_version` 全部错记 `0.74.1`, 而 9/1 起实际跑的是 v0.74.2 代码。`pipeline.py:1080` 以本字段为 `skill_version` **单一真源** ⇒ 违「新旧基线必须切分」(数据口径七律#2), 恰是该字段被设计出来要防的事。
   **遗留缺口 (登记待裁, 本批未擅改代码)**: `skill_version` 只写 bridge JSON (`pipeline.py:1378`), **不写 DB 指令行** — 实测 `raw_instruction_json` 内 125/125 条为 NULL ⇒ 指令级无法按 skill 版本切分, 只能按 date join bridge 文件。与 ② 所修的「band 只在 checkpoint 内, 指令级不可 join」是同一族病灶。补法=同 ② 模式加一个顶层键, 但按 P7 军规须先登记消费方 + 基数自检, 故留待用户裁。
验证: 复跑 `pipeline.py:1080` 的 `^version:\s*(\S+)` 解析得 `0.75`; 版本史与 Pitfalls 迁移块均经 sha1 逐字节校验; SKILL.md 内全部 `references/` 指针可解析。回滚: `git -C /root checkout -- .hermes/skills/deep-stock-analysis/SKILL.md` (工作区改动前已确认干净) + 删 `references/{CHANGELOG,INDEX,pitfalls-closed-archive}.md`。

## v0.74.2 (2026-09-01) — 补记

2026-09-01 红队复查: **检查点原子写修复** — `_ckpt_save` / `_ckpt_save_raw` 原 `open("w")+json.dump` 非原子, 蒸馏影子 21:40 读 raw.json/checkpoint 时思考模式 DA (全轮延后) 可能仍在写 → 半文件 `json.load` 失败 → 丢样误判。修: 新增 `_atomic_write_json` (tmp+fsync+os.replace, 旧文件滚动留 .bak; tmp/.bak 后缀与三个消费方 glob 核对无碰撞)。回滚: `scripts/pipeline.py.bak-atomic-20260901`。(/root 仓提交 `f9add74`。**本条为补记** — 该提交未同步更新 SKILL.md frontmatter, 是 `version` 漏更的第一例。)

## (未版本化首行)

自我进化交易闭环：盘前扫描→LLM深度分析→信号门禁→FTSeek执行→盘后复盘→策略记忆积累。

## v0.74.1

2026-09-01 复查收口(v0.74两处修复, 修尺子前置救火) — ①思考模式硬超时越线修复(P0): _call_llm urlopen timeout=60 硬编码未随 v0.74 思考开关调整, 真实负载探针实测 81.3s/候选(2048推理+3228内容=5276 out tok, ~65 tok/s, json_mode+前缀缓存格式全复刻) 越旧60s墙 → 今晚首夜全候选将timeout→重试链(60+8+60+降级60s)全灭→DA全轮停摆; 修复: _call_llm 增 timeout 参数(默认60=关思考路径逐字节原行为), synthesize 思考分支传 240s(3×实测/2×DEB-b判据② p90 120s线, 真超慢调用仍经 _llm_latency_ms 观测暴露非腰斩). v0.74冒烟"2.1s简题"未覆盖真实负载延迟为本病灶根因. ②system_override 指纹独立: v0.74 的 _prompt_hash 恒记 PROMPT_HASH(V1), 蒸馏影子V2臂将顶着V1指纹落盘(归因切分反向污染, 违DEB-c §三"V2独立指纹"承诺); 修复: override 时按实际system文本计 _prompt_fingerprint, 生产路径(不传override)仍恒 PROMPT_HASH 1f53d632452b 不变. 验证: 布线4断言(思考on=240/off=60/override指纹d5dbc86a≠生产/生产hash不变)+py_compile. 回滚: scripts/llm_synth.py.bak-latency-20260901.

## v0.74

DEB-20260901b DA思考预算直接切生产(2026-09-01 用户裁"直接切生产, 修尺子提升质量"; 提案原推荐影子先行, 用户终裁覆盖) — _call_llm 增 extra_body 透传参数(默认None=逐字节原行为); synthesize 分析师调用开 enable_thinking=True + thinking_budget=2048, max_tokens 配套 3000→6000 (推理token计入输出预算, 防网关7/6 P0 empty_response 教训重演); 新增 _llm_latency_ms/_thinking_enabled 观测字段随 _llm_output 落 checkpoint (修尺子: 延迟/成本/截断三指标从今晚可核)。冒烟实弹: thinking_budget 参数可达+JSON共存+finish=stop。同批为 DEB-20260901c 预埋: synthesize 增 system_override 参数(蒸馏影子专用, 默认None生产不变, 单一变量=system文本)。回滚: DA_THINKING_ENABLED=0 (.env.us) 恢复关思考+3000上限逐字节原行为; 备份 scripts/*.bak-thinking-20260901。风险已披露: 全轮延迟预估 2-4x (桥接惰性加载无硬截止, 07:00 ET 发车仍远早于开盘); 成本 +$0.3-1.5/日 (日报全链路口径已可视)。PROMPT_HASH 不变。

## v0.73

DEB-20260901 Phase A 结构化入场语义 + 2026-09-01 PE审阅执行批(用户裁"按照建议处理/按建议执行"): ①结构化入场语义(影子先行, 零执行变更) — USER_PROMPT execution_plan schema 增 entry_archetype(BREAKOUT/PULLBACK_LIMIT/FADE_SHORT 枚举+判定规则)/confirmation(确认位)/chase_cap_price(禁追线), LLM 直出优先 + pipeline _derive_entry_semantics 文本确定性兜底; adapter.to_voting_result 三字段透传 (消费方: FTSeek Phase B 影子+弹药先行路由, 默认关). PROMPT_HASH bd93af5b0570→1f53d632452b(模板文本变更, 基线切分锚点, 9/1夜起生效). ②生料落盘(信息供应链审计建议①) — pipeline _ckpt_save_raw: 每候选 DeepAnalyzer 前写 data/da_checkpoint/{date}/{symbol}.raw.json (schema=da_raw_inputs/v1, 完整 collected+注入上下文), 回答"模型到底看到了什么"可溯源, 纯新增旁路零行为变更. ③负向论据警示前置注入(审计建议②) — llm_synth _load_negative_claims_warning_for_prompt: 窄口径(只负向/只语义论据 _INTERNAL 前缀过滤/alpha口径 avg_alpha_t1<-0.002∧n≥10/top10最差/声明参考非否决), 不复活 7/18 裁关的旧 IC 注入; 开关 FTSeek playbook.claim_negative_prompt_enabled(代码默认True, 键为纯回滚开关, false即停注); 动态数据段注入不改 PROMPT_HASH, 归因按日期+开关状态切分(与 trading_card/symbol_card 注入同惯例). ④DA分析师 system 前缀缓存 — _call_llm 增 cache_system 参数: SYSTEM_PROMPT 静态 → content数组+cache_control=ephemeral 命中 DashScope 显式前缀缓存(与网关 model_call 同格式, 实弹验证第2发命中1879/1904=98.7%); 开关 config.py DA_PROMPT_CACHE(默认开, =0回滚); 纯传输层不改内容不改指纹; 挑战者侧不启用(其模型数组格式未验证); 降级链: 缓存格式全败→纯字符串system再试一次. 验证: 双发实弹缓存命中+负向注入生产venv冒烟(594字符11论据)+py_compile. 回滚: scripts/*.bak-pe20260901b + 各开关; config.py 仍不入库(沿既有约定, 回滚靠 .bak).

## v0.72

DA链复查修复批(2026-08-31, 用户裁"明确有问题可修正的做修复"; 复查范围=SYSTEM/USER/挑战者prompt+注入+关联模块, 8/25-28四天生产实证): ①挑战者分析视图重构 — 旧json.dumps(分析师输出)[:3000]盲目截断实测n=50: execution_plan起始1500-3338字符, key_levels被切48/50(96%)/invalidation_triggers被切41/50(82%)/止损止盈价被切~30% → 核验维度e"价位合理性"与失效条件审查结构性失明; 新_challenger_analysis_view剥_前缀噪声字段(_usage/_finish_reason/score_legacy等)+execution_plan/key_levels前置+上限3000→6000, 50/50回归关键字段全保留(回滚DA_CHALLENGER_ANALYSIS_CAP=3000). ②挑战者数据视图白名单补4段(行业对比/财报日历/数据质量审计/前序回吐率) — 行业对比含DA-A1行业PE中位数(分析师引用后挑战者原无法核验), 财报日历系核验维度d硬日期风险(财报/CPI/FOMC)职责所需. ③覆盖统计单一真源 — 原头部读_quality宽松口径(空壳也算ok, 实测恒19/19=100%)与审计段严格口径(_has_meaningful_data, 16源)矛盾并存, 生产实证模型自行计数输出矛盾数据("15完整/1降级/3缺失"把字段当维度); 新_classify_data_sources(19维含news_v2/market_context/industry_peers)头部+审计同源, 充分性标记改严格口径(缺失+空壳), data_quality_note从"模型自行清点"改"照抄审计段数字"(P8原则); 注: 源降级≥6时充分性标记将如实翻"不充分✗"触发路由, 系契约本意非新行为(回滚DA_COVERAGE_STRICT=0精确复现旧双口径). ④USER_PROMPT schema补skip_reason字段 — 原三处规则要求+校验器检查但schema未列 → 稳定6-12违约/天+实测三天26次额外repair LLM调用(约9次/天白烧); ⑤盘前"当前价格"标注昨收防锚定(与LIF盲区同病灶). PROMPT_HASH 15c13f7cb3f3→bd93af5b0570(④⑤动模板文本; ①②③为数据段/接线不改指纹). 挑战者system prompt未动(其指纹不变). 验证: 合成数据双口径对照+50例checkpoint回归+AAPL真实采集端到端(无LLM调用)+py_compile. 零门禁/阈值/仓位变更. 回滚: scripts/llm_synth.py.bak-deb20260831-dareview + SKILL.md.bak-deb20260831dareview 或各环境变量开关. 未动(留观测): 新挑战者AGREE率96-100%(样本2天)/decision_conf恒0.70常量退化(第四例)/gate BLOCK率71-73% — 均属裁决件非缺陷件.

## v0.71

挑战者模型切换(2026-08-27用户裁决): CHALLENGER_MODEL默认 deepseek-v4-pro → deepseek-v4-pro-0813 (DashScope日期快照, 固定版本防基别名静默升级)。原诉求deepseek-v4-pro-0831经DashScope+官方API双端实测不存在(404/400), 0813为现有唯一pro快照(实弹验证_model_reported=deepseek-v4-pro-0813)。切换依据(亏损溯源): 8/14-8/21最差8笔DA亏损(-1596$, 全部SL_INITIAL)均为旧挑战者AGREE放行(旧设计104/107伪独立); 8/22四死门复活+8/25证伪官/score_band上线后连续3交易日零亏损(29笔+1190$) — 新挑战者设计有效但样本仅3日, 换模型不污染归因(每条决策落challenger_model/challenger_model_reported/challenger_prompt_hash, 新旧样本可切分)。PROMPT_HASH不变(模型非prompt)。回滚: scripts/config.py.bak-challenger-0813-20260827 或 .env.us设CHALLENGER_MODEL覆盖。

## v0.70

DA链路审计修复(2026-08-26全链复查, P0字段错配+P1机械批次): ①生产端字段错配修复 — collect_snapshot真键是pe_ttm_ratio/total_market_val/highest52weeks_price/lowest52weeks_price且无change_pct键, 而llm_synth prompt模板与_snapshot回填读的是pe_ttm/market_cap/change_pct等幻键 → 实测100%分析看到PE=0/市值=0/涨跌幅=0, 叠加USER_PROMPT"PE为负或0必须在bear_case提及"规则 = 系统性诱导模型编造基本面叙事. 修复: llm_synth新增_fundamental_view归一化helper(prompt渲染+回填同源), 缺失维度显式渲染"数据未采集(N/A)"防0假象; data_collector VIX块与peer块chg_pct/pe/market_cap改读真键+涨跌幅由last/prev_close现算. **数据层修复, PROMPT_HASH不变**(指纹只含SYSTEM/USER_PROMPT文本) — 基线连续性保持. ②财报日历DST: month近似偏移→zoneinfo America/New_York(llm_synth). ③机械批次(agent执行): ic_writer/strategy_memory/feedback_loop month-DST→真实ET时区; 4处外部进程PRAGMA journal_mode=WAL移除(防跨进程锁模式污染); alpha_backfill claim_ic_cache写原子化(tmp+os.replace)+pullback_stats落盘原子化; alpha_backfill无条件os._exit(0)改条件退出透传真实退出码(原cron失败伪装成功). 零门禁/阈值/仓位变更. 回滚: scripts/*.bak-deb20260826-chainaudit (该仓git不可用于回滚).

## v0.69

P10消费接线+P8锚点代码化(DEB-20260825第15轮, 独立复核三发现修复): ①invalidation_triggers从"只写不读"接通消费链 — adapter/bridge/DB三点透传到raw_instruction_json, FTSeek tripwire_checker.py新增结构化判定轨道(纯函数+收盘价收盘守卫+过期条件跳过+5日涨跌日K口径), 并修其pending过滤硬阻塞(原只检有自然语言invalidation的指令, 结构化条件整条被排除=必然判死). 判定语义与文本侧同宁漏原则, 双轨OR合并, 审计行structured_detail独立留痕. ②score_band锚点③"数据覆盖≥12/18维"修复 — 采集器实际19维("18"是错的)且模型无法自行清点 → 改代码按_quality算好"数据充分性:充分✓/不充分✗"注入数据头, 模型只读标记; 阈值=缺失<6维与【数据充分性路由】单一真源镜像对齐(原锚点与LOW条件②在19维下13维边界互斥矛盾一并消除). ③口径: 5日涨跌与DA技术面chg5差一根(现价口径), 阈值带裕量下不翻转, 已记边界. PROMPT_HASH c9cc35bfa345→15c13f7cb3f3. 实弹: 结构化判定9场景+提取器白名单+META双口径复算+当日12指令dry-run向后兼容+35契约测试全过. 回滚: 双仓均已有git提交可revert; DA_SCORE_BAND=0不影响本轮(锚点是注入非映射).

## v0.68

DA prompt 结构性去塌缩(DEB-20260825第14轮 P8/P9/P12, 含P10/P11): ①P8 score契约从"模型自由点估值"(实测塌缩到7.0占67%, merge的|orig-chall|>3→SKIP规则0/107结构性死亡)改为三档可判定枚举score_band(HIGH/MEDIUM/LOW, 锚定=独有事件+未被价格反映+数据充分, 逐条数不给感觉档)由代码映射为数字(HIGH→8/MEDIUM→6/LOW→3), 档间差HIGH vs LOW=5使改判规则复活, 原始score保留score_legacy; 回滚DA_SCORE_BAND=0. ②P9 挑战者从"独立复现"(实测independent==my方向107/107=伪独立, 同份证据二次阅读必然趋同)重构为"证伪官": 假设候选方向会亏, 找有数据出处的具体反证, 找不到≥2条就诚实AGREE+写"无实质反证"(禁止为显得严格编造missed_risks, 实测旧挑战者107/107都能凑4条风险=仪式化); 挑战者my_score_band同表映射. ③P12 同向AGREE时挑战者更保守→score取低(此前challenger_score只落盘不进合成, "更保守"信号完全丢失). ④P10 新增invalidation_triggers字段(本股可判定: metric限收盘价/成交量/5日涨跌/盘前涨跌幅+</>+纯数字value), 校验器只报告不repair, 合规旧tripwires可回填——治"tripwires写2条但metric是外部标的/自由文本, tripwire_checker无法消费"的仪式化. ⑤P11减法: 删challenger_system_v1死分支(DA_CHALLENGER_V2默认1永不命中)+_load_claim_ic_for_prompt改空壳(7/18起停用, 兼容归档脚本import)+USER模板KO分级制重复段合并. prompt指纹c9cc35bfa345(基线切分). 零门禁/阈值/仓位/方向改写变更. 代码回滚: scripts/*.bak-deb20260825r14 (该仓有未提交变更, git不可用于回滚).

## v0.67

DA输出契约执行化+影子结案(DEB-20260825第13轮): ①P1 输出契约由代码判定(tripwires>=2/三价位齐全且方向自洽/bull-bear各>=2/claim_type枚举/SKIP必带skip_reason), 违约落盘并对**纯结构缺失**打1次定向补全 — 补丁白名单只含tripwires/三价位/skip_reason, direction/rating/score结构上不接受补丁(零方向变更, 打桩实测恶意夹带改写无效); 修前基线 tripwires<2占17%(18/107). ②P3a 挑战者采样稳定性shadow(DEB-20260723 H5)按其自设判据结案下线: v2窗n=107方向翻转0/107+零消费方 → 省2次LLM调用/候选. 挑战者调用3→1. ③P6 观测补齐: _call_llm记录finish_reason/usage(截断与成本此前双盲)+prompt指纹sha1随决策落盘(新旧基线可切分)+da_gate_decisions.jsonl补14字段(DA自身score/rating/skip_reason/tripwire数/五维不通过维度/契约违约/token). 零门禁变更. 回滚: DA_SCHEMA_ENFORCE=0; 代码回滚用 scripts/*.bak-deb20260825r13 (该仓有未提交变更, git不可用于回滚).

## v0.66

DA prompt去偏修复(DEB-20260825第11轮): ①校准原则从docstring死链路移入SYSTEM_PROMPT实际生效 ②【交易经验参考】删除被证伪的"本股历史全亏→同方向加门槛"(反持续pearson=-0.40) ③SHORT三问去掉过时胜率论据改结构性理由+新增BUY镜像义务(多空对称) ④注入标签"方向先验"→"背景事实,非方向先验". 零规则变更, 纯信息层修正.

## v0.65

DA生成延后18:00→19:00CST(07:00ET, 财报80%在06:00-08:30ET发布; 就绪19:30距开盘2h缓冲不碰20:00预检) + bridge落盘premarket_movers块 + 盘后验证cron(延续率/顺势影子收益/指令影子结局, n≥30再评估转实盘). 详见 references/da-timing-and-premarket-verify-20260811.md

## v0.64

盘前异动全链路打通(LIF盘前-19.5%盲区): snapshot补pre/effective_price+真premarket_movers渠道+prompt盘前段硬规. Stage2注入|涨跌|≥8% top2. 执行侧extreme_gap>8%逆方向同步thesis_drift_invalidate.

## v0.63

结构约束前置(SL距entry 2-5%/不接跌>5%飞刀LONG/回踩优先追涨). v0.62: 挑战者禁SKIP必表态. v0.61: 版本桥戳+conf_semantic双写(DEB-20260723).

## v0.60及更早

交易哲学(不预测,识别)+候选瓶颈/score恒定7.0致tier失效/吞吐量瓶颈/单笔复盘方法论/5断裂点审计/幻觉检测/conf<40拦截/BridgeVotingAdapter/多渠道扫描/IC门禁/退出分桶. 详见refs/.
