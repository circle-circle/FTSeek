# Exit Rule Three-Layer Architecture (2026-07-09)

## Key Question Answered

"个股的退出阈值和策略是根据分桶配置还是基于盘前生成计划(无论voting还是skills)产生时加入?"

**Answer: Both — two layers determine exit strategy, plus a third dynamic override layer.**

## Three Layers

### Layer 1: Pre-market Plan conditions → Exit strategy TYPE selection

**Code path**: `pipeline.py:2677-2678`
```python
_conditions = meta.get("conditions", [])
_exit_cfg = _get_factor_exit_config(_conditions, _factor_exit_rules, direction=direction)
```

`_get_factor_exit_config` (pipeline.py:2505-2537) matches conditions against `playbook_horizon.yaml`'s `factor_exit_rules` dict. Direction-aware: BUY优先匹配BULLISH_CONDITIONS, SHORT优先匹配BEARISH_CONDITIONS.

**So the conditions produced by deep_analysis (bridge) or VotingCoordinator directly determine:**
- `trailing_enabled` (true/false)
- `time_exit_hours` (0.5h-999h)
- `breakeven_at_pct` (0.5-1.5%)
- `trailing_step_pct` (1.5-2.0%)
- `max_hold_days` (1-5 days)

### Layer 2: Static vol_buckets → SL/TP VALUES

**Code path**: `instruction_generator.py:324-329`
```python
_vol_sl_info = _compute_volatility_based_sl_tp(atr_pct, _direction, _horizon_params, pb_cfg)
_max_loss_pct = _vol_sl_info["sl_pct"]      # stop loss %
rr_ratio = _vol_sl_info["tp_multiplier"]    # take profit multiplier
```

vol_buckets (from `playbook_horizon.yaml`) compute SL distance based on ATR%, with floor/ceiling caps. Direction-aware: SHORT gets `short_widen_pct` added.

**BUT**: `short_horizon.rr_ratio=999` overrides tp_multiplier — TP is effectively disabled for short horizon. vol_buckets' tp_multiplier (1.5-2.0×) is computed but NOT used. Only `long_horizon.rr_ratio=2.0` lets TP work.

### Layer 3: exit_param_override.json → Dynamic feedback adjustment

**Code path**: `pipeline.py:2651-2674`

feedback_loop generates `exit_param_override.json` with overrides keyed by `direction+exit_reason` (e.g., "LONG+TIME_EXIT"). Overrides modify `time_exit_hours`, `trailing_enabled`, `breakeven_at_pct` in factor_exit_rules.

**Current state**: `overrides_count: 0` — no active overrides yet. feedback_loop analyzes but hasn't generated adjustments (needs ≥10 samples with WR<45%).

## Real Data: Bridge vs Voting conditions → Different exit strategies

| Candidate | Source | conditions | Matched rule | trailing | time_exit |
|---|---|---|---|---|---|
| TTE | bridge | `['news_positive','roe_high','sentiment_bullish']` | roe_high | ✅ | 999h |
| ANET | bridge | `['news_positive','revenue_growth_high','above_ma20']` | above_ma20 | ✅ | 6h |
| ASML | bridge | `['news_positive','sentiment_bullish','revenue_growth_high']` | revenue_growth_high | ✅ | 999h |
| ORCL | voting | `['above_ma20','macd_golden_cross','news_positive','volume_expansion']` | above_ma20 | ✅ | 6h |
| TSM | voting | `['insider_net_buy','news_positive']` | insider_net_buy | ✅ | 999h |

**Key insight**: Bridge candidates' conditions skew fundamental (roe_high/revenue_growth_high) → matched to long-hold exit rules (time_exit=999h, max_hold=5d). VotingCoordinator conditions skew technical (above_ma20/macd_golden_cross) → 6h time_exit. This is by design — deep_analysis conditions reflect LLM's thesis about the stock's fundamental drivers.

## Exit Execution Priority Chain (pipeline.py:2696-2766)

```
Rule 0: Opening cooldown (first 15min, SL widened to 4%)
  ↓
Rule 1: SL_FIXED_PCT (effective_sl touched, includes breakeven+trailing)
  ↓
Rule 1.5: TAKE_PROFIT (only if rr_ratio < 100 and take_profit > 0)
  ↓
Rule 2: OVERNIGHT_GAP_STOP (cohort B, gap > 3%)
  ↓
Rule 4: PRE_CLOSE_EXIT (8min before close, cohort B profit can skip)
  ↓
Rule 3: TIME_EXIT (hold > time_exit_hours AND profit < 0)
  ↓
Rule 5: MAX_HOLD (cohort B/long, hold ≥ max_hold_days)
  ↓
EOD backstop: force_close_orphaned_sim_positions
```

## Dynamic Effective SL (_compute_dynamic_effective_sl, pipeline.py:2540-2582)

1. If peak_profit < breakeven_at_pct → use initial_sl
2. If peak_profit ≥ breakeven_at_pct → SL moves to entry (breakeven)
3. If trailing_enabled:
   - Every trailing_step_pct beyond breakeven → lock 50% of profit
   - Max 3 steps
   - `locked_pct = breakeven + step × (step-1) + step × 0.5`
4. If not trailing_enabled → stay at breakeven

**Example** (above_ma20, breakeven=1.0%, trailing_step=2.0%):
- Peak +1.0% → SL=entry (breakeven)
- Peak +3.0% → SL=entry+2.0% (step 1: lock 1.0+2.0×0.5=2.0%)
- Peak +5.0% → SL=entry+4.0% (step 2: lock 1.0+2.0+2.0×0.5=4.0%)
- Peak +7.0% → SL=entry+6.0% (step 3: max)

## rr_ratio=999 Design Decision (2026-07-08)

```yaml
short_horizon:
  rr_ratio: 999  # 移除TP, 让EOD捕获利润(100%WR avg+$203)
```

**Rationale**: TP=3% never triggered in backtests. SHORT EOD avg return=5.66%. Removing TP lets winners run to EOD.

**Risk**: Intraday peak not captured if price retreats by close. But data supports: EOD_FORCE_CLOSE 86% WR, avg +$128/trade.

**Long horizon**: `rr_ratio=2.0` — TP IS active for long horizon positions (max_hold=3d, needs profit target).

## Current Limitation: No condition-level TP differentiation

rr_ratio is horizon-level (short=999, long=2.0), NOT condition-level. A bridge candidate with roe_high (max_hold=5d, time_exit=999h) uses rr_ratio=999 (no TP) because it's in short_horizon. If you wanted fundamental-conditions to use TP while technical-conditions don't, the current architecture doesn't support it — would need condition-level rr_ratio override.

## Verification Commands

```bash
# Check current exit_param_override
cat /opt/ftseek/FTSeek-US/data/exit_param_override.json

# Check bridge candidate conditions vs instruction conditions
cd /opt/ftseek/FTSeek-US
/opt/ftseek/FTSeek-US/venv/bin/python3.11 -c "
import sqlite3, json
db = sqlite3.connect('data/ftseek_us.db')
cur = db.cursor()
cur.execute(\"SELECT id,symbol,conditions_json,decision_id FROM playbook_instructions WHERE date='2026-07-08' AND direction != 'SKIP' ORDER BY confidence DESC LIMIT 10\")
for r in cur.fetchall():
    conds = json.loads(r[2]) if r[2] else []
    is_bridge = r[3].startswith('DA-') if r[3] else False
    print(f'id={r[0]} {r[1]:10s} conditions={conds} bridge={\"Y\" if is_bridge else \"N\"}')
"

# Check factor_exit_pnl analysis
cat /opt/ftseek/FTSeek-US/data/factor_exit_pnl.json | python3 -m json.tool | head -40
```
