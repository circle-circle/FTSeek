# Signal Gate Wiring — P0 Fix (2026-07-10)

## Problem

`pipeline.py` Stage3 (L147-153) computes `gate_result` via `signal_gate.evaluate_signal(analysis)`:
- 7-dimension quality assessment: symbol history, pattern match, claim IC, RR ratio, quality_score
- Decision: PASS (≥65) / WARN (≥40) / BLOCK (<40)
- Stored in `analysis["_signal_gate"]`

But `_write_bridge_file` (L358-361) writes DB instructions checking only `direction in (BUY, SELL_SHORT)`. Never reads `_signal_gate`. BLOCK signals write to DB and execute via auto_execute.

## Fix

In `_write_bridge_file` loop, after direction filter, before `to_voting_result`:

```python
_gate = a.get("_signal_gate", {})
_gate_decision = _gate.get("decision", "PASS") if _gate else "PASS"
if _gate_decision == "BLOCK":
    print(f"  [Gate] {symbol} BLOCKED (score={quality_score}): {reasons}", file=sys.stderr)
    continue
if _gate_decision == "WARN":
    a.setdefault("position_size_hint", "small")
```

## Behavior Matrix

| gate_decision | action | result |
|---|---|---|
| BLOCK | BUY/SELL_SHORT | not written to DB, not executed |
| WARN | BUY/SELL_SHORT | written to DB, position_size_hint=small |
| PASS | BUY/SELL_SHORT | written to DB, normal flow |
| gate missing | BUY/SELL_SHORT | fail-open → PASS, written to DB |
| gate empty {} | BUY/SELL_SHORT | fail-open → PASS, written to DB |
| any | SKIP | caught by direction filter first |

## Key Design Decisions

1. **Fail-open**: gate missing/empty → PASS (not BLOCK). Reason: if signal_gate module fails, don't block all signals.
2. **setdefault not overwrite**: WARN uses `setdefault("position_size_hint", "small")` — if LLM already set "tiny" (more conservative), it's preserved.
3. **Gate runs before adapter**: saves LLM adapter call cost for BLOCKED signals.
4. **BLOCK reason printed to stderr**: observability without blocking pipeline.

## Verification

- ast.parse: OK
- import pipeline: OK
- 9-case behavioral matrix: ALL PASS (BLOCK/WARN/PASS/gate-missing/gate-empty/SKIP/SHORT)
- Source ordering: direction filter < gate check < to_voting_result
