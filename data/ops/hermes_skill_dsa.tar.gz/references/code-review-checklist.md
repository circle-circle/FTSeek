# Code Review Checklist — deep-stock-analysis

从v0.13 code review总结的8类bug，每类给出检查方法。

## 1. 字段名跨模块不匹配（最高频、最隐蔽）

**症状**: 模块全OK、pipeline跑完不crash，但某个section永远不输出或数据质量审计撒谎。

**检查方法**:
```python
# 提取上游模块产出的字段名
import ast, re
with open('data_collector.py') as f:
    src = f.read()
# collect_all tasks的keys
tasks = re.search(r'tasks = \{(.*?)\}', src, re.DOTALL)
produced = set(re.findall(r'"(\w+)":\s*lambda', tasks.group(1)))

# 提取下游模块读取的字段名
with open('llm_synth.py') as f:
    llm_gets = set(re.findall(r'collected\.get\(["\'](\w+)', f.read()))
with open('deep_analyzer.py') as f:
    analyzer_gets = set(re.findall(r'self\.data\.get\(["\'](\w+)', f.read()))

# 找不匹配
missing = (llm_gets | analyzer_gets) - produced - {"_quality", "_timestamp", "symbol"}
```

**v0.13发现**: llm_synth读`capital`/`analyst_rating`/`insider_tx`，但collector产出`capital_distribution`/`analyst_consensus`/`insider_transactions`→3组不匹配。

**修复**: 下游字段名全部对齐上游产出名。

## 2. API返回格式 vs 代码期望格式

**症状**: API返回`{code:0, data:[...]}`但代码当list用→`dict[:5]`→TypeError（可能被其他分支截胡所以不crash）。

**检查方法**: 实跑API看返回格式：
```bash
/opt/ftseek/FTSeek-US/venv/bin/python3.11 \
  /root/.hermes/skills/futuapi/scripts/quote/get_capital_flow.py US.NVDA --json | head -5
```

**v0.13发现**: `collect_capital_flow`返回`{code:0, data:[{in_flow,...}]}`(dict)，但`_analyze_capital`的`flow[:5]`当list切片。

**修复**: `flow_raw.get("data", [])`先解包，再切片。

## 3. Dead variable（赋值不使用）

**检查方法**:
```python
import re
with open('deep_analyzer.py') as f:
    src = f.read()
# 找只出现1次的变量名（赋值但不使用）
for var in ['vol_change', 'some_var']:
    if src.count(var) == 1:
        print(f"  {var}: dead variable (only assigned, never used)")
```

**v0.13发现**: `vol_change`只在赋值行出现1次，不在输出dict里→dead variable。

## 4. Dead code（elif分支永远不执行）

**检查方法**: 看if/elif链的条件是否互斥。后面的elif条件如果被前面的覆盖→dead code。

**v0.13发现**: `elif pe > 200`在`elif pe > 60`之后→pe>200时先匹配pe>60→PE=300只扣0.3不是0.5。

**修复**: 调换顺序，`elif pe > 200`在`elif pe > 60`之前。

## 5. Index bug（正数索引 vs 负数索引）

**检查方法**: `volumes[2]`是第3天，`volumes[-2]`是倒数第2天（昨天）。如果代码意图是"昨天"但用了正数索引→bug。

## 6. RSI/技术指标计算的dead code

**检查方法**: 看变量是否被赋值两次（第一次被覆盖=dead code），看for循环里的if分支是否所有迭代都走同一分支。

**v0.13发现**: RSI的`change`变量赋值两次，`if i <= period`永远True（因为range(1,period+1)的i永远<=period）。

**修复**: 简化为`for i in range(period): idx = -(period-i); change = closes[idx] - closes[idx-1]`。

## 7. 过时的字符串匹配

**检查方法**: 代码里匹配的字符串（如exit_reason）是否还在实际数据中出现。

```sql
SELECT DISTINCT exit_reason FROM trade_records WHERE exit_reason IS NOT NULL;
```

**v0.13发现**: `feedback_loop`匹配`FLASH_EXIT`但FTSeek的exit_reason里没有这个值→改为`BREAKEVEN_STOP`。

## 8. 兜底值合法性

**检查方法**: `.get("key", default)`的default是否在下游系统的合法枚举里。

**v0.13确认**: `adapter.to_exit_meta`的`["default"]`→不在FTSeek 27个合法枚举里（v0.12已修为`[]`）。

## 总结：静态分析 + 实跑验证缺一不可

| 验证方式 | 能发现什么 | 不能发现什么 |
|----------|-----------|-------------|
| py_compile | 语法错误 | 字段名不匹配、dead code |
| 模块导入 | ImportError | 字段名不匹配、API格式不匹配 |
| pipeline跑完 | crash类bug | 数据不输出但不crash的bug |
| 实跑+查输出section | section缺失 | — |
| 跨模块字段名追踪 | 字段名不匹配 | — |
| SQL参数计数 | UPSERT参数错位 | — |
| 实跑API看返回格式 | dict vs list不匹配 | — |
