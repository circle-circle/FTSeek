# 规划-执行分离架构分析

> 来源: 2026-07-08 session, 用户要求"通过skills deep-stock-analysis实现独立的信息和策略输出, FTSeek管线基于其输出执行, 将规划和执行分开"
> 关联: DEB-20260708-deep-analysis-driven-trading.md, PROPOSAL-plan-execute-separation.md

## 当前链路 (grep验证)

```
FTSeek运行时 (盘中):
  _get_watchlist → screener.screen → _build_instructions_from_votes
    → voting_coordinator.vote() (3模型LLM, 盘中调, 30-60s/标的)
    → deep_analysis门禁 (pipeline.py:627, 读signal_snapshots方向一致性)
    → compute_instruction_values() (FTSeek自己算entry/SL/TP/position_size)
    → Instruction → save_instruction → DB
    → run_playbook_auto_execute → _check_intraday_trigger → execute_instruction → 下单
    → monitor_playbook_sim_exits (SL/breakeven/trailing/PRE_CLOSE/EOD)

deep_analysis skill (盘前):
  pipeline.py → scan → analyze → ic_writer → signal_snapshots.db
    → signal_gate (评估, 不执行)
    → adapter.to_voting_result() (输出4种格式, 但无人消费)
    → ObsidianWriter.write_symbol_analysis (归档)
```

## 三个断裂点

| # | 断裂 | 现状 | 影响 |
|---|------|------|------|
| 1 | adapter输出无人消费 | deep_analysis的adapter输出4种格式, FTSeek运行时不读 | deep的entry/SL/TP/conditions/strategy_type全被FTSeek重算覆盖 |
| 2 | 分桶/退出策略脱节 | deep有strategy_type(quality_breakout/oversold_bounce/trend_short)和position_size_hint, FTSeek用conditions→factor_exit_rules映射退出, 两者不连通 | deep的"超跌反弹应小仓快止盈"无法传递到FTSeek退出策略 |
| 3 | 反馈环路断裂 | feedback_loop更新strategy_memory+claim_ic_cache, 但只回写LLM prompt, 不回写FTSeek退出参数 | 学到"LONG+SL_ATR_STOP亏钱"但FTSeek退出参数不变 |

## 数据接口现状 (grep+SQL验证)

- signal_snapshots.db: deep_analysis写入(60条), FTSeek门禁读取(627) ← **唯一已连通的通道**
- playbook_instructions表: FTSeek写入+执行, deep_analysis不写 ← **断裂**
- claim_ic_cache.json: feedback_loop写入, llm_synth prompt读取 ← **已连通但只影响LLM, 不影响FTSeek退出参数**
- adapter.to_voting_result(): 输出direction/confidence/entry/SL/TP/conditions ← **无人消费**

## 今日(7/8)真实数据

```
voting_llm今日产出:   41只 (9 LONG, 12 SHORT, 21 NEUTRAL)
deep_analysis今日产出: 34只 (27有方向, 7 NEUTRAL)
重叠标的:             27只
voting NEUTRAL标的:   21只 → 其中9只deep有方向(AAPL/BABA/BWXT/GOOG/MSFT/NTES/XOM等)
NEUTRAL fallback救回率: 9/21 ≈ 42%
```

## 最小改动方案 (3个改动打通断裂, 复用已有数据通道)

### 改动1: ic_writer写strategy_type+position_size_hint到factors_json (skill侧, ~5行)

ic_writer.write_signal_snapshot已经写signal_snapshots.db, 只需在factors_json里加strategy_type和position_size_hint。FTSeek门禁(627)查询时能读到。

### 改动2: FTSeek用deep的conditions替代voting的 (FTSeek侧, ~15行, 冻结后)

pipeline.py:627门禁通过后, 如果deep_analysis有conditions, 用deep的conditions替代voting的。FTSeek的factor_exit_rules根据deep的conditions选择退出策略。

效果: deep说above_ma20→FTSeek用trailing让利润奔跑; deep说rsi_oversold→FTSeek用快止盈。

### 改动3: feedback_loop写exit_param_override.json (skill侧, ~20行)

如果某pattern持续亏损, 写exit_param_override.json, FTSeek盘前读取调整factor_exit_rules。

## 良性循环闭环

```
盘前: deep_analysis scan→analyze→ic_writer(signal_snapshots + strategy_type + conditions)
        ↓
盘前: FTSeek读signal_snapshots → deep方向背书 → deep conditions注入instruction
        ↓
盘中: voting(3模型) → 门禁(deep交叉验证) → instruction(deep conditions)
  → trigger → execute → monitor_playbook_sim_exits(deep conditions → factor_exit_rules)
        ↓
盘后: feedback_loop → trade_records → strategy_memory + claim_ic_cache
  → exit_param_override (持续亏损pattern → 调整退出参数)
        ↓
次日: claim_ic_cache → LLM prompt(论据有效性反馈)
      exit_param_override → FTSeek factor_exit_rules(退出参数优化)
      strategy_memory → signal_gate(策略推荐)
```

## FTSeek退出规则映射 (playbook_horizon.yaml factor_exit_rules)

| condition | trailing | breakeven_at | time_exit | 含义 |
|-----------|----------|-------------|-----------|------|
| above_ma20 | true | 1.0% | 6h | 趋势类: 让利润奔跑 |
| news_positive | true | 0.5% | 4h | 催化类: 中等持有 |
| revenue_growth_high | true | 0.5% | 999h | 基本面强: 长持有 |
| pe_below_industry | false | 0.5% | 0.5h | 价值类: 快进快出 |
| below_ma20 | false | 0.5% | 1.0h | 空头类: 快止盈 |
| sentiment_bearish | false | 0.5% | - | 情绪空: 不trailing |
| default | false | 1.5% | 4h | 默认: 跨过死亡区间 |

deep_analysis的adapter._map_conditions已经做了精细映射(bull_case→bullish conditions), 如果FTSeek用deep的conditions, 退出策略会更贴合个股特征。

## claim_ic_cache数据 (215样本)

| claim_type | IC(t1) | n | 有效性 |
|-----------|--------|---|--------|
| product_catalyst | +0.5571 | 9 | ✅有效 |
| insider_bearish | +0.4174 | 6 | ✅有效 |
| volume_expansion | +0.2824 | 35 | ✅有效 |
| earnings_beat | +0.2535 | 8 | ✅有效 |
| above_ma20 | +0.0930 | 106 | 微弱 |
| news_positive | +0.0558 | 67 | 微弱 |
| rsi_oversold | -0.0678 | 17 | ❌无效 |
| macd_golden_cross | -0.0717 | 32 | ❌无效 |
| news_negative | -0.1654 | 9 | ❌无效 |
| insider_net_sell | -0.2997 | 33 | ❌无效 |
| pe_below_industry | -0.4266 | 40 | ❌无效 |

**关键**: pe_below_industry IC=-0.43(最无效), 但deep_analysis的adapter会把它映射给BUY信号→FTSeek用快进快出退出(time_exit=0.5h)。如果IC反馈回写FTSeek, 应该对pe_below_industry的标的降仓而非快进快出。

## 冻结期可做 vs 冻结期后

| 改动 | 侧 | 行数 | 冻结期 |
|------|-----|------|--------|
| ic_writer写strategy_type到factors_json | skill | ~5 | ✅可做 |
| feedback_loop写exit_param_override | skill | ~20 | ✅可做 |
| cron传watchlist标的(--symbols) | cron | 0 | ✅可做 |
| FTSeek门禁读factors_json的strategy_type | FTSeek | ~10 | ❌冻结后 |
| FTSeek用deep conditions替代voting | FTSeek | ~15 | ❌冻结后 |
| FTSeek读exit_param_override | FTSeek | ~5 | ❌冻结后 |
