# SL/TP Re-price Kill Chain Analysis (2026-07-11)

## v0.54 更新 (2026-07-12): 全链路审计确认此断裂为6个断裂点之一

v0.54 全链路审计发现6个断裂点, 此文记录的是其中断裂点[4]。完整6点列表见 `references/da-to-executor-consistency-audit-20260712.md`。

DB验证补充: NVDA 7/10 DA SL=$193.99 → exec SL=$197.59 (1.9% diff), GOOG TP diff=3.3%, NU TP diff=3.4%, NVDA 7/9 TP diff=7.6%。

## 背景

用户追问: "结合止损止盈退出策略的联动" → 发现第4个断裂: re-price 块覆盖 LLM 结构止损.

## NVDA 7/10 完整 Kill Chain

```
LLM 计划:
  entry=$204  SL=$193.99 (MA60下方, 结构止损)  TP=$225
  thesis: "止损$193.99(MA60下方)"

re-price 块 (pipeline.py L2356-2466):
  实时 ask=$206.70 → vol_bucket 重算 SL=$197.59 (4.4% ATR-based)
  ⚠️ LLM 的 $193.99 被覆盖为 $197.59
  ⚠️ $197.59 在 MA60 ($193.99) 上方 → 结构止损被噪声止损替代

execute_instruction:
  custom_params.stop_loss = $197.59 (vol_bucket 值)
  → trade_records.metadata.stop_loss = $197.59
  → 退出系统只看到 $197.59, 永远看不到 LLM 的 $193.99

退出系统:
  entry=$206.70  initial_sl=$197.59 (vol_bucket)
  peak=$207.80 → profit_pct=0.53%
  breakeven_at_pct=0.5% → 触发 → SL 移到 entry=$206.70
  价格跌到 $206.24 < $206.70 → 止损
  结果: 8分钟, -$6.90
```

## DB 实查: 所有 DA- 交易的 SL 对比

| symbol | dir | plan entry | plan SL | plan SL% | actual entry | actual SL | actual SL% | verdict |
|--------|-----|-----------|---------|----------|-------------|-----------|-----------|---------|
| NVDA 7/10 | BUY | $204.00 | $193.99 | 4.9% | $206.70 | $197.59 | 4.4% | SHIFTED (vol_bucket recalc) |
| GOOG 7/10 | BUY | $354.54 | $338.59 | 4.5% | $354.27 | $338.59 | 4.4% | SHIFTED (entry barely changed) |
| NU 7/10 | BUY | $13.93 | $13.23 | 5.0% | $13.93 | $13.23 | 5.0% | IDENTICAL (no reprice) |
| NVDA 7/9 | BUY | $201.96 | $192.87 | 4.5% | $201.92 | $192.87 | 4.5% | IDENTICAL (no reprice) |

**关键发现**: vol_bucket 与 LLM SL 的差异通常很小 (0-0.5%).

## 退出数据验证

| 退出原因 | 笔数 | avg PnL | 说明 |
|----------|------|---------|------|
| PRE_CLOSE_EXIT | 13 | +$24 | 收盘前平仓, 大部分微利/微亏 |
| BROKER_GHOST_CLOSE | 10 | -$10 | broker清理幽灵仓 |
| EOD_FORCE_CLOSE | 7 | +$52 | 盘后强平, 唯一稳定盈利 |
| SL_FIXED_PCT | 6 | -$4 | SL触发, 损失可控 |
| TIME_EXIT | 5 | -$46 | 持仓太久未盈利 |
| TAKE_PROFIT | 1 | +$247 | 唯一TP触发 |

### MFE 分布

| MFE bucket | 笔数 | avg PnL | 洞察 |
|------------|------|---------|------|
| 0 (zero) | 13 | -$223 | 从未盈利 → 入场时机错误 |
| <0.5% | 9 | -$14 | 勉强盈利后回撤 |
| 0.5-1% | 12 | +$1 | breakeven 区域 |
| 1-2% | 7 | +$68 | 有空间 |
| >2% | 7 | +$221 | 足够空间, breakeven 锁利正确 |

### Breakeven 影响

| breakeven_triggered | 笔数 | avg PnL |
|---------------------|------|---------|
| true | 19 | +$92 |
| false (0) | 17 | +$9 |
| null (旧数据) | 12 | -$241 |

## 核心洞察

**入场质量 > 止损位置 > 止盈位置.**

- MFE=0 (13笔, avg -$223): 无论 SL 放在哪都亏 — 方向错了
- MFE>0: breakeven 机制有效锁利 — SL 位置差异不显著
- 真凶是 breakeven_at_pct=0.5%: 0.5% 浮盈就把 SL 移到 entry, 然后任何回撤就止损
- 但 breakeven=true 的 19笔 avg +$92: 整体正期望, 不宜急着改

## reprice 审计字段丢失

`_reprice_params` dict 包含:
- `entry_price` → ✅ 在 _TRACKING_FIELDS 中
- `stop_loss` → ✅ 在 _TRACKING_FIELDS 中
- `take_profit` → ❌ 不在 _TRACKING_FIELDS 中 → 被丢弃
- `reprice_from` → ❌ 不在 _TRACKING_FIELDS 中 → 被丢弃
- `reprice_to` → ❌ 不在 _TRACKING_FIELDS 中 → 被丢弃
- `reprice_original_sl` → ❌ 不在 _TRACKING_FIELDS 中 → 被丢弃

**结果**: 顶层 entry_price/stop_loss 被 update_instruction_tracking 更新, 但审计字段丢失. trade_records.metadata 仍有完整值 (来自 custom_params 直接传递).

## 解决方案: sl_basis 分流

```
LLM 输出 sl_basis:
  "structural" → SL 是技术位 (MA/支撑/阻力) → re-price 时 SHIFT (平移)
  "atr"        → SL 是波动率驱动 → re-price 时 vol_bucket recalculate (原逻辑)
```

**为什么优雅**:
- SL 来源决策集中在 re-price 块一个地方
- 下游全部透明消费: re-price → custom_params → trade_records.metadata → exit monitor
- 不需要改退出系统、不需要改 DB schema、不需要改 executor
- 向后兼容: 旧指令无 sl_basis → 默认 atr → 走原逻辑

## 审计 SQL 模板

```sql
-- 对比 plan SL vs actual SL (DA- trades)
SELECT tr.symbol, tr.direction,
       pi.entry_price as plan_entry, pi.stop_loss as plan_sl,
       tr.entry_price as actual_entry,
       json_extract(tr.metadata_json, '$.stop_loss') as actual_sl
FROM trade_records tr
JOIN playbook_instructions pi
  ON json_extract(tr.metadata_json, '$.playbook_instruction_id') = pi.id
WHERE tr.source_type = 'PLAYBOOK_SIM' AND pi.decision_id LIKE 'DA-%'
ORDER BY tr.id DESC;

-- MFE 分布
SELECT CASE WHEN mfe_pct = 0 THEN 'zero'
            WHEN mfe_pct < 0.5 THEN '<0.5%'
            WHEN mfe_pct < 1.0 THEN '0.5-1%'
            WHEN mfe_pct < 2.0 THEN '1-2%'
            ELSE '>2%' END as mfe_bucket,
       COUNT(*), AVG(realized_pnl) as avg_pnl
FROM trade_records WHERE source_type = 'PLAYBOOK_SIM'
GROUP BY mfe_bucket;

-- Breakeven 影响
SELECT json_extract(metadata_json, '$.breakeven_triggered') as be,
       COUNT(*), AVG(realized_pnl) as avg_pnl
FROM trade_records WHERE source_type = 'PLAYBOOK_SIM'
GROUP BY be;
```
