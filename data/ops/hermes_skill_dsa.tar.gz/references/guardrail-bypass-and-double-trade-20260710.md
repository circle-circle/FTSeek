# 7/10 全链路审计: guardrail 空过 + 双重 trade_record + None穿透

## Date: 2026-07-10

## Status: 全部已修复 (pipeline.py + position_exit_monitor.py + shadow_tracker.py), 服务已重启验证

## Background
7/9 首次实盘运行 deep_analysis bridge → auto_execute 链路。NVDA 成交(1股, fill=0→quote_fallback)。
3条 trade_records 产生: 1036(TTE, POSITION_SYNC), 1037(NVDA, PLAYBOOK_SIM), 1038(NVDA, MAIN_PIPELINE)。

## Bug1: position_size=None 穿透 guardrail ✅ Fixed

### Root Cause
```
BridgeVotingAdapter 直写 DB → position_size=NULL (设计如此, re-price 时兜底计算)
auto_execute L2329: _size = inst.get("position_size") or 0  → None or 0 → 0
L2331: _new_notional = 0 (因为 _size=0)
L2332: if _bp_limit > 0 and (_max_deploy + 0) > _bp_limit  → 永远不触发
L2341: if _today_opened_notional + 0 > _daily_notional_cap  → 永远不触发
→ guardrail 全部空过, 无限仓位理论上可开
```

### Why re-price doesn't fix this
re-price 段 (L2281-2300) 在 guardrail 检查 **之前** 执行, 计算结果存入 `_reprice_params`。
但 guardrail 读的是 `inst.get("position_size")` 而非 `_reprice_params.get("position_size")`。
re-price 计算了正确的 size, guardrail 却没用它。

### Fix (pipeline.py L2328-2337, +6行)
```python
# Before:
_entry = inst.get("entry_price") or 0.0
_size = inst.get("position_size") or 0

# After:
if _reprice_params and _reprice_params.get("position_size"):
    _entry = _reprice_params.get("entry_price") or 0.0
    _size = _reprice_params.get("position_size") or 0
else:
    _entry = inst.get("entry_price") or 0.0
    _size = inst.get("position_size") or 0
```

### General Pattern
**guardrail/limit 检查必须读"消费时的实际值"而非"DB 原始值"**, 特别是当有 re-price/transform 步骤在检查之前执行时。DB 原始值可能为 NULL 或 stale, 而消费时的 reprice_params 是最终生效值。

---

## Bug2: exit_monitor fallback 'main' 劫持 playbook 仓位 → 双重 trade_record ✅ Fixed

### Symptom
NVDA 产生 2 条 trade_records:
- 1037: PLAYBOOK_SIM, DA- decision, BROKER_GHOST_CLOSE, entry=201.92
- 1038: MAIN_PIPELINE, DEC- decision, PRE_CLOSE_EXIT, entry=201.96

### Root Cause Chain
```
1. 启动: NVDA 是9只注入持仓之一 (trade_records.json → daily_active_pool → PositionStore)
   → 内存 Position.owner_strategy=None (注入时不设)
2. 11:57 ET: playbook auto_execute 开 NVDA
   → playbook_service.upsert_position_simple(owner_strategy='playbook_sim')
   → open_positions DB: owner_strategy='playbook_sim' ✅
   → 但内存 Position 对象仍是旧的, owner_strategy=None
3. position_sync 30s 轮询: 检测到 NVDA 在 broker
   → 查 trade_records 有 PLAYBOOK_SIM → 跳过 ✅
   → 但内存 Position 仍未更新 owner_strategy
4. exit_monitor 扫描内存 Position:
   → owner_strategy=None → fallback 设为 'main' (L870)
   → 不匹配 playbook skip check (L799: _pb_owner in ('playbook_sim',...))
   → exit_monitor 接管 NVDA, 用 DEC- decision (voting_predictions 04:17 ET 生成)
5. 15:59 ET: exit_monitor PRE_CLOSE_EXIT 平仓 → trade_record 1038 (MAIN_PIPELINE)
   同时: monitor_playbook_sim_exits 也在平仓 → trade_record 1037 (PLAYBOOK_SIM)
```

### Why this is hard to catch
- open_positions DB 有正确的 owner_strategy='playbook_sim'
- position_sync 正确跳过了 playbook 仓位
- 但内存 Position 对象(从启动注入)从未被更新
- exit_monitor 扫描的是内存 Position, 不是 DB open_positions
- 日志 `[策略隔离·兜底]` 是 WARNING 级别, 容易被忽略

### Fix (position_exit_monitor.py L863-889, +18行)
```python
# Before: fallback 无条件设 'main'
position.owner_strategy = "main"

# After: 查 trade_records 是否有未平仓 PLAYBOOK_SIM, 是则设 'playbook_sim'
_fallback_owner = "main"
_pb_row = _pc.execute(
    "SELECT 1 FROM trade_records WHERE symbol=? AND source_type='PLAYBOOK_SIM' "
    "AND (exit_price = 0 OR exit_price IS NULL OR exit_time = '' OR exit_time IS NULL) LIMIT 1",
    (symbol,)
).fetchone()
if _pb_row:
    _fallback_owner = "playbook_sim"
position.owner_strategy = _fallback_owner
```

### General Pattern
**内存与DB双轨制的责任链断裂**: 当 Position 对象在内存中创建后不被更新, 而 DB 有正确的字段值, 所有依赖内存 Position 的消费者(exit_monitor)都会用 stale 值。修复方式: 要么在内存 Position 创建时设正确字段, 要么在消费时 fallback 查 DB。前者改动大(需改注入逻辑), 后者是 surgical 单点修复。

---

## Bug3: shadow_tracker NoneType TypeError ✅ Fixed

### Log
```
ERROR: Error tracking US.NVDA: '>' not supported between instances of 'NoneType' and 'int'
```

### Root Cause
```python
# shadow_tracker.py L185:
position_size = inst.get("position_size", 0)  # DB value=None → returns None, NOT 0!
# L186:
if exit_price > 0 and position_size > 0:  # None > 0 → TypeError!
```

### Why .get(key, default) returns None
Python dict.get(key, default) only returns default when key is **absent**.
When key exists with value=None, it returns None.
DB column position_size is NULL → sqlite3 returns None → dict has key='position_size' with value=None.

### Fix (applied 2026-07-10)
3处 `inst.get("position_size", 0)` → `inst.get("position_size") or 0`:
- L185, L210 (had bug), L150 (ma20 same pattern)
- L295, L498 already had `or` guard, no change needed

### General Pattern
`inst.get(key) or default` is safer than `inst.get(key, default)` for DB-sourced dicts.
The `or` form converts None→default. The `.get(key, default)` form doesn't.

---

## DB+Log Evidence Summary

### playbook_instructions (7/9)
| id | symbol | dir | entry | SL | conf | exec | trig | ps | dec_id |
|----|--------|-----|-------|----|------|------|------|----|----|
| 586 | NVDA | BUY | 201.96 | 192.87 | 70 | 1 | 1 | None | DA-... |
| 587 | PSX | BUY | 178.98 | 172.0 | 70 | 0 | 0 | None | DA-... |
| 588 | TTE | BUY | 78.57 | 76.08 | 70 | 1 | 0 | None | DA-... |
| 589 | VLO | BUY | 281.46 | 268.8 | 60 | 0 | 0 | None | DA-... |
| 590 | MPC | BUY | 265.0 | 248.32 | 60 | 0 | 0 | None | DA-... |

All position_size=None (bridge直写DB).

### trade_records (7/9)
| id | symbol | entry | exit | src | dec_id | reason |
|----|--------|-------|------|-----|--------|--------|
| 1036 | TTE | 78.54 | 78.47 | POSITION_SYNC | - | external_close |
| 1037 | NVDA | 201.92 | 202.71 | PLAYBOOK_SIM | DA-... | BROKER_GHOST_CLOSE |
| 1038 | NVDA | 201.96 | 202.83 | MAIN_PIPELINE | DEC-... | PRE_CLOSE_EXIT |

### auto_execute timeline
| Time(ET) | Event |
|----------|-------|
| 09:43 | Run1: 5 inst, PSX/VLO/MPC gap>5% skipped (old code), 0 executed |
| 10:08 | Run2: same, 0 executed |
| 10:29 | Run3: "不利方向gap" (patched code), 0 executed |
| 11:56 | Run4: NVDA triggered+executed, VLO conf=60<70 skipped |

### Key log lines
```
21:43:02 [playbook] 查询当日已开仓失败, 从0开始: name '_today' is not defined  ← Bug4 (已修)
23:57:06 [playbook] re-price: US.NVDA BUY 盘前=$201.42 → 实时=$201.96 SL=192.87
23:57:08 [DualBroker] 下单成功: US.NVDA LONG qty=1 env=sim fill=0.0  ← fill=0
23:57:09 [playbook] 成交价=0, 用实时报价$201.92兜底记账 src=quote_fallback
00:56:10 (07/10 CST) [策略隔离·兜底] US.NVDA owner_strategy 为空, 默认赋值 'main'  ← Bug2
03:59:14 (07/10 CST) [平仓] US.NVDA reason=PRE_CLOSE_EXIT PnL=$0.87  ← trade 1038
```

## Verification
```
语法: ✅ 3文件 py_compile PASS
导入: ✅ 3模块 import PASS
重启: ✅ systemctl restart ftseek-us → active, bridge加载4 candidates, 无error/traceback
```
