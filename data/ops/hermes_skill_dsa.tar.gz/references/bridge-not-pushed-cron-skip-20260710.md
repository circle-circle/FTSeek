# Bridge 未推送根因 — 2026-07-10

## 状态: 根因已定位, 手动触发补跑中

## 现象

7/10 美股盘前 bridge 计划没有推送。FTSeek 在交易时段全部 NullVotingAdapter (全SKIP)。

## 两个 cron job 的时序关系

| Job | Schedule (UTC+8) | ET | 作用 |
|-----|-----------------|-----|------|
| scan job (e0d574cc1a3c) | 0 18 * * 1-5 | 06:00 | 运行 pipeline.py, 生成 opportunity_scan_YYYYMMDD.json |
| bridge-gen job (13dde1f65703) | 0 21 * * 1-5 | 09:00 | 同样运行 pipeline.py + 钉钉推送 |

## 根因: 三个问题叠加

### 问题1: bridge-generation cron job 跳过 7/10

```
Job: deep-analysis-bridge-generation (13dde1f65703)
Schedule: 0 21 * * 1-5 (Mon-Fri 21:00 UTC+8 = 09:00 ET)
last_run: 2026-07-09T21:11 UTC+8 (Thursday) ✓
next_run: 2026-07-13T21:00 UTC+8 (Monday) ✗ 跳过了7/10(Friday)!
```

7/10 是周五, 在 `1-5` 范围内, 应该运行。但 scheduler 把 next_run_at 算成了 7/13 (周一)。这是 Hermes cron 调度器的 bug。

### 问题2: scan job 生成 bridge 但时间太晚

scan job 在 19:08 UTC+8 (07:08 ET) 生成了 `opportunity_scan_2026-07-10.json`。但 FTSeek 从 12:00 UTC+8 (00:00 ET) 就开始用 ET 日期查找 bridge 文件。7小时 gap 期间全部 NullVotingAdapter。

FTSeek 的 `_try_load_bridge()` (pipeline.py L387-398) 用 ET 日期查找:
```python
_today_str = datetime.now(_et_tz).strftime("%Y-%m-%d")
bridge_path = f"data/opportunity_scan_{_today_str}.json"
```

时间线:
```
12:00 UTC+8 (00:00 ET) → ET日期变07-10, FTSeek找07-10 bridge → 不存在
12:20 UTC+8 → "bridge文件不存在 → NullVotingAdapter" ❌
15:07 UTC+8 → "bridge文件不存在" ❌
19:08 UTC+8 (07:08 ET) → scan job生成07-10 bridge ✅ (但已错过盘前)
21:00 UTC+8 (09:00 ET) → bridge-gen cron应运行但跳过 ❌
```

### 问题3: 飞书 delivery 失败

两个 job 都有 `last_delivery_error = "99992402 field validation failed"`。即使 job 运行了, 飞书推送也失败。

## 手动触发

```bash
cd /root/.hermes/skills/deep-stock-analysis/scripts && \
/opt/ftseek/FTSeek-US/venv/bin/python3.11 pipeline.py \
  --mode full --market US --limit 15 --top 5 --synth llm \
  --symbols US.MSFT,US.AAPL,US.NVDA,US.META,US.AMZN,US.JPM,US.LMT,US.CRM,US.ORCL,US.LLY,US.UBER,US.COIN,US.TSLA,US.AVGO,US.MU \
  --format text
```

pipeline 运行约 15-20 分钟 (20只标的深度分析+2模型辩论)。
完成后覆盖 `opportunity_scan_2026-07-10.json` 并写 instruction 到 DB。

## 待修复

1. Hermes cron scheduler 跳过 7/10 的原因 (scheduler 侧 bug)
2. scan job 时间提前到 04:00 UTC+8 (16:00 ET 前一天), 确保 ET 00:00 时 bridge 已存在
3. 飞书 delivery 99992402 field validation error
