# 自我进化交易闭环架构

> v0.9 核心设计文档 — 2026-07-05

## 设计理念

用户原话："如何在美股市场利用最新最及时的资讯和信号筛选，选择合理的交易策略，并能控制风险，并能结合表现不断积累和迭代优化完善整个链路，形成独有的交易技能沉淀和完善，实现稳定收益完成并超越okr目标"

核心：不是一次性建好系统就完了——是**每天自动积累、持续迭代的进化系统**。跑得越久，memory越丰富，pattern识别越准，信号质量越高。

## 4个断点诊断（修复前）

```
当前： scan → analyze → adapter → FTSeek执行 → 退出 → ❌ 无复盘 → ❌ 无积累 → ❌ 无迭代
                                                              ↑         ↑         ↑
                                                            断点1      断点2     断点3

deep_analysis IC: 9条样本0回填 → 无法评估信号质量 → ❌ 无门禁(断点4)
```

## 3个新模块

### strategy_memory.py
- DB: `/opt/ftseek/FTSeek-US/data/strategy_memory.db`
- 3张表: pattern_memory / symbol_memory / lesson_log
- 写: `update_from_trade(trade)` — 盘后逐笔更新
- 读: `get_strategy_hint(symbol)` → `format_hint_for_prompt()` — 盘前注入LLM

### signal_gate.py
- `evaluate_signal(analysis)` → 6维评估 → PASS/WARN/BLOCK
- 关键修复: BUY→LONG方向映射（pattern_memory存LONG/SHORT不是BUY/SELL_SHORT）
- 策略推荐: 基于历史最赚退出方式推荐hold时长+exit方式+仓位大小

### feedback_loop.py
- `run_daily(date)` → 扫描当日交易→更新memory→提取教训→生成报告
- `run_backfill(days)` → 回填历史
- 4类教训: win_pattern / loss_pattern / symbol_insight / market_regime

## 数据流

```
盘前9:00:
  pipeline.py analyze → deep_analyzer._get_trade_experience()
    → strategy_memory.get_strategy_hint(symbol)
    → format_hint_for_prompt() → 注入llm_synth USER_PROMPT
  → LLM输出 → adapter → signal_gate.evaluate_signal()
    → PASS/WARN/BLOCK + 策略推荐
  → ic_writer写入signal_snapshots.db

盘后5:00:
  feedback_loop.py run_daily()
    → _get_today_trades() 从trade_records读当日已平仓
    → update_memory_from_trades() 逐笔更新strategy_memory.db
    → extract_lessons() 提取赢/亏pattern教训
    → save_lessons() 写入lesson_log
    → format_daily_report() 生成飞书Markdown报告
```

## 验证结果

### 7/2复盘报告
```
📊 2026-07-02 盘后复盘
交易: 10笔 | 6胜2负 | WR=60% | P&L: $331.13
🟢 AVGO SHORT +$169 EOD_FORCE_CLOSE 17.6h
🔴 UBER SHORT $-103 EOD_FORCE_CLOSE 17.1h
📝 教训: SHORT+EOD_FORCE_CLOSE赚$169(AVGO) / 亏$-103(UBER)
🧠 memory: 64pattern 92股票 148教训
  最赚: SHORT+DAY_TRADE_TP WR=100% PnL=$10786
  最亏: SHORT+BREAKEVEN_STOP PnL=$-6235
```

### NVDA signal_gate
```
decision: PASS | quality: 70
reasons:
  - 匹配赚钱pattern: LONG+TRAILING_STOP WR=50%
  - 匹配亏钱pattern: LONG+SL_ATR_STOP PnL=$-5474
  - 盈亏比7.4:1，良好
strategy: hold=mid(2-12h) exit=TRAILING_STOP size=normal
risks: 此方向+SL_ATR_STOP历史PnL=$-5474
```

## cron jobs

| 时间 | job_id | 职责 |
|------|--------|------|
| 9:00 CST 周一-五 | e0d574cc1a3c | 盘前scan→analyze→gate→IC写入 |
| 5:00 CST 周二-六 | 3a6c83bbd84c | 盘后feedback_loop→更新memory→推送报告 |
