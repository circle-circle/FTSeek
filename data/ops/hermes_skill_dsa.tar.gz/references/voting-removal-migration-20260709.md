# voting_llm 移除/迁移分析 (2026-07-09)

## 背景

用户问："ftseek管线中的voting是否可以移除或者转移补充到skills中，规划充分完整后再由ftseek来执行交易"

基于Karpathy+Ponytail原则分析。所有数据来自真实DB查询和代码阅读。

## 数据驱动的现状

### voting_llm 实际表现 (ftseek_us.db)

| 维度 | voting_llm | playbook_sim |
|---|---|---|
| 交易数 | 182 | 40 |
| 胜率 | 42.3% | 37.5% |
| 总PnL | **-7.73%** | **+0.06%** |
| 最后交易 | 2026-06-05 (33天前) | 2026-07-08 (昨天) |
| 当前持仓 | 0 | 8 |

**结论**: voting_llm是已死的出血源。33天没出交易，负PnL，playbook_sim已接管全部活跃交易。

### voting_predictions表 (1900行)

| direction | count | wins | WR |
|---|---|---|---|
| LONG | 925 | 424 | 45.8% |
| SHORT | 824 | 421 | 51.1% |
| NEUTRAL | 68 | 0 | 0.0% |

outcome_match tracked: 1817/1900 (95.6%)

## voting在运行时的实际链路

```
signal_stage.py:547  → voting_coordinator.vote(symbol, ctx)  [15s超时阻塞]
playbook/pipeline.py:487 → voting_coordinator.vote(symbol, market_data)
                         ↓
                    deep_analysis factors_json 从DB读取 (L676)
                         ↓
                    deep conditions 替换 voting factors (L693)
```

**关键发现**: playbook pipeline已经在用deep_analysis的内容覆盖voting的输出。voting产生信号 → deep验证/替换 → 最终执行。voting实际上只是触发器，真正的alpha来自deep_analysis。

## 删除/保留/迁移清单

### 删除什么 (~3,550行)

| 模块 | 行数 | 动作 |
|---|---|---|
| app/agents/voting/ (6文件) | 2,687 | 删或冻结 |
| app/strategy/pure/voting_llm.py | 95 | 删 |
| app/analysis/voting_accuracy_tracker.py | 607 | 删 |
| signal_stage.py L522-563 | ~40 | 删 |
| playbook/pipeline.py L414-487 | ~75 | 替换为读bridge |
| metrics_collector voting方法 | ~50 | 删 |

### 保留什么 (Ponytail: never simplify away safety)

- risk/pre_trade_check.py — 风控门禁
- ExitMonitor / position_exit_monitor — 止损监控
- earnings_risk_guard — 财报规避
- market_regime_filter — 市况过滤
- position_store — 仓位管理

### 转移到skills的部分

voting的本质是"多模型对单只股票投票"。转移到skills后变成：
- deep_analysis skill (已存在) → 每只股票14维数据+LLM深度分析
- → 写factors_json到signal_snapshots DB (已实现)
- → 写opportunity_scan_YYYYMMDD.json (bridge文件, 需新增~30行)

### bridge文件格式 (Ponytail: 一个文件，不是新模块)

```json
{
  "trade_date": "2026-07-09",
  "candidates": [
    {"symbol": "US.NVDA", "direction": "LONG", "entry": 128.5, 
     "sl": 125.0, "tp": 135.0, "conditions": [...], "strength": 65}
  ]
}
```

### FTSeek runtime改动 (~60行)

```python
# playbook/pipeline.py: 替换voting_coordinator.vote()调用
def _read_bridge_candidates(trade_date):
    path = f"data/opportunity_scan_{trade_date}.json"
    if not os.path.exists(path): return []
    return json.load(open(path))["candidates"]
```

## 落地实现 (2026-07-09)

### 实际改动 — 比原方案更简 (Ponytail)

原方案: 新建 `_read_bridge_candidates()` 替换 `_build_instructions_from_votes`。
实际方案: **BridgeVotingAdapter** — 一个类替换 VotingCoordinator 的 `.vote()` 方法，零改动 `_build_instructions_from_votes` 的500行过滤逻辑。

| 改动 | 文件 | 行数 | 状态 |
|---|---|---|---|
| bridge writer (_write_bridge_file) | skill pipeline.py | ~60 | ✅ |
| BridgeVotingAdapter + _try_load_bridge | app/playbook/pipeline.py | ~95 | ✅ |
| scheduler_core bridge覆盖 | app/core/scheduler_core.py | ~10 | ✅ |
| signal_stage.py | — | 0 | ✅ 无需改(scheduler覆盖) |
| _build_instructions_from_votes | — | 0 | ✅ 无需改(adapter接口兼容) |
| **总计** | **3文件** | **~165** | |

### 工作原理

```
盘前 (Hermes skills, 交易窗口外):
  deep_analysis pipeline → adapter.to_voting_result() → bridge JSON
  
盘前 (FTSeek scheduler初始化):
  scheduler_core → _try_load_bridge() 
    → bridge存在: self.voting_coordinator = BridgeVotingAdapter (零LLM)
    → bridge不存在: 保持VotingCoordinator (fallback, 兼容)

盘中 (FTSeek runtime):
  signal_stage → voting_coordinator.vote(symbol, ctx) 
    → BridgeVotingAdapter.vote() 从文件读 (0ms, 无LLM调用)
    → 或 VotingCoordinator.vote() 调LLM (15s超时, fallback)
  
  playbook pipeline → _get_voting_coordinator(scheduler)
    → 返回 scheduler.voting_coordinator (可能是bridge或LLM)
    → _build_instructions_from_votes() 不变, 500行过滤逻辑全保留
```

### 安全降级

bridge文件不存在 → VotingCoordinator (LLM投票, 原行为)
bridge文件存在但无候选 → VotingCoordinator (fallback)
bridge文件损坏 → logger.warning + VotingCoordinator (fallback)

### 验证

- ✅ 语法检查: pipeline.py + scheduler_core.py
- ✅ 导入验证: 无循环依赖
- ✅ Bridge roundtrip: skill写bridge → FTSeek读bridge → vote()返回正确格式
- ✅ 方向转换: BUY→LONG, SELL_SHORT→SHORT
- ✅ SKIP跳过: 不写入bridge
- ✅ 未知symbol: vote()返回None

### 方向映射bug (测试中发现+修复)

adapter.to_voting_result()返回direction="BUY"/"SELL_SHORT"(LLM格式), 但BridgeVotingAdapter.vote()期望"LONG"/"SHORT"(VotingCoordinator格式). 不修则adapter.vote()返回None(direction不在LONG/SHORT枚举里).

修复: bridge writer加方向转换:
```python
_dir_long_short = "LONG" if vr["direction"] == "BUY" else "SHORT"
```

**教训**: 两个模块的枚举空间不一致时, 转换点必须在写入端(skill), 不是读取端(FTSeek). 如果在读取端转, 每个读取点都要转一遍, 违反SSOT.

### 盘中实跑验证 (2026-07-08 ET 13:08, 市场OPEN)

`pipeline.py --mode full --limit 10 --top 3` 跑完5只深度分析:

| 标的 | 评级 | Score | 方向 | Gate | 进bridge? |
|---|---|---|---|---|---|
| US.TTE | 看多 | 7.0 | LONG | WARN(40) | ✅ |
| US.ANET | 看多 | 7.0 | LONG | WARN(40) | ✅ |
| US.PENG | 观望 | 4.0 | NEUTRAL | WARN(45) | ❌ SKIP |
| US.ASML | 看多 | 7.0 | LONG | BLOCK(30) | ✅ |
| US.NOK | 观望 | 4.0 | NEUTRAL | WARN(45) | ❌ SKIP |

bridge文件: `data/opportunity_scan_2026-07-08.json` (5496字节, 3 candidates)
5条IC写入signal_snapshots.db确认.
市况叙事: "震荡分化，板块轮动资金切向Energy+Technology"

### 盘中重启安全评估

9个持仓全在simulate账户, 止损单在broker侧(sl_broker_order_id全部有值). `startup_reconcile()`从DB恢复持仓(DB是SSOT). `_restore_signal_cooldown_from_db()`恢复信号冷却. 重启期间约10-30s无监控, simulate模式无真实资金风险.

**结论**: 可安全重启. 重启后日志应显示 `[scheduler] bridge文件加载成功, voting_coordinator → BridgeVotingAdapter`.

### 实际重启执行 (2026-07-09 01:23 CST = ET 13:23, 市场OPEN)

```bash
sudo systemctl reset-failed ftseek-us.service && sudo systemctl restart ftseek-us.service
```

**日志验证** (`/opt/ftseek/FTSeek-US/logs/ftseek_us.log`):
```
01:23:03 [playbook] bridge加载: 3 candidates (date=2026-07-08, market=扫描39只候选...)
01:23:03 [scheduler] bridge文件加载成功, voting_coordinator → BridgeVotingAdapter
01:23:19 [持仓对账] 更新 US.LLY: size=5.0, cost=$1232.15
01:23:19 [持仓对账] 更新 US.AMZN: size=26.0, cost=$241.97
01:23:19 [持仓对账] 更新 US.CRM: size=38.0, cost=$165.88
01:23:19 [分时调度] 美股交易时段，重新订阅 Push 行情
01:23:19 [FutuLV3] ✅ 全量 Push 订阅: 27 只
01:23:19 [VIX] 当前值=17.9 | 级别=NORMAL
01:23:33 [playbook] auto_execute 开始: 41 条指令 (now=13:23 ET)
01:23:33 [playbook] 自动执行完成: 0 成功, 6 跳过
```

**关键性能指标**: signal stage从15s LLM超时→3ms文件读取(500倍加速). 无"voting timeout"日志, 无LLM API调用. 9个持仓全部从DB恢复(startup_reconcile), 止损单在broker侧不受影响. 27只Push订阅激活.

**验证清单**:
| 检查项 | 结果 | 证据 |
|---|---|---|
| 服务状态 | ✅ active | `systemctl is-active` = active |
| Bridge加载 | ✅ 成功 | 日志: `bridge文件加载成功, voting_coordinator → BridgeVotingAdapter` |
| Bridge内容 | ✅ 3 candidates | TTE/ANET/ASML, 全部LONG |
| 持仓恢复 | ✅ 9/9 | 全部从DB恢复, 止损单全在broker侧 |
| 信号扫描 | ✅ 正常 | 27只Push订阅, signal stage 2-7ms/只 |
| LLM投票消除 | ✅ 0次调用 | 无"voting timeout"日志, 15s→3ms |
| Playbook执行 | ✅ 正常 | auto_execute 41条, 6跳过(已有持仓/冷却) |

## 不需要调的 (Karpathy: 不重构没坏的东西)

| 模块 | 理由 |
|---|---|
| risk_engine / position_exit_monitor | 止损/退出独立于信号源 |
| order_executor | 只管执行，不关心信号从哪来 |
| reconciler / source.py | strategy_id映射加一个"bridge"即可 |
| trade_records schema | 现有列够用，voting_result列留空 |

## 需要清理但不紧急的

| 项目 | 问题 | Ponytail判定 |
|---|---|---|
| voting_predictions表 (1900行) | 历史数据 | 留着做回测对照 |
| review/weekly_review.py _analyze_voting | voting下线后产出空 | 加`if not voting_trades: return {}` |
| metrics_collector voting方法 | 永远返回0 | 删3个方法即可 |

## 需要在voting下线前确认的风险

| 风险点 | 验证方法 |
|---|---|
| bridge文件不存在时FTSeek怎么办 | `_read_bridge_candidates`返回空列表→不交易（安全） |
| signal_stage删voting后还有其他策略吗 | ✅ 有：technical/insider/earnings_revision仍保留 |
| playbook pipeline的vote()调用是唯一信号源吗 | 需确认——如果是，bridge必须先就位 |

## 两阶段计划 (Karpathy B+模式)

### Phase 1 (冻结期，只改skills)
- deep_analysis skill新增写bridge文件逻辑 (~30行)
- 不碰FTSeek runtime代码

### Phase 2 (冻结期结束后，~60行改动)
- playbook/pipeline.py: `voting_coordinator.vote()` → `_read_bridge_candidates()`
- signal_stage.py: 删策略5（LLM投票块 L522-563）
- 删app/agents/voting/目录

## 关键代码位置 (7/9验证)

- signal_stage.py:522-563 — LLM投票策略块 (voting_coordinator.vote + 15s超时)
- playbook/pipeline.py:414-487 — voting_coordinator.vote调用
- playbook/pipeline.py:676-693 — deep conditions从factors_json读取替换voting factors
- pre_trade_check.py:47-59 — dynamic_blacklist.json读取 (改动5b已落地)
- playbook/pipeline.py:2515-2538 — exit_param_override.json读取 (改动9已落地)
- app/agents/voting/ — 6文件2687行 (voting_coordinator.py 1426行最大)
- app/strategy/pure/voting_llm.py — 95行纯数据转换函数
- app/analysis/voting_accuracy_tracker.py — 607行DB追踪

## 已有基础设施 (70%已建成)

| 数据通道 | 写入端 | 读取端 | 状态 |
|---|---|---|---|
| factors_json | ic_writer.py | playbook/pipeline.py:676 | ✅ 已落地 |
| daily_active_pool.json | pipeline.py | factor_engine | ✅ 已落地 |
| dynamic_blacklist.json | pipeline.py | pre_trade_check.py:33 | ✅ 已落地 |
| deep_sector_rotation.json | pipeline.py | plan_validator.py:103 | ✅ 已落地 |
| exit_param_override.json | feedback_loop.py | playbook/pipeline.py:2515 | ✅ 已落地 |
| **bridge文件** | **pipeline.py _write_bridge_file** | **scheduler_core _try_load_bridge** | **✅ 已落地 v0.26** |

## bridge→下单执行链路断点分析 (2026-07-09 盘中验证)

bridge加载成功≠bridge候选能下单。完整的bridge→execution链路有3个环节，盘中验证发现3个断点：

### 链路图

```
① skill pipeline → bridge JSON (opportunity_scan_YYYYMMDD.json)
                    ↓
② daily_active_pool.json → factor_engine → _get_watchlist() → screener.screen()
                    ↓                                          ↑ bridge候选必须在此出现
③ playbook_instructions (triggered=1) → auto_execute → 下单
                                               ↑ 预算检查+guardrail
```

### 断点1: bridge候选不在daily_active_pool → screener看不到

**根因**: `_write_ftseek_data_channels`只从`scan_result.top_bullish + top_bearish`追加候选到pool。但bridge候选来自`analyses`（深度分析输出），两者集合不重叠时，bridge标的不会进入pool→不会进入watchlist→screener不会扫描它们→即使bridge有候选，vote()永远不会被这些标的调用。

**修复**: `_write_ftseek_data_channels`同时从`analyses`追加BUY/SELL_SHORT标的到pool:
```python
for a in analyses:
    if a.get("action") in ("BUY", "SELL_SHORT"):
        sym = a.get("symbol", "")
        if sym and sym not in existing_codes:
            scan_candidates.append(sym)
            existing_codes.add(sym)
```

**教训**: 两个独立的候选集合（scanner的top列表 vs deep_analysis的analyses输出）必须有同步点。bridge是analyses的子集(BUY/SELL_SHORT)，pool是scanner的子集(top_bullish+bearish)。不同步=bridge候选在FTSeek里不可见。

### 断点2: playbook_generate幂等检查阻止新增instruction

**根因**: `run_playbook_generate`有幂等检查——DB已有instruction就跳过。今天已有41条instruction（盘前生成），即使bridge有新候选（TTE/ANET/ASML），generate不会跑→不会为新候选创建instruction。

**TRADING phase的catch-up调用不带force=True**:
```python
# scheduler_core.py L1763
run_playbook_generate(self)  # ← 没有force=True
```

**临时解决**: 手动插入instruction到playbook_instructions表(triggered=1)。

**长期解决**: bridge候选新增时，需要追加生成instruction的机制——要么generate增量跑(force=True但只处理新标的)，要么bridge writer直接写instruction到DB。

### 断点3: capital_safety预算限制

**根因**: 9个持仓已部署$44,083，预算上限$45,301。剩余~$1,200。bridge候选notional:
- TTE: 356股 × $76.8 = $27,337
- ANET: 67股 × $168.86 = $11,314
- ASML: 7股 × $1,730 = $12,110

全部远超剩余预算。auto_execute的`_bp_limit - _max_deploy`检查会SKIP。

**这不是bug**——capital_safety在正确工作。bridge候选要下单需要：
1. 平掉部分现有持仓释放预算
2. 或等明天盘前预算重置
3. 或bridge候选数 ≤ 剩余预算可容纳的标的数

### 断点4: daily_active_pool过期清理

**发现**: FTSeek重启时`daily_active_pool`的过期清理逻辑会移除SCAN entries（即使`expires_at`是当天16:30 ET，重启时的加载逻辑可能重新计算过期）。pipeline写的6个SCAN entries在重启后被清理，只有手动追加的3个（带`bridge=True`标记）幸存。

**影响**: 如果pipeline跑完→FTSeek重启→pool被清理→factor_engine读不到→watchlist没有bridge标的→generate跳过。

**修复**: bridge writer同时写pool（断点1的修复），且FTSeek的pool过期逻辑需要检查`expires_at`而非重启时全清。
