# v0.23 多渠道扫描实施记录

> 2026-07-08 session. agent-debate DEB-20260708收敛后Phase 1实施.

## 实施内容

### data_collector.py 新增3个collect函数

1. **collect_earnings_surprise(market, limit)**: Finnhub /calendar/earnings, 取今日+昨日财报, 计算EPS超预期% = (actual - estimate) / |estimate| * 100. 按surprise绝对值排序.
2. **collect_insider_movers(market, limit)**: 占位. Finnhub免费版无全市场insider API, 返回空. 付费版可扩展.
3. **collect_after_hours_movers(market, limit)**: 复用富途get_stock_filter(change_rate排序), 标注_source=after_hours.

### market_scanner.py 新增6个方法

#### _collect_multi_channel() → {candidates, data_quality}
6渠道: gainers + losers + volume + earnings_surprise + insider_movers + after_hours.
合并去重时记录`_channels`列表(每只股票命中了哪些渠道).
data_quality含channels_green/channels_empty/raw_count.

#### _quality_gate(candidates) → filtered
- 非杠杆ETF: TQQQ/SQQQ/SOXL/SPY/QQQ等30+前缀
- 价格>$5
- 市值>$2B(富途market_val单位人民币, 14e9≈$2B)

#### _four_signal_score(symbol, base_data) → result
替代旧_quick_score. 4个0-10信号:

| 信号 | 数据来源 | 评分逻辑 |
|------|---------|---------|
| catalyst | 渠道命中+财报超预期 | earnings_surprise surprise>20%→+3, >5%→+1.5; after_hours→+1; insider→+1; 多渠道≥3→+1 |
| momentum | K线MA/动量/量比 | 多头排列→+3, 空头排列→-3, 5日>10%→+1.5, 放量2x→+1 |
| sentiment | bid_ask_ratio+vol_ratio | bid_ask>1.5→+1.5(买盘), <0.5→-1.5(卖盘), vol>2x→+1 |
| value | PE/52周位置 | PE<15→+3, PE>60→-1.5, 52周低<20%→+1.5, 高>90%→-1 |

综合分 = 均权(valid scores) + 渠道加成(每多一渠道+0.5) + 市值加减分 + 主流标的微加.

**featured override**: momentum≥8 → 即使综合分不够也标featured.
**value trap检测**: value≥7但5日跌>10% → value降到4.0, 重算综合分.

#### _collect_sector_data(scored) → {sector_changes, strongest, weakest, symbol_sectors}
11个SPDR ETF(XLK/XLF/XLE/...)涨跌排名 + 个股→Finnhub industry映射.
注意: 板块ETF涨跌用`(last_price - prev_close_price) / prev_close_price * 100`计算, 不依赖change_rate字段(见pitfall #48).

#### _sector_narrative(scored, sector_rotation) → str
5要素: ①方向定调(普涨/普跌/震荡/休市) ②涨跌极值个股 ③板块轮动叙事("资金切向X, 撤离Y") ④资金切换(多头/空头信号集中股) ⑤量能特征.

#### _bucketing(scored) → {bullish, bearish, watchlist, avoid}
5桶:

| 桶 | 条件 | strategy_type | position_size_hint |
|----|------|--------------|-------------------|
| 质地/突破 | score≥6 + momentum≥6 + 52w>30 | quality_breakout | normal |
| 超跌反弹 | score≥5.5 + 5日跌>10% + 52w<20 | oversold_bounce | small |
| 趋势空 | score≤4 + 空头排列 | trend_short | small |
| 回避 | 当日跌>5% + 5日跌>15% | avoid | none |
| 观望 | 其余 | watch | none |

## 验证结果 (32/32 ad-hoc)

- 语法+导入: PASS
- 3个collect函数存在: PASS
- 6个新方法存在: PASS
- _quality_gate正确过滤ETF/低价/低市值: PASS
- _bucketing正确分5桶: PASS
- 端到端scan: 12只候选, 5/6渠道green, signal_scores四键完整, sector_rotation非空: PASS

## change_rate bug发现+修复 (pitfall #48)

用户质疑"目前是美股正式交易阶段, change_rate=0是怎么判定的?" → 暴露bug:
- get_market_snapshot返回的列里没有change_rate字段
- 只有pre_change_rate/after_change_rate/overnight_change_rate
- 代码用row.get("change_rate")=None→0.0
- 修复: 用(last_price - prev_close_price) / prev_close_price * 100计算

修复前: 19只候选全0%, 板块轮动全0%, 叙事"休市/盘前无变动"
修复后: 17/19非零(NVDA +0.65%, PENG +16.5%, HELE -9.7%), 板块轮动11/11非零(Energy +2.1%)

## 与辩论收敛的关系

DEB-20260708辩论收敛到方案D+:
- Phase 1 (skill脚本, 冻结期): 多渠道采集+四信号评分 → 本次实施
- Phase 2 (运行时, 冻结期后): NEUTRAL fallback ~15行
- Phase 3 (条件触发): 数据驱动决定是否替代voting

本次实施 = Phase 1, 0行FTSeek运行时改动.
