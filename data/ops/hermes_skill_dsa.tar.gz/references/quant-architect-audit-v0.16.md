# 量化架构师审计：12隐患 + 修复决策 (v0.16→v0.17)

## 审计方法论

以量化和架构师视角逐模块读源码。不是泛泛看"有没有bug"，而是问三个问题：
1. **数据正确性**: 任何统计量(alpha/IC/胜率)的计算有没有前视偏差、生存偏差、或用错基准？
2. **分类稳定性**: claim_type之类的分类是靠硬编码关键词还是结构化标注？分类不稳则下游IC不可信。
3. **评分正交性**: Gate的加减分维度是否正交？重复惩罚会让同一风险被计算多次。

## 12个隐患 + 修复决策

### P0级（致命 — 动摇验证体系根基）

| # | 隐患 | 修复状态 | 盈利OKR影响 |
|---|------|---------|------------|
| 1 | Alpha IC前视偏差(offset=[0,1,-1]匹配未来SPY) | ✅ v0.17修 | alpha算错→claim IC不可信→反馈错误 |
| 2 | claim_type关键词分类(否定句/多信号误分类) | ✅ v0.17修 | 分类不稳→论据级IC根基不稳 |
| 3 | quality_score非正交加减分(重复惩罚) | ❌ 暂不修 | 等IC跑稳(30+样本)再重构 |
| 4 | pattern_memory全量累计(regime change被稀释) | ✅ v0.17修 | 老pattern误导Gate→用错退出方式 |

### P1级（影响分析质量）

| # | 隐患 | 修复状态 | 不修理由 |
|---|------|---------|---------|
| 5 | Finnhub无限流处理 | ❌ | 5只/批次=30次<60/分钟限制 |
| 6 | prompt超长(claim_ic注入479字符) | ❌ | 占比小，等实测注意力分散再优化 |
| 7 | WAL模式冲突 | ❌ | WAL幂等不会出错 |
| 8 | feedback_loop用CST日期 | ✅ v0.17修 | 复盘查错日期→教训缺失 |

### P2级（设计缺陷）

| # | 隐患 | 修复状态 | 不修理由 |
|---|------|---------|---------|
| 9 | cache非原子写入 | ❌ | cron和手动同时跑概率极低 |
| 10 | _CLAIM_NAME_MAP硬编码 | ❌ | 能work，等FTSeek更新再改 |
| 11 | 串行分析无限流 | ❌ | 5只串行300秒可接受 |
| 12 | 回退SQL用CST日期 | ✅ v0.17修 | 和#8一起修了 |

## 修复决策框架

**原则**: 只修直接影响盈利OKR链路的，不修间接/设计缺陷的。

盈利OKR链路: `信号质量 → Gate决策 → 是否执行 → 交易盈亏 → KR1胜率/KR2 P&L`

- P0-1(前视偏差): alpha算错→claim IC不可信→反馈错误 → **致命，必修**
- P0-2(分类): 分类不准→论据级IC根基不稳 → **致命，必修**
- P0-4(全量累计): 老regime稀释→Gate误推→用错退出方式 → **高，必修**
- P1-8(时区): 复盘查错日期→教训缺失 → **中，必修(2分钟)**
- 其余8个: 间接影响或低概率，等核心验证体系跑稳后再处理

## 4个修复详情

### 1. Alpha前视偏差 (alpha_backfill.py:229)
```python
# 修复前
for offset in [0, 1, -1]:  # offset=1匹配后一天=未来数据！

# 修复后
for offset in [0, -1, -2, -3]:  # 只用当天或之前交易日
```
验证: 916条重跑alpha，IC结果一致(offset=0命中，无偏差case触发)，但修复防止未来边界case。

### 2. claim_type分类 (llm_synth.py prompt + ic_writer.py)
- llm_synth prompt JSON schema加`claim_type`字段+11种枚举说明
- ic_writer._extract_claim_factors()优先用LLM标注的claim_type
- 加`_VALID_CLAIM_TYPES`枚举校验(12种)
- 加`llm_labeled`布尔标记标注来源
- fallback到`_classify_claim()`关键词推断(只在LLM没标注时)

验证: LLM标注=True走直取，=False走_classify_claim。两种路径都测过。

### 3. pattern_memory rolling window (strategy_memory.py:226-278)
```python
cutoff_30d = (datetime.now() - timedelta(days=30)).strftime("%Y-%m-%d")
# 赢pattern/亏pattern/退出效果查询都加:
WHERE last_trade_date >= ?
```
全量数据保留(供其他分析用)，但Gate决策只看30天rolling window。
验证: NVDA查询只返回30天内活跃pattern ✅

### 4. 时区修复 (feedback_loop.py + deep_analyzer.py)
- feedback_loop.run_daily() → 用_get_et_today()
- feedback_loop.run_backfill() → 用ET时区计算起始日期
- deep_analyzer._get_trade_experience()回退SQL → 用ET时区计算cutoff

验证: ET today=2026-07-05 ✅

**时区bug是反复出现的pattern**: v0.4的ic_writer、v0.12的feedback_loop、v0.16的deep_analyzer回退SQL。凡是`datetime.now()`生成日期用于查trade_records/signal_snapshots的地方，都要用ET时区。

## 审计方法论要点

1. **逐模块读全部源码** — 不只读改过的文件
2. **追数据流** — LLM输出→ic_writer→DB→alpha_backfill→claim_ic_cache→llm_synth→signal_gate，每个环节检查数据正确性
3. **问量化问题** — 前视偏差？分类稳定性？评分正交性？这是量化审计和普通code review的核心区别
4. **按OKR链路排优先级** — 不修不影响OKR的，集中精力修致命的
