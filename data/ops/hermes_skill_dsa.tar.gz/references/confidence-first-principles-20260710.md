# confidence 第一性原理分析 (2026-07-10)

## 第一性原理

confidence = P(trade profitable | signal)

唯一合法功能: 按预期盈利性排序信号。如果 confidence=0.9 胜率31%、confidence=0.6 胜率50%, 这个 metric 有害(排序反了)。

## 数据验证: 三个 confidence 系统, 零个有预测力

### 系统1: compute_confidence (PLAYBOOK_SIM 路径)
- **本质**: 数据维度ok数×12 + 条件验证×28, 封顶90 (instruction_generator.py)
- **数据**: n=45, confidence范围70-90, 唯一值=[70,72,76,88,90]
- **vs PnL 相关性**: r=-0.073 (零相关)
- **WR分布**: conf=90→31%WR(n=32), conf=72→50%WR(n=6)
- **根因**: 数据完整≠能赚钱。"90"是"6/6数据维度ok", 不是"LLM确信度90%"

### 系统2: LLM定性confidence (3模型voting_result内)
- **本质**: LLM自评 confidence 0.0-1.0
- **数据**: n=35, avg_model_conf range 0.15-0.80
- **vs PnL 相关性**: r=-0.211 (负相关, 比随机猜还差)
- **根因**: LLM没有校准锚点。说"高"时不知道对应多少实际胜率。无反馈闭环。

### 系统3: SignalQualityScorer (MAIN_PIPELINE 路径)
- **本质**: 5维市场微观结构(trend/momentum/volume/order_flow/market) + 60/40混合 + 历史胜率校准
- **数据**: n=41(非零), 但139/180笔conf=0.000(scorer未触发, 77%)
- **vs PnL 相关性**: r=-0.038
- **WR分布**: conf<0.3→80%WR, conf>0.7→0%WR (反相关!)
- **根因**: 5个factor列(f1_trend~f5_lifecycle)全是constant/0 → scorer从未正确记录维度数据。calibration文件0条交易 → 从未生效

### 唯一正相关信号: 模型一致度 (consensus)
- **vs PnL 相关性**: r=+0.102 (弱正)
- **WR分布**: 2/3 agree→33%WR, 3/3 agree→41%WR
- **结论**: 唯一有(弱)预测力的信号, 但n=35不显著

## 三个 confidence 系统的数据流

```
系统1 (compute_confidence, 数据质量):
  pipeline.py L1014: confidence = compute_confidence(data, conditions, factors)
  → 存入 Instruction.confidence → trade_records.signal_confidence
  → 用于: gate check(L1065, ≥70), 排序(L2162)
  → 问题: 数据完整时永远=90, 无区分度

系统2 (LLM confidence, 被丢弃):
  llm_synth.py: LLM输出 score(0-10) + confidence("高"/"中"/"低")
  → _merge_debate_results: 辩论调整confidence档位
  → adapter.py L174: "confidence": score/10.0 ← LLM定性confidence被丢弃!
  → bridge JSON: confidence = score/10
  → 问题: confidence=score/10是同义反复, 辩论调整完全失效

系统3 (SignalQualityScorer, 未触发):
  signal_stage.py: _apply_quality_scoring(ctx, candidate)
  → SignalQualityScorer.score(ctx, direction, strategy_confidence)
  → 5维评分 + 60/40混合 + 历史胜率校准
  → 问题: 77%交易conf=0.000, scorer几乎没触发; 5个factor列全constant
```

## 关键发现: pipeline.py L1014 覆盖了 bridge confidence

```python
# pipeline.py L1014 (修复前):
confidence = compute_confidence(data, decision["selected_conditions"], factors)
# 这行直接覆盖了bridge传来的LLM分析confidence!
# vote_result.final_confidence(来自bridge)被忽略
# trade_records.signal_confidence存的是数据质量分, 不是分析确信度
```

## 我之前的错误改法 (已回退)

```python
# 错误: 用LLM定性confidence作为核心
def _compute_confidence(analysis):
    conf_str = llm_out.get("confidence", "")  # "高"/"中高"/"中"/"中低"/"低"
    conf_map = {"高": 0.9, "中高": 0.8, "中": 0.6, "中低": 0.4, "低": 0.3}
    confidence = conf_map.get(conf_str, 0)  # LLM自评 → r=-0.211
    if debate: confidence += 0.10 or -0.15  # 辩论调整
    # 问题: 垃圾进垃圾出 — LLM自评无预测力, 调整后仍无预测力
```

## 最终方案: debate-only confidence

```python
# adapter.py (skill)
def _compute_confidence(analysis):
    confidence = 0.50  # 中性基准
    debate = llm_out.get("_debate", {})
    if debate:
        if chall_dir == orig_dir and agreed:
            confidence += 0.20  # 2模型一致 → 0.70 (通过gate)
        else:
            confidence -= 0.15  # 方向分歧 → 0.35 (BLOCKED)
    return max(0.10, min(0.95, confidence))

# pipeline.py (FTSeek) BridgeVotingAdapter.vote() — 同步逻辑
# pipeline.py (FTSeek) L1036-1048 — bridge候选用final_confidence*100
```

## 7/9 验证结果

4个bridge候选全部2模型分歧(analyst BUY vs challenger SKIP):
| symbol | 旧confidence | 新confidence | gate(≥70) |
|--------|------------|------------|-----------|
| PSX | 90 (数据完整) | 35 (分歧) | BLOCKED ✅ |
| TTE | 90 | 35 | BLOCKED ✅ |
| VLO | 90 | 35 | BLOCKED ✅ |
| MPC | 90 | 35 | BLOCKED ✅ |

之前conf=90全部通过是虚假的 — 2模型分歧的信号不该执行。

## 相关性分析SQL

```sql
-- PLAYBOOK_SIM confidence vs PnL
SELECT signal_confidence, COUNT(*), 
       SUM(CASE WHEN realized_pnl > 0 THEN 1 ELSE 0 END) as wins,
       ROUND(SUM(realized_pnl), 0) as total_pnl
FROM trade_records
WHERE source_type = 'PLAYBOOK_SIM' AND signal_confidence IS NOT NULL AND realized_pnl IS NOT NULL
GROUP BY ROUND(signal_confidence) ORDER BY signal_confidence DESC;

-- MAIN_PIPELINE confidence vs PnL (SignalQualityScorer path)
SELECT signal_confidence, COUNT(*),
       SUM(CASE WHEN realized_pnl > 0 THEN 1 ELSE 0 END) as wins
FROM trade_records
WHERE source_type = 'MAIN_PIPELINE' AND signal_confidence > 0 AND realized_pnl IS NOT NULL
GROUP BY ROUND(signal_confidence * 10) / 10;

-- Model consensus from voting_result
SELECT json_extract(voting_result, '$.qwen3.7_max.direction') as qwen_dir,
       json_extract(voting_result, '$.deepseek_v4_pro.direction') as ds_dir,
       json_extract(voting_result, '$.glm_5_2.direction') as glm_dir,
       realized_pnl
FROM trade_records
WHERE source_type = 'PLAYBOOK_SIM' AND voting_result IS NOT NULL AND realized_pnl IS NOT NULL;
```

## 验证命令

```bash
# 检查confidence分布
cd /opt/ftseek/FTSeek-US && venv/bin/python3.11 -c "
import sqlite3; conn = sqlite3.connect('data/ftseek_us.db')
rows = conn.execute('''SELECT signal_confidence, COUNT(*), 
    SUM(CASE WHEN realized_pnl > 0 THEN 1 ELSE 0 END) as wins
    FROM trade_records WHERE source_type='PLAYBOOK_SIM' 
    AND signal_confidence IS NOT NULL AND realized_pnl IS NOT NULL 
    GROUP BY ROUND(signal_confidence)''').fetchall()
for r in rows: print(f'conf={r[0]:.0f}: n={r[1]}, wins={r[2]}, WR={r[2]/r[1]*100:.0f}%')
"

# 检查bridge候选的debate结果
cat /opt/ftseek/FTSeek-US/data/opportunity_scan_$(date -u -d 'ET today' +%Y-%m-%d 2>/dev/null || date +%Y-%m-%d).json | python3 -m json.tool | grep -A5 debate_outcome
```

## 教训总结

1. LLM自评confidence没有校准锚点 — LLM说"高"时不知道"高"对应多少胜率
2. 垃圾进垃圾出 — 无预测力信号经过调整仍是无预测力的变体
3. Ponytail: 用唯一正相关信号(辩论), 不是用更复杂的合成
4. 真正预测信号(退出IC/claim IC/个股pattern)已存在, 只是不叫"confidence"
5. SignalQualityScorer的5个factor列全constant → 从未正确记录, 需验证其是否工作
6. confidence的所有值都有问题, 因为没有足够样本(n=35-45)建立校准
