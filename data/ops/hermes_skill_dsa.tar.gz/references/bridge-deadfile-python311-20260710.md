# Bridge JSON 死文件冲突 + Python 3.11 切换 (2026-07-10)

## Bridge JSON 死文件 (Ponytail+Karpathy分析)

### 冲突根因
- 路径A: deep_analysis skill → 写bridge JSON + **直写playbook_instructions DB**
- 路径B: FTSeek run_playbook_generate → 读bridge JSON → BridgeVotingAdapter.vote → save_instruction
- 路径A直写DB后, 路径B幂等检查发现DB已有指令 → 跳过生成
- → BridgeVotingAdapter.vote() **永远不被调用**
- → bridge JSON文件写了但FTSeek不消费 → **死文件**
- → BridgeVotingAdapter + _try_load_bridge + NullVotingAdapter 全是死代码

### 证据
- 7/9 bridge文件存在(21KB) 但7/10重启后scheduler日志"bridge不存在→NullVotingAdapter"
- 原因: ET日期=7/10, 找7/10的bridge → 不存在; 7/9的bridge只在7/9有效
- 5条BUY指令的raw.source=deep_analysis, decision_id=DA-20260709...

### 推荐: 删bridge中间人
- skill只写DB, 不写bridge JSON
- 删除 _try_load_bridge + BridgeVotingAdapter + NullVotingAdapter
- scheduler.voting_coordinator = None (有hasattr守卫)
- 2环节替代4环节: skill直写DB → auto_execute直读DB

## Python 3.8→3.11 切换 (FTSeek-US)

### 改动
- venv/bin/python symlink → python3.11, pyvenv.cfg version=3.8.17→3.11.15
- 补装24个缺失pip包(finnhub/openai/psutil/scipy/yfinance/peewee/lark-oapi/jinja2等)

### 兼容性验证
- 475/476模块import OK(唯一失败=review_api死代码需flask, 3.8下也缺)
- numpy 1.24→2.4, pandas 2.0→3.0: 无breaking change
- Futu SDK 10.05.6508: 功能测试通过
- 启动0 ERROR

### 回滚
- 备份: /opt/ftseek/backups/ftseek-us-code-20260710_111602.tar.gz
- pip freeze(3.8): /opt/ftseek/backups/pip_freeze_38_.txt
